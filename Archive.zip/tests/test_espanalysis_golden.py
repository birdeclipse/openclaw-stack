#!/usr/bin/env python3
"""Golden test: the ported ``espanalysis`` core against legacy-captured fixtures.

    python3 tests/test_espanalysis_golden.py [case_name ...]

Fixtures under ``tests/golden/espanalysis/`` were produced by
``capture_fixtures.py`` running the LEGACY implementation (see that file's
docstring). This runner feeds the identical deck trees to the port and requires
**byte-identical** output: all five rendered documents, the canonical model /
diagnostics / integrity bytes and their digests, the receipt counts, and -- for
the failure case -- the refusal reason and its one safe sentence.

**pydantic.** ``espanalysis.models`` is pydantic v2 (MIGRATION.md section 10.2),
so this file re-executes itself under ``uv run --with 'pydantic>=2,<3'`` when the
import is not already satisfiable. That is what makes the bare
``python3 tests/test_espanalysis_golden.py`` in the line above true on a machine
with no pydantic installed, and it is also why the CLI subprocesses below spawn
``sys.executable``: after the hop, that interpreter is the one that has pydantic.
A venv or system install short-circuits the hop entirely.

Three layers, on purpose:

* **Pure layer.** ``build_setup_deck_model`` plus the five renderers, driven by
  the same minimal reader the capture used, so a document diff is attributable
  to the pipeline and to nothing else.
* **Wire layer.** The same decks are analyzed through ``espanalysis/cli.py`` as a
  subprocess with JSON on stdin, against the REAL confined
  :class:`WorkRootSourceReader`. The five documents it lands on disk must equal
  the same goldens, which is what ties the ported reader to the oracle's bytes,
  and the exit-0-for-domain-refusal contract is under test rather than assumed.
* **Gate layer.** The citation gate has no legacy oracle here -- it lived in the
  toolbox shell, which is not ported -- so it is tested against its own three
  checks: at least one citation must be present, at least one must resolve, and
  a model-authored document never counts as evidence.

Failures print the first differing line (or byte offset) and the run exits 1.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
SHARED_ROOT = REPO_ROOT / "skill" / "circuit_setup" / "_shared"
CLI = SHARED_ROOT / "espanalysis" / "cli.py"
FIXTURE_ROOT = REPO_ROOT / "tests" / "golden" / "espanalysis"
CASES_ROOT = FIXTURE_ROOT / "cases"

#: Set on the re-exec so a missing ``uv`` or a broken environment cannot loop.
_BOOTSTRAP_FLAG = "ESPANALYSIS_GOLDEN_BOOTSTRAPPED"
_PYDANTIC_SPEC = "pydantic>=2,<3"


def _bootstrap() -> None:
    """Re-exec under ``uv run`` when pydantic is missing, exactly once."""

    try:
        import pydantic  # noqa: F401
    except ModuleNotFoundError:
        pass
    else:
        return
    if os.environ.get(_BOOTSTRAP_FLAG):
        raise SystemExit(
            f"pydantic is still unimportable after the {_PYDANTIC_SPEC} hop; "
            "install it into this interpreter or run under a venv that has it"
        )
    environment = dict(os.environ, **{_BOOTSTRAP_FLAG: "1"})
    try:
        completed = subprocess.run(
            ["uv", "run", "--with", _PYDANTIC_SPEC, str(Path(__file__).resolve()), *sys.argv[1:]],
            env=environment,
            check=False,
        )
    except FileNotFoundError as error:
        raise SystemExit(
            "espanalysis needs pydantic v2 and neither this interpreter nor `uv` "
            f"can provide it: pip install '{_PYDANTIC_SPEC}' ({error})"
        ) from error
    raise SystemExit(completed.returncode)


_bootstrap()

if str(SHARED_ROOT) not in sys.path:
    sys.path.insert(0, str(SHARED_ROOT))

import asyncio  # noqa: E402

from espanalysis.builder import (  # noqa: E402
    BuildFailure,
    BuildOutcome,
    build_setup_deck_model,
)
from espanalysis.reader import SourceError  # noqa: E402
from espanalysis.report.documents import (  # noqa: E402
    BOUNDARY_DOCUMENT_NAME,
    COMMANDS_DOCUMENT_NAME,
    DIAGNOSTICS_DOCUMENT_NAME,
    OVERVIEW_DOCUMENT_NAME,
    SOURCES_DOCUMENT_NAME,
    render_boundary_document,
    render_commands_document,
    render_diagnostics_document,
    render_overview_document,
    render_sources_document,
)

DOCUMENTS = (
    (OVERVIEW_DOCUMENT_NAME, render_overview_document),
    (DIAGNOSTICS_DOCUMENT_NAME, render_diagnostics_document),
    (SOURCES_DOCUMENT_NAME, render_sources_document),
    (COMMANDS_DOCUMENT_NAME, render_commands_document),
    (BOUNDARY_DOCUMENT_NAME, render_boundary_document),
)

#: Receipt field per document, in write order. Mirrors ``cli._DOCUMENTS``; held
#: separately so a receipt that silently renames a field is a failure here.
RECEIPT_FIELDS = (
    (OVERVIEW_DOCUMENT_NAME, "overview_path"),
    (DIAGNOSTICS_DOCUMENT_NAME, "diagnostics_path"),
    (SOURCES_DOCUMENT_NAME, "sources_path"),
    (COMMANDS_DOCUMENT_NAME, "commands_path"),
    (BOUNDARY_DOCUMENT_NAME, "boundary_path"),
)

RUN_ID = "gold1234"
PUBLISHED = f"work/{RUN_ID}/deck-analysis"


@dataclass(slots=True)
class Report:
    """Checks run and failures found."""

    checks: int = 0
    failures: list[str] = field(default_factory=list)

    def check(self, ok: bool, label: str, detail: str = "") -> bool:
        self.checks += 1
        if not ok:
            self.failures.append(f"{label}: {detail}" if detail else label)
        return ok

    def equal_bytes(self, actual: bytes, expected: bytes, label: str) -> bool:
        return self.check(actual == expected, label, _bytes_diff(actual, expected))

    def equal(self, actual: object, expected: object, label: str) -> bool:
        return self.check(actual == expected, label, f"expected {expected!r}, got {actual!r}")


def _bytes_diff(actual: bytes, expected: bytes) -> str:
    if actual == expected:
        return ""
    try:
        actual_lines = actual.decode("utf-8").splitlines()
        expected_lines = expected.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return f"{len(actual)} bytes vs {len(expected)} expected (not UTF-8)"
    for index, (left, right) in enumerate(zip(actual_lines, expected_lines), start=1):
        if left != right:
            return f"line {index}\n      got:      {left!r}\n      expected: {right!r}"
    if len(actual_lines) != len(expected_lines):
        longer, which = (
            (actual_lines, "extra")
            if len(actual_lines) > len(expected_lines)
            else (expected_lines, "missing")
        )
        index = min(len(actual_lines), len(expected_lines))
        return f"{which} line {index + 1}: {longer[index]!r}"
    return f"{len(actual)} bytes vs {len(expected)} expected (trailing newline?)"


@dataclass(frozen=True, slots=True)
class OracleRead:
    """Structurally a ``sources.SourceReadPayload``. Mirrors the capture's reader."""

    relative_path: str
    data: bytes
    digest: str


@dataclass(frozen=True, slots=True)
class OracleReader:
    """The pure layer's reader: right bytes, true digest, coded absence."""

    root: Path

    def read(self, relative_path: str, /) -> OracleRead:
        target = self.root / relative_path
        try:
            raw = target.read_bytes()
        except FileNotFoundError as error:
            raise SourceError(
                "not_found", "the named path does not exist under the work root"
            ) from error
        except OSError as error:
            raise SourceError("unreadable", "a source could not be read") from error
        return OracleRead(
            relative_path=relative_path,
            data=raw,
            digest=sha256(raw).hexdigest(),
        )


def call(verb: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Invoke one CLI verb. Refuses to tolerate a non-zero (harness-defect) exit."""

    completed = subprocess.run(
        [sys.executable, str(CLI), verb],
        input=json.dumps(arguments),
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(
            f"cli.py {verb} exited {completed.returncode} (domain refusals must exit 0)\n"
            f"stdout: {completed.stdout.strip()}\nstderr: {completed.stderr.strip()}"
        )
    payload = json.loads(completed.stdout)
    for key in ("ok", "message", "data", "refusal"):
        if key not in payload:
            raise AssertionError(f"cli.py {verb} result is missing {key!r}: {payload}")
    return payload


# ---- pure layer -------------------------------------------------------


def check_pure_build(case_dir: Path, report: Report) -> None:
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    entry_deck = str(case["entry_deck"])
    expected = case_dir / "expected"
    deck_root = (case_dir / "deck").resolve()
    label = case_dir.name

    if str(case["expect"]) == "failure":
        failure = json.loads((expected / "failure.json").read_text(encoding="utf-8"))
        try:
            asyncio.run(
                build_setup_deck_model(
                    entry_deck=entry_deck, reader=OracleReader(root=deck_root)
                )
            )
        except BuildFailure as error:
            reason = _failure_reason(error)
            report.equal(reason, failure["refusal"], f"{label} pure failure reason")
            return
        report.check(False, f"{label} pure build", "expected BuildFailure, got a model")
        return

    outcome = asyncio.run(
        build_setup_deck_model(entry_deck=entry_deck, reader=OracleReader(root=deck_root))
    )
    digests = json.loads((expected / "digests.json").read_text(encoding="utf-8"))
    for name, render in DOCUMENTS:
        report.equal_bytes(
            render(outcome).encode("utf-8"),
            (expected / name).read_bytes(),
            f"{label} pure {name}",
        )
    _check_digests(outcome, digests, f"{label} pure", report)


def _check_digests(
    outcome: BuildOutcome, digests: dict[str, Any], label: str, report: Report
) -> None:
    report.equal(outcome.model_digest, digests["model_digest"], f"{label} model digest")
    report.equal(
        outcome.diagnostics_digest, digests["diagnostics_digest"], f"{label} diagnostics digest"
    )
    report.equal(
        outcome.integrity_digest, digests["integrity_digest"], f"{label} integrity digest"
    )
    report.equal(
        sha256(outcome.model_bytes).hexdigest(),
        digests["model_bytes_sha256"],
        f"{label} canonical model bytes",
    )
    report.equal(
        sha256(outcome.diagnostics_bytes).hexdigest(),
        digests["diagnostics_bytes_sha256"],
        f"{label} canonical diagnostics bytes",
    )
    report.equal(
        sha256(outcome.integrity_bytes).hexdigest(),
        digests["integrity_bytes_sha256"],
        f"{label} canonical integrity bytes",
    )
    report.equal(
        len(outcome.model.sources), digests["source_count"], f"{label} source count"
    )
    report.equal(
        len(outcome.model.commands), digests["command_count"], f"{label} command count"
    )
    report.equal(
        [diagnostic.code for diagnostic in outcome.diagnostics.diagnostics],
        digests["diagnostic_codes"],
        f"{label} diagnostic codes",
    )
    report.equal(
        [bound.name for bound in outcome.integrity.bounds_reached],
        digests["bounds_reached"],
        f"{label} bounds reached",
    )
    selected = (
        outcome.model.hdl_structure.selected_top
        if outcome.model.hdl_structure is not None
        else None
    )
    report.equal(selected, digests["hdl_selected_top"], f"{label} hdl selected top")


def _failure_reason(error: BuildFailure) -> str:
    """The port's own cause-chain walk, re-implemented so the test is independent."""

    current: BaseException | None = error
    while current is not None:
        if isinstance(current, SourceError):
            return current.code
        current = current.__cause__
    return "build_failed"


# ---- wire layer -------------------------------------------------------


def check_wire_analyze(case_dir: Path, workdir: Path, report: Report) -> None:
    """Analyze the same deck through the CLI, against the REAL confined reader."""

    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    entry_deck = str(case["entry_deck"])
    expected = case_dir / "expected"
    label = case_dir.name
    # The deck tree is placed at the workdir root, so the entry deck path the
    # analyst would type is the path the fixture names.
    deck_target = workdir
    _copy_tree(case_dir / "deck", deck_target)

    result = call("analyze", {"workdir": str(workdir), "run": RUN_ID, "deck": entry_deck})

    if str(case["expect"]) == "failure":
        failure = json.loads((expected / "failure.json").read_text(encoding="utf-8"))
        report.equal(result["ok"], False, f"{label} wire refuses")
        report.equal(result["refusal"], failure["refusal"], f"{label} wire refusal code")
        report.equal(result["message"], failure["message"], f"{label} wire refusal message")
        report.check(
            entry_deck not in result["message"],
            f"{label} wire refusal does not echo the deck path",
            result["message"],
        )
        return

    if not report.check(bool(result["ok"]), f"{label} wire analyze", str(result)):
        return
    receipt = result["data"] or {}
    digests = json.loads((expected / "digests.json").read_text(encoding="utf-8"))
    for name, field_name in RECEIPT_FIELDS:
        report.equal(
            receipt.get(field_name), f"{PUBLISHED}/{name}", f"{label} receipt {field_name}"
        )
        report.equal_bytes(
            (workdir / PUBLISHED / name).read_bytes(),
            (expected / name).read_bytes(),
            f"{label} published {name}",
        )
    report.equal(receipt.get("entry_deck"), entry_deck, f"{label} receipt entry_deck")
    report.equal(
        receipt.get("source_count"), digests["source_count"], f"{label} receipt source_count"
    )
    report.equal(
        receipt.get("command_count"), digests["command_count"], f"{label} receipt command_count"
    )
    report.equal(
        receipt.get("diagnostic_counts"),
        digests["diagnostic_counts"],
        f"{label} receipt diagnostic_counts",
    )
    report.equal(
        receipt.get("bounds_reached"),
        digests["bounds_reached"],
        f"{label} receipt bounds_reached",
    )
    report.check(
        "model" not in receipt and "commands" not in receipt,
        f"{label} receipt carries pointers and counts, never the model",
        ", ".join(sorted(receipt)),
    )


def _copy_tree(source: Path, target: Path) -> None:
    for path in sorted(source.rglob("*")):
        if not path.is_file():
            continue
        destination = target / path.relative_to(source)
        destination.parent.mkdir(parents=True, exist_ok=True)
        _ = destination.write_bytes(path.read_bytes())


# ---- gate layer -------------------------------------------------------


def check_citation_gate(report: Report) -> None:
    """The three checks of the citation gate, plus at-least-one acceptance.

    No legacy oracle: the gate lived in ``deck_analysis_tools``, which is not
    ported. Its contract is what is asserted -- the D6 rule that attribution is
    verified and validity is not.
    """

    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        (workdir / "cfg").mkdir()
        _ = (workdir / "cfg" / "deck.tcl").write_text(
            "line one\nline two\nline three\n", encoding="utf-8"
        )
        published = workdir / PUBLISHED
        published.mkdir(parents=True)
        _ = (published / "report.md").write_text("# my own claim\n", encoding="utf-8")
        # A deck file whose BASENAME is report.md but whose relative path is not
        # one of the authored spellings is citable deck evidence: the gate
        # matches whole relative paths, never basenames.
        (workdir / "docs").mkdir()
        _ = (workdir / "docs" / "report.md").write_text(
            "vendor notes\nsecond line\n", encoding="utf-8"
        )

        def log(evidence: str, *, kind: str = "intent") -> dict[str, Any]:
            return call(
                "log_fact",
                {
                    "workdir": str(workdir),
                    "run": RUN_ID,
                    "kind": kind,
                    "subject": "the deck",
                    "statement": "a reading a scanner cannot make",
                    "evidence": evidence,
                },
            )

        no_citation = log("the author clearly meant to gate on reset")
        report.equal(no_citation["ok"], False, "gate: no citation refuses")
        report.equal(
            no_citation["refusal"], "fact_refused", "gate: no citation refusal code"
        )
        report.check(
            "at least one `path:line`" in no_citation["message"],
            "gate: no-citation message names the contract",
            no_citation["message"],
        )

        accepted = log('cfg/deck.tcl:2 "line two"')
        report.equal(accepted["ok"], True, "gate: a resolving citation is accepted")
        report.equal(
            (accepted["data"] or {}).get("kind"), "intent", "gate: accepted fact kind"
        )

        # At least ONE must resolve, not all: the prose ratio below reads as a
        # citation to the regex and must not sink a well-attributed fact.
        mixed = log('cfg/deck.tcl:1 shows the ratio is 3:2', kind="design")
        report.equal(mixed["ok"], True, "gate: one resolving citation is enough")

        past_end = log("cfg/deck.tcl:99 is not there", kind="concern")
        report.equal(past_end["ok"], False, "gate: a line past the end refuses")
        report.check(
            "past the end" in past_end["message"],
            "gate: past-the-end message",
            past_end["message"],
        )

        escaping = log("../../../etc/passwd:1 outside the root")
        report.equal(escaping["ok"], False, "gate: an escaping path refuses")
        report.check(
            "not readable under the work root" in escaping["message"],
            "gate: escaping-path message",
            escaping["message"],
        )

        # Every spelling of an authored document is refused. The bare name is in
        # the set because that is how a model writes the citation when it means
        # "the report I just wrote"; the `deck-analysis/` and full
        # `work/<run>/deck-analysis/` forms are how it writes the same citation
        # when it copies the receipt.
        for spelling in ("report.md", "review.md", "deck-analysis/report.md",
                         f"{PUBLISHED}/report.md", f"{PUBLISHED}/review.md"):
            authored = log(f"{spelling}:1 as I wrote earlier")
            report.equal(authored["ok"], False, f"gate: {spelling} is not evidence")
            report.check(
                "is a document this run authored" in authored["message"],
                f"gate: {spelling} circular-attribution message",
                authored["message"],
            )

        by_path = log('docs/report.md:2 "second line"')
        report.equal(
            by_path["ok"], True, "gate: docs/report.md is evidence (not matched by basename)"
        )

        # `origin` is pinned by the CLI (D5): no verb reads it, so a caller that
        # supplies one cannot claim its inference was parsed from a source.
        claimed = call(
            "log_fact",
            {
                "workdir": str(workdir),
                "run": RUN_ID,
                "kind": "intent",
                "subject": "origin",
                "statement": "pinned by code",
                "evidence": 'cfg/deck.tcl:3 "line three"',
                "origin": "parsed",
            },
        )
        report.equal(claimed["ok"], True, "gate: a fact logs with an ignored origin")
        report.check(
            "inferred" in claimed["message"],
            "gate: origin is pinned to inferred",
            claimed["message"],
        )

        # The reader kinds are a closed set: a wrapper bug is a refusal, never a
        # write into another skill's fact kind.
        wrong_kind = log('cfg/deck.tcl:1 "line one"', kind="verilog")
        report.equal(wrong_kind["ok"], False, "gate: a non-reader kind refuses")
        report.equal(wrong_kind["refusal"], "invalid_args", "gate: non-reader kind code")

        listed = call(
            "facts", {"workdir": str(workdir), "run": RUN_ID, "op": "list"}
        )
        report.equal(listed["ok"], True, "facts list")
        rows = (listed["data"] or {}).get("facts") or []
        report.equal(len(rows), 4, "facts list row count")
        report.check(
            all(row["kind"] in ("intent", "design", "concern") for row in rows),
            "facts list carries reader kinds only",
            str(rows),
        )

        bad_filter = call(
            "facts",
            {"workdir": str(workdir), "run": RUN_ID, "op": "list", "kind_filter": "pin"},
        )
        report.equal(bad_filter["ok"], False, "facts list refuses a non-reader filter")

        retracted = call(
            "facts",
            {
                "workdir": str(workdir),
                "run": RUN_ID,
                "op": "retract",
                "fact_id": rows[0]["fact_id"],
                "reason": "it was a transcription, not a reading",
            },
        )
        report.equal(retracted["ok"], True, "facts retract")
        huge = call(
            "facts",
            {
                "workdir": str(workdir),
                "run": RUN_ID,
                "op": "retract",
                "fact_id": "9" * 32,
            },
        )
        report.equal(huge["ok"], False, "facts retract bounds a 32-digit id")


def check_no_ledger(report: Report) -> None:
    """A read verb before any fact is a bounded refusal, not a crash."""

    with tempfile.TemporaryDirectory() as raw:
        result = call("facts", {"workdir": raw, "run": RUN_ID, "op": "list"})
        report.equal(result["refusal"], "no_ledger", "facts list without a ledger")


def check_run_root(report: Report) -> None:
    """``dir`` names the run root, resolved by the shared ``espdeck`` helper.

    The three CLIs write one ledger and publish under one root, so this verb
    family has to honour a chosen ``dir`` too -- otherwise a run analyzed under
    ``decks/t6`` would log its reader facts into ``work/<run>`` and the deck and
    cycle-plan skills would never see them. The documents' BYTES must not depend
    on where the root is, so they are compared against the same fixtures the
    default-root case uses.
    """

    case_dir = CASES_ROOT / "case_01_multi_file_deck"
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    entry_deck = str(case["entry_deck"])
    expected = case_dir / "expected"
    chosen = "decks/t6"
    published = f"{chosen}/deck-analysis"
    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        _copy_tree(case_dir / "deck", workdir)
        base = {"workdir": str(workdir), "run": RUN_ID, "dir": chosen}

        analyzed = call("analyze", {**base, "deck": entry_deck})
        if report.check(
            bool(analyzed["ok"]), "analyze under a chosen run root", str(analyzed)
        ):
            receipt = analyzed["data"] or {}
            for name, field_name in RECEIPT_FIELDS:
                report.equal(
                    receipt.get(field_name),
                    f"{published}/{name}",
                    f"receipt {field_name} names the chosen root",
                )
                report.equal_bytes(
                    (workdir / published / name).read_bytes(),
                    (expected / name).read_bytes(),
                    f"{name} under a chosen root is byte-identical to the default root's",
                )
        report.check(
            not (workdir / "work").exists(),
            "a chosen root writes nothing under work/",
        )

        logged = call(
            "log_fact",
            {
                **base,
                "kind": "intent",
                "subject": "the deck",
                "statement": "a reading a scanner cannot make",
                "evidence": f"{entry_deck}:1 names the entry point",
            },
        )
        report.check(bool(logged["ok"]), "log_fact under a chosen root", str(logged))
        report.check(
            (workdir / chosen / "facts.sqlite3").is_file(),
            "the shared ledger lives under the chosen root",
        )
        report.equal(
            [row["subject"] for row in call("facts", {**base, "op": "list"})["data"]["facts"]],
            ["the deck"],
            "facts list reads the chosen root",
        )
        # One run must be called with one dir; a wrong one needs no refusal code
        # of its own, because it finds no ledger.
        report.equal(
            call("facts", {**base, "dir": "decks/other", "op": "list"})["refusal"],
            "no_ledger",
            "a wrong dir finds no ledger rather than another run's",
        )
        report.equal(
            call("facts", {**base, "dir": "", "op": "list"})["refusal"],
            "no_ledger",
            "an omitted dir is the work/<run> default, never the last dir used",
        )
        for bad, why in (
            ("../escape", "a traversal"),
            ("decks/../../escape", "an interior traversal"),
            ("/etc", "an absolute path"),
            (f"{workdir.parent}/escape", "an absolute path beside the workdir"),
            (".hidden", "a leading dot"),
        ):
            report.equal(
                call("facts", {**base, "dir": bad, "op": "list"})["refusal"],
                "invalid_args",
                f"facts refuses {why} ({bad!r})",
            )
            report.equal(
                call("analyze", {**base, "dir": bad, "deck": entry_deck})["refusal"],
                "invalid_args",
                f"analyze refuses {why} ({bad!r})",
            )


def check_harness_defect(report: Report) -> None:
    """An unknown verb is a harness defect and must exit non-zero."""

    completed = subprocess.run(
        [sys.executable, str(CLI), "no_such_verb"],
        input="{}",
        capture_output=True,
        text=True,
        check=False,
    )
    report.check(
        completed.returncode != 0,
        "an unknown verb exits non-zero",
        f"exit {completed.returncode}",
    )


def check_empty_stdin(report: Report) -> None:
    """`echo '{}' | cli.py analyze` is a clean JSON refusal at exit 0."""

    result = call("analyze", {})
    report.equal(result["ok"], False, "empty analyze refuses")
    report.equal(result["refusal"], "build_failed", "empty analyze refusal code")


def check_no_esp_agent(report: Report) -> None:
    """The port must not reach back into the legacy package.

    A leading double-backtick plus the module name is stripped before the
    search, the same way ``test_espdeck_golden.check_no_esp_agent`` does it:
    a docstring naming the legacy module inside an RST literal is what makes a
    1:1 port reviewable as a diff against its oracle, and deleting the
    provenance to satisfy a substring search would cost the review and buy
    nothing. What must not exist is a live reference -- an import, a path, an
    attribute -- and outside a double-backtick literal is exactly where those
    live.
    """

    offenders = [
        str(path.relative_to(REPO_ROOT))
        for root in (REPO_ROOT / "skill", REPO_ROOT / "tool")
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.suffix in {".py", ".ts"}
        and "esp_agent"
        in path.read_text(encoding="utf-8", errors="replace").replace("``esp_agent", "")
    ]
    report.check(not offenders, "no esp_agent reference in skill/ or tool/", ", ".join(offenders))


def check_one_catalog(report: Report) -> None:
    """Exactly one copy of the reviewed catalog asset, in ``_shared/data/``."""

    copies = sorted(
        str(path.relative_to(REPO_ROOT))
        for path in (REPO_ROOT / "skill").rglob("esp_command_catalog_v1.json")
    )
    report.equal(
        copies,
        ["skill/circuit_setup/_shared/data/esp_command_catalog_v1.json"],
        "one catalog copy",
    )
    report.check(
        (
            REPO_ROOT
            / "skill/circuit_setup/_shared/data/esp_command_catalog_v1.provenance.json"
        ).is_file(),
        "catalog provenance sidecar ships beside it",
    )


def main(argv: list[str]) -> int:
    if not CLI.is_file():
        print(f"missing {CLI}", file=sys.stderr)
        return 1
    if not CASES_ROOT.is_dir():
        print(f"missing fixtures at {CASES_ROOT}", file=sys.stderr)
        return 1
    selected = set(argv)
    cases = [
        path
        for path in sorted(CASES_ROOT.iterdir())
        if (path / "input.json").is_file() and (not selected or path.name in selected)
    ]
    if not cases:
        print(f"no cases matched {argv or ['*']}", file=sys.stderr)
        return 1

    report = Report()
    for case_dir in cases:
        check_pure_build(case_dir, report)
        with tempfile.TemporaryDirectory() as raw:
            check_wire_analyze(case_dir, Path(raw), report)
        print(f"  ran {case_dir.name}")
    if not selected:
        check_citation_gate(report)
        check_no_ledger(report)
        check_run_root(report)
        check_harness_defect(report)
        check_empty_stdin(report)
        check_no_esp_agent(report)
        check_one_catalog(report)
        print("  ran cli gate checks")

    for failure in report.failures:
        print(f"FAIL {failure}")
    print(f"{report.checks} check(s), {len(report.failures)} failure(s)")
    return 1 if report.failures else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
