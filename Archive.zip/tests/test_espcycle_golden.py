#!/usr/bin/env python3
"""Golden test: the ``espcycle`` evidence core against its captured fixtures.

    python3 tests/test_espcycle_golden.py [case_name ...]

This runner feeds each case's fact-log sequence to the package and requires
**byte-identical** output for the two artefacts a survey publishes: the prepared
corpus and the corner roster.

**Provision, not gating.** There used to be a lot more here: gate and checker
finding sets with order-independent digests, coverage-prediction tables,
rendered ``plan.md`` bytes, three reconciliation documents, an admissibility
layer, and a check that ``plan_render`` re-ran the gates so the deterministic
authority could not be skipped. All of it is deleted with the layers it tested
(MIGRATION.md section 13.11). The reversal is deliberate and twice-earned:
legacy ADR 0037 concluded that a document loop beats a schema gate, and trial-2
live testing re-proved it when one buggy gate spun the planner for 27 turns
arguing with a checker. ``espcycle``'s surface is now EVIDENCE plus CORNER
LOGGING AND LOOKUP; ``plan.md`` is prose the planner agent authors from the
survey's Evidence catalog and the skill's ``guide.md``, and the quality check is
the interrogator's adversarial review of that document, not a checker's score.

So there is nothing left here that asserts a plan is good. What IS asserted is
that the evidence served to the planner is exact, complete, and byte-stable.

**Fixture provenance.** Every fixture in this suite is now a CONTRACT fixture.
Legacy had no fact-ledger intake -- ``survey`` read markdown and guessed a pin
table out of prose, and ADR 0043's amendment replaced that with ``pin`` /
``operation`` / ``plan_scalar`` rows in the shared Design Fact Ledger -- so
there is no oracle for ``PreparedCorpusV3``. ``expected/corpus.json``,
``expected/roster.json`` and ``expected/digests.json`` were captured from this
implementation and reviewed by a human who agreed they are right. A diff in
those files asks "is the new corpus correct?", not "does it match legacy?" --
and answering it means reading the corpus, not re-running
``capture_fixtures.py`` until the test passes.

**pydantic.** ``espcycle`` is pydantic v2 (MIGRATION.md section 10.2), so this
file re-executes itself under ``uv run --with 'pydantic>=2,<3'`` when the import
is not already satisfiable. That is what makes the bare
``python3 tests/test_espcycle_golden.py`` in the line above true on a machine
with no pydantic installed, and it is also why the CLI subprocesses below spawn
``sys.executable``: after the hop, that interpreter is the one that has
pydantic. A venv or system install short-circuits the hop entirely.

Six layers, on purpose:

* **Pure layer.** ledger -> ``corpus`` -> ``survey``, called in-process, so a
  byte diff is attributable to the projection and to nothing else.
* **Wire layer.** The same facts are logged through the REAL ``espdeck`` and
  ``espcycle`` CLIs as subprocesses with JSON on stdin -- one batched call per
  run of one kind, the same batches the in-process staging uses -- and the
  ``corpus.json`` the ``survey`` verb lands on disk must equal the same fixture.
  That is what proves the verb seam and the in-process projection agree (and
  that a batched call and a row-by-row call build the identical ledger), and the
  exit-0-for-domain-refusal contract is under test rather than assumed.
* **Intake layer.** The refusals and receipts that only exist because the corpus
  comes from a ledger: ``no_facts`` on an empty run, the duplicate-pin and
  duplicate-scalar ``corpus_rejected`` refusals, the ``plan_scalar`` value/name
  refusals at the log seam, the batch receipts, the all-or-nothing property of a
  refused batch, and the provenance path -- logging a fact after a survey moves
  the corpus digest, which is how a reader notices the ledger shifted under a
  plan already written.
* **Corner layer.** The corner-log/retract round trip on the shared ledger (the
  legacy toolbox shell is not ported), the open vocabulary's slug rule at the
  write seam, and its roster-sized bound.
* **Catalog layer.** Every inventory pin resolves as a ``pin:<NAME>`` entry in
  the Evidence catalog -- the citation menu, checked as a menu.
* **Wire-contract layer.** Run roots, the unknown-verb harness defect, the
  empty-payload refusal for each of the five verbs, and the no-``esp_agent``
  hygiene rule.

Failures print the first differing line (or byte offset) and the run exits 1.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
SHARED_ROOT = REPO_ROOT / "skill" / "circuit_setup" / "_shared"
CLI = SHARED_ROOT / "espcycle" / "cli.py"
DECK_CLI = SHARED_ROOT / "espdeck" / "cli.py"
FIXTURE_ROOT = REPO_ROOT / "tests" / "golden" / "espcycle"
CASES_ROOT = FIXTURE_ROOT / "cases"

#: Set on the re-exec so a missing ``uv`` or a broken environment cannot loop.
_BOOTSTRAP_FLAG = "ESPCYCLE_GOLDEN_BOOTSTRAPPED"
_PYDANTIC_SPEC = "pydantic>=2,<3"


def _bootstrap() -> None:
    """Re-exec under ``uv run`` when pydantic is missing, exactly once."""

    try:
        import pydantic  # noqa: F401
    except ModuleNotFoundError:
        pass
    else:
        return
    if os.environ.get(_BOOTSTRAP_FLAG):
        raise SystemExit(
            f"pydantic is still unimportable after the {_PYDANTIC_SPEC} hop; "
            "install it into this interpreter or run under a venv that has it"
        )
    environment = dict(os.environ, **{_BOOTSTRAP_FLAG: "1"})
    try:
        completed = subprocess.run(
            ["uv", "run", "--with", _PYDANTIC_SPEC, str(Path(__file__).resolve()), *sys.argv[1:]],
            env=environment,
            check=False,
        )
    except FileNotFoundError as error:
        raise SystemExit(
            "espcycle needs pydantic v2 and neither this interpreter nor `uv` "
            f"can provide it: pip install '{_PYDANTIC_SPEC}' ({error})"
        ) from error
    raise SystemExit(completed.returncode)


_bootstrap()

for _root in (str(SHARED_ROOT), str(FIXTURE_ROOT)):
    if _root not in sys.path:
        sys.path.insert(0, _root)

from espcycle.corpus import corpus_digest  # noqa: E402
from espcycle.models import CUSTOM_CORNER_CAP  # noqa: E402
from espcycle.survey import derive_corner_roster  # noqa: E402

# The staging + projection the fixtures are defined by. Shared with
# ``capture_fixtures.py`` rather than restated, so the runner and the capture
# cannot disagree about what a case IS; see that module's docstring.
from ledger_case import RUN_ID, fact_batches, prepare_case_corpus  # noqa: E402

PUBLISHED = f"work/{RUN_ID}/cycle-plans"


@dataclass(slots=True)
class Report:
    """Checks run and failures found."""

    checks: int = 0
    failures: list[str] = field(default_factory=list)

    def check(self, ok: bool, label: str, detail: str = "") -> bool:
        self.checks += 1
        if not ok:
            self.failures.append(f"{label}: {detail}" if detail else label)
        return ok

    def equal_bytes(self, actual: bytes, expected: bytes, label: str) -> bool:
        return self.check(actual == expected, label, _bytes_diff(actual, expected))

    def equal(self, actual: object, expected: object, label: str, note: str = "") -> bool:
        detail = f"expected {expected!r}, got {actual!r}"
        # A CLI refusal message is the only useful thing to print when a wire
        # verb answered `ok: false` where the fixture says it should not have.
        return self.check(actual == expected, label, f"{detail} ({note})" if note else detail)


def _bytes_diff(actual: bytes, expected: bytes) -> str:
    if actual == expected:
        return ""
    try:
        actual_lines = actual.decode("utf-8").splitlines()
        expected_lines = expected.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return f"{len(actual)} bytes vs {len(expected)} expected (not UTF-8)"
    for index, (left, right) in enumerate(zip(actual_lines, expected_lines), start=1):
        if left != right:
            return f"line {index}\n      got:      {left!r}\n      expected: {right!r}"
    if len(actual_lines) != len(expected_lines):
        longer, which = (
            (actual_lines, "extra")
            if len(actual_lines) > len(expected_lines)
            else (expected_lines, "missing")
        )
        index = min(len(actual_lines), len(expected_lines))
        return f"{which} line {index + 1}: {longer[index]!r}"
    return f"{len(actual)} bytes vs {len(expected)} expected (trailing newline?)"


def _run_cli(
    cli: Path, verb: str, arguments: dict[str, Any], cwd: Path | None = None
) -> dict[str, Any]:
    """Invoke one CLI verb. Refuses to tolerate a non-zero (harness-defect) exit."""

    completed = subprocess.run(
        [sys.executable, str(cli), verb],
        input=json.dumps(arguments),
        capture_output=True,
        text=True,
        check=False,
        cwd=cwd,
    )
    if completed.returncode != 0:
        raise AssertionError(
            f"{cli.parent.name}/cli.py {verb} exited {completed.returncode} "
            "(domain refusals must exit 0)\n"
            f"stdout: {completed.stdout.strip()}\nstderr: {completed.stderr.strip()}"
        )
    payload = json.loads(completed.stdout)
    for key in ("ok", "message", "data", "refusal"):
        if key not in payload:
            raise AssertionError(f"cli.py {verb} result is missing {key!r}: {payload}")
    return payload


def call(verb: str, arguments: dict[str, Any], cwd: Path | None = None) -> dict[str, Any]:
    """Invoke one ``espcycle`` verb."""

    return _run_cli(CLI, verb, arguments, cwd=cwd)


def deck_call(verb: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Invoke one ``espdeck`` verb. Pin facts are logged through the deck CLI.

    ``pin`` is ``setup.deck``'s kind and ``espcycle`` deliberately grew no verb
    to write it: the two skills share one pin inventory, so a second writer
    would be a second vocabulary for the same fact. Staging a case through the
    REAL deck CLI is what proves that sharing works end to end.
    """

    return _run_cli(DECK_CLI, verb, arguments)


# ---- shared case staging ----------------------------------------------


def _stage_wire(case: dict[str, Any], workdir: Path, dir_override: str = "") -> None:
    """Log the case's facts through the REAL CLI verbs, in fixture order.

    Deliberately NOT one loop over ``espdeck log``: routing ``operation``,
    ``plan_scalar`` and ``function_corner`` through ``espcycle``'s own verbs is
    what puts their receipt shape, their origin handling and their argument seam
    under test. Each run of one kind goes in as ONE batched call -- the batches
    ``ledger_case.fact_batches`` defines, shared so the two layers cannot drift
    -- and the resulting ledger must still be the one
    ``ledger_case.stage_ledger`` builds in-process, which the corpus byte
    comparison then proves.

    ``function_corner`` matters twice over: ``corner_log`` is the seam that
    slug-checks a name, and its rows reach the roster rather than the corpus, so
    staging them here is what makes the wire layer's certified selection
    comparable to the pure layer's.
    """

    base = {
        "workdir": str(workdir),
        "run": RUN_ID,
        "session": RUN_ID,
        "dir": dir_override,
    }
    for index, batch in enumerate(fact_batches(case), start=1):
        kind = str(batch[0]["kind"])
        if kind == "operation":
            result = call(
                "operation_log",
                {
                    **base,
                    "rows": [
                        {
                            **spec["fields"],
                            "evidence": spec["evidence"],
                            "origin": spec["origin"],
                        }
                        for spec in batch
                    ],
                },
            )
        elif kind == "plan_scalar":
            result = call(
                "scalar_log",
                {
                    **base,
                    "rows": [
                        {**spec["fields"], "evidence": spec["evidence"]} for spec in batch
                    ],
                },
            )
        elif kind == "function_corner":
            result = call(
                "corner_log",
                {
                    **base,
                    "rows": [
                        {**spec["fields"], "evidence": spec["evidence"]} for spec in batch
                    ],
                },
            )
        else:
            result = deck_call(
                "log",
                {
                    **base,
                    "kind": kind,
                    "facts": [
                        {
                            "fields": spec["fields"],
                            "evidence": spec["evidence"],
                            "origin": spec["origin"],
                        }
                        for spec in batch
                    ],
                },
            )
        if not result["ok"]:
            raise AssertionError(
                f"staging batch {index} ({len(batch)} x {kind}) failed: {result['message']}"
            )


def _expected_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


# ---- pure layer -------------------------------------------------------


def check_pure_case(case_dir: Path, report: Report) -> None:
    label = case_dir.name
    case = _expected_json(case_dir / "input.json")
    expected = case_dir / "expected"
    corpus, counts, custom_corners = prepare_case_corpus(case)
    roster = derive_corner_roster(corpus, custom_corners)

    report.equal_bytes(
        corpus.to_canonical_bytes(),
        (expected / "corpus.json").read_bytes(),
        f"{label} pure corpus bytes",
    )
    report.equal_bytes(
        roster.to_canonical_bytes(),
        (expected / "roster.json").read_bytes(),
        f"{label} pure roster bytes",
    )
    digests = _expected_json(expected / "digests.json")
    report.equal(corpus_digest(corpus), digests["corpus_digest"], f"{label} corpus digest")
    report.equal(
        list(roster.recommended),
        digests["recommended"],
        f"{label} certified selection",
    )
    report.equal(
        len(custom_corners),
        digests["custom_corner_count"],
        f"{label} custom corner count",
    )
    for field_name in ("pin_count", "operation_count", "scalar_count", "directive_count"):
        report.equal(counts[field_name], digests[field_name], f"{label} {field_name}")


# ---- wire layer -------------------------------------------------------


def check_wire_case(case_dir: Path, workdir: Path, report: Report) -> None:
    label = case_dir.name
    case = _expected_json(case_dir / "input.json")
    expected = case_dir / "expected"
    digests = _expected_json(expected / "digests.json")

    empty = call("survey", {"workdir": str(workdir), "run": RUN_ID})
    report.equal(
        empty["refusal"], "no_facts", f"{label} wire survey before any fact refuses no_facts"
    )
    report.check(
        not (workdir / "work" / RUN_ID / "facts.sqlite3").is_file(),
        f"{label} a refused survey leaves no ledger behind",
    )

    _stage_wire(case, workdir)

    survey = call(
        "survey",
        {
            "workdir": str(workdir),
            "run": RUN_ID,
            "directives": case.get("directives") or [],
            "user_prompt": case.get("user_prompt") or "",
        },
    )
    if not report.equal(survey["ok"], True, f"{label} wire survey", survey["message"][:200]):
        return
    data = survey["data"]
    report.equal(data["corpus_digest"], digests["corpus_digest"], f"{label} wire corpus digest")
    report.equal(data["recommended"], digests["recommended"], f"{label} wire certified selection")
    report.equal(
        data["corpus_path"], f"{PUBLISHED}/corpus.json", f"{label} wire corpus receipt path"
    )
    report.equal(
        data["survey_path"], f"{PUBLISHED}/survey.md", f"{label} wire survey receipt path"
    )
    for field_name in (
        "pin_count",
        "operation_count",
        "scalar_count",
        "directive_count",
        "custom_corner_count",
    ):
        report.equal(data[field_name], digests[field_name], f"{label} wire {field_name}")
    # The wire ledger was built by the CLI verbs; the fixture corpus was built
    # in-process by ``ledger_case``. Equal bytes is the proof that the verb seam
    # and the projection agree -- the check a hand-written mirror only pretended
    # to make.
    report.equal_bytes(
        (workdir / PUBLISHED / "corpus.json").read_bytes(),
        (expected / "corpus.json").read_bytes(),
        f"{label} wire corpus.json bytes",
    )
    report.check(
        (workdir / PUBLISHED / "survey.md").is_file(), f"{label} wire survey.md is published"
    )
    # ``survey.md`` has no byte fixture on purpose: it is a report over the
    # corpus bytes above, so pinning it would pin report prose. What must hold
    # is that the planner's two inputs are actually in the document -- the
    # provenance digest it cites in ``plan.md``, and the citation menu it quotes
    # from.
    report.check(
        digests["corpus_digest"] in survey["message"],
        f"{label} wire survey report carries the corpus digest",
    )
    report.check(
        "## Evidence catalog" in survey["message"],
        f"{label} wire survey report carries the evidence catalog",
    )
    report.check(
        "## Certified selection" in survey["message"],
        f"{label} wire survey report carries the certified selection",
    )
    # Nothing but the corpus and the report. ``<corner>/plan.md`` is the
    # planner's to write, so a survey that created a corner directory would be
    # this module claiming authorship it no longer has.
    report.equal(
        sorted(path.name for path in (workdir / PUBLISHED).iterdir()),
        ["corpus.json", "survey.md"],
        f"{label} survey publishes exactly the corpus and the report",
    )


# ---- intake layer -----------------------------------------------------


def _pin_row(name: str, direction: str) -> dict[str, Any]:
    """One well-formed ``pin`` row for an ``espdeck log`` batch."""

    return {
        "fields": {
            "pin_name": name,
            "direction": direction,
            "function_type": "generic",
            "allowed_values": "",
            "value": "",
        },
        "evidence": f"intake fixture: {name} is an {direction}",
        "origin": "parsed",
    }


def _pin_batch(*pins: tuple[str, str]) -> dict[str, Any]:
    """The ``espdeck log`` arguments that record every named pin in one call."""

    return {
        "kind": "pin",
        "facts": [_pin_row(name, direction) for name, direction in pins],
    }


def check_fact_intake(report: Report) -> None:
    """The refusals and receipts that exist only because the corpus is a ledger.

    No legacy oracle exists for any of this -- legacy ``survey`` read markdown
    (ADR 0043 amendment) -- so each behaviour is checked against the contract
    it was written to, not against captured bytes. The batch shapes are newer
    still, and the property that carries them is all-or-nothing: a refused
    ``rows`` call must leave the ledger exactly as it was, because a partly
    applied batch would leave the planner guessing which rows it still owes.
    """

    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        base = {"workdir": str(workdir), "run": RUN_ID, "session": RUN_ID}

        logged = call(
            "operation_log",
            {
                **base,
                "rows": [
                    {
                        "operation_name": "READ",
                        "pin_conditions": "CEN=L, GWEN=H",
                        "output_effect": "Q = mem[A]",
                        "evidence": "datasheet 4.1 truth table row READ",
                    }
                ],
            },
        )
        report.equal(logged["ok"], True, "operation_log accepts a full row")
        report.equal(logged["data"]["operation_count"], 1, "operation_log receipt counts the row")
        report.equal(logged["data"]["fact_ids"], [1], "operation_log receipt names the row's id")
        report.check(
            "1 on the truth table" in logged["message"],
            "operation_log receipt names the live operation count",
            logged["message"],
        )
        # ``origin`` is no longer a receipt field (a batch may carry a mix), so
        # the default is read back off the ledger row itself.
        stored = deck_call("list", {**base, "kind_filter": "operation"})
        report.check(
            "operation [parsed]" in stored["message"],
            "operation_log defaults origin to parsed",
            stored["message"],
        )
        blank = call(
            "operation_log",
            {
                **base,
                "rows": [
                    {
                        "operation_name": "STANDBY",
                        "pin_conditions": "CEN=H",
                        "output_effect": "",
                        "evidence": "datasheet 4.1 truth table row STANDBY",
                    }
                ],
            },
        )
        report.equal(
            blank["ok"], True, "operation_log accepts an omitted output_effect", blank["message"]
        )
        report.equal(blank["data"]["operation_count"], 2, "the second row is counted")
        report.equal(
            call(
                "operation_log",
                {
                    **base,
                    "rows": [
                        {
                            "operation_name": "X",
                            "pin_conditions": "y",
                            "evidence": "z",
                            "origin": "guessed",
                        }
                    ],
                },
            )["refusal"],
            "invalid_args",
            "operation_log refuses an origin outside the ledger vocabulary",
        )
        # All-or-nothing: the good first row of a refused batch is not stored.
        mixed = call(
            "operation_log",
            {
                **base,
                "rows": [
                    {
                        "operation_name": "WRITE",
                        "pin_conditions": "CEN=L, GWEN=L",
                        "output_effect": "mem[A] = D",
                        "evidence": "datasheet 4.1 truth table row WRITE",
                    },
                    {
                        "operation_name": "MYSTERY",
                        "pin_conditions": "CEN=L",
                        "evidence": "datasheet 4.1",
                        "origin": "guessed",
                    },
                ],
            },
        )
        report.equal(mixed["refusal"], "invalid_args", "one bad row refuses the whole batch")
        report.check(
            mixed["message"].startswith("rows[1]: "),
            "the batch refusal names the offending row by its argument index",
            mixed["message"],
        )
        report.equal(
            deck_call("list", {**base, "kind_filter": "operation"})["data"]["count"],
            2,
            "a refused operation batch logs nothing at all",
        )
        report.equal(
            call("operation_log", {**base, "rows": []})["refusal"],
            "invalid_args",
            "operation_log refuses an empty rows array",
        )

        scalar = call(
            "scalar_log",
            {
                **base,
                "rows": [
                    {
                        "name": "scan_chain_length",
                        # Leading zero on purpose: the ledger stores str(int(...)),
                        # so "02" and "2" must not become two facts with two
                        # digests. The receipt shows the STORED value.
                        "value": "02",
                        "statement": "scan chain length is 2",
                        "evidence": "user statement in session",
                    }
                ],
            },
        )
        report.equal(scalar["ok"], True, "scalar_log accepts a declared scalar")
        report.equal(scalar["data"]["scalar_count"], 1, "scalar_log receipt counts the scalar")
        report.check(
            "scan_chain_length = 2" in scalar["message"],
            "scalar_log canonicalizes the value and the receipt shows it",
            scalar["message"],
        )
        report.check(
            "1 scalar(s) declared" in scalar["message"],
            "scalar_log receipt names the live scalar count",
            scalar["message"],
        )
        for value, label in (("-1", "negative"), ("two", "non-numeric"), ("1.5", "fractional")):
            refused = call(
                "scalar_log",
                {
                    **base,
                    "rows": [
                        {
                            "name": "pipeline_depth",
                            "value": value,
                            "statement": "x",
                            "evidence": "y",
                        }
                    ],
                },
            )
            report.equal(
                refused["refusal"], "invalid_args", f"scalar_log refuses a {label} value"
            )
        report.equal(
            call(
                "scalar_log",
                {
                    **base,
                    "rows": [
                        {
                            "name": "clock_period",
                            "value": "1",
                            "statement": "x",
                            "evidence": "y",
                        }
                    ],
                },
            )["refusal"],
            "invalid_args",
            "scalar_log refuses a name outside the closed scalar vocabulary",
        )
        mixed_scalars = call(
            "scalar_log",
            {
                **base,
                "rows": [
                    {
                        "name": "reset_latency_cycles",
                        "value": "3",
                        "statement": "reset takes 3 cycles",
                        "evidence": "user statement in session",
                    },
                    {
                        "name": "pipeline_depth",
                        "value": "two",
                        "statement": "pipeline depth is two",
                        "evidence": "user statement in session",
                    },
                ],
            },
        )
        report.check(
            mixed_scalars["message"].startswith("rows[1]: "),
            "the scalar batch refusal names the offending row by index",
            mixed_scalars["message"],
        )
        report.equal(
            deck_call("list", {**base, "kind_filter": "plan_scalar"})["data"]["count"],
            1,
            "a refused scalar batch logs nothing at all",
        )

        # Operations and scalars alone are not a design: survey wants pins.
        report.equal(
            call("survey", {**base})["refusal"],
            "no_facts",
            "survey refuses a ledger with operations but no pin fact",
        )

        pinned = deck_call("log", {**base, **_pin_batch(("CLK", "input"), ("Q", "output"))})
        report.equal(
            pinned["ok"], True, "the shared deck CLI logs both pin facts in one batch"
        )
        report.equal(pinned["data"]["count"], 2, "the pin batch receipt counts both rows")
        surveyed = call("survey", {**base, "directives": ["verify the read"]})
        report.equal(surveyed["ok"], True, "survey accepts a pinned ledger", surveyed["message"])
        first_digest = surveyed["data"]["corpus_digest"]
        report.equal(surveyed["data"]["pin_count"], 2, "survey counts the pins")
        report.equal(surveyed["data"]["operation_count"], 2, "survey counts the operations")
        report.equal(surveyed["data"]["scalar_count"], 1, "survey counts the scalars")
        report.equal(surveyed["data"]["directive_count"], 1, "survey counts the directives")
        report.check(
            "| cycle_fact:0 |" in surveyed["message"],
            "the evidence catalog serves the operation refs back",
        )
        report.check(
            "also citable evidence as `pin:<NAME>`" in surveyed["message"],
            "the evidence catalog says how a pin is cited",
        )

        # Provenance: a fact logged after the survey moves the corpus digest.
        # Nothing refuses over it -- there is no freshness gate any more -- but
        # the digest in a published ``plan.md`` no longer matches the ledger,
        # which is exactly how a reader notices the evidence shifted underneath
        # a document that was already written.
        report.equal(
            deck_call("log", {**base, **_pin_batch(("CEN", "input"))})["ok"],
            True,
            "a pin can be logged after a survey",
        )
        resurveyed = call("survey", {**base, "directives": ["verify the read"]})
        report.equal(resurveyed["ok"], True, "the re-survey succeeds")
        report.check(
            resurveyed["data"]["corpus_digest"] != first_digest,
            "logging a fact after a survey changes the corpus digest",
        )

        # Duplicates: the deterministic layer refuses to pick a winner.
        report.equal(
            deck_call("log", {**base, **_pin_batch(("CLK", "inout"))})["ok"],
            True,
            "the ledger itself accepts a second CLK fact",
        )
        duplicated = call("survey", {**base})
        report.equal(
            duplicated["refusal"], "corpus_rejected", "a duplicate pin name refuses the corpus"
        )
        report.check(
            "fact_retract" in duplicated["message"],
            "the duplicate-pin refusal names the repair",
            duplicated["message"],
        )

    with tempfile.TemporaryDirectory() as raw:
        base = {"workdir": raw, "run": RUN_ID, "session": RUN_ID}
        deck_call("log", {**base, **_pin_batch(("CLK", "input"), ("Q", "output"))})
        # Two rows, one call, one name twice: the ledger records both because
        # neither row is malformed, and the corpus is where the contradiction is
        # refused. A batch does not merge them into one fact.
        report.equal(
            call(
                "scalar_log",
                {
                    **base,
                    "rows": [
                        {
                            "name": "pipeline_depth",
                            "value": value,
                            "statement": f"pipeline depth is {value}",
                            "evidence": "user statement in session",
                        }
                        for value in ("1", "3")
                    ],
                },
            )["data"]["scalar_count"],
            2,
            "the ledger itself accepts two pipeline_depth rows in one batch",
        )
        duplicated = call("survey", {**base})
        report.equal(
            duplicated["refusal"],
            "corpus_rejected",
            "a duplicate scalar name refuses the corpus",
        )
        report.check(
            "plan_scalar" in duplicated["message"] and "fact_retract" in duplicated["message"],
            "the duplicate-scalar refusal names the kind and the repair",
            duplicated["message"],
        )


# ---- corner layer -----------------------------------------------------


def check_corner_roster(report: Report) -> None:
    """The corner-log/retract round trip on the shared ``espdeck`` ledger.

    No legacy oracle: the semantics came from ``document_loop_tools``, whose
    toolbox shell is not ported, so the contract is tested directly. A
    retraction keeps the row and its reason, which is why a re-log of the same
    name is legal afterwards. ``corner_log`` batches; ``corner_retract`` stays
    single-id, because a retraction is a correction of one named row and its
    reason belongs to that row.
    """

    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        base = {"workdir": str(workdir), "run": RUN_ID}
        logged = call(
            "corner_log",
            {
                **base,
                "rows": [
                    {
                        "corner_name": "mission_write_read",
                        "statement": "verify a write followed by a read of the same address",
                        "evidence": "spec.md:24 — the truth table lists Read and Write",
                    }
                ],
            },
        )
        report.equal(logged["ok"], True, "corner_log accepts a safe name")
        report.equal(
            logged["data"]["roster"], ["mission_write_read"], "corner_log returns the live roster"
        )
        second = call(
            "corner_log",
            {
                **base,
                "rows": [
                    {
                        "corner_name": "scan_shift",
                        "statement": "verify the scan chain shifts the declared length",
                        "evidence": "spec.md:17 — SE is the shift enable",
                    }
                ],
            },
        )
        report.equal(
            second["data"]["roster"],
            ["mission_write_read", "scan_shift"],
            "corner_log appends in ledger order",
        )
        report.equal(
            (workdir / "work" / RUN_ID / "facts.sqlite3").is_file(),
            True,
            "the roster rides the shared espdeck ledger",
        )

        for bad in ("../escape", "with/slash", ".hidden", "-leading-dash", ""):
            refused = call(
                "corner_log",
                {
                    **base,
                    "rows": [{"corner_name": bad, "statement": "x", "evidence": "y"}],
                },
            )
            report.equal(
                refused["ok"], False, f"corner_log refuses the unsafe name {bad!r}"
            )
            report.equal(
                refused["refusal"], "invalid_args", f"corner_log refusal code for {bad!r}"
            )

        retracted = call(
            "corner_retract",
            {**base, "corner_name": "scan_shift", "reason": "no chain is fitted on this instance"},
        )
        report.equal(retracted["ok"], True, "corner_retract accepts a live corner")
        report.equal(
            retracted["data"]["roster"],
            ["mission_write_read"],
            "corner_retract drops it from the live roster",
        )
        again = call(
            "corner_retract",
            {**base, "corner_name": "scan_shift", "reason": "already gone"},
        )
        report.equal(
            again["refusal"], "unknown_corner", "corner_retract refuses a retracted corner"
        )
        listed = call(
            "corner_log",
            {
                **base,
                "rows": [
                    {
                        "corner_name": "scan_shift",
                        "statement": "the chain is fitted after all",
                        "evidence": "addendum.md:3",
                    }
                ],
            },
        )
        report.equal(
            listed["data"]["roster"],
            ["mission_write_read", "scan_shift"],
            "a retracted name can be re-logged; the retracted row stays",
        )
        batched = call(
            "corner_log",
            {
                **base,
                "rows": [
                    {
                        "corner_name": "low_power_retention",
                        "statement": "verify retention across a supply collapse",
                        "evidence": "spec.md:31",
                    },
                    {
                        "corner_name": "boundary_scan",
                        "statement": "verify the boundary chain",
                        "evidence": "spec.md:33",
                    },
                ],
            },
        )
        report.equal(
            batched["data"]["roster"],
            [
                "mission_write_read",
                "scan_shift",
                "low_power_retention",
                "boundary_scan",
            ],
            "one batched call appends every row, in row order",
        )
        report.equal(
            len(batched["data"]["fact_ids"]), 2, "the batch receipt names both new rows"
        )

    # An unsafe name anywhere in the batch refuses the batch AND leaves no store
    # behind: every row is slug-checked before the ledger is opened, which is the
    # ordering ``_rows``' docstring is about. A fresh workdir is the only way to
    # observe it.
    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        refused = call(
            "corner_log",
            {
                "workdir": str(workdir),
                "run": RUN_ID,
                "rows": [
                    {
                        "corner_name": "mission_write_read",
                        "statement": "verify a write followed by a read",
                        "evidence": "spec.md:24",
                    },
                    {
                        "corner_name": "../escape",
                        "statement": "verify the escape",
                        "evidence": "spec.md:99",
                    },
                ],
            },
        )
        report.equal(refused["refusal"], "invalid_args", "one unsafe row refuses the batch")
        report.check(
            refused["message"].startswith("rows[1]: "),
            "the unsafe-name refusal names the offending row by index",
            refused["message"],
        )
        report.equal(
            (workdir / "work" / RUN_ID / "facts.sqlite3").is_file(),
            False,
            "a refused corner batch leaves no ledger behind",
        )

    with tempfile.TemporaryDirectory() as raw:
        empty = call(
            "corner_retract",
            {"workdir": raw, "run": RUN_ID, "corner_name": "any", "reason": "why"},
        )
        report.equal(empty["refusal"], "no_ledger", "corner_retract without a ledger")


def check_custom_corner_bound(report: Report) -> None:
    """The open corner vocabulary is open, not unbounded.

    ``CornerRosterV1.entries`` holds ``CORNER_ROSTER_CAP`` corners, eight of
    which are the built-ins, so ``CUSTOM_CORNER_CAP`` custom names fit. Logging
    is deliberately unbounded (``corner_roster.roster``) -- what a design has is
    what it has -- so the bound belongs where the document is built. It must be
    a NAMED refusal that says the number and the repair, never a pydantic
    traceback out of ``derive_corner_roster``.
    """

    case = _expected_json(CASES_ROOT / "case_01_sram_mission_scan" / "input.json")
    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        base = {"workdir": str(workdir), "run": RUN_ID}
        _stage_wire(case, workdir)

        # Batched at 8 rows, well inside the corner_log transport bound.
        names = [f"declared-corner-{index:02d}" for index in range(CUSTOM_CORNER_CAP + 1)]

        def log_corners(batch: list[str]) -> bool:
            logged = call(
                "corner_log",
                {
                    **base,
                    "rows": [
                        {
                            "corner_name": name,
                            "statement": f"verify declared behaviour {name}",
                            "evidence": "spec.md:1",
                        }
                        for name in batch
                    ],
                },
            )
            if not logged["ok"]:
                report.check(False, "staging many corners", logged["message"][:200])
            return bool(logged["ok"])

        for start in range(0, CUSTOM_CORNER_CAP, 8):
            if not log_corners(names[start : start + 8]):
                return
        survey_arguments = {
            **base,
            "directives": case["directives"],
            "user_prompt": case["user_prompt"],
        }
        under = call("survey", survey_arguments)
        report.equal(
            under["ok"], True, f"{CUSTOM_CORNER_CAP} custom corners survey", under["message"][:200]
        )
        report.equal(
            under["data"]["custom_corner_count"],
            CUSTOM_CORNER_CAP,
            "the survey receipt counts every custom corner",
        )
        report.equal(
            _expected_json(workdir / PUBLISHED / "corpus.json").get("directives"),
            case["directives"],
            "corner facts are roster state, not corpus evidence",
        )

        if not log_corners(names[CUSTOM_CORNER_CAP:]):
            return
        over = call("survey", survey_arguments)
        report.equal(
            over["refusal"],
            "corpus_rejected",
            f"{CUSTOM_CORNER_CAP + 1} custom corners refuse the survey",
        )
        report.check(
            str(CUSTOM_CORNER_CAP) in over["message"] and "corner_retract" in over["message"],
            "the over-full refusal names the bound and the repair",
            over["message"][:240],
        )
        retracted = call(
            "corner_retract",
            {**base, "corner_name": names[-1], "reason": "not planning this one"},
        )
        report.equal(retracted["ok"], True, "corner_retract frees a roster slot")
        report.equal(
            call("survey", survey_arguments)["ok"],
            True,
            "the survey passes again once the roster is back inside the bound",
        )


# ---- catalog layer ----------------------------------------------------


def check_pin_evidence_refs(report: Report) -> None:
    """Every inventory pin is a resolvable ``pin:<NAME>`` entry on the menu.

    The Evidence catalog is a CITATION MENU, not a gate: nothing refuses a
    ``plan.md`` for quoting a ref, and nothing refuses one for quoting a bad
    ref either. What the catalog owes is completeness and resolvability -- every
    ref ``survey.md`` teaches must resolve, and a ref naming nothing must
    resolve to ``None`` so the reviewer reading the document can tell the
    difference.

    Pins are the case worth pinning down. Trial-2 live testing caught the
    inverse defect back when a gate DID score refs: the planner docs and the
    survey report both taught ``pin:<NAME>`` as citable while the allocator
    minted no pin entries, so every proposal citing a pin's direction failed.
    The gate is gone; the promise ``survey.md`` prints is not, and a citation
    the interrogator cannot resolve is a false negative in the review.
    """

    from espcycle.refs import allocate_evidence_catalog, resolve_evidence_ref

    case_dir = CASES_ROOT / "case_01_sram_mission_scan"
    corpus, _counts, _customs = prepare_case_corpus(
        json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    )
    catalog = allocate_evidence_catalog(corpus)
    for pin in corpus.pin_inventory:
        entry = resolve_evidence_ref(catalog, f"pin:{pin.name}")
        report.check(entry is not None, f"pin:{pin.name} resolves as evidence")
        if entry is not None:
            report.equal(entry.kind, "pin", f"pin:{pin.name} catalog kind")
            report.equal(entry.text, f"{pin.name} ({pin.direction})", f"pin:{pin.name} catalog text")
    report.equal(
        resolve_evidence_ref(catalog, "pin:NO_SUCH_PIN"),
        None,
        "an unknown pin name does not resolve",
    )
    # The other three namespaces the survey report prints, resolved the same
    # way: a menu is only a menu if every line on it comes back.
    for index in range(len(corpus.cycle_facts)):
        report.check(
            resolve_evidence_ref(catalog, f"cycle_fact:{index}") is not None,
            f"cycle_fact:{index} resolves as evidence",
        )
    for fact in corpus.declared_facts:
        report.check(
            resolve_evidence_ref(catalog, f"fact:{fact.fact_id}") is not None,
            f"fact:{fact.fact_id} resolves as evidence",
        )
    for index in range(len(corpus.directives)):
        report.check(
            resolve_evidence_ref(catalog, f"directive:{index}") is not None,
            f"directive:{index} resolves as evidence",
        )
    report.equal(
        resolve_evidence_ref(catalog, f"cycle_fact:{len(corpus.cycle_facts)}"),
        None,
        "an index past the corpus does not resolve",
    )
    # Byte-stable: the catalog is printed into a published report, so an
    # identical corpus must allocate an identical menu.
    report.equal_bytes(
        allocate_evidence_catalog(corpus).to_canonical_bytes(),
        catalog.to_canonical_bytes(),
        "the catalog allocation is deterministic",
    )


# ---- wire-contract layer ----------------------------------------------


def check_run_root(report: Report) -> None:
    """``dir`` names the run root, and one run is one root.

    A whole survey under a chosen root, because the interesting part is not the
    ledger (``test_espdeck_golden`` covers that) but the published tree: the
    corpus and the report must move together with every receipt path, and the
    bytes must not depend on where the root is. A different ``dir`` must then
    read as an empty run rather than a peek into this one.
    """

    case_dir = CASES_ROOT / "case_01_sram_mission_scan"
    case = _expected_json(case_dir / "input.json")
    expected = case_dir / "expected"
    chosen = "plans/sram"
    published = f"{chosen}/cycle-plans"
    with tempfile.TemporaryDirectory() as raw:
        workdir = Path(raw)
        base = {"workdir": str(workdir), "run": RUN_ID, "dir": chosen}

        _stage_wire(case, workdir, chosen)
        report.check(
            (workdir / chosen / "facts.sqlite3").is_file(),
            "the shared ledger lives under the chosen root",
        )
        report.check(
            not (workdir / "work").exists(),
            "a chosen root writes nothing under work/",
        )

        surveyed = call(
            "survey",
            {
                **base,
                "directives": case["directives"],
                "user_prompt": case["user_prompt"],
            },
        )
        if report.equal(
            surveyed["ok"], True, "survey under a chosen root", surveyed["message"][:200]
        ):
            report.equal(
                surveyed["data"]["corpus_path"],
                f"{published}/corpus.json",
                "the survey receipt names the chosen root",
            )
            report.equal(
                surveyed["data"]["survey_path"],
                f"{published}/survey.md",
                "the report receipt names the chosen root",
            )
            report.equal_bytes(
                (workdir / published / "corpus.json").read_bytes(),
                (expected / "corpus.json").read_bytes(),
                "the corpus under a chosen root is byte-identical to the default root's",
            )

        # One run must be called with one dir. A wrong one needs no refusal code
        # of its own: it finds no facts, which is what says so.
        report.equal(
            call("survey", {**base, "dir": "plans/other"})["refusal"],
            "no_facts",
            "a wrong dir finds no facts rather than another run's",
        )
        report.equal(
            call("survey", {**base, "dir": ""})["refusal"],
            "no_facts",
            "an omitted dir is the work/<run> default, never the last dir used",
        )
        report.equal(
            call(
                "corner_retract",
                {**base, "dir": "plans/other", "corner_name": "any", "reason": "why"},
            )["refusal"],
            "no_ledger",
            "a wrong dir finds no ledger rather than another run's",
        )

        for bad, why in (
            ("../escape", "a traversal"),
            ("plans/../../escape", "an interior traversal"),
            ("/etc", "an absolute path"),
            (f"{workdir.parent}/escape", "an absolute path beside the workdir"),
            (".hidden", "a leading dot"),
        ):
            for verb, arguments in (
                ("survey", {}),
                (
                    "corner_log",
                    {
                        "rows": [
                            {
                                "corner_name": "mission_write_read",
                                "statement": "verify a write followed by a read",
                                "evidence": "spec.md:24",
                            }
                        ]
                    },
                ),
                (
                    "operation_log",
                    {
                        "rows": [
                            {
                                "operation_name": "READ",
                                "pin_conditions": "CEN=L",
                                "evidence": "spec.md:24",
                            }
                        ]
                    },
                ),
            ):
                refused = call(verb, {**base, "dir": bad, **arguments})
                report.equal(
                    refused["refusal"], "invalid_args", f"{verb} refuses {why} ({bad!r})"
                )
        report.equal(
            sorted(path.name for path in workdir.iterdir()),
            ["plans"],
            "no refused dir created anything beside the chosen root",
        )


def check_harness_defect(report: Report) -> None:
    """An unknown verb is a harness defect and must exit non-zero.

    Includes the three verbs this cutover deleted: ``check``, ``render`` and
    ``reconcile`` are not deprecated aliases, they are unknown words, and a
    caller still sending one must hear so loudly rather than get a domain
    refusal it might retry.
    """

    for verb in ("no_such_verb", "check", "render", "reconcile"):
        completed = subprocess.run(
            [sys.executable, str(CLI), verb],
            input="{}",
            capture_output=True,
            text=True,
            check=False,
        )
        report.check(
            completed.returncode != 0,
            f"the verb {verb!r} exits non-zero",
            f"exit {completed.returncode}: {completed.stdout.strip()}",
        )


def check_empty_stdin(report: Report) -> None:
    """`echo '{}' | cli.py <verb>` is a clean JSON refusal at exit 0.

    The pairing is the refusal ORDER, not just the exit code: every writing
    verb validates its arguments before it touches the ledger, so an empty
    payload reads as ``invalid_args`` and never leaves a ``facts.sqlite3``
    behind for a fact it then refused. The ``no_ledger`` path (exercised in
    ``check_corner_roster``) belongs to a well-formed call against a run that
    has no ledger yet.

    All five verbs are listed, which makes this the enumeration of the surface:
    a verb added or removed without a decision fails here.
    """

    # An isolated cwd, NOT the repo root: the empty payload leaves ``workdir``
    # to its default, so where the process runs is where a defect would leave a
    # stray ``work/``. Asserting on the repo root instead made this check fail
    # whenever live-run state legitimately sat there.
    with tempfile.TemporaryDirectory() as isolated:
        cwd = Path(isolated)
        expected = {
            "survey": "no_facts",
            "operation_log": "invalid_args",
            "scalar_log": "invalid_args",
            "corner_log": "invalid_args",
            "corner_retract": "invalid_args",
        }
        for verb, refusal in expected.items():
            result = call(verb, {}, cwd=cwd)
            report.equal(result["ok"], False, f"empty {verb} refuses")
            report.equal(result["refusal"], refusal, f"empty {verb} refusal code")
            report.check(
                result["refusal"] in REFUSAL_CODES,
                f"empty {verb} refusal code is in the declared set",
                str(result["refusal"]),
            )
        report.equal(
            sorted(expected),
            sorted(VERB_NAMES),
            "every declared verb is covered by an empty-payload check",
        )
        report.check(
            not (cwd / "work").exists(),
            "an argument-less write verb creates no ledger in the working directory",
        )


def check_no_esp_agent(report: Report) -> None:
    """The port must not reach back into the legacy package.

    A leading double-backtick plus the module name is stripped before the
    search, the same way ``test_espdeck_golden.check_no_esp_agent`` does it: a
    docstring naming the legacy module inside an RST literal is what makes a
    1:1 port reviewable as a diff against its oracle, and deleting the
    provenance to satisfy a substring search would cost the review and buy
    nothing. What must not exist is a live reference -- an import, a path, an
    attribute -- and outside a double-backtick literal is exactly where those
    live.
    """

    offenders = [
        str(path.relative_to(REPO_ROOT))
        for root in (REPO_ROOT / "skill", REPO_ROOT / "tool")
        for path in sorted(root.rglob("*"))
        if path.is_file()
        and path.suffix in {".py", ".ts"}
        and "esp_agent"
        in path.read_text(encoding="utf-8", errors="replace").replace("``esp_agent", "")
    ]
    report.check(not offenders, "no esp_agent reference in skill/ or tool/", ", ".join(offenders))


def check_no_gate_layer(report: Report) -> None:
    """The gate layer is deleted, not disabled (MIGRATION.md section 13.11).

    A dead module left importable is a module something will import again. The
    twelve names below were the gate layer and the proposal schema graph it
    scored; none of them may exist as a file, and no survivor may name one as a
    live import.
    """

    package = SHARED_ROOT / "espcycle"
    deleted = (
        "gates",
        "checkers",
        "archetypes",
        "applicability",
        "prediction",
        "reconcile",
        "render",
        "outcomes",
        "review",
        "unresolved",
        "context",
        "provenance",
    )
    for name in deleted:
        report.check(
            not (package / f"{name}.py").is_file(),
            f"espcycle/{name}.py is deleted",
        )
    survivors = sorted(path.name for path in package.glob("*.py"))
    report.equal(
        survivors,
        [
            "__init__.py",
            "canonical.py",
            "cli.py",
            "corner_roster.py",
            "corpus.py",
            "models.py",
            "refs.py",
            "render_text.py",
            "survey.py",
        ],
        "espcycle carries exactly the surviving modules",
    )
    live_imports = [
        f"{path.name}: {name}"
        for path in sorted(package.glob("*.py"))
        for name in deleted
        for line in path.read_text(encoding="utf-8").splitlines()
        if line.startswith(("import ", "from "))
        and (f"espcycle.{name} " in line or f"from .{name} " in line)
    ]
    report.check(
        not live_imports,
        "no survivor imports a deleted module",
        ", ".join(live_imports),
    )


#: The declared wire surface, read off the CLI rather than restated, so a verb
#: or refusal code added without a decision shows up as a failing count.
def _declared_surface() -> tuple[tuple[str, ...], frozenset[str]]:
    from espcycle.cli import REFUSALS, VERBS

    return VERBS, frozenset(REFUSALS)


VERB_NAMES, REFUSAL_CODES = _declared_surface()


def main(argv: list[str]) -> int:
    if not CLI.is_file():
        print(f"missing {CLI}", file=sys.stderr)
        return 1
    if not CASES_ROOT.is_dir():
        print(f"missing fixtures at {CASES_ROOT}", file=sys.stderr)
        return 1
    selected = set(argv)
    cases = [
        path
        for path in sorted(CASES_ROOT.iterdir())
        if (path / "input.json").is_file() and (not selected or path.name in selected)
    ]
    if not cases:
        print(f"no cases matched {argv or ['*']}", file=sys.stderr)
        return 1

    report = Report()
    for case_dir in cases:
        check_pure_case(case_dir, report)
        with tempfile.TemporaryDirectory() as raw:
            check_wire_case(case_dir, Path(raw), report)
        print(f"  ran {case_dir.name}")
    if not selected:
        check_fact_intake(report)
        check_corner_roster(report)
        check_custom_corner_bound(report)
        check_pin_evidence_refs(report)
        check_run_root(report)
        check_harness_defect(report)
        check_empty_stdin(report)
        check_no_esp_agent(report)
        check_no_gate_layer(report)
        print("  ran cli surface checks")

    for failure in report.failures:
        print(f"FAIL {failure}")
    print(f"{report.checks} check(s), {len(report.failures)} failure(s)")
    return 1 if report.failures else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
