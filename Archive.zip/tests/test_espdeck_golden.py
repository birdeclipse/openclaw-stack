#!/usr/bin/env python3
"""Golden test: the ported ``espdeck`` core against legacy-captured fixtures.

    python3 tests/test_espdeck_golden.py [case_name ...]

Fixtures under ``tests/golden/espdeck/`` were produced by
``capture_fixtures.py`` running the LEGACY implementation (see that file's
docstring). This runner feeds the identical fact sets to the port and requires
**byte-identical** output: the three Tcl deck files, ``diagnostics.json``,
``fact-ledger.md``, the snapshot digest, every per-fact digest, and the
canonical-JSON serializer's own bytes.

Two layers, on purpose:

* **Wire layer.** Every fact is logged, retracted, snapshotted, compiled and
  reported through ``espdeck/cli.py`` as a subprocess with JSON on stdin, so the
  exit-0-for-domain-refusal contract and the run-root convention are under
  test, not just the pure functions. Facts go in as ``log`` batches of
  consecutive same-kind rows, which is what proves a batched call and a
  row-by-row call build the identical ledger: the captured digests are unchanged
  by the batching.
* **Store layer.** The resulting sqlite ledger is then read in-process and each
  row is digested, which pins the normalization the compiler and the report both
  depend on.

Failures print the first differing line (or byte offset) and the run exits 1.
"""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parent.parent
SHARED_ROOT = REPO_ROOT / "skill" / "circuit_setup" / "_shared"
CLI = SHARED_ROOT / "espdeck" / "cli.py"
FIXTURE_ROOT = REPO_ROOT / "tests" / "golden" / "espdeck"
CASES_ROOT = FIXTURE_ROOT / "cases"

if str(SHARED_ROOT) not in sys.path:
    sys.path.insert(0, str(SHARED_ROOT))

from espdeck.canonical import canonical_json_bytes  # noqa: E402
from espdeck.ledger import FactLedger  # noqa: E402


@dataclass(slots=True)
class Report:
    """Checks run and failures found."""

    checks: int = 0
    failures: list[str] = field(default_factory=list)

    def check(self, ok: bool, label: str, detail: str = "") -> bool:
        self.checks += 1
        if not ok:
            self.failures.append(f"{label}: {detail}" if detail else label)
        return ok

    def equal_bytes(self, actual: bytes, expected: bytes, label: str) -> bool:
        return self.check(actual == expected, label, _bytes_diff(actual, expected))

    def equal(self, actual: object, expected: object, label: str) -> bool:
        return self.check(
            actual == expected, label, f"expected {expected!r}, got {actual!r}"
        )


def _bytes_diff(actual: bytes, expected: bytes) -> str:
    if actual == expected:
        return ""
    try:
        actual_lines = actual.decode("utf-8").splitlines()
        expected_lines = expected.decode("utf-8").splitlines()
    except UnicodeDecodeError:
        return f"{len(actual)} bytes vs {len(expected)} expected (not UTF-8)"
    for index, (left, right) in enumerate(zip(actual_lines, expected_lines), start=1):
        if left != right:
            return f"line {index}\n      got:      {left!r}\n      expected: {right!r}"
    if len(actual_lines) != len(expected_lines):
        longer, which = (
            (actual_lines, "extra")
            if len(actual_lines) > len(expected_lines)
            else (expected_lines, "missing")
        )
        index = min(len(actual_lines), len(expected_lines))
        return f"{which} line {index + 1}: {longer[index]!r}"
    return f"{len(actual)} bytes vs {len(expected)} expected (trailing newline?)"


def call(verb: str, arguments: dict[str, Any]) -> dict[str, Any]:
    """Invoke one CLI verb. Refuses to tolerate a non-zero (harness-defect) exit."""

    completed = subprocess.run(
        [sys.executable, str(CLI), verb],
        input=json.dumps(arguments),
        capture_output=True,
        text=True,
        check=False,
    )
    if completed.returncode != 0:
        raise AssertionError(
            f"cli.py {verb} exited {completed.returncode} (domain refusals must exit 0)\n"
            f"stdout: {completed.stdout.strip()}\nstderr: {completed.stderr.strip()}"
        )
    payload = json.loads(completed.stdout)
    for key in ("ok", "message", "data", "refusal"):
        if key not in payload:
            raise AssertionError(f"cli.py {verb} result is missing {key!r}: {payload}")
    return payload


def run_case(case_dir: Path, report: Report) -> None:
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    expected_dir = case_dir / "expected"
    digests = json.loads((expected_dir / "digests.json").read_text(encoding="utf-8"))
    run = str(case["run"])
    session = str(case["session_id"])
    label = case_dir.name

    with tempfile.TemporaryDirectory(prefix="espdeck-golden-") as temp:
        workdir = Path(temp)
        base = {"run": run, "workdir": str(workdir), "session": session}

        # A read verb before the first log must refuse cleanly, at exit 0.
        empty = call("compile", dict(base))
        report.equal(empty["refusal"], "no_ledger", f"{label}: compile before any fact")

        for group in _kind_runs(case["facts"]):
            kind = str(group[0]["kind"])
            first = group[0]["index"]
            result = call(
                "log",
                {
                    **base,
                    "kind": kind,
                    "facts": [
                        {
                            "fields": spec.get("fields", {}),
                            "evidence": spec["evidence"],
                            "origin": spec.get("origin", "parsed"),
                        }
                        for spec in group
                    ],
                },
            )
            if not report.check(
                bool(result["ok"]),
                f"{label}: log {len(group)} {kind} fact(s) from {first}",
                result["message"],
            ):
                return
            report.equal(
                result["data"]["fact_ids"],
                list(range(first, first + len(group))),
                f"{label}: {kind} batch from {first} keeps the fixture's fact ids",
            )
            report.equal(
                result["data"]["count"],
                len(group),
                f"{label}: {kind} batch from {first} counts its rows",
            )

        for retraction in case.get("retractions", ()):
            result = call(
                "retract",
                {**base, "fact_id": str(retraction["fact_id"]), "reason": retraction["reason"]},
            )
            report.check(
                bool(result["ok"]),
                f"{label}: retract fact {retraction['fact_id']}",
                result["message"],
            )

        snapshot = call("snapshot", dict(base))
        report.equal(
            snapshot["data"]["snapshot_digest"],
            digests["snapshot_digest"],
            f"{label}: snapshot digest",
        )
        report.equal(
            snapshot["data"]["live_facts"], digests["live_facts"], f"{label}: live fact count"
        )
        report.equal(
            snapshot["data"]["minimum_gaps"], digests["minimum_gaps"], f"{label}: minimum gaps"
        )
        report.equal(
            snapshot["data"]["blocking_minimum_gaps"],
            digests["blocking_minimum_gaps"],
            f"{label}: blocking minimum gaps",
        )

        published = workdir / "work" / run
        macro = digests["macro"]
        if case.get("constraints_file_present") and macro:
            # The compiler only tests for existence; the content is the model's.
            published.mkdir(parents=True, exist_ok=True)
            _ = (published / f"{macro}_constraints.tcl").write_text(
                "# worker-owned constraints\n", encoding="utf-8"
            )

        compiled = call("compile", dict(base))
        if macro is None:
            report.equal(compiled["ok"], False, f"{label}: compile must refuse")
            report.equal(compiled["refusal"], "nothing_compiled", f"{label}: refusal code")
            expected_diagnostics = json.loads(
                (expected_dir / "diagnostics.json").read_text(encoding="utf-8")
            )["diagnostics"]
            report.equal(
                compiled["data"]["diagnostics"],
                expected_diagnostics,
                f"{label}: refusal diagnostics",
            )
            report.check(
                not any(published.glob("*.tcl")) if published.is_dir() else True,
                f"{label}: nothing written on refusal",
            )
        else:
            if not report.check(
                bool(compiled["ok"]), f"{label}: compile", compiled["message"]
            ):
                return
            report.equal(compiled["data"]["macro"], macro, f"{label}: macro")
            report.equal(
                compiled["data"]["files"], digests["files"], f"{label}: written file names"
            )
            report.equal(
                compiled["data"]["run_root"],
                f"work/{run}",
                f"{label}: run root is workdir-relative",
            )
            for filename in digests["files"]:
                report.equal_bytes(
                    (published / filename).read_bytes(),
                    (expected_dir / filename).read_bytes(),
                    f"{label}: {filename}",
                )
            report.equal_bytes(
                (published / "diagnostics.json").read_bytes(),
                (expected_dir / "diagnostics.json").read_bytes(),
                f"{label}: diagnostics.json",
            )

        published_report = call("report", dict(base))
        if report.check(
            bool(published_report["ok"]), f"{label}: report", published_report["message"]
        ):
            report.equal_bytes(
                (published / "fact-ledger.md").read_bytes(),
                (expected_dir / "fact-ledger.md").read_bytes(),
                f"{label}: fact-ledger.md",
            )
            report.equal(
                published_report["data"]["live_facts"],
                digests["live_facts"],
                f"{label}: report live count",
            )
            report.equal(
                published_report["data"]["retracted_facts"],
                digests["retracted_facts"],
                f"{label}: report retracted count",
            )

        check_store(workdir, run, digests, label, report)


def _kind_runs(facts: list[dict[str, Any]]) -> list[list[dict[str, Any]]]:
    """Split the fixture's fact list into CONSECUTIVE same-kind batches.

    Consecutive, not grouped by kind across the whole list: the ledger's
    ``fact_id`` order is the fixture's order, and every captured oracle -- the
    per-fact digests, the snapshot digest, the compiler's bytes -- hangs off it.
    Reordering facts to win bigger batches would rewrite the oracle instead of
    testing against it. Each entry carries its 1-based fixture position so the
    expected ``fact_ids`` stay readable.
    """

    runs: list[list[dict[str, Any]]] = []
    for index, spec in enumerate(facts, start=1):
        entry = dict(spec, index=index)
        if runs and runs[-1][0]["kind"] == entry["kind"]:
            runs[-1].append(entry)
        else:
            runs.append([entry])
    return runs


def check_store(
    workdir: Path, run: str, digests: dict[str, Any], label: str, report: Report
) -> None:
    """Re-read the sqlite rows and digest each one against the legacy value."""

    ledger = FactLedger(workdir, run)
    try:
        records = ledger.list()
    finally:
        ledger.close()
    expected_facts = digests["facts"]
    if not report.equal(len(records), len(expected_facts), f"{label}: ledger row count"):
        return
    for record, expected in zip(records, expected_facts):
        prefix = f"{label}: fact {expected['fact_id']}"
        report.equal(record.fact_id, expected["fact_id"], f"{prefix} id")
        report.equal(record.kind, expected["kind"], f"{prefix} kind")
        report.equal(record.origin, expected["origin"], f"{prefix} origin")
        report.equal(dict(record.fields), expected["fields"], f"{prefix} fields")
        report.equal(record.evidence, expected["evidence"], f"{prefix} evidence")
        report.equal(record.retracted, expected["retracted"], f"{prefix} retracted")
        report.equal(
            record.retract_reason, expected["retract_reason"], f"{prefix} retract reason"
        )
        digest = sha256(
            canonical_json_bytes(
                {
                    "fact_id": record.fact_id,
                    "kind": record.kind,
                    "origin": record.origin,
                    "fields": dict(record.fields),
                    "evidence": record.evidence,
                }
            )
        ).hexdigest()
        report.equal(digest, expected["digest"], f"{prefix} digest")


def _pin_row(name: str, direction: str) -> dict[str, Any]:
    """One well-formed ``pin`` row for the batch and run-root checks."""

    return {
        "fields": {
            "pin_name": name,
            "direction": direction,
            "function_type": "generic",
            "allowed_values": "",
            "value": "",
        },
        "evidence": f"batch fixture: {name} is an {direction}",
        "origin": "parsed",
    }


def check_batch_log(report: Report) -> None:
    """``log`` is all-or-nothing and names the row that refused.

    No legacy oracle: the legacy tool logged one fact per call, so the batch
    shape is checked against the contract it was written to. The property that
    matters is that a refused batch is INVISIBLE -- a partially applied batch
    would leave the model guessing which rows it still owes, and would move the
    snapshot digest a proposal may already have been written against.
    """

    with tempfile.TemporaryDirectory(prefix="espdeck-batch-") as temp:
        workdir = Path(temp)
        base = {"run": "batch01", "workdir": str(workdir), "session": "ses-batch"}

        good = call(
            "log",
            {
                **base,
                "kind": "pin",
                "facts": [_pin_row("CLK", "input"), _pin_row("Q", "output")],
            },
        )
        report.equal(good["data"]["fact_ids"], [1, 2], "a two-row batch logs two rows")
        report.equal(good["data"]["count"], 2, "the batch receipt counts its rows")
        report.check(
            "2 pin fact(s)" in good["message"] and "2 live pin fact(s)" in good["message"],
            "the batch receipt names the kind, the count and the live count",
            good["message"],
        )

        before = call("list", base)["data"]["count"]
        broken = _pin_row("CEN", "input")
        del broken["fields"]["pin_name"]
        refused = call(
            "log",
            {
                **base,
                "kind": "pin",
                "facts": [_pin_row("WEN", "input"), broken, _pin_row("A0", "input")],
            },
        )
        report.equal(refused["refusal"], "rejected_fact", "one bad row refuses the whole batch")
        report.equal(
            refused["message"],
            "facts[1]: field pin_name is required for a pin fact",
            "the refusal names the offending row by its argument index",
        )
        report.equal(
            call("list", base)["data"]["count"],
            before,
            "a refused batch logs nothing at all -- not even its good rows",
        )

        for facts, why in (
            ([], "an empty facts array"),
            ("CLK", "a facts argument that is not an array"),
            ([_pin_row("D0", "input"), "D1"], "a row that is not an object"),
            ([dict(_pin_row("D0", "input"), fields="pin_name=D0")], "fields that is not an object"),
            ([_pin_row(f"D{index}", "input") for index in range(65)], "a batch over the bound"),
        ):
            report.equal(
                call("log", {**base, "kind": "pin", "facts": facts})["refusal"],
                "invalid_args",
                f"log refuses {why}",
            )
        report.equal(
            call("list", base)["data"]["count"],
            before,
            "none of the malformed calls logged a row",
        )


def check_run_root(report: Report) -> None:
    """``dir`` names the run root, confined to the workdir.

    The ``work/<run>`` default is what every case above exercises. What is
    checked here is that a chosen root carries the WHOLE run -- ledger and
    deck bundle -- that nothing lands in ``work/`` when one is given, that
    a different ``dir`` is a different run rather than a peek into this one, and
    that a root which is not a safe relative path under the workdir refuses
    instead of writing outside the tree.
    """

    with tempfile.TemporaryDirectory(prefix="espdeck-root-") as temp:
        workdir = Path(temp)
        chosen = "decks/sram_2p_hd"
        base = {
            "run": "root01",
            "workdir": str(workdir),
            "session": "ses-root",
            "dir": chosen,
        }

        logged = call(
            "log",
            {
                **base,
                "kind": "verilog",
                "facts": [
                    {
                        "fields": {
                            "top_design_name": "sram_2p_hd",
                            "verilog_file_location": "rtl/sram_2p_hd.v",
                            "filelist_location": "",
                            "vcs_options": "",
                        },
                        "evidence": "run-root fixture: the RTL names the top design",
                    }
                ],
            },
        )
        report.check(
            bool(logged["ok"]), "log accepts a chosen run root", logged["message"]
        )
        report.check(
            (workdir / chosen / "facts.sqlite3").is_file(),
            "the ledger lives under the chosen root",
        )
        report.check(
            not (workdir / "work").exists(),
            "a chosen root writes nothing under work/",
        )

        compiled = call("compile", dict(base))
        if report.check(bool(compiled["ok"]), "compile under a chosen root", compiled["message"]):
            report.equal(
                compiled["data"]["run_root"],
                chosen,
                "the compile receipt names the chosen root, workdir-relative",
            )
            report.check(
                (workdir / chosen / "diagnostics.json").is_file(),
                "the deck bundle lands in the chosen root",
            )
        reported = call("report", dict(base))
        if report.check(bool(reported["ok"]), "report under a chosen root", reported["message"]):
            report.equal(
                reported["data"]["path"],
                f"{chosen}/fact-ledger.md",
                "the report receipt names the chosen root",
            )

        # One run must be called with one dir. A wrong one is not an error code
        # of its own: it finds no ledger, which is exactly what says so.
        report.equal(
            call("compile", {**base, "dir": "decks/other"})["refusal"],
            "no_ledger",
            "a wrong dir finds no ledger rather than another run's",
        )
        report.equal(
            call("compile", {**base, "dir": ""})["refusal"],
            "no_ledger",
            "an omitted dir is the work/<run> default, never the last dir used",
        )

        for bad, why in (
            ("../escape", "a traversal"),
            ("decks/../../escape", "an interior traversal"),
            ("/etc", "an absolute path"),
            (f"{workdir.parent}/escape", "an absolute path beside the workdir"),
            (".hidden", "a leading dot"),
            ("a/b/c/d/e/f/g/h/i", "more segments than a run root takes"),
        ):
            refused = call(
                "log",
                {**base, "dir": bad, "kind": "pin", "facts": [_pin_row("CLK", "input")]},
            )
            report.equal(refused["refusal"], "invalid_args", f"dir refuses {why} ({bad!r})")
        entries = sorted(path.name for path in workdir.iterdir())
        report.equal(
            entries, ["decks"], "no refused dir created anything beside the chosen root"
        )


def check_canonical(report: Report) -> None:
    vectors = json.loads((FIXTURE_ROOT / "canonical_vectors.json").read_text(encoding="utf-8"))
    expected = (FIXTURE_ROOT / "expected_canonical.txt").read_text(encoding="utf-8")
    actual = "\n".join(canonical_json_bytes(vector).decode("utf-8") for vector in vectors) + "\n"
    report.equal_bytes(
        actual.encode("utf-8"), expected.encode("utf-8"), "canonical_json_bytes vectors"
    )


def check_no_esp_agent(report: Report) -> None:
    """The port must not reach back into the legacy package."""

    offenders = [
        str(path.relative_to(REPO_ROOT))
        for path in sorted((REPO_ROOT / "skill").rglob("*.py"))
        if "esp_agent" in path.read_text(encoding="utf-8").replace("``esp_agent", "")
    ]
    report.check(not offenders, "no esp_agent import in skill/", ", ".join(offenders))


def main(argv: list[str]) -> int:
    if not CLI.is_file():
        print(f"missing {CLI}", file=sys.stderr)
        return 1
    cases = sorted(path for path in CASES_ROOT.iterdir() if (path / "input.json").is_file())
    if argv:
        wanted = set(argv)
        cases = [case for case in cases if case.name in wanted]
        if not cases:
            print(f"no case matched {sorted(wanted)}", file=sys.stderr)
            return 1
    report = Report()
    for case_dir in cases:
        if not (case_dir / "expected" / "digests.json").is_file():
            print(
                f"{case_dir.name}: no captured fixtures; run "
                "tests/golden/espdeck/capture_fixtures.py under the legacy venv",
                file=sys.stderr,
            )
            return 1
        run_case(case_dir, report)
        print(f"  ran {case_dir.name}")
    check_batch_log(report)
    check_run_root(report)
    check_canonical(report)
    check_no_esp_agent(report)

    print(f"{report.checks} check(s), {len(report.failures)} failure(s)")
    for failure in report.failures:
        print(f"  FAIL {failure}")
    return 1 if report.failures else 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
