"""Stage one golden case's fact-log sequence and project it to a corpus.

Shared by ``test_espcycle_golden.py`` (which compares the result against the
captured bytes) and ``capture_fixtures.py`` (which writes them). One module
because the two must agree by construction: a second copy of the staging order
would let the runner and the capture drift into disagreeing about what the
fixture even is.

**The projection is imported, never re-implemented.** ``espcycle.cli``'s
``_pin_inventory`` / ``_operation_records`` / ``_declared_facts`` are the
production seam between the shared ledger and ``PreparedCorpusV3``, and they are
module-private. Reaching past the underscore is deliberate: a
hand-written mirror of a projection is a second implementation that goes stale
silently, and the point of the pure layer is to compare BYTES, not to re-derive
them. The wire layer independently proves the CLI verbs produce this same
corpus, which is the check a mirror was pretending to be.
"""

from __future__ import annotations

import tempfile
from pathlib import Path
from typing import Any

from espcycle.cli import (
    CORNER_FACT_KIND,
    CORNER_ORIGIN,
    OPERATION_FACT_KIND,
    PIN_FACT_KIND,
    SCALAR_FACT_KIND,
    SCALAR_ORIGIN,
    Result,
    _custom_corners,
    _declared_facts,
    _operation_records,
    _pin_inventory,
)
from espcycle.corpus import prepare_corpus
from espdeck.facts import facts_of_kind
from espdeck.ledger import FactDraft, FactLedger

RUN_ID = "gold1234"

#: Kinds whose ``origin`` the espcycle write verb fixes rather than accepts.
_PINNED_ORIGINS = {
    SCALAR_FACT_KIND: SCALAR_ORIGIN,
    CORNER_FACT_KIND: CORNER_ORIGIN,
}


def fact_specs(case: dict[str, Any]) -> tuple[dict[str, Any], ...]:
    """The case's fact-log sequence, with each entry's origin resolved.

    ``plan_scalar`` and ``function_corner`` origins are not the fixture's to
    choose: ``scalar_log`` and ``corner_log`` pin both to ``declared``, so a
    fixture that said otherwise would stage a ledger the wire verbs cannot
    reproduce. They are asserted rather than silently overwritten, because a
    fixture that disagrees is a fixture bug.
    """

    specs: list[dict[str, Any]] = []
    for entry in case["facts"]:
        kind = str(entry["kind"])
        origin = str(entry.get("origin") or "parsed")
        pinned = _PINNED_ORIGINS.get(kind)
        if pinned is not None and origin != pinned:
            raise AssertionError(
                f"{kind} fixtures must declare origin {pinned!r}, got {origin!r}"
            )
        specs.append(
            {
                "kind": kind,
                "origin": origin,
                "fields": dict(entry["fields"]),
                "evidence": str(entry["evidence"]),
            }
        )
    return tuple(specs)


def fact_batches(case: dict[str, Any]) -> tuple[tuple[dict[str, Any], ...], ...]:
    """The case's fact-log sequence, split into CONSECUTIVE same-kind batches.

    Consecutive, and never grouped by kind across the whole list: ``fact_id``
    order is the fixture's order and every captured oracle -- the corpus bytes,
    the roster, the findings -- hangs off it, so reordering facts to win bigger
    batches would rewrite the oracle instead of testing against it. Shared with
    the runner so the wire layer batches exactly the way this staging does.
    """

    batches: list[list[dict[str, Any]]] = []
    for spec in fact_specs(case):
        if batches and batches[-1][0]["kind"] == spec["kind"]:
            batches[-1].append(spec)
        else:
            batches.append([spec])
    return tuple(tuple(batch) for batch in batches)


def stage_ledger(ledger: FactLedger, case: dict[str, Any]) -> None:
    """Log the case's facts in fixture order, one batch per run of one kind.

    A rejected fact is a fixture defect. The batch is all-or-nothing, so the
    refused row is named by its position within its own batch.
    """

    for batch in fact_batches(case):
        kind = str(batch[0]["kind"])
        outcome = ledger.log_many(
            kind,
            [
                FactDraft(
                    fields=spec["fields"],
                    evidence=spec["evidence"],
                    origin=spec["origin"],
                )
                for spec in batch
            ],
        )
        if outcome.is_error:
            index = 0 if outcome.rejected_index is None else outcome.rejected_index
            raise AssertionError(f"fixture {kind} batch row {index}: {outcome.message}")


def prepare_case_corpus(
    case: dict[str, Any],
) -> tuple[Any, dict[str, int], tuple[Any, ...]]:
    """Stage the case in a throwaway ledger and project it, as ``survey`` does.

    Returns the corpus, the counts a receipt reports, and the run's custom
    corners. The corners are a THIRD value rather than part of the corpus
    because they are not corpus evidence: a ``function_corner`` fact declares
    what to verify, so it opens the corner vocabulary the roster classifies and
    leaves ``corpus.json`` and its digest alone. Every caller must hand them to
    ``derive_corner_roster`` alongside the corpus, exactly as ``cli`` does.
    """

    with tempfile.TemporaryDirectory(prefix="espcycle-case-") as raw:
        ledger = FactLedger(Path(raw), RUN_ID)
        try:
            stage_ledger(ledger, case)
            snapshot = ledger.snapshot()
            corners = _custom_corners(ledger)
        finally:
            ledger.close()
    if isinstance(corners, Result):
        raise AssertionError(f"fixture function_corner facts do not project: {corners.message}")

    pins = _pin_inventory(facts_of_kind(snapshot, PIN_FACT_KIND))
    if isinstance(pins, Result):
        raise AssertionError(f"fixture pin facts do not project: {pins.message}")
    operations = facts_of_kind(snapshot, OPERATION_FACT_KIND)
    scalars = _declared_facts(facts_of_kind(snapshot, SCALAR_FACT_KIND))
    if isinstance(scalars, Result):
        raise AssertionError(f"fixture plan_scalar facts do not project: {scalars.message}")

    directives = tuple(str(item) for item in (case.get("directives") or []))
    corpus = prepare_corpus(
        user_prompt=str(case.get("user_prompt") or ""),
        directives=directives,
        declared_facts=scalars,
        pins=pins,
        cycle_facts=_operation_records(operations),
    )
    counts = {
        "pin_count": len(corpus.pin_inventory),
        "operation_count": len(operations),
        "scalar_count": len(corpus.declared_facts),
        "directive_count": len(corpus.directives),
    }
    return corpus, counts, corners


__all__ = [
    "RUN_ID",
    "fact_batches",
    "fact_specs",
    "prepare_case_corpus",
    "stage_ledger",
]
