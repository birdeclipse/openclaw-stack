#!/usr/bin/env python3
"""Capture golden fixtures for the ``espcycle`` core.

    uv run --with 'pydantic>=2,<3' \\
        tests/golden/espcycle/capture_fixtures.py [case_name ...]

**Contract fixtures, not oracle fixtures.** This script used to run under the
LEGACY checkout's virtualenv, because most of what it wrote was an oracle value:
the legacy pure pipeline produced the gate findings, the coverage prediction,
the rendered ``plan.md`` and the reconciliation documents, and the port had to
match them byte for byte. Those layers are deleted (MIGRATION.md section 13.11 --
``plan.md`` is prose the planner writes, checked by the interrogator's review),
so the oracle half of this capture is gone with them and no legacy checkout is
needed for any of it.

What is left has no legacy counterpart at all. Legacy ``survey`` read markdown
and guessed a pin table out of prose; ADR 0043's amendment replaced that with
``pin`` / ``operation`` / ``plan_scalar`` rows in the shared Design Fact Ledger.
So ``corpus.json``, ``roster.json`` and ``digests.json`` are CONTRACT fixtures:
captured from this implementation after a human read them and agreed they are
right. Regenerating them is a reviewable act, not a mechanical one -- if a diff
appears here, the question is "is the new corpus correct?", never "does it match
legacy?".

Per case, written under ``cases/<case>/expected/``:

* ``corpus.json``  -- ``PreparedCorpusV3`` canonical bytes
* ``roster.json``  -- ``CornerRosterV1`` canonical bytes: the eight built-in
                      corners, then the run's own ``function_corner`` slugs
* ``digests.json`` -- corpus digest plus the counts a receipt reports,
                      including ``custom_corner_count``. A ``function_corner``
                      fact is roster state, not corpus evidence, so adding one
                      changes ``roster.json`` and leaves ``corpus.json`` and the
                      corpus digest byte-identical.

Nothing under ``cases/<case>/`` is generated any more except those three files.
``survey.md`` is deliberately NOT captured: it is a report over exactly these
bytes, so a byte fixture for it would pin report PROSE and fail on every
wording fix. The runner asserts its structure -- the digest, the Evidence
catalog, the pin citation rule -- instead.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any

FIXTURE_ROOT = Path(__file__).resolve().parent
CASES_ROOT = FIXTURE_ROOT / "cases"
REPO_ROOT = FIXTURE_ROOT.parent.parent.parent
SHARED_ROOT = REPO_ROOT / "skill" / "circuit_setup" / "_shared"

for _root in (str(SHARED_ROOT), str(FIXTURE_ROOT)):
    if _root not in sys.path:
        sys.path.insert(0, _root)

from espcycle.corpus import corpus_digest  # noqa: E402
from espcycle.survey import derive_corner_roster  # noqa: E402

from ledger_case import prepare_case_corpus  # noqa: E402


def _write_bytes(path: Path, payload: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    _ = path.write_bytes(payload)
    print(f"  wrote {path.relative_to(FIXTURE_ROOT)} ({len(payload)} bytes)")


def _write_json(path: Path, payload: Any) -> None:
    _write_bytes(path, (json.dumps(payload, indent=2, sort_keys=True) + "\n").encode("utf-8"))


def capture_case(case_dir: Path) -> None:
    print(f"case {case_dir.name}")
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    expected = case_dir / "expected"
    corpus, counts, custom_corners = prepare_case_corpus(case)
    roster = derive_corner_roster(corpus, custom_corners)

    _write_bytes(expected / "corpus.json", corpus.to_canonical_bytes())
    _write_bytes(expected / "roster.json", roster.to_canonical_bytes())
    _write_json(
        expected / "digests.json",
        {
            "corpus_digest": corpus_digest(corpus),
            "recommended": list(roster.recommended),
            "custom_corner_count": len(custom_corners),
            "pin_count": counts["pin_count"],
            "operation_count": counts["operation_count"],
            "scalar_count": counts["scalar_count"],
            "directive_count": counts["directive_count"],
        },
    )


def main(argv: list[str]) -> int:
    selected = set(argv)
    cases = [
        path
        for path in sorted(CASES_ROOT.iterdir())
        if (path / "input.json").is_file() and (not selected or path.name in selected)
    ]
    if not cases:
        raise SystemExit(f"no cases matched {argv or ['*']} under {CASES_ROOT}")
    for case_dir in cases:
        capture_case(case_dir)
    print(f"captured {len(cases)} case(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
