#!/usr/bin/env python3
"""Capture golden fixtures for the ``espdeck`` port from the LEGACY oracle.

Run it with the legacy virtualenv, from the legacy checkout, so the imports
below resolve to the ORIGINAL modules:

    cd ~/projects/openhands_setup_agent && \\
        .venv/bin/python ~/projects/circuit-setup-general/tests/golden/espdeck/capture_fixtures.py

The legacy checkout is read-only: nothing here writes outside
``tests/golden/espdeck/`` in THIS repository, and no legacy ``FactLedger`` is
constructed -- a ledger would create a store under the legacy Workspace State
Root. Every oracle value comes from the legacy PURE functions
(``normalize_fact``, ``snapshot_digest``, ``compile_deck``,
``render_fact_report``, ``canonical_json_bytes``) fed hand-written fact sets from
``cases/*/input.json``.

Records are assembled exactly the way the sqlite ledger produces them, so the
ported end-to-end run has to match byte for byte:

* ``fact_id`` is the 1-based log order (``INTEGER PRIMARY KEY AUTOINCREMENT``);
* ``fields`` is the canonical-JSON round trip, hence sorted keys;
* ``evidence`` is stripped, as the INSERT stores it;
* a retraction keeps the row and its (512-char capped) reason.

Written per case, under ``cases/<case>/expected/``:

    <macro>_esp_setup.tcl  <macro>_supplies.tcl  <macro>_pin_attributes.tcl
    diagnostics.json       fact-ledger.md        digests.json

plus ``expected_canonical.txt`` beside ``canonical_vectors.json``.
"""

from __future__ import annotations

import json
from hashlib import sha256
from pathlib import Path
from types import MappingProxyType
from typing import Any

FIXTURE_ROOT = Path(__file__).resolve().parent
CASES_ROOT = FIXTURE_ROOT / "cases"

try:
    from esp_agent.design_facts.facts import (
        FactRecord,
        FactSnapshot,
        blocking_minimum_gaps,
        minimum_gaps,
        normalize_fact,
        snapshot_digest,
    )
    from esp_agent.design_facts.report import render_fact_report
    from esp_agent.orchestration.contracts import canonical_json_bytes
    from esp_agent.setup_deck.compiler import (
        COMPILER_VERSION,
        SKELETON_VERSION,
        CompileResult,
        compile_deck,
    )
except ModuleNotFoundError as error:  # pragma: no cover - operator error
    raise SystemExit(
        "capture_fixtures.py must run under the LEGACY interpreter, e.g.\n"
        "  cd ~/projects/openhands_setup_agent && .venv/bin/python "
        f"{Path(__file__).resolve()}\n"
        f"({error})"
    ) from error

#: Mirrors ``espdeck.cli.DIAGNOSTICS_SCHEMA`` / ``diagnostics_payload``. The
#: payload assembly is new code (the legacy compiler returned objects, not a
#: file), so it is duplicated here on purpose: the fixture then pins the
#: LEGACY diagnostic content -- severities, codes, messages, fact ids, order,
#: manifest digests -- inside the new envelope, and a drift in either the
#: envelope or the compiler fails the golden test.
DIAGNOSTICS_SCHEMA = "espdeck.diagnostics.v1"
_MAX_REASON_CHARS = 512


def diagnostics_payload(
    result: CompileResult,
    *,
    snapshot_digest_value: str,
    minimum_gaps_found: tuple[str, ...],
    blocking_gaps_found: tuple[str, ...],
) -> dict[str, Any]:
    return {
        "schema": DIAGNOSTICS_SCHEMA,
        "compiler_version": COMPILER_VERSION,
        "skeleton_version": SKELETON_VERSION,
        "snapshot_digest": snapshot_digest_value,
        "macro": result.macro,
        "files": sorted(result.files),
        "manifest": dict(result.manifest),
        "minimum_gaps": list(minimum_gaps_found),
        "blocking_minimum_gaps": list(blocking_gaps_found),
        "diagnostics": [
            {
                "severity": item.severity,
                "code": item.code,
                "message": item.message,
                "fact_ids": list(item.fact_ids),
            }
            for item in result.diagnostics
        ],
    }


def _fact_digest(record: FactRecord) -> str:
    """Per-fact digest over the same payload ``snapshot_digest`` hashes."""

    return sha256(
        canonical_json_bytes(
            {
                "fact_id": record.fact_id,
                "kind": record.kind,
                "origin": record.origin,
                "fields": dict(record.fields),
                "evidence": record.evidence,
            }
        )
    ).hexdigest()


def build_records(case: dict[str, Any]) -> tuple[FactRecord, ...]:
    """Normalize the case's facts the way ``FactLedger.log`` would."""

    reasons: dict[int, str] = {
        int(item["fact_id"]): str(item.get("reason", "")).strip()[:_MAX_REASON_CHARS]
        for item in case.get("retractions", ())
    }
    records: list[FactRecord] = []
    for index, spec in enumerate(case["facts"], start=1):
        normalized = normalize_fact(
            str(spec["kind"]),
            dict(spec.get("fields", {})),
            str(spec["evidence"]),
            str(spec.get("origin", "parsed")),
        )
        if isinstance(normalized, str):
            raise SystemExit(
                f"{case['name']} fact {index} ({spec['kind']}) was refused by the "
                f"legacy validator: {normalized}"
            )
        clean_fields, clean_origin = normalized
        # ``fields_json`` is canonical JSON, so the row reads back sorted.
        stored = json.loads(canonical_json_bytes(clean_fields).decode("utf-8"))
        records.append(
            FactRecord(
                fact_id=index,
                kind=str(spec["kind"]),
                origin=clean_origin,
                fields=MappingProxyType(dict(stored)),
                evidence=str(spec["evidence"]).strip(),
                retracted=index in reasons,
                retract_reason=reasons.get(index, ""),
            )
        )
    unknown = sorted(set(reasons) - {record.fact_id for record in records})
    if unknown:
        raise SystemExit(f"{case['name']}: retraction names unknown fact id(s) {unknown}")
    return tuple(records)


def capture_case(case_dir: Path) -> list[str]:
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    expected = case_dir / "expected"
    expected.mkdir(parents=True, exist_ok=True)
    for stale in sorted(expected.iterdir()):
        stale.unlink()

    records = build_records(case)
    live = tuple(record for record in records if not record.retracted)
    digest = snapshot_digest(live)
    snapshot = FactSnapshot(facts=live, digest=digest)
    gaps = minimum_gaps(snapshot)
    blocking = blocking_minimum_gaps(snapshot)

    result = compile_deck(
        snapshot,
        constraints_file_present=bool(case.get("constraints_file_present", False)),
    )
    written: list[str] = []
    for filename, content in sorted(result.files.items()):
        _ = (expected / filename).write_bytes(content)
        written.append(filename)

    payload = diagnostics_payload(
        result,
        snapshot_digest_value=digest,
        minimum_gaps_found=gaps,
        blocking_gaps_found=blocking,
    )
    _ = (expected / "diagnostics.json").write_bytes(canonical_json_bytes(payload) + b"\n")
    written.append("diagnostics.json")

    text = render_fact_report(
        records,
        session_id=str(case["session_id"]),
        work_item_id=str(case["run"]),
    )
    _ = (expected / "fact-ledger.md").write_text(text, encoding="utf-8")
    written.append("fact-ledger.md")

    digests = {
        "snapshot_digest": digest,
        "live_facts": len(live),
        "retracted_facts": len(records) - len(live),
        "minimum_gaps": list(gaps),
        "blocking_minimum_gaps": list(blocking),
        "macro": result.macro,
        "files": sorted(result.files),
        "facts": [
            {
                "fact_id": record.fact_id,
                "kind": record.kind,
                "origin": record.origin,
                "fields": dict(record.fields),
                "evidence": record.evidence,
                "retracted": record.retracted,
                "retract_reason": record.retract_reason,
                "digest": _fact_digest(record),
            }
            for record in records
        ],
    }
    _ = (expected / "digests.json").write_bytes(canonical_json_bytes(digests) + b"\n")
    written.append("digests.json")
    return written


def capture_canonical() -> int:
    vectors = json.loads((FIXTURE_ROOT / "canonical_vectors.json").read_text(encoding="utf-8"))
    lines = [canonical_json_bytes(vector).decode("utf-8") for vector in vectors]
    for line in lines:
        if "\n" in line or "\r" in line:  # pragma: no cover - guards the format
            raise SystemExit("a canonical vector rendered a line terminator; fix the format")
    _ = (FIXTURE_ROOT / "expected_canonical.txt").write_text(
        "\n".join(lines) + "\n", encoding="utf-8"
    )
    return len(lines)


def main() -> int:
    cases = sorted(path for path in CASES_ROOT.iterdir() if (path / "input.json").is_file())
    if not cases:
        raise SystemExit(f"no cases with an input.json under {CASES_ROOT}")
    for case_dir in cases:
        written = capture_case(case_dir)
        print(f"{case_dir.name}: {len(written)} fixture file(s)")
        for name in written:
            print(f"  {name}")
    count = capture_canonical()
    print(f"expected_canonical.txt: {count} vector(s)")
    print(f"legacy compiler {COMPILER_VERSION}, skeleton {SKELETON_VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
