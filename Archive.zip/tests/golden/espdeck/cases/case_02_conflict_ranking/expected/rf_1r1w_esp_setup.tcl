# rf_1r1w ESP setup deck
# compiler setup-deck-compiler-v1, skeleton setup-deck-skeleton-v1
# fact snapshot ff0d004d3ce05eba5383bf5bfa049844548683e7557c5c87140432860342bb97
# generated from the Design Fact Ledger; edit facts, not this file

# --- house application variables (template default) ---
set_app_var waveform_format fsdb
set_app_var verify_rcdelay_unit fs
set_app_var verify_delay_round_multiple 100
set_app_var verify_stop_on_randomize true
set_app_var verify_randomize_variables sysmem
set_app_var netlist_supply_by_connection off
set_app_var parser_verilog latest
set_app_var coverage true

puts "INFO: READ REFERENCE DESIGN"
read_verilog -r -vcs "-sverilog +define+RF_1R1W -timescale=1ns/1ps design/rtl/rf_1r1w_wrapper.sv -f design/rtl/rf.f -f design/rtl/rf_common.f"
puts "INFO: READ IMPLEMENTATION DESIGN"
read_spice -i design/spice/rf_1r1w.cdl

# --- top design ---
set_top_design -r rf_1r1w
set_top_design -i rf_1r1w

puts "INFO: SET SUPPLY NETS"
source -echo -verbose rf_1r1w_supplies.tcl
report_potential_supply -i > supplies.rpt

puts "INFO: MATCH DESIGN PORTS"
set_matched_ports -i VDDPE
set_matched_ports -i VSS
match_design_ports
report_matched_ports
report_unmatched_ports

# --- timescale and clock (template defaults) ---
set_simulation_timescale 1 ns 1 ps
create_clock -period 5000 -setup 500 CK
report_clock

puts "INFO: SOURCE TESTBENCH PIN ATTRIBUTES"
source -echo -verbose rf_1r1w_pin_attributes.tcl

puts "INFO: SOURCE WORKER-OWNED CONSTRAINTS"
source -echo -verbose rf_1r1w_constraints.tcl

report_process -i

# --- testbench and verification epilogue (template default) ---
set_app_var testbench_style symbolic
current_design -i rf_1r1w
set BENCH tb_func
set TYPE sym
write_testbench -replace "$BENCH"
set_active_testbench "$BENCH.$TYPE"

if {![verify]} {
  if { ![info exists debug_cmd]} {
    set debug_cmd "debug_design "
  }
  eval $debug_cmd
  report_log
  report_status
  quit
} else {
  report_assertion_coverage > sva_pass_cov.rpt
  report_assertion > sva_pass.rpt
  report_log
  report_status
  quit
}
