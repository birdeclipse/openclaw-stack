# Design Fact Ledger

session: ses-02-conflict
work item: case02
snapshot digest: ff0d004d3ce05eba5383bf5bfa049844548683e7557c5c87140432860342bb97
live facts: 12
retracted facts: 1
missing minimum fact kinds: edm

## Live facts

### Parsed

#### verilog

- fact 2
  top_design_name: rf_1r1w_wrapper
  filelist_location: design/rtl/rf.f
  vcs_options: -sverilog +define+RF_1R1W
  evidence: design/rtl/rf.f:1 '+define+RF_1R1W'; design/rtl/rf_1r1w_wrapper.sv:3 'module rf_1r1w_wrapper'

- fact 3
  top_design_name: rf_1r1w_wrapper
  filelist_location: design/rtl/rf_common.f
  verilog_file_location: design/rtl/rf_1r1w_wrapper.sv
  vcs_options: -sverilog -timescale=1ns/1ps
  evidence: design/rtl/rf_common.f:1-2 shared package sources; wrapper compiled from design/rtl/rf_1r1w_wrapper.sv

#### spice

- fact 1
  top_design_name: rf_1r1w
  spice_file_location: design/spice/rf_1r1w.cdl
  evidence: design/spice/rf_1r1w.cdl:18 .SUBCKT rf_1r1w CK CKB ... VDDPE VSS VDDAR_GATED

#### pin

- fact 5
  pin_name: CK
  direction: input
  function_type: clock
  allowed_values: 0 1
  value: high
  evidence: rf_1r1w datasheet p.5 table 2-1: 'CK - write clock, idles high, falling-edge capture'

- fact 6
  pin_name: CKB
  direction: input
  function_type: clock
  allowed_values: 0 1
  value: high
  evidence: rf_1r1w datasheet p.5 table 2-1: 'CKB - read clock, idles high'

- fact 7
  pin_name: DIN
  direction: input
  function_type: data
  allowed_values: 0,1,x
  value: low
  evidence: design/spice/rf_1r1w.cdl:18 port list 'DIN[15:0]'; datasheet p.5 'DIN - write data'

- fact 8
  pin_name: QOUT
  direction: output
  function_type: data
  evidence: design/spice/rf_1r1w.cdl:18 port list 'QOUT[15:0]'; datasheet p.5 'QOUT - read data'

#### supply

- fact 9
  supply_name: VDDPE
  subcircuit_name: rf_1r1w
  supply_type: real
  logic_type: 1
  evidence: design/spice/rf_1r1w.cdl:18 boundary port VDDPE

- fact 11
  supply_name: VSS
  supply_type: real
  logic_type: 0
  evidence: design/spice/rf_1r1w.cdl:18 boundary port VSS

- fact 12
  supply_name: VDDAR_GATED
  subcircuit_name: rf_1r1w_head
  supply_type: virtual
  logic_type: 1
  evidence: design/spice/rf_1r1w.cdl:96 MP_AR gated by RET inside rf_1r1w_head drives VDDAR_GATED

### Declared by the user

#### pin

- fact 4
  pin_name: CK
  direction: input
  function_type: clock
  allowed_values: 0 1
  value: low
  evidence: user statement in the request: 'CK idles low' - declared, no datasheet page opened for it

### Observed from the toolchain

#### supply

- fact 10
  supply_name: VDDPE
  subcircuit_name: rf_1r1w
  supply_type: real
  logic_type: 1
  evidence: esp report_potential_supply -i output line 12: 'VDDPE logic 1 real' - observed from the toolchain

## Retracted facts

- fact 13 (declared, supply)
  reason: VDDRET is not in the top-level port list; the name came from a comment, not from a port, so it was never observed
  supply_name: VDDRET
  subcircuit_name: rf_1r1w
  supply_type: real
  logic_type: 1
  evidence: assumed from the pin name while skimming design/spice/rf_1r1w.cdl
