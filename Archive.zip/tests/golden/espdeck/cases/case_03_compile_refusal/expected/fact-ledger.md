# Design Fact Ledger

session: ses-03-refusal
work item: case03
snapshot digest: e8af8ea1ba8a0a47e38a264348ab29075f301aec3533d3b6a58ade4c775122cb
live facts: 4
retracted facts: 1
missing minimum fact kinds: verilog, spice, pin

## Live facts

### Parsed

#### edm

- fact 3
  top_design_name: unnamed_macro
  edm_file_location: tech/n3.edm
  evidence: tech/n3.edm:1 'edm version=2' - the technology model was found, the two design views were not

### Declared by the user

#### supply

- fact 2
  supply_name: VDD
  supply_type: real
  logic_type: 1
  evidence: unnamed_macro datasheet p.2 supply table: 'VDD - core supply'; no netlist was located

#### function_corner

- fact 5
  corner_name: read-only
  statement: writes disabled, read enable asserted for the whole symbolic window
  evidence: user statement in the request: 'read-only corner first'

### Inferred by the reader

#### intent

- fact 4
  subject: verification scope
  statement: prove the read path only; the write path is covered by a separate deck
  evidence: user statement in the request: 'this run is read-path only'

## Retracted facts

- fact 1 (parsed, pin)
  reason: the pin table belongs to a different revision of the macro; no netlist confirmed CLK, so the fact was withdrawn
  pin_name: CLK
  direction: input
  function_type: clock
  allowed_values: 0 1
  value: low
  evidence: unnamed_macro datasheet p.2 pin table: 'CLK - clock input'
