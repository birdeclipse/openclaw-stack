# Design Fact Ledger

session: ses-01-full
work item: case01
snapshot digest: d22e6215456fd37bd6828af70714db1570349ef806bfec81e859c447bd2f6340
live facts: 16
retracted facts: 1

## Live facts

### Parsed

#### verilog

- fact 2
  top_design_name: sram_2p_hd
  filelist_location: design/rtl/sram_2p_hd.f
  vcs_options: -sverilog +define+SRAM_2P +incdir+design/rtl/inc
  evidence: design/rtl/sram_2p_hd.f:1-3 '+define+SRAM_2P', '+incdir+design/rtl/inc'

#### spice

- fact 1
  top_design_name: sram_2p_hd
  spice_file_location: design/spice/sram_2p_hd.cdl
  evidence: design/spice/sram_2p_hd.cdl:41 .SUBCKT sram_2p_hd CLKA CLKB ... VDD VSS VDDV

#### edm

- fact 3
  top_design_name: sram_2p_hd
  edm_file_location: tech/n5 models/n5.edm
  evidence: tech/n5 models/n5.edm:1 'edm version=2'

#### pin

- fact 4
  pin_name: CLKA
  direction: input
  function_type: clock
  allowed_values: 0 1
  value: low
  evidence: sram_2p_hd datasheet p.6 table 3-1: 'CLKA - port A clock, rising edge'

- fact 5
  pin_name: CENA
  direction: input
  function_type: enable
  allowed_values: 0 1
  value: low
  evidence: sram_2p_hd datasheet p.6 table 3-1: 'CENA - port A chip enable, active low'

- fact 7
  pin_name: AA
  direction: input
  function_type: address
  allowed_values: 0 1
  value: low
  evidence: design/spice/sram_2p_hd.cdl:41 port list 'AA[9:0]'; datasheet p.6 'AA - port A address'

- fact 8
  pin_name: DA
  direction: input
  function_type: data
  allowed_values: 0 1 X
  value: low
  evidence: design/spice/sram_2p_hd.cdl:41 port list 'DA[31:0]'; datasheet p.6 'DA - port A write data'

- fact 9
  pin_name: QB
  direction: output
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_2p_hd.cdl:41 port list 'QB[31:0]'; datasheet p.6 'QB - port B read data'

- fact 17
  pin_name: WENA
  direction: input
  function_type: control
  allowed_values: 0 1
  value: high
  evidence: sram_2p_hd datasheet p.7 table 3-2: 'WENA is active low; hold high to keep the array read-only during flush'

#### supply

- fact 11
  supply_name: VDD
  subcircuit_name: sram_2p_hd
  supply_type: real
  logic_type: 1
  evidence: design/spice/sram_2p_hd.cdl:41 boundary port VDD; datasheet p.4 'VDD - core supply'

- fact 12
  supply_name: VSS
  subcircuit_name: sram_2p_hd
  supply_type: real
  logic_type: 0
  evidence: design/spice/sram_2p_hd.cdl:41 boundary port VSS; datasheet p.4 'VSS - ground'

- fact 13
  supply_name: VDDV
  subcircuit_name: sram_2p_hd_header
  supply_type: virtual
  logic_type: 1
  evidence: design/spice/sram_2p_hd.cdl:212 MP_HEAD gated by SLPB inside sram_2p_hd_header drives VDDV

#### global_constraint

- fact 14
  pin_name: TESTMODE
  facts: tie low for the functional proof; the test path is out of scope for this deck
  evidence: sram_2p_hd datasheet p.11 section 5.1 'TESTMODE must be 0 in functional operation'

#### device

- fact 15
  device_name: MP_HEAD
  subcircuit_name: sram_2p_hd_header
  facts: periphery header, needs an instance strength multiplier of 2 to close the rail
  evidence: design/spice/sram_2p_hd.cdl:212 'MP_HEAD VDD VDDV SLPB VDD pch w=4u'

#### net

- fact 16
  net_name: VDDV
  subcircuit_name: sram_2p_hd_header
  facts: initial value 0 at time zero; the header walks it up during flush
  evidence: design/spice/sram_2p_hd.cdl:212 header output net VDDV

### Declared by the user

#### pin

- fact 10
  pin_name: SLPB
  direction: input
  function_type: PowerControl
  allowed_values: 0 1
  value: high
  evidence: sram_2p_hd datasheet p.9 section 4.2: 'SLPB low places the periphery in sleep'

## Retracted facts

- fact 6 (parsed, pin)
  reason: datasheet p.7 states WENA is active low, so a low flush value would write the array; re-logged as fact 17
  pin_name: WENA
  direction: input
  function_type: control
  allowed_values: 0 1
  value: low
  evidence: sram_2p_hd datasheet p.6 table 3-1: 'WENA - port A write enable'
