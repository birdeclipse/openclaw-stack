# sram_2p_hd ESP setup deck
# compiler setup-deck-compiler-v1, skeleton setup-deck-skeleton-v1
# fact snapshot d22e6215456fd37bd6828af70714db1570349ef806bfec81e859c447bd2f6340
# generated from the Design Fact Ledger; edit facts, not this file

# --- house application variables (template default) ---
set_app_var waveform_format fsdb
set_app_var verify_rcdelay_unit fs
set_app_var verify_delay_round_multiple 100
set_app_var verify_stop_on_randomize true
set_app_var verify_randomize_variables sysmem
set_app_var netlist_supply_by_connection off
set_app_var parser_verilog latest
set_app_var coverage true

# --- process / technology model ---
set_process -i -technology_file {tech/n5 models/n5.edm}

puts "INFO: READ REFERENCE DESIGN"
read_verilog -r -vcs "-sverilog +define+SRAM_2P +incdir+design/rtl/inc -timescale=1ns/1ps -f design/rtl/sram_2p_hd.f"
puts "INFO: READ IMPLEMENTATION DESIGN"
read_spice -i design/spice/sram_2p_hd.cdl

# --- top design ---
set_top_design -r sram_2p_hd
set_top_design -i sram_2p_hd

puts "INFO: SET SUPPLY NETS"
source -echo -verbose sram_2p_hd_supplies.tcl
report_potential_supply -i > supplies.rpt

puts "INFO: MATCH DESIGN PORTS"
set_matched_ports -i VDD
set_matched_ports -i VSS
match_design_ports
report_matched_ports
report_unmatched_ports

# --- timescale and clock (template defaults) ---
set_simulation_timescale 1 ns 1 ps
create_clock -period 5000 -setup 500 CLKA
report_clock

puts "INFO: SOURCE TESTBENCH PIN ATTRIBUTES"
source -echo -verbose sram_2p_hd_pin_attributes.tcl

report_process -i

# --- testbench and verification epilogue (template default) ---
set_app_var testbench_style symbolic
current_design -i sram_2p_hd
set BENCH tb_func
set TYPE sym
write_testbench -replace "$BENCH"
set_active_testbench "$BENCH.$TYPE"

if {![verify]} {
  if { ![info exists debug_cmd]} {
    set debug_cmd "debug_design "
  }
  eval $debug_cmd
  report_log
  report_status
  quit
} else {
  report_assertion_coverage > sva_pass_cov.rpt
  report_assertion > sva_pass.rpt
  report_log
  report_status
  quit
}
