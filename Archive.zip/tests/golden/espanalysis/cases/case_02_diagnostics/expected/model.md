# Setup deck model

- Entry deck: run.tcl
- Builder: esp.setup-model-builder 1
- Parser: esp.setup-static-parser 1
- Model digest: 0208d95c8874f3450a9fc8d39f99c6b52ac55b1bec83e61601437c706cb3c3d1

## Inventory

- Sources: 4
- Commands: 22
- Diagnostics: 17 (error 0, warning 17, info 0)

## Verification setup

- supply: vdd -type=real -logic=1 -i (run.tcl:30-30)
- supply: vdd -type=real -logic=0 -i (run.tcl:31-31)
- supply: vss -type=real -logic=0 -i (run.tcl:32-32)
- clock: CLK -period=10 -setup=2 (run.tcl:35-35)
- clock: CLK -period=20 -setup=4 (run.tcl:36-36)
- constraint: -set=1'b0 -cycle=BINCYCLE1 (run.tcl:40-40)
- constraint: -cycle=SYMCYCLE1 (run.tcl:41-41)
- constraint: CE -set=1'b1 -cycle=BINCYCLE1 (run.tcl:44-44)
- check: (none) (run.tcl:55-55)

## Cycle plan facts

- cycle_assignment: BINCYCLE1 (run.tcl:40-40)
- cycle_check: SYMCYCLE1 (run.tcl:41-41)
- cycle_assignment: CE BINCYCLE1 (run.tcl:44-44)

## HDL structure

- Selected top: none captured
- Ports: none captured
- Scanner findings: 1
  - HDL-TOP-AMBIGUOUS: no unique top candidate is available (none captured)

## Coverage and unresolved

- BOUNDS-LIMIT-REACHED: 0
- CATALOG-ARGUMENT-UNRESOLVED: 0
- CATALOG-NO-OPTION-SPEC: 0
- DEFERRED-CONTAINED-TCL: 0
- DEFERRED-SEMANTIC-HDL: 0
- DEFERRED-SPICE: 1
- FILELIST-CYCLE: 0
- FILELIST-DEPTH: 0
- FILELIST-UNSUPPORTED-FORM: 0
- HDL-COMPLEX-PORT-TYPE: 0
- HDL-ESCAPED-IDENTIFIER: 0
- HDL-NONANSI-PARTIAL: 0
- HDL-PREPROCESSING-DEPENDENT: 0
- HDL-TOP-AMBIGUOUS: 1
- HDL-TOP-DECLARED-MISSING: 0
- HDL-TOP-INFERRED-SOLE-CANDIDATE: 0
- RV-DYNAMIC-ARGUMENT: 0
- RV-EMBEDDED-OPTION-VECTOR: 0
- SOURCE-MISSING: 3
- SOURCE-ROOT-ESCAPE: 0
- SOURCE-SYMLINK: 0
- TCL-BRACKET-GUARD: 0
- TCL-CONTROL-REGION: 0
- TCL-DYNAMIC: 3
- TCL-UNBALANCED: 0

## Bounds

no bound reached

## Detail documents

- diagnostics.md: 17 rows (one per deterministic diagnostic)
- model-sources.md: 4 rows (one per reachable source)
- model-commands.md: 22 rows (one per normalized command occurrence)
- model-boundary.md: 3 rows (one per pin the deck names or the boundary exports)
