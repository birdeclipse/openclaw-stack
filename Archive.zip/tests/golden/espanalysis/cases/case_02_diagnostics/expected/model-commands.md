# Deck commands

- Model digest: 0208d95c8874f3450a9fc8d39f99c6b52ac55b1bec83e61601437c706cb3c3d1
- Rows: 22 (one per normalized command occurrence)
- Bounds: command_count not reached

| Flow order | Command | Arguments | Resolution | Source span |
|---|---|---|---|---|
| 0 | source | loop.tcl | unknown | run.tcl:12-12 |
| 1 | source | absent.tcl | unknown | run.tcl:15-15 |
| 2 | source | $::env(CASE02_SITE_TCL) | dynamic | run.tcl:19-19 |
| 3 | read_verilog | -r rtl/case02_top.v | resolved | run.tcl:21-21 |
| 4 | read_verilog | -f filelists/rtl.f | resolved | run.tcl:22-22 |
| 5 | read_spice | -i spice/case02_top.sp | resolved | run.tcl:23-23 |
| 6 | set_supply_net | -i -type real -logic 1 vdd | resolved | run.tcl:30-30 |
| 7 | set_supply_net | -i -type real -logic 0 vdd | resolved | run.tcl:31-31 |
| 8 | set_supply_net | -i -type real -logic 0 vss | resolved | run.tcl:32-32 |
| 9 | create_clock | -period 10 -setup 2 CLK | resolved | run.tcl:35-35 |
| 10 | create_clock | -period 20 -setup 4 CLK | resolved | run.tcl:36-36 |
| 11 | set_constraint | -set 1'b0 -cycle BINCYCLE1 | resolved | run.tcl:40-40 |
| 12 | set_constraint | -cycle SYMCYCLE1 | resolved | run.tcl:41-41 |
| 13 | set_constraint | CE -set 1'b1 -cycle BINCYCLE1 | resolved | run.tcl:44-44 |
| 14 | set_testbench_pin_attributes | CLK -function clock | resolved | run.tcl:46-46 |
| 15 | set_testbench_pin_attributes | CE -function chipen | resolved | run.tcl:47-47 |
| 16 | set_testbench_pin_attributes | ADDR -function address | resolved | run.tcl:48-48 |
| 17 | esp_enable_turbo_mode | (none) | unknown | run.tcl:51-51 |
| 18 | set_undocumented_option | -value 3 | unknown | run.tcl:52-52 |
| 19 | report_nonexistent_thing | (none) | unknown | run.tcl:53-53 |
| 20 | check_design | (none) | resolved | run.tcl:55-55 |
| 21 | source | run.tcl | unknown | loop.tcl:3-3 |
