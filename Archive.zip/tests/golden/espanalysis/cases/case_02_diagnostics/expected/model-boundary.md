# Deck boundary

- Model digest: 0208d95c8874f3450a9fc8d39f99c6b52ac55b1bec83e61601437c706cb3c3d1
- Pins: 3 rows, 3 off boundary, 0 out of range
- Supplies: 3 rows

## Pins

| Pin | Boundary | Function | Group | Constraint | Timing |
|---|---|---|---|---|---|
| ADDR | absent | -function address | (none) | (none) | (none) |
| CE | absent | -function chipen | (none) | -set 1'b1 -cycle BINCYCLE1 (run.tcl:44) | (none) |
| CLK | absent | -function clock | (none) | (none) | create_clock -period 10 -setup 2; create_clock -period 20 -setup 4 |

## Supplies

| Rail | Type | Logic | Subcircuit | Status |
|---|---|---|---|---|
| vdd | real | 1 | (none) | declared |
| vdd | real | 0 | (none) | declared |
| vss | real | 0 | (none) | declared |
