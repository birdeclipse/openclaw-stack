# Deck sources

- Model digest: 0208d95c8874f3450a9fc8d39f99c6b52ac55b1bec83e61601437c706cb3c3d1
- Rows: 4 (one per reachable source)
- Bounds: file_count not reached

| Relative path | Digest | Role | Parse status | Reached from |
|---|---|---|---|---|
| run.tcl | 54e3a38bc6e5706d23d8aabc90836dadf221185cb752889d947dc1bee585899f | deck | scanned | (entry) |
| loop.tcl | 3d982240bcdfec6b7b2da9fc1ad1c1c7cc6a0cac2f6db0dcb9e2923ef7c570f2 | source-deck | scanned | run.tcl |
| rtl/case02_top.v | 5aacef44d502a12c0d548083e48e3658ce4ff426d829884a58ecde20ef81c1ba | rtl | opaque | run.tcl |
| filelists/rtl.f | d40ebb9e1c798ba68f3064f1dbba54028bedec57bec453d568456d739f08c2ef | filelist | opaque | run.tcl |
