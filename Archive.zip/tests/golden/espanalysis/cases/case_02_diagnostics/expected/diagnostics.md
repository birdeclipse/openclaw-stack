# Deck diagnostics

- Model digest: 0208d95c8874f3450a9fc8d39f99c6b52ac55b1bec83e61601437c706cb3c3d1
- Diagnostics: 17 (error 0, warning 17, info 0)

## 1. ESP-F3-HDL-TOP-AMBIGUOUS (warning)

- Diagnostic ID: diag-b1e50532f131e7a0
- Message: No unique HDL top declaration
- Source span: none captured

## 2. AA-SRC-MISSING (warning)

- Diagnostic ID: diag-2c9a1a3fbe0d98a2
- Message: Declared source does not exist
- Source span: filelists/rtl.f:3-3
- Source: filelists/rtl.f

## 3. AA-SRC-MISSING (warning)

- Diagnostic ID: diag-4ba34139a0c2cee7
- Message: Declared source does not exist
- Source span: filelists/rtl.f:4-4
- Source: filelists/rtl.f

## 4. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-b9a41b1e22f3f3d0
- Message: Unknown static Tcl command
- Source span: loop.tcl:3-3

## 5. AA-SRC-CYCLE (warning)

- Diagnostic ID: diag-c7813557077669ce
- Message: Tcl source cycle
- Source span: loop.tcl:3-3
- Source: loop.tcl

## 6. ESP-F3-TOP-MISSING (warning)

- Diagnostic ID: diag-fdaeb55ed57c4fef
- Message: No resolved top design declaration
- Source span: run.tcl:12-12

## 7. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-3ac8f273a3420e95
- Message: Unknown static Tcl command
- Source span: run.tcl:12-12

## 8. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-895653abb2c83e4b
- Message: Unknown static Tcl command
- Source span: run.tcl:15-15

## 9. AA-SRC-MISSING (warning)

- Diagnostic ID: diag-7a6104d04b481322
- Message: Declared source does not exist
- Source span: run.tcl:15-15
- Source: run.tcl

## 10. AA-SRC-DYNAMIC (warning)

- Diagnostic ID: diag-18b5bac9629482a6
- Message: Dynamic Tcl source path
- Source span: run.tcl:19-19
- Source: run.tcl

## 11. ESP-F3-SUPPLY-CONFLICT (warning)

- Diagnostic ID: diag-da0965e49520fed1
- Message: Supply has conflicting logic values
- Source span: run.tcl:31-31

## 12. ESP-F3-CLOCK-CONFLICT (warning)

- Diagnostic ID: diag-714b209f3b84230d
- Message: Clock has conflicting periods
- Source span: run.tcl:36-36

## 13. ESP-F3-CYCLE-INCOMPLETE (warning)

- Diagnostic ID: diag-04af204872ad1074
- Message: Cycle fact lacks a pin or label
- Source span: run.tcl:40-40

## 14. ESP-F3-CYCLE-INCOMPLETE (warning)

- Diagnostic ID: diag-2068ff9214b51dba
- Message: Cycle fact lacks a pin or label
- Source span: run.tcl:41-41

## 15. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-6754ab3fec9a9636
- Message: Unknown static Tcl command
- Source span: run.tcl:51-51

## 16. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-e07b0eaba714d985
- Message: Unknown static Tcl command
- Source span: run.tcl:52-52

## 17. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-a4556d6095d45960
- Message: Unknown static Tcl command
- Source span: run.tcl:53-53
