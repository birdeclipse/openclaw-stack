// case_02 RTL: TWO module declarations on purpose, so no unique HDL top can be
// selected and the scanner reports HDL-TOP-AMBIGUOUS.
module case02_top (CLK, CE, ADDR, DIN, DOUT);
  input CLK, CE;
  input [4:0] ADDR;
  input [7:0] DIN;
  output [7:0] DOUT;

  reg [7:0] data_r;

  always @(posedge CLK) if (CE) data_r <= DIN;

  assign DOUT = data_r;
endmodule

module case02_shadow (CLK, Q);
  input CLK;
  output Q;
  reg q_r;

  always @(posedge CLK) q_r <= ~q_r;

  assign Q = q_r;
endmodule
