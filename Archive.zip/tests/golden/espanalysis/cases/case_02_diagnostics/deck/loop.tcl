## The other half of the deliberate source cycle: this file sources the entry
## deck, so the locator has to detect the cycle rather than recurse.
source run.tcl
