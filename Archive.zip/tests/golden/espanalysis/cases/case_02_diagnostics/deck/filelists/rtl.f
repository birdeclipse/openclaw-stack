# case_02 filelist: one real source and one that does not exist, so the
# filelist walk contributes an rtl row AND a missing-source diagnostic.
rtl/case02_top.v
rtl/case02_absent.v
