* case_02 SPICE: the implementation container read_spice -i names.
.subckt case02_top CLK CE ADDR DIN DOUT vdd vss
M1 DOUT DIN vdd vdd pmos_lvt
M2 DOUT DIN vss vss nmos_lvt
.ends case02_top
