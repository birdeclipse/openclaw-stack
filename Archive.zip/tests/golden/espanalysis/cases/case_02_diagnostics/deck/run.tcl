## case_02 -- a deck built to trip the deterministic diagnostics.
##
## Every defect below is deliberate and named in the comment above it. This is
## the fixture that pins the diagnostics renderer, so a rule that stops firing
## is a golden diff rather than a silent regression.
##
## `source` is itself absent from the reviewed catalog -- it is a Tcl builtin,
## not an ESP command -- so every line below also contributes one
## ESP-F3-UNKNOWN-COMMAND. That is the scanner being literal, not a defect.

# AA-SRC-CYCLE: loop.tcl sources this file straight back.
source loop.tcl

# AA-SRC-MISSING: nothing at that path.
source absent.tcl

# AA-SRC-DYNAMIC: a path the scanner refuses to evaluate. It never runs the
# deck, so an environment lookup is a fact about the deck, not a value.
source $::env(CASE02_SITE_TCL)

read_verilog -r rtl/case02_top.v
read_verilog -f filelists/rtl.f
read_spice -i spice/case02_top.sp

# ESP-F3-TOP-MISSING: nothing declares a top design, and the RTL below carries
# two module declarations, so the HDL scanner cannot pick one either
# (ESP-F3-HDL-TOP-AMBIGUOUS).

# ESP-F3-SUPPLY-CONFLICT: vdd is declared with both logic values.
set_supply_net -i -type real -logic 1 vdd
set_supply_net -i -type real -logic 0 vdd
set_supply_net -i -type real -logic 0 vss

# ESP-F3-CLOCK-CONFLICT: CLK gets two periods.
create_clock -period 10 -setup 2 CLK
create_clock -period 20 -setup 4 CLK

# ESP-F3-CYCLE-INCOMPLETE: -cycle with no positional pin, so the lifted cycle
# fact carries the label alone.
set_constraint -set {1'b0} -cycle BINCYCLE1
set_constraint -cycle SYMCYCLE1

# A well-formed constraint, so the inventory has a row that is not a defect.
set_constraint CE -set {1'b1} -cycle BINCYCLE1

set_testbench_pin_attributes CLK -function clock
set_testbench_pin_attributes CE -function chipen
set_testbench_pin_attributes ADDR -function address

# ESP-F3-UNKNOWN-COMMAND: none of these three is in the reviewed catalog.
esp_enable_turbo_mode
set_undocumented_option -value 3
report_nonexistent_thing

check_design
