# case_03 deck tree

Deliberately holds no `.tcl` file. The case names `absent_deck.tcl` as the entry
deck, so `builder._read_entry` gets a `not_found` from the source reader on the
very first read and the whole build fails closed — which is the failure the
`not_found` refusal reason exists for.

This file is here so git tracks the directory. It is never read by the analyzer:
the entry deck the case names does not exist, which is the point.
