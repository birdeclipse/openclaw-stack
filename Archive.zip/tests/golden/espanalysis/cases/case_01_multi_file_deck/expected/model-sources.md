# Deck sources

- Model digest: 869c6a21ec9b28d4939fdfeae33ca56d36423c5ec79d7fdfd88de3a58a8b8876
- Rows: 13 (one per reachable source)
- Bounds: file_count not reached

| Relative path | Digest | Role | Parse status | Reached from |
|---|---|---|---|---|
| run.tcl | f8d282ef571569597b7bd425ab88f060ea4c832e6aeaec57434750f92795e3fd | deck | scanned | (entry) |
| env/prelude.tcl | fe037169c5574cb5a0ab7811e1a1841e702e906814a4e7bbff360fb94ee3dff0 | source-deck | scanned | run.tcl |
| cfg/read_design.tcl | 1fe9bb460d79019099872bd4a8ec75343f924bba9ed052c91635acd698078166 | source-deck | scanned | run.tcl |
| cfg/rtl/t6_top.v | 3a9615f8713317b36b96f527bce35c003e3d1d1a387c76f3699c9510f4359a9e | rtl | opaque | cfg/read_design.tcl |
| cfg/rtl/t6_core.v | cfc049c7e21f5b3d8e81877c0265369dcf5e03dc6075187db7085f4af8da92c1 | rtl | opaque | cfg/read_design.tcl |
| cfg/supplies.tcl | 06e69ff10fc8f70cbc03b289ad4a33dd02cd36f4334489411c7630952393e134 | source-deck | scanned | run.tcl |
| cfg/tb_config.tcl | 5657cd5f16972fb6af9f0d22ceef932995d731fc2ead6cb3f3bfd6ae154616c5 | source-deck | scanned | run.tcl |
| cfg/tb_overrides.tcl | 635e879f729e4890eff70a9f777b0811dff45e5182bc31ae46601e17e21cfad0 | source-deck | scanned | run.tcl |
| cfg/constraints_cycles.tcl | d34d6bcab0b6b21f61264cd16a2f1ddabc21ef991145c1c555962d16fefca190 | source-deck | scanned | run.tcl |
| cfg/constraints_modes.tcl | 2a9e3287cfddacda8643e223159e01e1101312eb0f7a60c90aebfd7cfaf4c6c6 | source-deck | scanned | run.tcl |
| cfg/generated_banks.tcl | dfd65c1856a6f7f5b32e4798f4acf7b7479623fdb4d5f312d3302a18310d2563 | source-deck | scanned | run.tcl |
| cfg/symbols.tcl | 5e6384d5332fa65f35bf8842c1cf562ac48db005bb7da00bd3b4eec0eb78948b | source-deck | scanned | run.tcl |
| run/execute.tcl | b0af5f27843442895a74289c4b66c2123369f56e1fec243e293e423e2d79f170 | source-deck | scanned | run.tcl |
