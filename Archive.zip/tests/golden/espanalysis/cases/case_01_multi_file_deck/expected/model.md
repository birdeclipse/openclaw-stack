# Setup deck model

- Entry deck: run.tcl
- Builder: esp.setup-model-builder 1
- Parser: esp.setup-static-parser 1
- Model digest: 869c6a21ec9b28d4939fdfeae33ca56d36423c5ec79d7fdfd88de3a58a8b8876

## Inventory

- Sources: 13
- Commands: 88
- Diagnostics: 18 (error 0, warning 18, info 0)

## Verification setup

- top_design: t6_top -r (cfg/read_design.tcl:18-18)
- top_design: t6_top_XTOR -i (cfg/read_design.tcl:19-19)
- supply: vdd -design=t6_core_XTOR -type=real -logic=1 -i (cfg/supplies.tcl:4-4)
- supply: vss -design=t6_core_XTOR -type=real -logic=0 -i (cfg/supplies.tcl:5-5)
- clock: clk -period=10 -setup=3 -initial=1 -clktype=primary (cfg/tb_config.tcl:16-16)
- constraint: ce -set=1'b1 (cfg/constraints_cycles.tcl:8-8)
- constraint: din -set=8'h11 -cycle=BINCYCLE1 (cfg/constraints_cycles.tcl:13-13)
- constraint: din -set=8'h22 -cycle=BINCYCLE2 (cfg/constraints_cycles.tcl:14-14)
- constraint: din -set=8'h33 -cycle=BINCYCLE3 (cfg/constraints_cycles.tcl:15-15)
- constraint: din -set=8'h44 -cycle=BINCYCLE4 (cfg/constraints_cycles.tcl:16-16)
- constraint: wen -set=1'b0 -if=inno_cycle == "SYMCYCLE1" (cfg/constraints_cycles.tcl:22-22)
- constraint: wen -set=1'b0 -cycle=SYMCYCLE1 (cfg/constraints_cycles.tcl:23-23)
- constraint: ce -set=1'b0 -if=(inno_cycle[79:16]=="BINCYCLE")||(inno_cycle[71:8]=="BINCYCLE") (cfg/constraints_cycles.tcl:29-29)
- constraint: ce -set=1'b1 -if=(inno_cycle[79:16]=="SYMCYCLE")||(inno_cycle[71:8]=="SYMCYCLE") (cfg/constraints_cycles.tcl:30-30)
- constraint: din -set=8'h00 -if=tm == 2'b01 (cfg/constraints_modes.tcl:12-12)
- constraint: din -set=8'hff -if=tm == 2'b10 (cfg/constraints_modes.tcl:13-13)
- constraint: mode_a -set=1'b1 -if=tm == 2'b00 (cfg/constraints_modes.tcl:21-21)
- constraint: mode_b -set=1'b1 -if=tm == 2'b01 (cfg/constraints_modes.tcl:22-22)
- constraint: mode_c -set=1'b1 -if=tm == 2'b10 (cfg/constraints_modes.tcl:23-23)
- constraint: mode_d -set=1'b1 -if=tm == 2'b11 (cfg/constraints_modes.tcl:24-24)
- constraint: dout -check_num=1 2 -cycle=BINCYCLE1 -ignore (cfg/constraints_modes.tcl:30-30)
- constraint: banksel0 banksel1 banksel2 banksel3 -1hot (cfg/symbols.tcl:8-8)
- constraint: alwaysIgnored_DOUT[3] -set=0 (cfg/symbols.tcl:9-9)
- constraint: trimsel0 trimsel1 -symbolic_static (cfg/symbols.tcl:21-21)
- constraint: sleep -set=1'b0 (cfg/symbols.tcl:27-27)
- constraint: iso -set=1'b0 (cfg/symbols.tcl:28-28)
- constraint: ret -set=1'b0 (cfg/symbols.tcl:29-29)
- constraint: bisten -set=1'b0 (cfg/symbols.tcl:30-30)
- constraint: dftmode -set=1'b0 (cfg/symbols.tcl:31-31)
- constraint: pwrgate -set=1'b1 (cfg/symbols.tcl:32-32)
- constraint: addr -mask=4'b00.. (cfg/symbols.tcl:40-40)
- check: (none) (run/execute.tcl:6-6)
- check: (none) (run/execute.tcl:13-13)

## Cycle plan facts

- cycle_assignment: din BINCYCLE1 (cfg/constraints_cycles.tcl:13-13)
- cycle_assignment: din BINCYCLE2 (cfg/constraints_cycles.tcl:14-14)
- cycle_assignment: din BINCYCLE3 (cfg/constraints_cycles.tcl:15-15)
- cycle_assignment: din BINCYCLE4 (cfg/constraints_cycles.tcl:16-16)
- cycle_assignment: wen SYMCYCLE1 (cfg/constraints_cycles.tcl:23-23)
- cycle_check: dout BINCYCLE1 (cfg/constraints_modes.tcl:30-30)
- check_event: dout 1 2 (cfg/constraints_modes.tcl:30-30)

## HDL structure

- Selected top: t6_top
- Ports: 24
  - clk input (no declared width) (cfg/rtl/t6_top.v:7-7)
  - rstb input (no declared width) (cfg/rtl/t6_top.v:8-8)
  - ce input (no declared width) (cfg/rtl/t6_top.v:9-9)
  - wen input (no declared width) (cfg/rtl/t6_top.v:10-10)
  - tm input [1:0] (cfg/rtl/t6_top.v:11-11)
  - addr input [3:0] (cfg/rtl/t6_top.v:12-12)
  - din input [7:0] (cfg/rtl/t6_top.v:13-13)
  - dout output [7:0] (cfg/rtl/t6_top.v:14-14)
  - banksel0 input (no declared width) (cfg/rtl/t6_top.v:15-15)
  - banksel1 input (no declared width) (cfg/rtl/t6_top.v:16-16)
  - banksel2 input (no declared width) (cfg/rtl/t6_top.v:17-17)
  - banksel3 input (no declared width) (cfg/rtl/t6_top.v:18-18)
  - trimsel0 input (no declared width) (cfg/rtl/t6_top.v:19-19)
  - trimsel1 input (no declared width) (cfg/rtl/t6_top.v:20-20)
  - sleep input (no declared width) (cfg/rtl/t6_top.v:21-21)
  - iso input (no declared width) (cfg/rtl/t6_top.v:22-22)
  - ret input (no declared width) (cfg/rtl/t6_top.v:23-23)
  - bisten input (no declared width) (cfg/rtl/t6_top.v:24-24)
  - dftmode input (no declared width) (cfg/rtl/t6_top.v:25-25)
  - pwrgate input (no declared width) (cfg/rtl/t6_top.v:26-26)
  - mode_a input (no declared width) (cfg/rtl/t6_top.v:27-27)
  - mode_b input (no declared width) (cfg/rtl/t6_top.v:28-28)
  - mode_c input (no declared width) (cfg/rtl/t6_top.v:29-29)
  - mode_d input (no declared width) (cfg/rtl/t6_top.v:30-30)
- Scanner findings: none captured

## Coverage and unresolved

- BOUNDS-LIMIT-REACHED: 0
- CATALOG-ARGUMENT-UNRESOLVED: 0
- CATALOG-NO-OPTION-SPEC: 18
- DEFERRED-CONTAINED-TCL: 0
- DEFERRED-SEMANTIC-HDL: 0
- DEFERRED-SPICE: 1
- FILELIST-CYCLE: 0
- FILELIST-DEPTH: 0
- FILELIST-UNSUPPORTED-FORM: 0
- HDL-COMPLEX-PORT-TYPE: 0
- HDL-ESCAPED-IDENTIFIER: 0
- HDL-NONANSI-PARTIAL: 0
- HDL-PREPROCESSING-DEPENDENT: 0
- HDL-TOP-AMBIGUOUS: 0
- HDL-TOP-DECLARED-MISSING: 0
- HDL-TOP-INFERRED-SOLE-CANDIDATE: 0
- RV-DYNAMIC-ARGUMENT: 0
- RV-EMBEDDED-OPTION-VECTOR: 0
- SOURCE-MISSING: 0
- SOURCE-ROOT-ESCAPE: 0
- SOURCE-SYMLINK: 0
- TCL-BRACKET-GUARD: 0
- TCL-CONTROL-REGION: 2
- TCL-DYNAMIC: 8
- TCL-UNBALANCED: 0

## Bounds

no bound reached

## Detail documents

- diagnostics.md: 18 rows (one per deterministic diagnostic)
- model-sources.md: 13 rows (one per reachable source)
- model-commands.md: 88 rows (one per normalized command occurrence)
- model-boundary.md: 29 rows (one per pin the deck names or the boundary exports)
