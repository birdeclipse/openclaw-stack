# Deck boundary

- Model digest: 869c6a21ec9b28d4939fdfeae33ca56d36423c5ec79d7fdfd88de3a58a8b8876
- Pins: 29 rows, 1 off boundary, 0 out of range
- Supplies: 2 rows

## Pins

| Pin | Boundary | Function | Group | Constraint | Timing |
|---|---|---|---|---|---|
| addr | input [3:0] | (none) | (none) | -mask 4'b00.. (cfg/symbols.tcl:40) | set_input_delay -delay 2.5 |
| banksel0 | input 1 | (none) | (none) | -1hot (cfg/symbols.tcl:8) | (none) |
| banksel1 | input 1 | (none) | (none) | -1hot (cfg/symbols.tcl:8) | (none) |
| banksel2 | input 1 | (none) | (none) | -1hot (cfg/symbols.tcl:8) | (none) |
| banksel3 | input 1 | (none) | (none) | -1hot (cfg/symbols.tcl:8) | (none) |
| bisten | input 1 | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:30) | (none) |
| ce | input 1 | -function chipen | CORE | -set 1'b1 (cfg/constraints_cycles.tcl:8); -set 1'b0 -if (inno_cycle[79:16]=="BINCYCLE")\|\|(inno_cycle[71:8]=="BINCYCLE") (cfg/constraints_cycles.tcl:29); -set 1'b1 -if (inno_cycle[79:16]=="SYMCYCLE")\|\|(inno_cycle[71:8]=="SYMCYCLE") (cfg/constraints_cycles.tcl:30) | (none) |
| clk | input 1 | -function clock | CORE | (none) | create_clock -period 10 -setup 3 -initial 1 -clktype primary |
| dftmode | input 1 | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:31) | (none) |
| din | input [7:0] | (none) | (none) | -set 8'h11 -cycle BINCYCLE1 (cfg/constraints_cycles.tcl:13); -set 8'h22 -cycle BINCYCLE2 (cfg/constraints_cycles.tcl:14); -set 8'h33 -cycle BINCYCLE3 (cfg/constraints_cycles.tcl:15); -set 8'h44 -cycle BINCYCLE4 (cfg/constraints_cycles.tcl:16); -set 8'h00 -if tm == 2'b01 (cfg/constraints_modes.tcl:12); -set 8'hff -if tm == 2'b10 (cfg/constraints_modes.tcl:13) | (none) |
| dout | output [7:0] | (none) | (none) | -check_num 1 2 -cycle BINCYCLE1 -ignore (cfg/constraints_modes.tcl:30) | (none) |
| iso | input 1 | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:28) | (none) |
| mode_a | input 1 | (none) | (none) | -set 1'b1 -if tm == 2'b00 (cfg/constraints_modes.tcl:21) | (none) |
| mode_b | input 1 | (none) | (none) | -set 1'b1 -if tm == 2'b01 (cfg/constraints_modes.tcl:22) | (none) |
| mode_c | input 1 | (none) | (none) | -set 1'b1 -if tm == 2'b10 (cfg/constraints_modes.tcl:23) | (none) |
| mode_d | input 1 | (none) | (none) | -set 1'b1 -if tm == 2'b11 (cfg/constraints_modes.tcl:24) | (none) |
| pwrgate | input 1 | (none) | (none) | -set 1'b1 (cfg/symbols.tcl:32) | (none) |
| ret | input 1 | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:29) | (none) |
| rstb | input 1 | -function reset; -value low | CORE | (none) | (none) |
| sleep | input 1 | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:27) | (none) |
| tm | input [1:0] | (none) | (none) | (none) | (none) |
| trimsel0 | input 1 | (none) | (none) | -symbolic_static (cfg/symbols.tcl:21) | (none) |
| trimsel1 | input 1 | (none) | (none) | -symbolic_static (cfg/symbols.tcl:21) | (none) |
| wen | input 1 | -function write | CORE | -set 1'b0 -if inno_cycle == "SYMCYCLE1" (cfg/constraints_cycles.tcl:22); -set 1'b0 -cycle SYMCYCLE1 (cfg/constraints_cycles.tcl:23) | (none) |
| addr[0] | input [3:0] | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:36) | (none) |
| addr[1] | input [3:0] | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:37) | (none) |
| addr[2] | input [3:0] | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:38) | (none) |
| addr[3] | input [3:0] | (none) | (none) | -set 1'b0 (cfg/symbols.tcl:39) | (none) |
| alwaysIgnored_DOUT[3] | absent | (none) | (none) | -set 0 (cfg/symbols.tcl:9) | (none) |

## Supplies

| Rail | Type | Logic | Subcircuit | Status |
|---|---|---|---|---|
| vdd | real | 1 | t6_core_XTOR | declared |
| vss | real | 0 | t6_core_XTOR | declared |
