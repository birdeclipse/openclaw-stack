# Deck diagnostics

- Model digest: 869c6a21ec9b28d4939fdfeae33ca56d36423c5ec79d7fdfd88de3a58a8b8876
- Diagnostics: 18 (error 0, warning 18, info 0)

## 1. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-47a06ca2a604b161
- Message: Unknown static Tcl command
- Source span: cfg/generated_banks.tcl:8-10

## 2. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-e033f9b3b2d5c552
- Message: Unknown static Tcl command
- Source span: cfg/generated_banks.tcl:12-14

## 3. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-596d645070a942ed
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:9-9

## 4. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-63c285fdd360e2e7
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:10-10

## 5. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-2ac1775e5f7985fb
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:11-11

## 6. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-5b2a4772b6128b59
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:12-12

## 7. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-2da9cdf5415f6616
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:16-16

## 8. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-0559bedff79eae37
- Message: Unknown static Tcl command
- Source span: env/prelude.tcl:18-18

## 9. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-a53db723bd23d28e
- Message: Unknown static Tcl command
- Source span: run.tcl:4-4

## 10. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-4a69a884f3787167
- Message: Unknown static Tcl command
- Source span: run.tcl:5-5

## 11. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-80c7eea974c797fa
- Message: Unknown static Tcl command
- Source span: run.tcl:6-6

## 12. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-487effe4f44ea90d
- Message: Unknown static Tcl command
- Source span: run.tcl:7-7

## 13. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-17e2651cbaf57dd0
- Message: Unknown static Tcl command
- Source span: run.tcl:8-8

## 14. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-d13b4daf58bd6803
- Message: Unknown static Tcl command
- Source span: run.tcl:9-9

## 15. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-b2732e7c46d5201f
- Message: Unknown static Tcl command
- Source span: run.tcl:10-10

## 16. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-d5234d95bb6dfac8
- Message: Unknown static Tcl command
- Source span: run.tcl:11-11

## 17. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-d9a12ac54339281a
- Message: Unknown static Tcl command
- Source span: run.tcl:12-12

## 18. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-0df6c139b50ff38d
- Message: Unknown static Tcl command
- Source span: run.tcl:13-13
