# Deck commands

- Model digest: 869c6a21ec9b28d4939fdfeae33ca56d36423c5ec79d7fdfd88de3a58a8b8876
- Rows: 88 (one per normalized command occurrence)
- Bounds: command_count not reached

| Flow order | Command | Arguments | Resolution | Source span |
|---|---|---|---|---|
| 0 | source | env/prelude.tcl | unknown | run.tcl:4-4 |
| 1 | source | cfg/read_design.tcl | unknown | run.tcl:5-5 |
| 2 | source | cfg/supplies.tcl | unknown | run.tcl:6-6 |
| 3 | source | cfg/tb_config.tcl | unknown | run.tcl:7-7 |
| 4 | source | cfg/tb_overrides.tcl | unknown | run.tcl:8-8 |
| 5 | source | cfg/constraints_cycles.tcl | unknown | run.tcl:9-9 |
| 6 | source | cfg/constraints_modes.tcl | unknown | run.tcl:10-10 |
| 7 | source | cfg/generated_banks.tcl | unknown | run.tcl:11-11 |
| 8 | source | cfg/symbols.tcl | unknown | run.tcl:12-12 |
| 9 | source | run/execute.tcl | unknown | run.tcl:13-13 |
| 10 | set_app_var | sh_continue_on_error false | opaque | env/prelude.tcl:4-4 |
| 11 | set_app_var | sh_source_uses_search_path true | opaque | env/prelude.tcl:5-5 |
| 12 | set_app_var | sh_new_variable_message false | opaque | env/prelude.tcl:6-6 |
| 13 | set | search_path . | unknown | env/prelude.tcl:9-9 |
| 14 | lappend | search_path env | unknown | env/prelude.tcl:10-10 |
| 15 | lappend | search_path cfg | unknown | env/prelude.tcl:11-11 |
| 16 | lappend | search_path run | unknown | env/prelude.tcl:12-12 |
| 17 | suppress_message | ESPTB-091 | unknown | env/prelude.tcl:16-16 |
| 18 | alias | rl report_log | unknown | env/prelude.tcl:18-18 |
| 19 | set_app_var | netlist_port_bus off | opaque | cfg/read_design.tcl:4-4 |
| 20 | set_app_var | netlist_bus_extraction_style %s<%d> | opaque | cfg/read_design.tcl:5-5 |
| 21 | read_verilog | -r rtl/t6_top.v | resolved | cfg/read_design.tcl:12-12 |
| 22 | read_verilog | -r rtl/t6_core.v | resolved | cfg/read_design.tcl:13-13 |
| 23 | read_spice | -i spice/t6_core.sp | resolved | cfg/read_design.tcl:14-14 |
| 24 | set_hierarchy_separator | / | resolved | cfg/read_design.tcl:16-16 |
| 25 | set_top_design | -r t6_top | resolved | cfg/read_design.tcl:18-18 |
| 26 | set_top_design | -i t6_top_XTOR | resolved | cfg/read_design.tcl:19-19 |
| 27 | match_designs | (none) | resolved | cfg/read_design.tcl:21-21 |
| 28 | match_design_ports | (none) | resolved | cfg/read_design.tcl:22-22 |
| 29 | set_simulation_timescale | 1 ns 1 ps | resolved | cfg/read_design.tcl:24-24 |
| 30 | set_supply_net | -i -design t6_core_XTOR -type real -logic 1 vdd | resolved | cfg/supplies.tcl:4-4 |
| 31 | set_supply_net | -i -design t6_core_XTOR -type real -logic 0 vss | resolved | cfg/supplies.tcl:5-5 |
| 32 | set_verification_defaults | -design_verification | resolved | cfg/tb_config.tcl:8-8 |
| 33 | set_app_var | testbench_style symbolic | opaque | cfg/tb_config.tcl:10-10 |
| 34 | set_app_var | testbench_binary_cycles 4 | opaque | cfg/tb_config.tcl:11-11 |
| 35 | set_app_var | testbench_symbolic_cycles 6 | opaque | cfg/tb_config.tcl:12-12 |
| 36 | set_app_var | testbench_flush_cycles 2 | opaque | cfg/tb_config.tcl:13-13 |
| 37 | set_app_var | testbench_output_checks 3check | opaque | cfg/tb_config.tcl:14-14 |
| 38 | create_clock | -period 10 -setup 3 -initial 1 -clktype primary clk | resolved | cfg/tb_config.tcl:16-16 |
| 39 | set_portgroup | CORE | resolved | cfg/tb_config.tcl:18-18 |
| 40 | set_testbench_pin_attributes | clk -function clock -portgroup CORE | resolved | cfg/tb_config.tcl:20-20 |
| 41 | set_testbench_pin_attributes | rstb -function reset -value low -portgroup CORE | resolved | cfg/tb_config.tcl:21-21 |
| 42 | set_testbench_pin_attributes | ce -function chipen -portgroup CORE | resolved | cfg/tb_config.tcl:22-22 |
| 43 | set_testbench_pin_attributes | wen -function write -portgroup CORE | resolved | cfg/tb_config.tcl:23-23 |
| 44 | set_input_delay | -delay 2.5 addr | resolved | cfg/tb_config.tcl:26-26 |
| 45 | set_app_var | testbench_setup_file tb_overrides/t6_setup.v | opaque | cfg/tb_overrides.tcl:12-12 |
| 46 | set_app_var | testbench_declaration_file tb_overrides/t6_decl.v | opaque | cfg/tb_overrides.tcl:13-13 |
| 47 | set_app_var | testbench_initialization_file tb_overrides/t6_init.v | opaque | cfg/tb_overrides.tcl:14-14 |
| 48 | set_app_var | testbench_constraint_file tb_overrides/t6_cons.v | opaque | cfg/tb_overrides.tcl:15-15 |
| 49 | set_constraint | ce -set 1'b1 | resolved | cfg/constraints_cycles.tcl:8-8 |
| 50 | set_constraint | din -set 8'h11 -cycle BINCYCLE1 | resolved | cfg/constraints_cycles.tcl:13-13 |
| 51 | set_constraint | din -set 8'h22 -cycle BINCYCLE2 | resolved | cfg/constraints_cycles.tcl:14-14 |
| 52 | set_constraint | din -set 8'h33 -cycle BINCYCLE3 | resolved | cfg/constraints_cycles.tcl:15-15 |
| 53 | set_constraint | din -set 8'h44 -cycle BINCYCLE4 | resolved | cfg/constraints_cycles.tcl:16-16 |
| 54 | set_constraint | wen -set 1'b0 -if inno_cycle == "SYMCYCLE1" | resolved | cfg/constraints_cycles.tcl:22-22 |
| 55 | set_constraint | wen -set 1'b0 -cycle SYMCYCLE1 | resolved | cfg/constraints_cycles.tcl:23-23 |
| 56 | set_constraint | ce -set 1'b0 -if (inno_cycle[79:16]=="BINCYCLE")\|\|(inno_cycle[71:8]=="BINCYCLE") | resolved | cfg/constraints_cycles.tcl:29-29 |
| 57 | set_constraint | ce -set 1'b1 -if (inno_cycle[79:16]=="SYMCYCLE")\|\|(inno_cycle[71:8]=="SYMCYCLE") | resolved | cfg/constraints_cycles.tcl:30-30 |
| 58 | set_constraint | din -set 8'h00 -if tm == 2'b01 | resolved | cfg/constraints_modes.tcl:12-12 |
| 59 | set_constraint | din -set 8'hff -if tm == 2'b10 | resolved | cfg/constraints_modes.tcl:13-13 |
| 60 | set_constraint | mode_a -set 1'b1 -if tm == 2'b00 | resolved | cfg/constraints_modes.tcl:21-21 |
| 61 | set_constraint | mode_b -set 1'b1 -if tm == 2'b01 | resolved | cfg/constraints_modes.tcl:22-22 |
| 62 | set_constraint | mode_c -set 1'b1 -if tm == 2'b10 | resolved | cfg/constraints_modes.tcl:23-23 |
| 63 | set_constraint | mode_d -set 1'b1 -if tm == 2'b11 | resolved | cfg/constraints_modes.tcl:24-24 |
| 64 | set_constraint | dout -ignore -check_num 1 2 -cycle BINCYCLE1 | resolved | cfg/constraints_modes.tcl:30-30 |
| 65 | foreach | cyc 1 2 3 4 ␊  set_constraint wen -set {1'b1} -cycle BINCYCLE$cyc␊ | unknown | cfg/generated_banks.tcl:8-10 |
| 66 | foreach | cyc 1 2 3 4 ␊  set_constraint wen -set {1'b0} -cycle SYMCYCLE$cyc␊ | unknown | cfg/generated_banks.tcl:12-14 |
| 67 | set_constraint | banksel0 banksel1 banksel2 banksel3 -1hot | resolved | cfg/symbols.tcl:8-8 |
| 68 | set_constraint | alwaysIgnored_DOUT[3] -set 0 | resolved | cfg/symbols.tcl:9-9 |
| 69 | create_symbol | trimsel0 trimsel1 | opaque | cfg/symbols.tcl:20-20 |
| 70 | set_constraint | -symbolic_static trimsel0 trimsel1 | resolved | cfg/symbols.tcl:21-21 |
| 71 | set_symbol_to_pass | trimsel0 trimsel1 | opaque | cfg/symbols.tcl:22-22 |
| 72 | set_constraint | sleep -set 1'b0 | resolved | cfg/symbols.tcl:27-27 |
| 73 | set_constraint | iso -set 1'b0 | resolved | cfg/symbols.tcl:28-28 |
| 74 | set_constraint | ret -set 1'b0 | resolved | cfg/symbols.tcl:29-29 |
| 75 | set_constraint | bisten -set 1'b0 | resolved | cfg/symbols.tcl:30-30 |
| 76 | set_constraint | dftmode -set 1'b0 | resolved | cfg/symbols.tcl:31-31 |
| 77 | set_constraint | pwrgate -set 1'b1 | resolved | cfg/symbols.tcl:32-32 |
| 78 | set_constraint | addr[0] -set 1'b0 | dynamic | cfg/symbols.tcl:36-36 |
| 79 | set_constraint | addr[1] -set 1'b0 | dynamic | cfg/symbols.tcl:37-37 |
| 80 | set_constraint | addr[2] -set 1'b0 | dynamic | cfg/symbols.tcl:38-38 |
| 81 | set_constraint | addr[3] -set 1'b0 | dynamic | cfg/symbols.tcl:39-39 |
| 82 | set_constraint | addr -mask 4'b00.. | resolved | cfg/symbols.tcl:40-40 |
| 83 | set_net_value | -i -design t6_core_XTOR -code initial force t6_core_XTOR.trim_bias = 4'b0101; | opaque | cfg/symbols.tcl:45-45 |
| 84 | write_esp_db | -disable_line_coverage netlist_implementation.gv | resolved | run/execute.tcl:4-4 |
| 85 | check_design | (none) | resolved | run/execute.tcl:6-6 |
| 86 | set_app_var | testbench_symbolic_cycles 8 | opaque | run/execute.tcl:11-11 |
| 87 | verify | (none) | resolved | run/execute.tcl:13-13 |
