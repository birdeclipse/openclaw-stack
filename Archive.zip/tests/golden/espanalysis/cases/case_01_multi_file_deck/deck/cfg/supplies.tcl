## supplies.tcl -- define real power/ground supplies (L5)
## must run after cfg/read_design.tcl; needs the SPICE container populated

set_supply_net -i -design t6_core_XTOR -type real -logic 1 vdd
set_supply_net -i -design t6_core_XTOR -type real -logic 0 vss

# end of supplies.tcl
