* t6_core.sp -- implementation container netlist stub
* read via cfg/read_design.tcl's read_spice -i spice/t6_core.sp
.subckt t6_top_XTOR clk rstb ce wen tm<1:0> addr<3:0> din<7:0>
+ dout<7:0> banksel0 banksel1 banksel2 banksel3 vdd vss

xcore clk rstb ce wen tm<1:0> addr<3:0> din<7:0> dout<7:0>
+ banksel0 banksel1 banksel2 banksel3 vdd vss t6_core_XTOR

.ends t6_top_XTOR

.subckt t6_core_XTOR clk rstb ce wen tm<1:0> addr<3:0>
+ din<7:0> dout<7:0> banksel0 banksel1 banksel2 banksel3 vdd vss

* trim_bias<3:0> is the internal bias-trim net set_net_value -code
* (cfg/symbols.tcl) injects an initial force onto post-write_esp_db.
rtrim0 trim_bias<0> vss 1k
rtrim1 trim_bias<1> vss 1k
rtrim2 trim_bias<2> vss 1k
rtrim3 trim_bias<3> vss 1k

.ends t6_core_XTOR
