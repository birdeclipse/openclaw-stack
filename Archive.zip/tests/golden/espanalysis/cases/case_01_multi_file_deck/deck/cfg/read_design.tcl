## read_design.tcl -- load reference RTL, match containers (L2 + L4)
## must run before cfg/supplies.tcl

set_app_var netlist_port_bus off
set_app_var netlist_bus_extraction_style {%s<%d>}

# two direct positional reads (not a -vcs "-f ..." filelist splice --
# that composite-string shape is t2_sram32x8_hand's own construct, and this
# fixture needs its RTL as a plain corpus attachment so
# intent/namespace.py::build_symbol_table can ground modes.py's z3 pairwise
# check against real port widths, DESIGN.md section 25.1 / roadmap/09 C12).
read_verilog -r rtl/t6_top.v
read_verilog -r rtl/t6_core.v
read_spice -i spice/t6_core.sp

set_hierarchy_separator /

set_top_design -r t6_top
set_top_design -i t6_top_XTOR

match_designs
match_design_ports

set_simulation_timescale 1 ns 1 ps

# end of read_design.tcl
