## constraints_modes.tcl -- symbolic-pin relations over tm (L7)
## must run after cfg/tb_config.tcl
##
## Amendment A2 decision 4 (the load-bearing one): -if on a symbolic pin is a
## RELATION, never enumerated into concrete modes in the primary view. This
## file supplies the deck evidence intent/modes.py's bounded pairwise z3 check
## (DESIGN.md section 25.1, USER DECISION 2) proves claims over -- tm is a real
## 2-bit port (rtl/t6_top.v), so every condition below is grounded.

# Content item 3 (first half): one relation plus a disjoint arm on the same
# pin -- mutually exclusive, not exhaustive (tm can still be 2'b00/2'b11).
set_constraint din -set {8'h00} -if {tm == 2'b01}
set_constraint din -set {8'hff} -if {tm == 2'b10}

# Content item 3 (second half): four modes from one shared sub-expression over
# tm, each selecting a disjoint pin -- modes.py's pairwise pass proves all six
# pairs mutually exclusive. mode_b/mode_c deliberately reuse the exact -if text
# din already used above (spacing matters to _distinct_conditions's bucket key
# -- one shared string means one relation, evidenced by both facts, not two
# near-duplicate conditions that only differ by whitespace).
set_constraint mode_a -set {1'b1} -if {tm == 2'b00}
set_constraint mode_b -set {1'b1} -if {tm == 2'b01}
set_constraint mode_c -set {1'b1} -if {tm == 2'b10}
set_constraint mode_d -set {1'b1} -if {tm == 2'b11}

# Content item 6: -ignore -check_num on an output, and a late app-var write
# (run/execute.tcl, after check_design) that I2's boundary rule must catch --
# check_num is a within-cycle check-event index (default 3, espvariable.txt:
# 2431-2434), never a cycle index; it belongs on this table, never the wave axis.
set_constraint dout -ignore -check_num {1 2} -cycle BINCYCLE1

# end of constraints_modes.tcl
