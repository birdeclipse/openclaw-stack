// t6_top.v -- top-level RTL wrapper, reference container
// listed in cfg/filelists/rtl.f; every pin the deck names below gets a real
// width here (DESIGN.md section 26.5 / roadmap/09 section 5 C12) -- without
// this, intent/namespace.py's ports-only symbol table is empty and every
// modes.py claim is vacuous.
module t6_top (
  input        clk,
  input        rstb,
  input        ce,
  input        wen,
  input  [1:0] tm,
  input  [3:0] addr,
  input  [7:0] din,
  output [7:0] dout,
  input        banksel0,
  input        banksel1,
  input        banksel2,
  input        banksel3,
  input        trimsel0,
  input        trimsel1,
  input        sleep,
  input        iso,
  input        ret,
  input        bisten,
  input        dftmode,
  input        pwrgate,
  input        mode_a,
  input        mode_b,
  input        mode_c,
  input        mode_d
);

  t6_core u_core (
    .clk      (clk),
    .rstb     (rstb),
    .ce       (ce),
    .wen      (wen),
    .tm       (tm),
    .addr     (addr),
    .din      (din),
    .dout     (dout),
    .banksel0 (banksel0),
    .banksel1 (banksel1),
    .banksel2 (banksel2),
    .banksel3 (banksel3)
  );

endmodule
