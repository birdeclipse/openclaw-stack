## tb_config.tcl -- testbench style, cycle counts, clocks, pin functions (L6)
## must run after cfg/supplies.tcl
##
## Cycle inventory (Amendment A2 / DESIGN.md section 26.2): symbolic style,
## 4 binary + 6 symbolic + 2 flush cycles, the 3check default written explicitly
## so R5's -check_num row has a discriminator (espvariable.txt:2431-2434).

set_verification_defaults -design_verification

set_app_var testbench_style symbolic
set_app_var testbench_binary_cycles 4
set_app_var testbench_symbolic_cycles 6
set_app_var testbench_flush_cycles 2
set_app_var testbench_output_checks 3check

create_clock -period 10 -setup 3 -initial 1 -clktype primary clk

set_portgroup {CORE}

set_testbench_pin_attributes clk -function clock -portgroup CORE
set_testbench_pin_attributes rstb -function reset -value low -portgroup CORE
set_testbench_pin_attributes ce -function chipen -portgroup CORE
set_testbench_pin_attributes wen -function write -portgroup CORE

# address settles a quarter cycle after every other input
set_input_delay -delay 2.5 addr

# end of tb_config.tcl
