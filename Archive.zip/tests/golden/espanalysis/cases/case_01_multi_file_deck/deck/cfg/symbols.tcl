## symbols.tcl -- explicit relational groups, symbol search, static ties (L7/L11)
## must run after cfg/tb_config.tcl

# Content item 4: an explicit -1hot group over a real bus of single-bit pins,
# plus the alwaysIgnored_ reserved-namespace tie-off idiom (espug.txt:4045) --
# groups.py's explicit path claims the first, groups.py's pin_roles classifies
# the second as a tb_register, never a design pin.
set_constraint {banksel0 banksel1 banksel2 banksel3} -1hot
set_constraint {alwaysIgnored_DOUT[3]} -set 0

# Content item 8: create_symbol / -symbolic_static / set_symbol_to_pass with no
# companion set_stuck_fault_group or set_net_group anywhere in this deck --
# intent/symbols.py's SYMBOL_SEARCH claim fires the don't-care/trimmer-style
# clause, not the redundancy/fault-masking one. Basic-usage form (no -type),
# per espcommand.txt:3049's own example -- `-type`'s label-only note embeds a
# `espcommand.txt/espug.txt/espref.txt` citation string that collides with
# test_aa_goldens.py's absolute-path leak regex (`/[a-z]+/`, unanchored); a
# pre-existing latent defect this pass surfaced but does not own, see this
# fixture's own close-out notes.
create_symbol {trimsel0 trimsel1}
set_constraint -symbolic_static {trimsel0 trimsel1}
set_symbol_to_pass {trimsel0 trimsel1}

# Content item 10: >= 6 pins constrained once, unconditionally, no -cycle/-if
# (STATIC_TIES row candidates for schedule.py's row selection, DESIGN.md
# section 27.2e -- not yet built, but the deck evidence is authored now).
set_constraint sleep -set {1'b0}
set_constraint iso -set {1'b0}
set_constraint ret -set {1'b0}
set_constraint bisten -set {1'b0}
set_constraint dftmode -set {1'b0}
set_constraint pwrgate -set {1'b1}

# Content item 10: one bus as four bit-selects plus one whole-bus line
# (bus-collapse candidate for the same future row-selection pass).
set_constraint addr[0] -set {1'b0}
set_constraint addr[1] -set {1'b0}
set_constraint addr[2] -set {1'b0}
set_constraint addr[3] -set {1'b0}
set_constraint addr -mask {4'b00..}

# Content item 10: one set_net_value -code line -- L9 tuning, no mapper ships
# in this milestone (plan's "Command coverage" table), so this stays a
# captured-but-unclaimed fact (preserved, facts owned) rather than lifted.
set_net_value -i -design t6_core_XTOR -code {initial force t6_core_XTOR.trim_bias = 4'b0101;}

# end of symbols.tcl
