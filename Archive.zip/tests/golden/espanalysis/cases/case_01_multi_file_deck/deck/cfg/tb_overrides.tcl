## tb_overrides.tcl -- hand-written Verilog spliced into every testbench
## paths are relative to the corpus root, not this file
##
## Content items live under tb_overrides/ -- declaration file half of the
## injected-sequence surface (roadmap/09 section 2.6). The three-file join
## (declaration + initialization-file load-loop + consuming -if constraint)
## needs intent/declfile.py, which is P3.5-RESCOPE decision 3's WaveDrom-half
## sibling, not landed by this pass -- see KNOWN-GAPS.md. Promoting these four
## paths into Corpus.attachments (DESIGN.md section 25.2's fingerprint fix) and
## the AA-INTENT-OPAQUE-VERILOG findings below both exercise already-landed code.

set_app_var testbench_setup_file tb_overrides/t6_setup.v
set_app_var testbench_declaration_file tb_overrides/t6_decl.v
set_app_var testbench_initialization_file tb_overrides/t6_init.v
set_app_var testbench_constraint_file tb_overrides/t6_cons.v

# end of tb_overrides.tcl
