// t6_core.v -- instantiated child, reference container
module t6_core (
  input        clk,
  input        rstb,
  input        ce,
  input        wen,
  input  [1:0] tm,
  input  [3:0] addr,
  input  [7:0] din,
  output [7:0] dout,
  input        banksel0,
  input        banksel1,
  input        banksel2,
  input        banksel3
);

  reg [7:0] mem [0:15];

  always @(posedge clk) begin
    if (ce && wen) begin
      mem[addr] <= din;
    end
  end

  assign dout = mem[addr];

endmodule
