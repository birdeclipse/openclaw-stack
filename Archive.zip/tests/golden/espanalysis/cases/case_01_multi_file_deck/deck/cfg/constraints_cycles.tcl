## constraints_cycles.tcl -- per-cycle literal walk + inno_cycle scoping (L7)
## must run after cfg/tb_config.tcl; pin functions must already be set
##
## Amendment A2's corrected cycle order is the LAW here: axis is cycles, never
## time; -check_num (constraints_modes.tcl) is a within-cycle check index, never
## a cycle index.

set_constraint ce -set {1'b1}

# Content item 1: per-cycle -set walk over one pin, distinct literals per
# BINCYCLE label -- these are literal repeated lines, not a foreach generator,
# so each stays its own CommandFact (I2/I6's cycle-label inventory).
set_constraint din -set {8'h11} -cycle BINCYCLE1
set_constraint din -set {8'h22} -cycle BINCYCLE2
set_constraint din -set {8'h33} -cycle BINCYCLE3
set_constraint din -set {8'h44} -cycle BINCYCLE4

# Content item 2 (first half): -if {inno_cycle == "SYMCYCLE1"} and -cycle
# SYMCYCLE1 adjacent on the same pin -- both cycle-scoping surfaces landing in
# one column is schedule.py's job (deferred); this pass only needs the deck
# content and the honest "not yet routed" behaviour from the landed passes.
set_constraint wen -set {1'b0} -if {inno_cycle == "SYMCYCLE1"}
set_constraint wen -set {1'b0} -cycle SYMCYCLE1

# Content item 2 (second half): the wildcard idiom for "every binary cycle" /
# "every symbolic cycle", verbatim from espcommand.txt:17561-17572 -- the only
# documented way to scope a constraint across every cycle of one kind without
# writing one line per cycle.
set_constraint ce -set {1'b0} -if {(inno_cycle[79:16]=="BINCYCLE")||(inno_cycle[71:8]=="BINCYCLE")}
set_constraint ce -set {1'b1} -if {(inno_cycle[79:16]=="SYMCYCLE")||(inno_cycle[71:8]=="SYMCYCLE")}

# end of constraints_cycles.tcl
