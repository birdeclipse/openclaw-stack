## generated_banks.tcl -- generator-shaped per-cycle constraints (L7)
## must run after cfg/tb_config.tcl
##
## Content item 5: a foreach-shaped generator, >= 8 near-identical calls, one
## varying integer token -- I3's anti-unification pass (intent/templates.py)
## summarizes each foreach site as its own GeneratorSummary + IntentClaim.

foreach cyc {1 2 3 4} {
  set_constraint wen -set {1'b1} -cycle BINCYCLE$cyc
}

foreach cyc {1 2 3 4} {
  set_constraint wen -set {1'b0} -cycle SYMCYCLE$cyc
}

# end of generated_banks.tcl
