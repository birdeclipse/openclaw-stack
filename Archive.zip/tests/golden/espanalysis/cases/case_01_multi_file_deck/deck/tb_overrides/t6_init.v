// t6_init.v -- spliced into every testbench via testbench_initialization_file
// original content, patterned on the structure espug.txt:11138-11159
// describes for the load-loop half; not transcribed from it. Not read by
// anything landed in this pass -- see t6_decl.v's own comment.

initial begin : load_trim_seed
  integer i;
  for (i = 0; i < 4; i = i + 1) begin
    trimSeedSym[i] = 1'b0;
  end
end
