// t6_decl.v -- spliced into every testbench via testbench_declaration_file
// original content, patterned on the structure espug.txt:11138-11159
// describes for a declaration-file/initialization-file pair; not transcribed
// from it. Declares the register a future intent/declfile.py pass (P3.5's
// deferred injected-sequence half, KNOWN-GAPS.md) would join against
// t6_init.v's load loop -- not read by anything landed in this pass.

reg [0:3] trimSeedSym;
