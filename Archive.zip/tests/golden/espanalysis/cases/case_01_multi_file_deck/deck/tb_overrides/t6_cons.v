// t6_cons.v -- spliced into every testbench via testbench_constraint_file
// original content; not transcribed from any manual example.

// nothing beyond a comment marker for this deck -- see t6_setup.v's own note.
