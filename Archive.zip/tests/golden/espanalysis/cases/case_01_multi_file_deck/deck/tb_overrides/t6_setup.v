// t6_setup.v -- spliced into every testbench via testbench_setup_file
// original content, patterned on the structure espug.txt:11138-11159
// describes for a setup-file splice; not transcribed from it.

// nothing beyond a comment marker for this deck -- the setup file exists to
// exercise cfg/tb_overrides.tcl's fingerprint promotion (DESIGN.md section
// 25.2), not to carry load-bearing content.
