## t6_cycle_intent -- cycle-schedule stress deck, esp_analysis_agent P3.5 completion corpus
## owner: verification infra; sources every layer in dependency order below

source env/prelude.tcl
source cfg/read_design.tcl
source cfg/supplies.tcl
source cfg/tb_config.tcl
source cfg/tb_overrides.tcl
source cfg/constraints_cycles.tcl
source cfg/constraints_modes.tcl
source cfg/generated_banks.tcl
source cfg/symbols.tcl
source run/execute.tcl

# end of run.tcl
