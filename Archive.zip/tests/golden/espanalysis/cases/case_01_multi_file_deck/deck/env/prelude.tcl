## prelude.tcl -- shell behavior + file search path (L1)
## sourced first by run.tcl; nothing below reads design data

set_app_var sh_continue_on_error false
set_app_var sh_source_uses_search_path true
set_app_var sh_new_variable_message false

# the deck lives under corpus root; sourced files resolve here too
set search_path "."
lappend search_path env
lappend search_path cfg
lappend search_path run

# ESPTB-091 fires on every dual-checker symbolic build for this part;
# tracked as a known false positive, see JIRA VERIF-6031
suppress_message {ESPTB-091}

alias rl report_log

# end of prelude.tcl
