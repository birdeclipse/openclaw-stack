## execute.tcl -- database build + run (L10)
## must run after every cfg/ file has been sourced

write_esp_db -disable_line_coverage netlist_implementation.gv

check_design

# Content item 6 (second half): a write to a declared cycle-count app-var
# AFTER the terminal-generation call -- I2's boundary rule (intent/cycles.py)
# must classify this as AA-INTENT-APPVAR-LATE, never as the resolved value.
set_app_var testbench_symbolic_cycles 8

verify

# end of execute.tcl
