#!/usr/bin/env python3
"""Capture golden fixtures for the ``espanalysis`` port from the LEGACY oracle.

Run it with the legacy virtualenv, from the legacy checkout, so the imports
below resolve to the ORIGINAL modules:

    cd ~/projects/openhands_setup_agent && \\
        .venv/bin/python \\
        ~/projects/circuit-setup-general/tests/golden/espanalysis/capture_fixtures.py

The legacy checkout is read-only: nothing here writes outside
``tests/golden/espanalysis/`` in THIS repository. Every oracle value comes from
the legacy PURE pipeline -- ``build_setup_deck_model`` plus the five
``report.documents`` renderers -- driven by the minimal reader below rather than
by the kernel's ``ClaimBoundModuleSourcePort``, because that port needs a claim
token and an execution projection and neither exists outside a live Attempt.

That substitution is safe for exactly one reason, and it is worth stating: the
builder consumes a reader through a structural protocol
(``sources.SourceReadPayload``) and re-verifies every identity it is handed
(``builder._read_entry`` and ``builder._commands_from_graph`` both recompute the
SHA-256 and compare). So a reader that reads the right bytes and reports their
true digest is indistinguishable to the pipeline from the confined one. What the
confined port adds -- confinement, bounds, symlink denial, mutation detection --
is refusal behaviour, and refusal behaviour is what the ported
:mod:`espanalysis.reader` is tested for separately; it cannot change the bytes of
a document rendered from a deck that reads cleanly.

Per case, written under ``cases/<case>/expected/``:

* a successful build: the five rendered documents byte for byte, plus
  ``digests.json`` carrying the canonical model / diagnostics / integrity bytes'
  digests and the counts the receipt reports;
* a failing build: ``failure.json`` carrying the reason the legacy cause-chain
  walk names and the one safe sentence that goes with it.

``cases/<case>/deck/`` is the input tree and is committed. ``input.json`` names
the entry deck and whether the case is expected to build.
"""

from __future__ import annotations

import asyncio
import json
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any

FIXTURE_ROOT = Path(__file__).resolve().parent
CASES_ROOT = FIXTURE_ROOT / "cases"

try:
    from esp_agent.orchestration.runtime.module import ModuleSourceError
    from esp_agent.setup_analysis.builder import (
        BuildFailure,
        BuildOutcome,
        build_setup_deck_model,
    )
    from esp_agent.setup_analysis.report.documents import (
        BOUNDARY_DOCUMENT_NAME,
        COMMANDS_DOCUMENT_NAME,
        DIAGNOSTICS_DOCUMENT_NAME,
        OVERVIEW_DOCUMENT_NAME,
        SOURCES_DOCUMENT_NAME,
        render_boundary_document,
        render_commands_document,
        render_diagnostics_document,
        render_overview_document,
        render_sources_document,
    )
except ModuleNotFoundError as error:  # pragma: no cover - operator error
    raise SystemExit(
        "run this from the legacy checkout with its venv:\n"
        "  cd ~/projects/openhands_setup_agent && .venv/bin/python "
        f"{Path(__file__).resolve()}\n"
        f"({error})"
    ) from error

#: ``deck_analysis_tools._SOURCE_FAILURE_REASONS``, copied so the capture does
#: not import the toolbox shell (which pulls in the whole SDK seam).
_SOURCE_FAILURE_REASONS = frozenset(
    {
        "not_found",
        "outside_root",
        "symlink_denied",
        "protected_path",
        "budget_exhausted",
        "mutated",
        "unreadable",
    }
)
_BUILD_FAILED = "build_failed"

#: ``deck_analysis_tools._REASON_DETAIL``, copied for the same reason.
_REASON_DETAIL = {
    "not_found": "the named path does not exist under the work root",
    "outside_root": "the named path escapes the work root",
    "symlink_denied": "a source resolves outside the work root through a link",
    "protected_path": "the named path is protected",
    "budget_exhausted": "a source-read budget stopped the walk",
    "mutated": "a source changed digest while the deck was being read",
    "unreadable": "a source could not be read",
    _BUILD_FAILED: "the deterministic build failed closed",
}

DOCUMENTS = (
    (OVERVIEW_DOCUMENT_NAME, render_overview_document),
    (DIAGNOSTICS_DOCUMENT_NAME, render_diagnostics_document),
    (SOURCES_DOCUMENT_NAME, render_sources_document),
    (COMMANDS_DOCUMENT_NAME, render_commands_document),
    (BOUNDARY_DOCUMENT_NAME, render_boundary_document),
)

SEVERITIES = ("error", "warning", "info")


@dataclass(frozen=True, slots=True)
class OracleRead:
    """Structurally a ``sources.SourceReadPayload``."""

    relative_path: str
    data: bytes
    digest: str


@dataclass(frozen=True, slots=True)
class OracleReader:
    """The minimal honest reader: right bytes, true digest, coded absence.

    ``ModuleSourceError`` is raised rather than ``FileNotFoundError`` so the
    legacy ``_build_failure_reason`` cause-chain walk sees what it sees in
    production. That walk is the thing the failure fixture pins.
    """

    root: Path

    def read(self, relative_path: str, /) -> OracleRead:
        target = self.root / relative_path
        try:
            raw = target.read_bytes()
        except FileNotFoundError as error:
            raise ModuleSourceError(
                "not_found", "Module source was not found"
            ) from error
        except OSError as error:
            raise ModuleSourceError("unreadable", "Module source is unreadable") from error
        return OracleRead(
            relative_path=relative_path,
            data=raw,
            digest=sha256(raw).hexdigest(),
        )


def build_failure_reason(error: BuildFailure) -> str:
    """``deck_analysis_tools._build_failure_reason``, verbatim in semantics."""

    current: BaseException | None = error
    while current is not None:
        if isinstance(current, ModuleSourceError):
            return current.code if current.code in _SOURCE_FAILURE_REASONS else _BUILD_FAILED
        current = current.__cause__
    return _BUILD_FAILED


def digests(outcome: BuildOutcome) -> dict[str, Any]:
    """The identity and the counts the ported receipt has to reproduce."""

    severities = {severity: 0 for severity in SEVERITIES}
    for diagnostic in outcome.diagnostics.diagnostics:
        if diagnostic.severity in severities:
            severities[diagnostic.severity] += 1
    return {
        "model_digest": outcome.model_digest,
        "diagnostics_digest": outcome.diagnostics_digest,
        "integrity_digest": outcome.integrity_digest,
        "model_bytes_sha256": sha256(outcome.model_bytes).hexdigest(),
        "diagnostics_bytes_sha256": sha256(outcome.diagnostics_bytes).hexdigest(),
        "integrity_bytes_sha256": sha256(outcome.integrity_bytes).hexdigest(),
        "source_count": len(outcome.model.sources),
        "command_count": len(outcome.model.commands),
        "diagnostic_counts": severities,
        "diagnostic_codes": [
            diagnostic.code for diagnostic in outcome.diagnostics.diagnostics
        ],
        "bounds_reached": [bound.name for bound in outcome.integrity.bounds_reached],
        "hdl_selected_top": (
            outcome.model.hdl_structure.selected_top
            if outcome.model.hdl_structure is not None
            else None
        ),
    }


def capture_case(case_dir: Path) -> str:
    case = json.loads((case_dir / "input.json").read_text(encoding="utf-8"))
    entry_deck = str(case["entry_deck"])
    expect = str(case["expect"])
    reader = OracleReader(root=(case_dir / "deck").resolve())
    expected = case_dir / "expected"
    expected.mkdir(parents=True, exist_ok=True)

    try:
        outcome = asyncio.run(
            build_setup_deck_model(entry_deck=entry_deck, reader=reader)
        )
    except BuildFailure as error:
        if expect != "failure":
            raise SystemExit(f"{case_dir.name}: expected a build, got BuildFailure {error}")
        reason = build_failure_reason(error)
        (expected / "failure.json").write_text(
            json.dumps(
                {"refusal": reason, "message": _REASON_DETAIL[reason]},
                ensure_ascii=False,
                indent=2,
            )
            + "\n",
            encoding="utf-8",
        )
        return f"{case_dir.name}: failure {reason}"

    if expect != "build":
        raise SystemExit(f"{case_dir.name}: expected a failure, the build succeeded")
    for name, render in DOCUMENTS:
        (expected / name).write_text(render(outcome), encoding="utf-8")
    (expected / "digests.json").write_text(
        json.dumps(digests(outcome), ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return (
        f"{case_dir.name}: {len(outcome.model.sources)} source(s), "
        f"{len(outcome.model.commands)} command(s), "
        f"{len(outcome.diagnostics.diagnostics)} diagnostic(s)"
    )


def main() -> int:
    if not CASES_ROOT.is_dir():
        raise SystemExit(f"no cases directory at {CASES_ROOT}")
    cases = sorted(path for path in CASES_ROOT.iterdir() if (path / "input.json").is_file())
    if not cases:
        raise SystemExit(f"no cases with an input.json under {CASES_ROOT}")
    for case_dir in cases:
        print(capture_case(case_dir))
    print(f"captured {len(cases)} case(s) into {CASES_ROOT}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
