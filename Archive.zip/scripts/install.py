#!/usr/bin/env python3
"""Sync the authoring layout into an opencode discovery layout.

The authoring layout (skill/circuit_setup/<module>/, tool/, agents/,
commands/, plugins/) is the source of truth; opencode only discovers
`skills/*/SKILL.md` one level deep with hyphenated names, so this script
materializes the discoverable tree (MIGRATION.md section 4.1).

Modes:
  --mode symlink   (default) symlink directories/files into the target —
                   development checkouts; edits in the source are live.
  --mode copy      copy files — global installs (e.g. ~/.config/opencode).

TypeScript definition files (tool/, plugins/) are always COPIED, in both
modes: Bun resolves a module at its real path, so a symlinked
`tools/fact.ts` would look for `../circuit_paths` and
`@opencode-ai/plugin` next to `tool/` in the source checkout and fail to
load. Re-run this script after editing a `.ts`; skills, scripts, agents
and commands stay live under `--mode symlink`.

Skill SKILL.md sources carry the FINAL hyphenated `name:`; this script
validates (name regex, mapping match, description length) and refuses on
mismatch instead of rewriting, so symlink mode never mutates sources.

A `circuit_paths.ts` module is generated at the target root (outside
tools/, invisible to tool discovery); tool/*.ts import it to locate the
deterministic scripts regardless of install mode.
"""

from __future__ import annotations

import argparse
import json
import re
import shutil
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
SKILL_SOURCE_ROOT = REPO_ROOT / "skill" / "circuit_setup"

#: authoring directory name -> installed (and frontmatter) skill name.
SKILL_NAME_MAP: dict[str, str] = {
    "setup_deck": "circuit-setup-deck",
    "cycle_plan": "circuit-cycle-plan",
    "authoring": "circuit-authoring",
    "deck_analysis": "circuit-deck-analysis",
}

#: non-skill shared payload; installed without a SKILL.md so discovery
#: skips it while scripts remain reachable on disk.
SHARED_DIR_NAME = "_shared"
SHARED_INSTALLED_NAME = "circuit-setup-shared"

NAME_RE = re.compile(r"^[a-z0-9]+(-[a-z0-9]+)*$")

#: (source dir, target subdir, glob, always_copy)
#:
#: ``always_copy`` is load-bearing for the TypeScript entries. Bun resolves a
#: module at its REAL path, so a symlinked ``tools/fact.ts`` resolves
#: ``../circuit_paths`` and ``@opencode-ai/plugin`` against ``<repo>/tool/``
#: -- where neither exists -- and the tool fails to load. Copying the two-dozen
#: line definition files keeps every resolution inside the opencode config dir;
#: the deterministic scripts and the prompts, which are what actually get
#: iterated on, stay symlinked and live.
FLAT_SYNCS: tuple[tuple[str, str, str, bool], ...] = (
    ("tool", "tools", "*.ts", True),
    ("agents", "agents", "*.md", False),
    ("commands", "commands", "*.md", False),
    ("plugins", "plugins", "*.ts", True),
)

PACKAGE_JSON = {
    "name": "circuit-setup-general-opencode",
    "private": True,
    "dependencies": {"@opencode-ai/plugin": "latest"},
}


class InstallError(Exception):
    """Refusal with a user-facing message; exits 1."""


def parse_frontmatter(skill_md: Path) -> dict[str, str]:
    """Parse the simple `key: value` frontmatter block of a SKILL.md."""
    text = skill_md.read_text(encoding="utf-8")
    if not text.startswith("---\n"):
        raise InstallError(f"{skill_md}: missing frontmatter block")
    end = text.find("\n---", 4)
    if end < 0:
        raise InstallError(f"{skill_md}: unterminated frontmatter block")
    fields: dict[str, str] = {}
    for line in text[4:end].splitlines():
        if not line.strip() or line.startswith(" "):
            continue
        key, sep, value = line.partition(":")
        if sep:
            fields[key.strip()] = value.strip().strip("\"'")
    return fields


def validate_skill(source: Path, installed_name: str) -> None:
    skill_md = source / "SKILL.md"
    if not skill_md.is_file():
        raise InstallError(f"{source}: no SKILL.md")
    fields = parse_frontmatter(skill_md)
    name = fields.get("name", "")
    description = fields.get("description", "")
    if name != installed_name:
        raise InstallError(
            f"{skill_md}: name '{name}' must equal installed name "
            f"'{installed_name}' (sources carry the final hyphenated name)"
        )
    if not NAME_RE.fullmatch(name) or len(name) > 64:
        raise InstallError(f"{skill_md}: name '{name}' fails opencode name rules")
    if not 1 <= len(description) <= 1024:
        raise InstallError(
            f"{skill_md}: description length {len(description)} outside 1..1024"
        )


def place(source: Path, target: Path, mode: str) -> None:
    """Materialize source at target (dir or file) per mode, replacing target."""
    if target.is_symlink() or target.is_file():
        target.unlink()
    elif target.is_dir():
        shutil.rmtree(target)
    target.parent.mkdir(parents=True, exist_ok=True)
    if mode == "symlink":
        target.symlink_to(source)
    elif source.is_dir():
        shutil.copytree(source, target)
    else:
        shutil.copy2(source, target)


def sync_skills(target_root: Path, mode: str) -> list[str]:
    installed: list[str] = []
    for source_name, installed_name in SKILL_NAME_MAP.items():
        source = SKILL_SOURCE_ROOT / source_name
        if not source.is_dir() or not any(p.is_file() for p in source.rglob("*")):
            continue  # module not migrated yet
        validate_skill(source, installed_name)
        place(source, target_root / "skills" / installed_name, mode)
        installed.append(installed_name)
    shared = SKILL_SOURCE_ROOT / SHARED_DIR_NAME
    if shared.is_dir() and any(p.is_file() for p in shared.rglob("*")):
        place(shared, target_root / "skills" / SHARED_INSTALLED_NAME, mode)
        installed.append(f"{SHARED_INSTALLED_NAME} (payload only)")
    return installed


def sync_flat(target_root: Path, mode: str) -> list[str]:
    installed: list[str] = []
    for source_dir, target_sub, pattern, always_copy in FLAT_SYNCS:
        source = REPO_ROOT / source_dir
        if not source.is_dir():
            continue
        item_mode = "copy" if always_copy else mode
        for item in sorted(source.glob(pattern)):
            place(item, target_root / target_sub / item.name, item_mode)
            installed.append(
                f"{target_sub}/{item.name}" + (" (copied)" if item_mode != mode else "")
            )
    return installed


def write_paths_module(target_root: Path, mode: str) -> None:
    """Generate circuit_paths.ts used by tool/*.ts to locate scripts."""
    if mode == "symlink":
        roots = {key: str(SKILL_SOURCE_ROOT / key) for key in SKILL_NAME_MAP}
        roots["shared"] = str(SKILL_SOURCE_ROOT / SHARED_DIR_NAME)
    else:
        skills = target_root / "skills"
        roots = {
            key: str(skills / installed)
            for key, installed in SKILL_NAME_MAP.items()
        }
        roots["shared"] = str(skills / SHARED_INSTALLED_NAME)
    body = (
        "// GENERATED by scripts/install.py — do not edit.\n"
        "export const CIRCUIT_PATHS = "
        + json.dumps(roots, indent=2)
        + " as const;\n"
    )
    target_root.mkdir(parents=True, exist_ok=True)
    (target_root / "circuit_paths.ts").write_text(body, encoding="utf-8")


def write_package_json(target_root: Path) -> None:
    path = target_root / "package.json"
    if not path.exists():
        path.write_text(
            json.dumps(PACKAGE_JSON, indent=2) + "\n", encoding="utf-8"
        )


def main(argv: list[str]) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=("symlink", "copy"), default="symlink")
    parser.add_argument(
        "--target",
        type=Path,
        default=REPO_ROOT / ".opencode",
        help="opencode config directory (default: <repo>/.opencode)",
    )
    args = parser.parse_args(argv)
    target_root = args.target.expanduser().resolve()

    try:
        skills = sync_skills(target_root, args.mode)
        flat = sync_flat(target_root, args.mode)
    except InstallError as error:
        print(f"refused: {error}", file=sys.stderr)
        return 1
    write_paths_module(target_root, args.mode)
    write_package_json(target_root)

    print(f"installed to {target_root} (mode={args.mode})")
    for name in skills:
        print(f"  skill  {name}")
    for name in flat:
        print(f"  {name}")
    if not skills and not flat:
        print("  (nothing to install yet)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
