---
description: Author ESP input constraints from a plain-language request — triage into workstreams, author each sequentially, ask one skippable question set, report in chat.
---

Load the `circuit-authoring` skill — it carries the command knowledge — and
run this workflow for the authoring request:

$ARGUMENTS

Resolve the write target before authoring:

- a file the user named is the target — an incremental edit when it already
  exists;
- otherwise, a project with a deck (`esp-setup/` holding
  `<macro>_pin_attributes.tcl`) gets constraints in
  `esp-setup/<macro>_constraints.tcl` and declaration content in
  `esp-setup/testbench_declarations.sv`;
- otherwise, create a new `.tcl` (declaration file: `.sv`) beside the run
  artifacts or design files the request points at.

Never write a compiler-generated file (`<macro>_esp_setup.tcl`,
`<macro>_supplies.tcl`, `<macro>_pin_attributes.tcl`, `diagnostics.json`,
`fact-ledger.md`): the next compile overwrites it. Correct the facts and
recompile instead.

Run the four phases in order — do not interleave them:

1. **Triage.** Invoke `@circuit-setup-triage` once with the request verbatim,
   the resolved targets, and whether discovery is armed. Prefer pin facts
   already in a fact ledger — `fact_list` / `fact_report` with the run root
   the user pointed at — and arm discovery only when no ledger carries pins.
   Triage returns its workstream table (kind: new_file / incremental_edit /
   answer), out-of-scope notes, and source disagreements in its final
   message; it writes no files. Zero workstreams is a legitimate report-only
   outcome.

2. **Sequential authoring.** For each workstream, in table order, one at a
   time, invoke `@circuit-constraint-author`. Paste the pin roster (the block
   shape in the skill's `documents/guide.md` Part 1) and the resolved write
   target into each invocation, plus what earlier workstreams already wrote
   to the same file. Never fan out: concurrent authors lose bytes. Before the
   first in-place edit of an existing file, keep a copy beside it
   (`<file>.bak`) unless the project is under version control.

3. **One consolidated interview.** Collect every open question the authoring
   phase raised and ask them once, in chat, as a single numbered set that is
   fully skippable — a skipped question becomes a reported gap, never a
   blocked run. Re-invoke the author only for the workstreams whose questions
   were answered. At most one interview.

4. **Report in chat.** Per workstream, in order: kind, the request extract it
   satisfied, the commands emitted or the answer, gaps, and every file
   written. Then the out-of-scope notes, source disagreements, questions that
   stayed open, and any answer-downgrades — a write workstream answered in
   prose because no roster or pin could be trusted, always named, since a
   silent downgrade reads as a completed write.

Triage never authors constraints. If the request is entirely outside the
constraint family — device or net overrides — say so as an out-of-scope note
and report rather than guessing a lowering.
