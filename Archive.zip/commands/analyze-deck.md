---
description: Analyze an existing ESP Tcl setup deck and explain what it configures, what it leaves undecided, and what looks wrong
agent: circuit-deck-analyst
---

Load the `circuit-deck-analysis` skill and run its workflow for one deck.

Deck path (or a note pointing at one) from the user:

$ARGUMENTS

If that names a `.tcl` file, use it as the entry deck. If it names a directory,
a macro, or nothing at all, **discover the entry deck yourself** with `glob` and
`list` before reasoning about it — never invent a name and never assume a
conventional one.

Deliver, in `<run root>/deck-analysis/` — the run root is the user's stated
destination, else one you pick and pass as `dir` on every tool call
(`work/<run>` only when you never pass one):

- the five generated documents from **one** `analyze_deck` call (`model.md`,
  `diagnostics.md`, `model-sources.md`, `model-commands.md`,
  `model-boundary.md`);
- citation-backed reader facts for the intent, stated-but-not-encoded design
  properties, and concerns the scanner cannot produce — and none for anything a
  document already carries;
- `report.md`: what the deck sets up, the verification setup and cycle facts, the
  complete pin and supply tables, your reading of the deck's own prose under a
  heading that says it is yours, and anything the deck does that its name would
  not suggest. If the user named a destination for the report, that wins over
  the default location.

Then hand the analysis to the `circuit-deck-reviewer` subagent for `review.md`,
written beside the report. Give it pointers, not transcriptions: the run root,
the report path, and the entry deck. Both documents are published and both are
read; if the review contradicts the report, that disagreement is the product.

If `analyze_deck` refuses, read the reason, fix what you can — usually the path —
and call it again. If it still refuses, say so in the report and describe the
deck from what you can open yourself. A failed analyzer means a smaller report,
not an abandoned one.

Do not declare the deck correct, approved, or verified. Close with a short
message: what was analyzed, whether the analyzer succeeded, how many reader
facts were logged, what is unresolved, and where the report and review landed.
