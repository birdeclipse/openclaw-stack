---
description: Build an ESP Tcl setup deck for one memory macro from its design collateral
agent: circuit-deck-engineer
---

Load the `circuit-setup-deck` skill and run its workflow for one macro.

Design notes from the user:

$ARGUMENTS

Work from those notes plus what you find on disk. If the notes name a macro, a
datasheet, or a directory, start there; otherwise discover the collateral before
reasoning about it.

Deliver, in the run root — the user's stated destination, else one you pick
and pass as `dir` on every verb (`work/<run>` only when you never pass one):

- the compiler-owned deck (`compile_deck`: `<macro>_esp_setup.tcl`,
  `<macro>_supplies.tcl`, `<macro>_pin_attributes.tcl`, `diagnostics.json`),
  compiled last after every fact change;
- `fact-ledger.md` (`fact_report`);
- `<macro>_constraints.tcl` when there is anything to lower into it;
- `<macro>_setup_report.md` separating evidenced facts from applied template
  defaults, with every gap named;
- `STATUS.md`.

Ask at most one consolidated, fully skippable question set, and skip it when the
five minimum fact kinds are present and nothing is ambiguous.
