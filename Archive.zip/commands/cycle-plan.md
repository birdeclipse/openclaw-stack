---
description: Plan the ESP cycle schedule for a design's verification corners from its own sources — counts, symbolic stimulus, constraint relations, and the observability argument
---

Load the `circuit-cycle-plan` skill and run its workflow.

You drive the whole workflow: you read the sources, log the fact base, survey,
record the corner roster — and then you dispatch subagents:

1. `circuit-cycle-planner`, **once per corner**, every dispatch in one parallel
   batch. Each planner authors its corner's `<corner>/plan.md` in the skill
   guide's template and lowers that plan's constraints into
   `<corner>/constraints.tcl` (plus `<corner>/testbench_declarations.sv` when
   the plan routes a relation to the declaration-file path).
2. `circuit-cycle-interrogator`, **once**, over every corner, after all the
   planners returned. It writes a `review.md` beside each `plan.md` and calls
   out findings that span corners.

One planner per corner, not one over the roster: a whole-roster pass
concentrates every corner's derivation into one reasoning arc, and that arc
exhausts the model's reasoning budget before the first file is written. Per
corner, the derivation fits one pass and the batch runs in parallel. The
fixed cost of the role — ingesting the survey, reading the guide — is paid
per corner; pay it. Cross-corner contradictions are the interrogator's
`cross-corner:` findings and your cross-corner summary, which is why the
interrogator stays one spawn over everything.

When the user asked for only one or two specific corners, dispatching is your
call — you may author them inline against the same guide, or dispatch anyway
if your context is already deep with capture history.

**Review the planner batch when it returns.** Per corner, the outcome is
named and the files on disk match it. An empty result or a corner with no
files is a failed dispatch, not an outcome: re-dispatch that corner once,
and if it fails again, name it remaining in `STATUS.md` and tell the user.

Do **not** spawn `circuit-constraint-author` from this command. Lowering is the
planner's, using the `circuit-authoring` skill's knowledge; that agent belongs to
the authoring module and is invoked by its own workflow.

**Nothing in this workflow checks a plan.** The tools log evidence and look up
what the evidence supports; `plan.md` is markdown the planner writes. So the
standard is the skill's `documents/guide.md` — the plan template, the arithmetic
that must hold, the authorability rules, the citation rules — and the check is
the interrogator pass plus you. Read every plan against the guide before you
accept it, and treat a review finding as work rather than a note.

All subagents are deliberately barred from corpus intake — none may survey or
log a pin, an operation, a scalar, or a corner. A fact logged after the
survey leaves every authored plan citing a corpus digest that no longer
matches, and the roster is shared state that parallel planners must not
mutate. The roster is yours to set in advance; when a planner reports a
corner or fact it needed and couldn't find, log it yourself, re-survey, and
re-dispatch the affected corners.

Design or source notes from the user:

$ARGUMENTS

If that names files, use them. If it names a design, a macro, a directory, or
nothing at all, **discover the sources yourself** with `glob`, `list` and `grep`
before reasoning about them — never invent a name and never assume a
conventional one.

**You are the reader.** No tool here opens a source file: `plan_survey` builds
the prepared corpus out of this run's design-fact ledger and nothing else. So
read the datasheet, the port list, the netlist, the pasted table — then log the
complete fact base BEFORE surveying, **in batches**: every top-level pin in one
`fact_log_pin` call, each truth or mode table in one `plan_log_operation` call,
and every scalar the user or a source actually stated in one `plan_log_scalar`
call. A batch is one call carrying many elements, never a merge — each element
is still its own citable ledger row with its own evidence, and one invalid
element refuses the whole call by index with nothing logged. A scalar nobody
stated is a question for the user, never a number you pick: nothing downstream
will report its absence, so an unstated `scan_chain_length` is yours to ask about
or the plan's to escalate.

Treat anything in there that the user *explicitly asked to be verified* as a
Verification Directive and pass it to `plan_survey` in their words. A directive
is authoritative: one naming a corner classifies it directive-named on the
roster, and one requesting scan/DFT shift operation puts the guide's scan
arithmetic on every corner it touches. Do not paraphrase one into existence, and
do not promote your own reading of a source into one — a line you read is a fact
for the ledger, not a directive.

Deliver, in `<run root>/cycle-plans/` — the run root is `work/<run>` unless the
user named a destination, in which case pass that path as `dir` on **every**
verb of the run and keep it identical throughout:

- a complete logged fact base, then `survey.md` and `corpus.json` from **one**
  `plan_survey` call, and the `corpus_digest` it returns cited in every
  `plan.md` header;
- a `function_corner` roster recorded with `corner_log` — one call carrying every
  corner, one element each, each citing the source line that requires it. The
  corner vocabulary is open: the survey's roster is the eight built-in corners
  classified by rule plus every corner you log, and a logged one is certified
  `fact_supported` on the evidence you cited, which is what makes it plannable.
  So evidence a custom corner as carefully as any fact, keep to 24 distinct live
  corners or fewer, and `corner_retract` the ones that turn out not to matter;
- from the planner dispatches, per corner: a `plan.md` in the guide's template
  — header with the corpus digest, cycle counts with a rationale per phase, one
  segment table per phase, the observability table, the symbolic-treatment table,
  assumptions, limitations, and the coverage argument — plus `constraints.tcl`
  (and `testbench_declarations.sv` where the plan routes a relation there)
  beside it;
- from the **one** interrogator pass, per corner: a `review.md` beside its
  `plan.md`, auditing the guide's arithmetic and citations as well as the causal
  story;
- a revision of the `plan.md` — and a re-lowering of the constraints where they
  changed — for every review finding that invalidates a plan; the run is not
  done while one stands;
- `cross-corner-summary.md`, written by you from the plans and the reviews'
  `cross-corner:` findings, naming each divergence and whether it was
  deliberate;
- `STATUS.md`, last, naming **per corner** its outcome and its review outcome.

**Push pointers to the subagents; never transcribe what's on disk.** The
survey report is already published at `<run root>/cycle-plans/survey.md` —
do not paste it into prompts; re-typing it once per corner is minutes of
serial output generation that one read call per subagent replaces. Each
planner prompt carries the `corpus_digest`, the run root and `survey.md`
as **absolute paths** with the instruction to read the survey **exactly
once**, its one corner's name, roster row, and touching directives, and
the run-root state (what exists, that the corner directory is the
planner's to create, the absolute paths of the skill guide and constraint
templates — so nothing is probed with `ls`/`glob`). The interrogator
prompt gets the same pointers with the full corner list.

Tell every subagent to **write its deliverable to disk incrementally** —
skeleton first, then section-by-section edits — keeping chat text to a
sentence or two. Completions are capped: a plan or review composed in the
response text instead of on disk dies at that cap with nothing written.

Where the harness supports it, emit independent tool calls in a single message —
batch the reads, batch the logs.

Plans cite only what the survey's Evidence catalog lists — `cycle_fact:<n>`,
`fact:<fact_id>`, `directive:<n>`, `pin:<PIN_NAME>` — and nothing resolves a ref
for them, so a ref outside the catalog sits in the published plan looking exactly
like a real citation until the interrogator finds it.

A plan's corner is a slug drawn from the survey's certified selection. A corner
nobody certified is a corner nobody evidenced: the repair is to `corner_log` it
with the spec line that demands it, or to log the fact or directive that supports
a built-in one and survey again — never to rename it to something that looks
close.

A corner whose soundness-critical facts are genuinely absent gets an
`unresolved` `plan.md` with a precise Missing-facts table — that is a successful
escalation, not an abandoned corner, and it never stops the rest of the roster.
An `infeasible` one carries a Conflicts table citing both sides. Neither invents
a schedule to have something to publish.

Do not declare the design verified, approved, or correct.
