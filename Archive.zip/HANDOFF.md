# Session handoff — cycle-plan opencode migration and live-test hardening

Date: 2026-08-28. Written for the next session in this repo. The prior session
history lives in the omp harness, not here; this file is the load-bearing
summary. `MIGRATION.md` §13 is the design record; this is the state record.

## Where the module is now

`circuit-cycle-plan` went through four architecture revisions in this session,
each driven by measured live-test evidence, each recorded in MIGRATION.md:

1. **Fact-ledger intake** (§13.1–13.7, commit `30d9f23`): the markdown-spec
   path (`spec_extract.py`, excerpt machinery) was deleted. The LLM is the
   reader; it logs `pin` / `operation` / `plan_scalar` facts into the shared
   espdeck ledger; `plan_survey` assembles the corpus from the ledger alone.
2. **Runtime** (§13.8–13.9, commit `c2ee593`): batched logging (every ledger
   verb takes an array; all-or-nothing; each element its own citable row),
   caller-chosen run roots (optional `dir` on every verb of all three CLIs;
   `work/<run>` is only the default), and the dispatch model (one planner
   spawn per corner, in a parallel batch; one interrogator pass over all
   corners; survey pushed into every prompt).
3. **Open corner vocabulary** (§13.10, commit `361bd13`): the 8 `CornerKind`s
   are built-ins with classification rules; every `function_corner` ledger
   fact adds a certified, plannable corner (slug identity, roster cap 32,
   custom cap 24). Live corner facts thread into roster derivation at every
   site — a corner logged after survey is immediately plannable.
4. **Advisory knowledge over hard gates** (§13.11, commit `b848ac0`):
   `plan_check` / `plan_render` / `plan_reconcile` and the entire
   proposal-JSON/gates/checkers/prediction/render/reconcile layer are DELETED
   (12 espcycle modules; cli.py 1711 → 1100 lines). espcycle is five verbs:
   `survey`, `operation_log`, `scalar_log`, `corner_log`, `corner_retract` —
   evidence and corner logging plus lookup. `guide.md` (322 → 608 lines) is
   the main teacher: plan.md authoring template, A1/A3/A5 arithmetic, selector
   sanity, authorability, citation and corner discipline, all translated from
   the deleted gate sources. The planner authors `plan.md` directly
   (edit-allow flipped); the interrogator is the only check and must re-derive
   the mechanical audit with numbers; adversarial-library.md was rewritten
   from "consume trusted findings" to "derive it yourself". User decision,
   mirroring legacy ADR 0037: both implementations showed hard gates make
   agents spin on refusals, and trial 2 proved a WRONG gate poisons a run.

## Live-test evidence behind those decisions

Workspace `E2E_TEST/live_test/` (gitignored): TSMC N3A SRAM compiler-spec PDF
+ `design/` RTL wrapper and CDL, plus my synthetic `docs/sphs512x16_datasheet.md`.
Runs on `deepseek/deepseek-v4-flash` via `opencode run --command cycle-plan`.

- **Trial 1** (synthetic datasheet, pre-runtime-work): mission corner passed
  end-to-end — perfect capture (10/10 pins, 4/4 rows, did NOT invent the
  deliberately-unstated scalar), clean check first pass, high-quality
  adversarial review. Cost: ~21 min and ~62 LLM turns for ONE corner; 20 turns
  were single-fact logs, ~10 were subagents re-reading docs. Artifacts:
  `E2E_TEST/live_test/results-trial1/`.
- **Trial 2** (real PDF + RTL, post-runtime-work): intake+survey in 7.5 min —
  59 pins, 48 operations from the PDF via MCP; roster certified 5 corners
  including a custom `bist-mode` the agent logged unprompted (open-vocabulary
  feature used correctly on first exposure). Then the planner burned 27 turns
  fighting `UNRESOLVED_EVIDENCE_REF`: our docs taught `pin:<NAME>` as citable
  evidence but the catalog never allocated pin entries. Run killed. The
  immediate defect was fixed in `c12d7e2` (pins are catalog entries), and the
  systemic lesson became revision 4 above. Artifacts:
  `E2E_TEST/live_test/runs/trial2/` (survey.md is worth reading).

## Commits this session (oldest first)

- `9f3444f` … `7a277fe` prior sessions: scaffold, four module ports, docs
- `4cd4d0b` proposal reference generated from validators (deleted in `b848ac0`)
- `a080b6a` survey evidence-gap contention fix
- `30d9f23` fact-ledger corpus intake, retire markdown spec path
- `e6f77a3` gitignore work/ run state
- `c2ee593` batched logging, caller-chosen run roots, two-subagent model
- `361bd13` open corner vocabulary
- `c12d7e2` pin refs resolve as evidence catalog entries
- `b848ac0` gate removal — advisory knowledge over hard gates (§13.11)

## Verification

- Golden suites: `python3 tests/test_espdeck_golden.py` (418),
  `tests/test_espanalysis_golden.py` (136), `tests/test_espcycle_golden.py`
  (250 after gate removal; survey/corpus fixture bytes verified unchanged).
- Install: `python3 scripts/install.py` (repo `.opencode/`) and
  `python3 scripts/install.py --target E2E_TEST/live_test/.opencode`.
  tool/*.ts are COPIED (Bun resolves at real paths); skills/agents symlink.
  Both targets are freshly installed as of `b848ac0`.
- Live run: `~/.opencode/bin/opencode run --dir <workspace> -m
  deepseek/deepseek-v4-flash --command cycle-plan --auto "<ask>"`.
  Sessions in `~/.local/share/opencode/opencode.db` (`part` table has the
  transcripts); logs in `~/.local/share/opencode/log/opencode.log`.

## Immediately next (first acts of the new session)

1. Launch trial 3 — the real run under the advisory architecture:
   `~/.opencode/bin/opencode run --dir
   /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test -m
   deepseek/deepseek-v4-flash --command cycle-plan --auto "The macro is the
   TSMC N3A 1.2M single-port SRAM instance described by
   TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf with functional collateral under
   design/. Verify mission-mode read and write operations, the scan shift
   path, BIST-mode operation, and the deep-sleep/shutdown retention sequence.
   Put all run state under E2E_TEST/live_test/runs/trial3."
2. Judge trial 3 on: capture quality (trial-2 oracle: 59 pins / 48 ops),
   corner set (expect a custom bist-mode again), plan.md quality against
   guide.md's template (nothing deterministic checks it now), interrogator
   re-derivation of the A1/A3/A5 arithmetic with numbers, wall time and turn
   count vs trial 1 (~62 turns/corner) and trial 2.
3. Reliability doctrine: one trial is an existence proof, not a claim —
   claims need ≥3 trials read as pass^k.

## Authoring module (state as of 2026-08-28)

Two passes, both this date. First: `skill/circuit_setup/authoring/SKILL.md`
was rewritten as a generic lowering skill — intent → set_constraint
EDIT/RELATION forms, cycle-count app vars, declaration-file routing, the five
hard rules, pin-fact discipline, and the injection firewall — with the legacy
openhands workflow contracts moved into `commands/author-constraints.md`.
Second, per user direction ("no `work/<run>/authoring/` requirement — this is
a generic edit-or-create ability"): the run-directory apparatus was deleted
outright. No workstreams.md file, no report.md, no STATUS.md — triage
(`circuit-setup-triage`) returns its workstream table, roster, out-of-scope
notes, and disagreements in its final message and writes nothing (edit
`"*": deny`); the row cap and slug regex are gone; the orchestrator reports in
chat. `circuit-constraint-author` edit permissions are now generic —
`*.tcl` / `*.sv` / `*.v` / `*esp-setup/*` allow, everything else deny —
so it can incrementally edit
any constraints file the user names (e.g. a prior cycle-plan run's
`<corner>/constraints.tcl`), with the compiler-generated deck files protected
by prose (they are regenerated on every compile). Targets resolve as:
user-named file → deck's
`esp-setup/` files → new file beside what the request points at, with a
`<file>.bak` copy before the first in-place edit when no VCS.
`documents/guide.md` and the templates are unchanged. Consumers that load the
skill for knowledge alone (the cycle planner's lowering phase) get exactly
the command forms and rules with none of the run bureaucracy.

## Setup-deck module (state as of 2026-08-28)

Three doc-level corrections, no schema or wire-contract change:

- **Run root is the model's choice.** SKILL.md and the `fact_*`/`compile_deck`
  arg descriptions no longer prescribe `work/<run>` as *the* location; the
  model picks `dir` (user's stated destination wins), and `work/<run>` is only
  the CLI fallback when `dir` is omitted. The `run_dir` mechanism itself is
  unchanged.
- **`-value` semantics corrected.** `set_testbench_pin_attributes -value
  high|low` is the pin's **active value** — the level at which the pin performs
  its function, per the datasheet's stated polarity (active-high reset →
  `high`) — NOT the value driven during FLUSH cycles, which is what
  `setup_deck/documents/guide.md`, `deck_analysis/documents/guide.md`, the
  `fact_log_pin` tool description, and the compiler's emitted header comment
  all wrongly claimed. All four corrected; the pin fact field stays named
  `value` (it mirrors the emitted `-value` option, and renaming would churn
  the ledger digests the espdeck golden fixtures pin). The emitted-comment
  change moved two golden fixture files and their `diagnostics.json` manifest
  hashes; all three golden suites pass (418/136/250 checks).
- **Guide trimmed to worker-decision knowledge.** The "Device and net
  overrides" and "Testbench style and the epilogue" sections were removed from
  `setup_deck/documents/guide.md`: the epilogue and app-var preamble are
  compiler template defaults (visible in the compiled deck), and the override
  command detail belongs to the other circuit-setup skills. SKILL.md phase 4
  still names the override commands for lowering `device`/`net` facts, but no
  longer points at the guide for their shapes.

Live evidence — **deck-trial1** (`E2E_TEST/live_test/runs/deck-trial1/`,
deepseek-v4-flash, real TSMC PDF + RTL/CDL): completed in 7.4 min / 45
assistant turns (20.8K output, 33.8K reasoning — no rumination blowup), all
eight deliverables published. 67 facts, all with file+line/page+quote
evidence; 59 pins in ONE batched call. The corrected `-value` semantics held:
`WE`/`ME`/`DS`/`LS`/`SD` got `-value high` and `CAPT` `-value low` from
datasheet polarity statements (the old flush-drive semantics would have
inverted these); clocks and data/address buses carry no `-value`. Mission-mode
constraints file with per-line citations and derived 4/2/8 cycle counts;
honest gaps (vacuous Q/QP data path in the CDL, no `.edm`, template clock).
One caveat observed: `dir` resolves against the git worktree, so a prompt
saying `runs/<trial>` landed at the REPO root, not the `--dir` workspace —
prompts must name `E2E_TEST/live_test/runs/<trial>` (AGENTS.md already says
so); state was relocated by hand. One pass = anecdote; pass³ still owed.

Fourth pass (later same date): **the `published/` subdirectory is gone.** The
run was already rooted at the model-chosen `dir`; the forced
`<run root>/published/` nesting was the last location rule, and it is deleted
end to end. `espdeck/ledger.py` lost `published_dir()`; `cli.py` writes the
deck bundle, `diagnostics.json` and `fact-ledger.md` straight into the run
root, and the compile receipt's `published_dir` key is renamed `run_root`
(wire-contract change; golden tests updated, 418/418). The colocation rule
that remains is Tcl, not policy: the entry deck sources
`<macro>_constraints.tcl` by bare filename, so the model's constraints file
must sit beside it — the compile message now spells the full
`<root>/<file>` path to write. `circuit-deck-engineer` edit permissions
switched from `published/`-suffix patterns to disjoint file-name patterns
(allow the model's three files anywhere; deny the five compiler-owned names
plus `facts.sqlite3`). SKILL.md, `commands/setup-deck.md`,
`commands/author-constraints.md` and `circuit-constraint-author` now name
compiler-generated files instead of a `published/` tree.

## Deck-analysis module (state as of 2026-08-28)

Doc-and-agent pass, no deterministic-core change (espanalysis golden suite
still 136/136; a direct CLI smoke confirmed `dir=custom/spot` lands all five
documents under `custom/spot/deck-analysis/`):

- **Run root and report location are the model's choice.** SKILL.md, the
  analyst/reviewer agents, and `commands/analyze-deck.md` no longer hardcode
  `work/<run>/deck-analysis/`; the user's stated destination wins, `dir` is
  passed on every verb, and `work/<run>` is only the CLI fallback. Agent edit
  permissions went run-root-agnostic (match on the `deck-analysis/` suffix or
  the `review.md` filename, deck-engineer precedent), and the analyst may
  place `report.md` at a user-named markdown path outside the run tree.
- **STATUS.md removed from this flow.** The analyst runs as the command's top
  agent, so its closing chat message carries the status (authoring-module
  precedent). setup-deck and cycle-plan keep theirs.
- **SKILL.md rewritten** (12.9 KB → 11 KB, humanizer pass): the ownership
  table and paths duplicated from tool descriptions are gone; the refusal
  table, reading order, citation-gate nuances, report contract, and review
  buckets stay. Reviewer dispatch now says pointers-not-transcriptions.

Live trial — **deck-analysis-trial1**
(`E2E_TEST/live_test/runs/deck-analysis-trial1/`, deepseek-v4-flash, 13.1 min,
subject: deck-trial1's four-file suite): all seven deliverables landed and
both documents are citation-dense — the reviewer re-derived every claim and
filed only minor omissions. But the run succeeded through three harness
defects, diagnosed against opencode v1.18.23 source and recorded as
MIGRATION.md §14: permission rules are LAST-MATCH-WINS, so the analyst's
trailing `"**": deny` shadowed every allow (report.md written via bash
heredoc); a task-child subagent gets `task: deny` unless its frontmatter
names the task permission (the analyst shelled out to a nested
`opencode run` to reach its reviewer); and `run --agent <subagent>` silently
falls back to `build` (review.md was written by the unrestricted default
agent). Fixes applied: catch-all-first rule order in analyst, reviewer,
interrogator, planner (whose `**: allow` tail had made its survey/corpus/
review protections dead), and deck-engineer; the analyst gained
`task: { "*": deny, "circuit-deck-reviewer": allow }`. Verified with
`opencode debug agent` probes. Pass³ still owed on a rerun with the fences
live.

## Standing constraints

- `~/projects/openhands_setup_agent` is READ-ONLY reference.
- Ported Python never imports `esp_agent`; espdeck stays stdlib-only;
  espcycle/espanalysis are pydantic v2 (PEP 723 + `uv run` bootstrap).
- Wire contract everywhere: JSON stdin → `{ok, message, data, refusal}`,
  exit 0 for domain refusals; non-zero = harness defect only.
- Ledger write-seam validation (FIELD_SPECS, slug safety, dir confinement,
  batch all-or-nothing) is data integrity, not gating — it stays.
- setup.deck / deck-analysis / authoring modules are NOT covered by the
  gate-removal decision; their deterministic compilers stand.
