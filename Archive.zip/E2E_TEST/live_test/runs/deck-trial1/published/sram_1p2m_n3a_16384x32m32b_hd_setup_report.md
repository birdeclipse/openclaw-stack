# ESP setup report — sram_1p2m_n3a_16384x32m32b_hd

Run root: `runs/deck-trial1` — resolved against the workspace root, so the
published files live at
`/Users/qiuyuxun/projects/circuit-setup-general/runs/deck-trial1/published/`.
Snapshots: fact-ledger `915f9e4ea7c7481840669108dd96b9791e58718667b4696d524b779465425bcd`.

## 1. What was set up

One macro, two views, one symbolic testbench deck:

| Item | Value |
|---|---|
| Macro (compiled name) | `sram_1p2m_n3a_16384x32m32b_hd` |
| Reference view (RTL) | `design/rtl/sram_1p2m_n3a_wrapper.sv` via `design/rtl/filelist.func.f` |
| Implementation view (SPICE) | `design/spice/sram_1p2m_n3a_wrapper.cdl` |
| Datasheet | `TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf` (28 pp., reconstructed spec) |
| Files produced | `sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl`, `_supplies.tcl`, `_pin_attributes.tcl`, `_constraints.tcl`, `diagnostics.json`, `fact-ledger.md`, this report, `STATUS.md` |

**Naming observation (not a conflict).** The user's brief names the macro
`sram_1p2m_n3a_wrapper`, which is the *file* prefix. The top cell in **both**
views is `sram_1p2m_n3a_16384x32m32b_hd` (Verilog `module` at
`design/rtl/sram_1p2m_n3a_wrapper.sv:36`; SPICE `.SUBCKT` at
`design/spice/sram_1p2m_n3a_wrapper.cdl:23`). The two views agree, so there is
no TOP-DISAGREE; the deck and every published file correctly carry the cell
name. The datasheet and the filelist header (line 2) describe this same part
("sram_1p2m_n3a_16384x32m32b_hd", 16384×32, IT/ST capable).

## 2. Facts logged (all evidence-backed; ledger rows 1–67)

All facts are `parsed` — read from sources I opened. **There are no
`declared` facts in this run.** The user's brief contributed the run root and
the "skip the interview" instruction; every design value in the ledger was
observed in a file.

### 2.1 Views

- **Verilog** (fact 1): top `sram_1p2m_n3a_16384x32m32b_hd`; filelist
  `design/rtl/filelist.func.f`; vcs options captured verbatim from the filelist
  lines 9–17: `-sverilog -timescale=1ns/1ps +define+FUNCTIONAL +define+SPEEDSIM
  +define+SRAM_ADDR_WIDTH=14 +define+SRAM_DATA_WIDTH=32 +incdir+./include`.
- **SPICE** (fact 2): top `.SUBCKT sram_1p2m_n3a_16384x32m32b_hd` at cdl:23.

### 2.2 Supplies (facts 3–8)

| Net | Type | Logic | Owner | Evidence |
|---|---|---|---|---|
| VDD | real | 1 | top | cdl:15,63 |
| VDDA | real | 1 | top | cdl:16,63 |
| VSS | real | 0 | top | cdl:17,63 |
| VDDV_PERI | virtual | 1 | `..._pdv_peri_hdr` | cdl:18, 67–68, switch at 104 |
| VDDV_ARRAY | virtual | 1 | `..._pdv_array_hdr` | cdl:19, 70–71, switch at 117 |
| VSSV_BIAS | virtual | 0 | `..._pdv_bias_ftr` | cdl:20, 73–74, footers at 127–128 |

The real/virtual split and the owner cells come from the CDL header comment
(cdl:14–20) and the header/footer instances (cdl:67–74). VSSV_BIAS is a
ground-like net (`logic 0`) that is *raised* in LS/DS retention — its role is a
source-biased ground, so logic 0 is correct.

### 2.3 Pins (facts 9–67) — 59 pins, one ledger row each

Structure (name/direction/width) taken from the CDL top port list (cdl:24–62)
and the Verilog port list; function and polarity taken from the datasheet
(Tables 2-3/2-4, pp. 7–12; truth tables pp. 16–18). Summary of the function
assignment and the polarity statements the datasheet actually makes:

- **clocks**: CLK, TCLK (allow `0 1`).
- **enable** (active high): ME, PIPEME, TME, TPIPEME.
- **address**: ADR[13:0], TADR[13:0]. **data**: D[31:0], TD[3:0], CD[3:0].
- **control** (active high unless noted): WE, WEM, HW[1:0], TWE, TWEM, THW[1:0],
  BISTE, TCLKE, DFTCLKEN, DFTMASK, RME, WA[2:0]*, TPR, BC0; active-low: CAPT
  ("When CAPT is logic 0, the output from the comparator is stored", p.10); no
  stated polarity: STICKY, RM[3:0], RA[1:0], WPULSE[2:0], TEST1, BC1, BC2.
  \*WA: the datasheet states "WA[2] Write assist enable pin (Active High)";
  WA[1:0] are level settings. The `-value high` on the WA bus rests on that
  one stated bit — see gaps.
- **ScanEnable / ScanDataIn / ScanDataOut**: SE_IN (active high), SI_Q_L/H,
  SI_D_L/H, SI_CNTR, SO_Q_L/H, SO_D_L/H, SO_CNTR.
- **RedEnable / RedAddress**: CRE1, CRE2, RRE (all active high per Tables
  2-15/2-16), FCA1[5:0], FCA2[5:0], FRA[7:0].
- **PowerControl**: LS, DS, SD (active high), POFF[1:0] (mode encoding
  00/01/10/11, no single polarity), and outputs ROP_DS, ROP_SD.
- **data outputs** (checked with `comparex`): Q[31:0], QP[31:0].

Allowed-values policy (documented decision, not sourced per pin): clocks take
`{0 1}`; every other pin takes `{0 1 X}`. Rationale: a clock must be binary;
omitting X from the other inputs would over-constrain the symbolic search
(setup-deck guide, `-allow` section). Outputs keep `{0 1 X}` under `comparex`.

## 3. Template defaults applied (not derived)

These are the house/template values the deck carries because nothing in the
sources overrode them:

1. **Built-in process models** — no `.edm` technology file exists anywhere
   under the workspace (glob `**/*.edm` → none). The deck therefore omits
   `set_process`/`set_device_model` and ESP uses its built-in process models
   (diagnostics `MIN-MISSING`, `EDM-DEFAULT`). If the run must be signoff-grade
   on TSMC N3A devices, a foundry `.edm` must be supplied and logged.
2. **Clock period/setup** — `create_clock -period 5000 -setup 500 CLK`
   (diagnostic `CLOCK-DEFAULT`). The datasheet publishes **no** absolute cycle
   time: its AC section is explicitly labeled synthetic ("Transition timing is
   intentionally conservative and synthetic … must not be treated as foundry or
   vendor signoff data", datasheet p.25). No override was sourced; the cycle
   planner should pick the period per corner.
3. **House app-var preamble** (lines 6–14 of the entry deck: fsdb waveform,
   rcdelay unit, randomize variables, `netlist_supply_by_connection off`,
   `parser_verilog latest`, coverage on) and the verification epilogue
   (symbolic style, tb_func, verify loop). Standard template content.

## 4. Compile diagnostics, in plain words

| Diagnostic | What it means here |
|---|---|
| `MIN-MISSING` + `EDM-DEFAULT` | no `.edm`; deck runs on ESP built-in process models. See §3.1 and gaps. |
| `SUPPLY-PORT-MATCH` | VDD, VDDA, VSS are SPICE-only ports; the deck declares them implementation-only (`set_matched_ports -i`) so port matching does not flag them. Expected. |
| `CLOCK-AMBIGUOUS` | two clock pins (CLK fact 9, TCLK fact 19). `create_clock` landed on CLK (lowest fact id). TCLK is the BIST clock (datasheet p.9); the constraints file holds it and TCLKE low (below). |
| `CLOCK-DEFAULT` | template 5000/500 clock; see §3.2. |

The compile is deterministic and clean: **no TOP-DISAGREE, no ORIGIN-CONFLICT,
no FORBIDDEN-EMIT, no ADVANCED-DEFERRED**.

## 5. What the constraints file does (worker-owned)

`..._constraints.tcl` is sourced by the entry deck (line 46) and carries
baseline verification-plan decisions:

- **Cycle counts (baseline decision, not template)**: flush 4, binary 2,
  symbolic 8. Justification: the read pipeline is one cycle deep ("will follow
  the regular output with a latency of one clock cycle", datasheet p.10), so
  flush ≥ 2× pipeline plus margin; symbolic 8 leaves room for several
  write/read pairs. Each corner plan re-derives its own counts.
- **Mission-mode scope** — mode-selecting pins held literal, functional pins
  free: `BISTE=0` (Table 2-13 normal mode), `SE_IN=0`, `TPR=0`, `DFTCLKEN=0`,
  `DFTMASK=0`; clock select `TCLKE=0` and `TCLK=0` (TCLKE is the CLK/TCLK
  mux select — datasheet p.17 note; with TCLKE=0 and BISTE=0 the BIST clock is
  inert in both views); test pins `TEST1=0` (Table 2-11 note: "The status of
  test signals for the above truth table is TEST1=L", p.16) and `TEST_RNM=0`;
  power row `LS=0, DS=0, SD=0, POFF=2'b00` (Table 2-12 NORMAL row).
- These mirror the constraint shape already validated on this macro in earlier
  runs (`runs/trial8/cycle-plans/*/constraints.tcl`), including holding a clock
  pin low via `set_constraint`.

## 6. Gaps — confirm before sign-off

1. **The implementation view does not implement the data path.** In the CDL,
   the top-level instances (cdl:77–89) never connect `Q`, `QP`, `SO_*`, `D`, or
   `WEM`; the only outputs actually driven are `ROP_DS`/`ROP_SD` (cdl:92–95).
   In the implementation view, `Q`/`QP`/`SO_*` float to X for every stimulus,
   and `comparex` tolerates that, so **Q/QP/SO equivalence is vacuous with this
   netlist**. The deck's real content is structural: port matching, supplies,
   clock, pin attributes. A human must confirm whether this CDL is the intended
   implementation view or whether a fuller transistor netlist exists.
2. **No `.edm` technology file** — deck uses ESP built-in process models
   (§3.1). Supply a foundry `.edm` for signoff-grade device modeling.
3. **Datasheet is a reconstruction.** The PDF's own header states it was
   "Reconstructed from photographed spec pages … for EDA-agent tuning purposes"
   and that sections 6–8 (AC timing, PVT corners, pin diagram) fill gaps with
   synthetic values. Pin functions/polarities came from Tables 2-3/2-4; a
   human should confirm the polarity statements against the vendor's official
   datasheet before signoff.
4. **Clock period is a template default** (5000/500); no absolute tCK exists in
   the datasheet (§3.2). The cycle planner should pick the period per corner.
5. **WA `-value high` rests on WA[2]** ("Write assist enable pin (Active
   High)", p.10); WA[1:0] are settings without stated polarity. Confirm the
   bus-level interpretation.
6. **Allowed-values policy** (`{0 1 X}` except clocks) is a documented
   decision, not per-pin sourced.
7. **`+incdir+./include` is stale**: `design/rtl/include/` does not exist on
   disk, though the filelist passes it to VCS. The wrapper `.sv` contains no
   `` `include `` directive, so impact is likely nil — confirm or clean the
   filelist.
8. **Deliberately unconstrained** (each named so a reviewer can object):
   functional operation pins (ME, WE, ADR, D, WEM, HW, PIPEME); BIST-side data
   pins (TME, TWE, TADR, TD, TWEM, THW, TPIPEME, CD, CAPT, STICKY — inert under
   BISTE=0/TCLKE=0); redundancy pins (CRE1, CRE2, FCA1, FCA2, RRE, FRA); margin
   and assist pins (RME, RM, RA, WA, WPULSE); bias straps (BC0, BC1, BC2).
   The RTL consumes none of the redundancy/margin/assist/bias pins (all folded
   into the `_unused` wire, `sram_1p2m_n3a_wrapper.sv:182–185`), and the CDL's
   repair/margin blocks do not reach Q, so constraining them would narrow the
   run without adding proof. The scan inputs (SI_*) are likewise unconstrained;
   with SE_IN=0 the RTL drives SO_*=0 while the implementation floats — a
   comparex-tolerated, but content-free, scan comparison in this deck.
9. **Power-down, BIST, scan, and redundancy corners are out of baseline
   scope.** The baseline run is NORMAL power, functional port, CLK active (the
   datasheet's Table 2-11 space). Deep-sleep/shutdown/retention, BIST-mode, and
   scan-shift behavior are separate corners for the cycle planner, which will
   author its own constraints (and its own clock handling for TCLK).
10. **Cycle counts (4/2/8)** are baseline decisions; corner plans supersede.

## 7. Provenance summary

- 67 live facts, 0 retracted, all `parsed` (opened sources), 0 `declared`.
- Interview: skipped per the user's instruction; every uncertainty above is
  recorded as a gap rather than asked.
- No compiler-owned file was hand-edited; the constraints file is the only
  worker-authored Tcl and the last `compile_deck` ran after both the last fact
  change and the constraints write (entry deck sources it at line 46).
