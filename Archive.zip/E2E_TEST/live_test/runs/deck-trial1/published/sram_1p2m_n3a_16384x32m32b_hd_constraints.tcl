# ---------------------------------------------------------------------------
# sram_1p2m_n3a_16384x32m32b_hd — setup-deck constraints (worker-owned)
#
# Baseline scope for the symbolic run: MISSION MODE — the functional port
# (CLK/ME/WE/ADR/D/WEM/HW/PIPEME) owns the memory and the power row is NORMAL
# (Table 2-12: LS=DS=SD=0, POFF=2'b00). Mode-selecting pins are held literal;
# the functional operation pins are deliberately left UNCONSTRAINED so the
# engine explores the full read/write/mask/idle space (Table 2-11).
#
# Power-down, BIST, scan, and redundancy behaviour are separate verification
# corners; the cycle planner owns per-corner constraint sets (see the
# circuit-cycle-plan skill's roster) and its files supersede these baselines.
#
# Cycle counts are baseline starting decisions, not template values:
#   - flush 4: >2x the one-cycle read-pipeline depth (QP follows Q one cycle
#     later; datasheet p.10 PIPEME/TPIPEME) plus settling margin;
#   - binary 2: concrete settling cycles before symbolic stimulus;
#   - symbolic 8: room for several write/read pairs at distinct addresses.
# Each corner plan should re-derive its own counts.
# ---------------------------------------------------------------------------

# --- testbench cycle counts (baseline) ---
set_app_var testbench_flush_cycles    4
set_app_var testbench_binary_cycles   2
set_app_var testbench_symbolic_cycles 8

# --- mission mode: functional port owns the memory (Table 2-13) ---
set_constraint {BISTE}    -set {1'b0}
set_constraint {SE_IN}    -set {1'b0}
set_constraint {TPR}      -set {1'b0}
set_constraint {DFTCLKEN} -set {1'b0}
set_constraint {DFTMASK}  -set {1'b0}

# --- clock select: CLK is the only active clock ---
# TCLKE is the CLK/TCLK select (datasheet p.17 note); with TCLKE=0 and BISTE=0
# the BIST clock TCLK is inert (RTL sel_clk = TCLKE ? TCLK : CLK,
# sram_1p2m_n3a_wrapper.sv:114), so hold it quiescent.
set_constraint {TCLKE}    -set {1'b0}
set_constraint {TCLK}     -set {1'b0}

# --- test pins held at their functional-truth-table values ---
# Table 2-11 note (p.16): "The status of test signals for the above truth
# table is TEST1=L"; TEST_RNM=1 precharges bit-lines (R15 containment).
set_constraint {TEST1}    -set {1'b0}
set_constraint {TEST_RNM} -set {1'b0}

# --- NORMAL power row (Table 2-12) ---
set_constraint {LS}   -set {1'b0}
set_constraint {DS}   -set {1'b0}
set_constraint {SD}   -set {1'b0}
set_constraint {POFF} -set {2'b00}
