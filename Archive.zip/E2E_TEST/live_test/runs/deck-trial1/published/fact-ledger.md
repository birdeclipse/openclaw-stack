# Design Fact Ledger

session: ses_fb5d840e0ffeZxhFxffRLv4OkR
work item: ses_fb5d
snapshot digest: 915f9e4ea7c7481840669108dd96b9791e58718667b4696d524b779465425bcd
live facts: 67
retracted facts: 0
missing minimum fact kinds: edm

## Live facts

### Parsed

#### verilog

- fact 1
  top_design_name: sram_1p2m_n3a_16384x32m32b_hd
  filelist_location: design/rtl/filelist.func.f
  verilog_file_location: design/rtl/sram_1p2m_n3a_wrapper.sv
  vcs_options: -sverilog -timescale=1ns/1ps +define+FUNCTIONAL +define+SPEEDSIM +define+SRAM_ADDR_WIDTH=14 +define+SRAM_DATA_WIDTH=32 +incdir+./include
  evidence: design/rtl/sram_1p2m_n3a_wrapper.sv:36 'module sram_1p2m_n3a_16384x32m32b_hd ('; design/rtl/filelist.func.f:9-17 '-sverilog / -timescale=1ns/1ps / +define+SRAM_ADDR_WIDTH=14 / +define+SRAM_DATA_WIDTH=32 / +incdir+./include / ./sram_1p2m_n3a_wrapper.sv'

#### spice

- fact 2
  top_design_name: sram_1p2m_n3a_16384x32m32b_hd
  spice_file_location: design/spice/sram_1p2m_n3a_wrapper.cdl
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:23 '.SUBCKT sram_1p2m_n3a_16384x32m32b_hd' and .ENDS at line 96

#### pin

- fact 9
  pin_name: CLK
  direction: input
  function_type: clock
  allowed_values: 0 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:24 port CLK; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.8 Table 2-3: 'Clock input. This is the external clock for the memory.'

- fact 10
  pin_name: ME
  direction: input
  function_type: enable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:24 port ME; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.8 Table 2-3: 'When the Memory Enable input is Logic High, the memory is enabled and read/write operations can be performed.'

- fact 11
  pin_name: WE
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:24 port WE; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.8 Table 2-3: 'When the Write Enable input is Logic High, the memory is in the Write cycle. When the Write Enable input is Logic Low, the memory is in the Read cycle.'

- fact 12
  pin_name: ADR
  direction: input
  function_type: address
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:25-26 ADR<13:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.7 Table 2-3: 'ADR[13:0] Address input. This Address input port is used to address the location to be written during the Write cycle and read during the Read cycle.'

- fact 13
  pin_name: D
  direction: input
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:27-30 D<31:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.7 Table 2-3: 'D[31:0] Data input. The data input bus is used to write the data into the memory location specified by the address input port during the Write cycle.'

- fact 14
  pin_name: WEM
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:31-34 WEM<31:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.16 Table 2-11 rows 'Write ... WE=H WEM=H ... Array = Data-in' vs 'Mask ... WE=H WEM=L ... NCM' (WEM high enables writing the bit)

- fact 15
  pin_name: HW
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:35 HW<1:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.8 Table 2-3: 'When the Half word Enable input is Logic High, the memory bits of a particular half or both halves are enabled and read/write operations can be performed.'

- fact 16
  pin_name: Q
  direction: output
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:36-39 Q<31:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'Q[31:0] Data output bus. It outputs the contents of the memory location addressed by the Address Input signals.'

- fact 17
  pin_name: PIPEME
  direction: input
  function_type: enable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:40 port PIPEME; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'When the PIPEME Input is Logic High, the pipeline output of the memory will switch at the rising edge of the clock and will follow the regular output with a latency of one clock cycle.'

- fact 18
  pin_name: QP
  direction: output
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:41-44 QP<31:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'QP[31:0] Data Output during pipeline mode.'

- fact 19
  pin_name: TCLK
  direction: input
  function_type: clock
  allowed_values: 0 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:45 port TCLK; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'TCLK BIST Clock Input. This is the external clock for the memory. This is used only when BIST is enabled.'

- fact 20
  pin_name: TME
  direction: input
  function_type: enable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:45 port TME; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'When the BIST Memory Enable is Logic High, the memory is enabled and read/write operations can be performed.'

- fact 21
  pin_name: TWE
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:45 port TWE; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'When the BIST Write Enable input is Logic High, the memory is in the Write cycle.'

- fact 22
  pin_name: TADR
  direction: input
  function_type: address
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:46-47 TADR<13:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'TADR[13:0] Address inputs for BIST.'

- fact 23
  pin_name: TD
  direction: input
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:48 TD<3:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'TD[3:0] Data Inputs for BIST.'

- fact 24
  pin_name: TWEM
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:49 port TWEM; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'when this pin is High, it will allow the write operation on all IOs' (TWEM is the BIST maskable write enable)

- fact 25
  pin_name: THW
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:49 THW<1:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'When the BIST Half word Enable input is Logic High, the memory bits of a particular half or both halves are enabled and read/write operations can be performed.'

- fact 26
  pin_name: BISTE
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:49 port BISTE; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'BISTE BIST Enable. It controls the BIST test mode.' and p.17 Table 2-13: 'BIST Mode H' selects TME/TWE/TADR/TD/TWEM/TCLK

- fact 27
  pin_name: TCLKE
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:49 port TCLKE; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'TCLKE Test external clock enable signal.' and p.17 note: 'TCLKE is used as select pin for CLK/TCLK.'

- fact 28
  pin_name: TPIPEME
  direction: input
  function_type: enable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:49 port TPIPEME; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'When the TPIPEME Input is Logic High, the pipeline output of the memory will switch at the rising edge of the clock' (BIST pipeline memory enable)

- fact 29
  pin_name: CD
  direction: input
  function_type: data
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:50 CD<3:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'CD[3:0] Control Data Input. Control bits to generate write compare data.'

- fact 30
  pin_name: CAPT
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: low
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:50 port CAPT; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'When CAPT is logic 0, the output from the comparator is stored in the comparison register inside the memory.'

- fact 31
  pin_name: STICKY
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:50 port STICKY; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'When STICKY is Logic level 0, the captured data in the comparison register is overwritten ... When STICKY is Logic level 1, the captured data ... is OR'ed' (mode select, no single active level)

- fact 32
  pin_name: SE_IN
  direction: input
  function_type: ScanEnable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SE_IN; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SE_IN Scan Enable input for Data and Control scan chains. Once made active, internal clock generation stops (READ/WRITE operation is disabled).'

- fact 33
  pin_name: SI_Q_L
  direction: input
  function_type: ScanDataIn
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SI_Q_L; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SI_Q_L Scan Chain Input for lower bits of QP.'

- fact 34
  pin_name: SI_Q_H
  direction: input
  function_type: ScanDataIn
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SI_Q_H; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SI_Q_H Scan Chain Input for higher bits of QP.'

- fact 35
  pin_name: SI_D_L
  direction: input
  function_type: ScanDataIn
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SI_D_L; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SI_D_L Scan Chain Input for lower bits of data.'

- fact 36
  pin_name: SI_D_H
  direction: input
  function_type: ScanDataIn
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SI_D_H; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SI_D_H Scan Chain Input for higher bits of data.'

- fact 37
  pin_name: SI_CNTR
  direction: input
  function_type: ScanDataIn
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:51 port SI_CNTR; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SI_CNTR Scan Chain Input for Control Signals.'

- fact 38
  pin_name: SO_Q_L
  direction: output
  function_type: ScanDataOut
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:52 port SO_Q_L; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'SO_Q_L Scan Chain Output for lower bits of QP.'

- fact 39
  pin_name: SO_Q_H
  direction: output
  function_type: ScanDataOut
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:52 port SO_Q_H; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'SO_Q_H Scan Chain Output for higher bits of QP.'

- fact 40
  pin_name: SO_D_L
  direction: output
  function_type: ScanDataOut
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:52 port SO_D_L; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'SO_D_L Scan Chain Output for lower bits of data.'

- fact 41
  pin_name: SO_D_H
  direction: output
  function_type: ScanDataOut
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:52 port SO_D_H; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'SO_D_H Scan Chain Output for higher bits of data.'

- fact 42
  pin_name: SO_CNTR
  direction: output
  function_type: ScanDataOut
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:52 port SO_CNTR; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'SO_CNTR Scan Chain Output for Control Signals.'

- fact 43
  pin_name: DFTCLKEN
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:53 port DFTCLKEN; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'DFTCLKEN This Input enables scan chain clocks for ATPG scan. Data bus flows synchronously with clock.'

- fact 44
  pin_name: DFTMASK
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:53 port DFTMASK; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'When DFTMASK is asserted, output bus follows data input bus synchronously.'

- fact 45
  pin_name: CRE1
  direction: input
  function_type: RedEnable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:54 port CRE1; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.8 Table 2-3: 'CRE1 Left side column repair enable Input.' and p.18 Table 2-15 'Left Repair 1 0 FCA1[n] X' (CRE1=1 selects left repair)

- fact 46
  pin_name: CRE2
  direction: input
  function_type: RedEnable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:54 port CRE2; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'CRE2 Right side column repair enable Input.' and p.18 Table 2-15 'Right Repair 0 1 X FCA2[n]' (CRE2=1 selects right repair)

- fact 47
  pin_name: FCA1
  direction: input
  function_type: RedAddress
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:55 FCA1<5:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'FCA1[5:0] Left side faulty column address.'

- fact 48
  pin_name: FCA2
  direction: input
  function_type: RedAddress
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:56 FCA2<5:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'FCA2[5:0] Right side faulty column address.'

- fact 49
  pin_name: RRE
  direction: input
  function_type: RedEnable
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:57 port RRE; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'RRE Row repair match Input. When RRE is high it will replace faulty location for with row repair block.' and p.18 Table 2-16 'Repair Mode 1 FRA[n]'

- fact 50
  pin_name: FRA
  direction: input
  function_type: RedAddress
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:57 FRA<7:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9 Table 2-3: 'FRA[7:0] Faulty row address.'

- fact 51
  pin_name: RME
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:58 port RME; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'This input selects between the default Read-Write margin setting (RME=0), and the external pin Read-Write margin setting (RME=1).'

- fact 52
  pin_name: RM
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:58 RM<3:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'RM[3:0] Read-Write margin Input. It programs the sense amp differential setting.'

- fact 53
  pin_name: RA
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:59 RA<1:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'RA[1:0] Read Assist Pins to control WL under-drive.'

- fact 54
  pin_name: WA
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:59 WA<2:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'WA[2] Write assist enable pin (Active High). WA[1:0] Write Assist pin to control negative voltage on SRAM bitline.'

- fact 55
  pin_name: WPULSE
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:59 WPULSE<2:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'WPULSE[2:0] Write Assist Pulse to control pulse width of negative voltage on SRAM bitline.'

- fact 56
  pin_name: TEST1
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:60 port TEST1; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.9-10 Table 2-3: 'TEST1 Test pin to bypass self-timed circuit. The external clock controls the read and write control signals.'; p.16 note 'The status of test signals for the above truth table is TEST1=L'

- fact 57
  pin_name: TEST_RNM
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:60 port TEST_RNM; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.10 Table 2-3: 'When this pin is high, memory bit-lines are pre-charged high. ATPG mode should be turned off in this mode.'

- fact 58
  pin_name: LS
  direction: input
  function_type: PowerControl
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port LS; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'LS Light Sleep Input. When this pin is active then memory goes into low leakage mode. There is no change in the output state.' and p.17 Table 2-12 'Light Sleep ... LS=1'

- fact 59
  pin_name: DS
  direction: input
  function_type: PowerControl
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port DS; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'DS Deep Sleep Input. This pin shuts down power to periphery and maintain memory contents. The outputs of the memory are pulled low.' and p.17 Table 2-12 'Deep Sleep ... DS 0->1'

- fact 60
  pin_name: SD
  direction: input
  function_type: PowerControl
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port SD; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'SD Shut Down Input. This pin shuts down power to periphery and memory core, no memory data retention.'

- fact 61
  pin_name: POFF
  direction: input
  function_type: PowerControl
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 POFF<1:0> ports; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'POFF[1:0] = 2'b00 No Periphery Off Mode. 2'b01 Standard Periphery Off Mode ... 2'b10 BC0 Periphery Off Mode ... 2'b11 SD Periphery Off Mode' (mode encoding, no single active level)

- fact 62
  pin_name: TPR
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port TPR; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'TPR Toggling Power Reduction Input. When pin is Logic High. It helps to reduce the pin toggling powers of ADR, D, WE and WEM pins.'

- fact 63
  pin_name: BC0
  direction: input
  function_type: control
  allowed_values: 0 1 X
  value: high
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port BC0; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'BC0 Biasing bypass input pin, setting BC0 to a logic 1 bypasses the array bias in Light and Deep sleep modes.'

- fact 64
  pin_name: BC1
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port BC1; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'BC1 Biasing Level Adjust Input. Its setting gives a smaller value of drop on vdd-core voltage.'

- fact 65
  pin_name: BC2
  direction: input
  function_type: control
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:61 port BC2; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.11 Table 2-3: 'BC2 Biasing Level Adjust Input. Its setting gives a higher value of drop on vdd-core voltage.'

- fact 66
  pin_name: ROP_DS
  direction: output
  function_type: PowerControl
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:62 port ROP_DS; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'ROP_DS Ready for Operation pin after DS mode. This pin should be low for any valid memory operation.'

- fact 67
  pin_name: ROP_SD
  direction: output
  function_type: PowerControl
  allowed_values: 0 1 X
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:62 port ROP_SD; TSMC_N3A_SRAM_1.2M_Compiler_Spec.pdf p.12 Table 2-4: 'ROP_SD Ready for Operation pin after SD mode. This pin should be low for any valid memory operation.'

#### supply

- fact 3
  supply_name: VDD
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd
  supply_type: real
  logic_type: 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:15 'VDD real, periphery rail, arrives at the macro boundary' and cdl:63 '+ VDD VDDA VSS' in the top subcircuit port list

- fact 4
  supply_name: VDDA
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd
  supply_type: real
  logic_type: 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:16 'VDDA real, array rail, arrives at the macro boundary' and cdl:63 '+ VDD VDDA VSS' in the top subcircuit port list

- fact 5
  supply_name: VSS
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd
  supply_type: real
  logic_type: 0
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:17 'VSS real, ground, arrives at the macro boundary' and cdl:63 '+ VDD VDDA VSS' in the top subcircuit port list

- fact 6
  supply_name: VDDV_PERI
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd_pdv_peri_hdr
  supply_type: virtual
  logic_type: 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:18 'VDDV_PERI virtual, periphery rail gated by the SD/DS/POFF header'; cdl:67-68 XHDR_PERI VDD VDDV_PERI SD DS POFF<1> POFF<0> VSS sram_1p2m_n3a_16384x32m32b_hd_pdv_peri_hdr; switch MPHDR_PERI at cdl:104

- fact 7
  supply_name: VDDV_ARRAY
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd_pdv_array_hdr
  supply_type: virtual
  logic_type: 1
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:19 'VDDV_ARRAY virtual, array rail gated by the POFF header'; cdl:70-71 XHDR_ARRAY VDDA VDDV_ARRAY POFF<1> POFF<0> VSS sram_1p2m_n3a_16384x32m32b_hd_pdv_array_hdr; switch MPHDR_ARRAY at cdl:117

- fact 8
  supply_name: VSSV_BIAS
  subcircuit_name: sram_1p2m_n3a_16384x32m32b_hd_pdv_bias_ftr
  supply_type: virtual
  logic_type: 0
  evidence: design/spice/sram_1p2m_n3a_wrapper.cdl:20 'VSSV_BIAS virtual, source-biased ground raised in LS/DS retention'; cdl:73-74 XFTR_BIAS VSS VSSV_BIAS LS DS BC0 BC1 BC2 sram_1p2m_n3a_16384x32m32b_hd_pdv_bias_ftr; footer MNFTR_ACT/MNFTR_BIAS at cdl:127-128

## Retracted facts

(none)
