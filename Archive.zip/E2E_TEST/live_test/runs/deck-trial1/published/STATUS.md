# STATUS

Deck compiled and published for **sram_1p2m_n3a_16384x32m32b_hd** (the top cell
behind the `sram_1p2m_n3a_wrapper` file) in
`runs/deck-trial1/published/` — 67 parsed facts (verilog, spice, 6 supplies,
59 pins), both views named, all pin functions/polarities from the datasheet,
real/virtual supply split from the CDL headers.

The baseline symbolic run is scoped to mission mode (BISTE/TCLKE/SE_IN/TPR/
DFTCLKEN/DFTMASK/TEST1/TEST_RNM held inactive; power row NORMAL: LS=DS=SD=0,
POFF=00; TCLK quiescent; functional pins free) with cycle counts 4/2/8 as
baseline decisions.

Unresolved, for a human to confirm before sign-off: (1) the CDL does not drive
Q/QP/SO_* — data-path equivalence is vacuous with this netlist; (2) no `.edm`
exists, so ESP built-in process models are used; (3) the datasheet is a
reconstructed spec whose polarity statements and synthetic AC timing should be
checked against the vendor original; (4) the clock period is the template
default 5000/500; (5) `+incdir+./include` in the filelist points at a
nonexistent directory. Full list in `sram_1p2m_n3a_16384x32m32b_hd_setup_report.md` §6.
