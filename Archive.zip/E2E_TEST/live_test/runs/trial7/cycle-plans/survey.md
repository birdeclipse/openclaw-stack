# Corner Survey

Schema: esp.corner-roster.v1
Corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
Ledger facts: 59 pin(s), 72 operation(s), 2 scalar(s)

## Roster

| Corner | Classification | Reason |
| --- | --- | --- |
| calibration | unresolved | no supporting fact |
| clock-gating | unresolved | no supporting fact |
| idle | unresolved | no supporting fact |
| low-power-sequence | directive_named | directive named the corner: Verify the deep-sleep/shutdown retention sequence |
| mission-mode-read-write | directive_named | directive named the corner: Verify mission-mode read and write operations |
| multi-port-contention | absent | structurally impossible: single-port from typed pins ADR, BC0, BC1, BC2, BISTE, CAPT, CD, CLK, CRE1, CRE2, D, DFTCLKEN, DFTMASK, DS, FCA1, FCA2, FRA, HW, LS, ME, PIPEME, POFF, Q, QP, RA, RM, RME, ROP_DS, ROP_SD, RRE, SD, SE_IN, SI_CNTR, SI_D_H, SI_D_L, SI_Q_H, SI_Q_L, SO_CNTR, SO_D_H, SO_D_L, SO_Q_H, SO_Q_L, STICKY, TADR, TCLK, TCLKE, TD, TEST1, TEST_RNM, THW, TME, TPIPEME, TPR, TWE, TWEM, WA, WE, WEM, WPULSE |
| redundancy | candidate | pin-name rule matched CRE1, CRE2, FCA1, FCA2, FRA, RRE |
| scan-dft | directive_named | directive named the corner: Verify the scan shift path; Verify BIST-mode operation |
| bist-mode-operation | fact_supported | function_corner fact 135: With BISTE=1 the BIST port &#40;TME/TWE/TADR/TD/TWEM/THW/TCLK&#41; owns the muxed memory inputs and executes BIST-mode reads and writes, with TCLKE selecting the BIST clock; ownership handoff must follow the one-inactive-cycle guard. |
| deep-sleep-shutdown-retention | fact_supported | function_corner fact 136: The deep-sleep/shutdown retention sequence: legal IDLE→DS entry with outputs forced 0 and ROP_DS=1, retained array through DS, wake through WAKE_DS &#40;ROP_DS=0 plus guard cycle&#41;, and the destructive IDLE→SD/DS→SD path with ROP_SD; clocks must be quiescent during powered-down states. |
| scan-shift-path | fact_supported | function_corner fact 134: With SE_IN asserted, each scan chain &#40;Q_L/Q_H/D_L/D_H/CNTR&#41; shifts its SI input to its SO output across one full chain traversal; SE_IN must be the only owner and power modes/DFTMASK must be quiet. |

## Certified selection

- mission-mode-read-write
- low-power-sequence
- scan-dft
- bist-mode-operation
- deep-sleep-shutdown-retention
- scan-shift-path
- redundancy

## Pin inventory

| Pin | Direction |
| --- | --- |
| ADR | input |
| BC0 | input |
| BC1 | input |
| BC2 | input |
| BISTE | input |
| CAPT | input |
| CD | input |
| CLK | input |
| CRE1 | input |
| CRE2 | input |
| D | input |
| DFTCLKEN | input |
| DFTMASK | input |
| DS | input |
| FCA1 | input |
| FCA2 | input |
| FRA | input |
| HW | input |
| LS | input |
| ME | input |
| PIPEME | input |
| POFF | input |
| Q | output |
| QP | output |
| RA | input |
| RM | input |
| RME | input |
| ROP_DS | output |
| ROP_SD | output |
| RRE | input |
| SD | input |
| SE_IN | input |
| SI_CNTR | input |
| SI_D_H | input |
| SI_D_L | input |
| SI_Q_H | input |
| SI_Q_L | input |
| SO_CNTR | output |
| SO_D_H | output |
| SO_D_L | output |
| SO_Q_H | output |
| SO_Q_L | output |
| STICKY | input |
| TADR | input |
| TCLK | input |
| TCLKE | input |
| TD | input |
| TEST1 | input |
| TEST_RNM | input |
| THW | input |
| TME | input |
| TPIPEME | input |
| TPR | input |
| TWE | input |
| TWEM | input |
| WA | input |
| WE | input |
| WEM | input |
| WPULSE | input |

## Evidence catalog

| Ref | Evidence |
| --- | --- |
| cycle_fact:0 | ledger:60: truth_table_row&#40;IDLE, CLK=L, ME=X, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;no change in memory contents&#41;&#41; |
| cycle_fact:1 | ledger:61: truth_table_row&#40;DISABLED, CLK=H, ME=L, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM&#41; |
| cycle_fact:2 | ledger:62: truth_table_row&#40;DISABLED, CLK=H, ME=X, TPR=H, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM&#41; |
| cycle_fact:3 | ledger:63: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;both halves disabled, no read&#41;&#41; |
| cycle_fact:4 | ledger:64: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH-1/QL; NCM &#40;lower half read out, upper half holds&#41;&#41; |
| cycle_fact:5 | ledger:65: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH/QL-1; NCM &#40;upper half read out, lower half holds&#41;&#41; |
| cycle_fact:6 | ledger:66: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q &#40;full word read from addressed location&#41;; NCM&#41; |
| cycle_fact:7 | ledger:67: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;both halves disabled, no bits written&#41;&#41; |
| cycle_fact:8 | ledger:68: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array&#91;L&#93;=Data-in&#91;L&#93; &#40;lower half written, upper half NCM&#41;&#41; |
| cycle_fact:9 | ledger:69: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array&#91;H&#93;=Data-in&#91;H&#93; &#40;upper half written, lower half NCM&#41;&#41; |
| cycle_fact:10 | ledger:70: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array=Data-in &#40;full word written&#41;&#41; |
| cycle_fact:11 | ledger:71: truth_table_row&#40;MASK, CLK=H, ME=H, TPR=L, HW=XX, WE=H, WEM=L, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;masked write, no bits written&#41;&#41; |
| cycle_fact:12 | ledger:72: truth_table_row&#40;NORMAL, ME=0/1, HW=hw_val, LS=0, DS=0, SD=0, POFF=00, BC0=0/1, Q=Q-1, QP=QP-1, SO=SO-1, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1; normal mode&#41; |
| cycle_fact:13 | ledger:73: truth_table_row&#40;LIGHT_SLEEP, ME=0/1, HW=XX, LS=1, DS=0, SD=0, POFF=00, BC0=0/1, Q=Q-1, QP=QP-1, SO=SO-1; Xdec power gate, source bias &#40;retained&#41;&#41; |
| cycle_fact:14 | ledger:74: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0→1, SD=0, POFF=00, BC0=0/1, Q=0, QP=0, SO=0, ROP_DS=1, ROP_SD=ROP_SD-1; periphery shutdown, source bias&#41; |
| cycle_fact:15 | ledger:75: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1→0, SD=0, POFF=00, BC0=0/1, Q=0, QP=X, SO=X, ROP_DS=0, ROP_SD=ROP_SD-1 &#40;DS exit&#41;&#41; |
| cycle_fact:16 | ledger:76: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0→1, SD=1, POFF=00, BC0=0/1, Q=0, QP=0, SO=0, ROP_DS=1, ROP_SD=ROP_SD-1&#41; |
| cycle_fact:17 | ledger:77: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1→0, SD=1, POFF=00, BC0=0/1, Q=0, QP=0, SO=0, ROP_DS=1, ROP_SD=ROP_SD-1&#41; |
| cycle_fact:18 | ledger:78: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0→1, POFF=00, BC0=X, Q=0, QP=0, SO=0, ROP_DS=ROP_DS-1, ROP_SD=1; periphery shutdown, array shutdown&#41; |
| cycle_fact:19 | ledger:79: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1→0, POFF=00, BC0=X, Q=0, QP=X, SO=X, ROP_DS=ROP_DS-1, ROP_SD=0 &#40;SD exit&#41;&#41; |
| cycle_fact:20 | ledger:80: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0→1, POFF=00, BC0=X, Q=0, QP=0, SO=0, ROP_DS=ROP_DS-1, ROP_SD=1&#41; |
| cycle_fact:21 | ledger:81: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1→0, POFF=00, BC0=X, Q=0, QP=0, SO=0, ROP_DS=ROP_DS-1, ROP_SD=1&#41; |
| cycle_fact:22 | ledger:82: truth_table_row&#40;STANDARD_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=01, BC0=X, Q=Q-1, QP=X, SO=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1; periphery shutdown, source bias, VDD can be floating&#41; |
| cycle_fact:23 | ledger:83: truth_table_row&#40;SHUTDOWN_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=11, BC0=X, Q=Q-1, QP=X, SO=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1; periphery shutdown, array shutdown, VDD can be floating&#41; |
| cycle_fact:24 | ledger:84: truth_table_row&#40;NORMAL, BISTE=L, Active pins: ME, WE, ADR, D, WEM, CLK &#40;functional port owns the memory&#41;&#41; |
| cycle_fact:25 | ledger:85: truth_table_row&#40;BIST, BISTE=H, Active pins: TME, TWE, TADR, TD, TWEM, TCLK &#40;BIST port owns the memory&#41;&#41; |
| cycle_fact:26 | ledger:86: truth_table_row&#40;BIAS_NORMAL, BC0=0/1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=0, Active-mode bias &#40;no source bias applied&#41;&#41; |
| cycle_fact:27 | ledger:87: truth_table_row&#40;BIAS_LS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=0, LS=1, Debug mode; array bias removed in Light Sleep&#41; |
| cycle_fact:28 | ledger:88: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=0, SD=0, DS=0, LS=1, Light Sleep with array bias via BC1&#41; |
| cycle_fact:29 | ledger:89: truth_table_row&#40;BIAS_LS, BC0=0, BC1=0, BC2=1, SD=0, DS=0, LS=1, Light Sleep with array bias via BC2&#41; |
| cycle_fact:30 | ledger:90: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=1, SD=0, DS=0, LS=1, Light Sleep with array bias via BC1 and BC2&#41; |
| cycle_fact:31 | ledger:91: truth_table_row&#40;BIAS_LS_NO_BIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=1, Light Sleep without array bias &#40;BC0 bypasses bias&#41;&#41; |
| cycle_fact:32 | ledger:92: truth_table_row&#40;BIAS_DS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=1, LS=0, Debug mode; array bias removed in Deep Sleep&#41; |
| cycle_fact:33 | ledger:93: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=0, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC1&#41; |
| cycle_fact:34 | ledger:94: truth_table_row&#40;BIAS_DS, BC0=0, BC1=0, BC2=1, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC2&#41; |
| cycle_fact:35 | ledger:95: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=1, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC1 and BC2&#41; |
| cycle_fact:36 | ledger:96: truth_table_row&#40;BIAS_DS_NO_BIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=1, LS=0, Deep Sleep without array bias &#40;BC0 bypasses bias&#41;&#41; |
| cycle_fact:37 | ledger:97: truth_table_row&#40;BIAS_SHUTDOWN, BC0=0/1, BC1=0/1, BC2=0/1, SD=1, DS=0, LS=0, Shutdown without array retention&#41; |
| cycle_fact:38 | ledger:98: truth_table_row&#40;R01_SD_DS, SD=1 and DS=1, Q/QP/SO forced 0; shutdown wins; retention not guaranteed&#41; |
| cycle_fact:39 | ledger:99: truth_table_row&#40;R02_POWER_LS_OVERLAP, SD=1 and LS=1, or DS=1 and LS=1, Q/QP/SO take the deeper-mode value &#40;0 in DS/SD&#41;; deeper mode wins; LS must be deasserted before wake begins&#41; |
| cycle_fact:40 | ledger:100: truth_table_row&#40;R05_CLOCK_WHILE_POWERED_DOWN, Any rising CLK/TCLK while DS, SD, or POFF is active, No valid output event; powered outputs retain forced value; illegal clock event&#41; |
| cycle_fact:41 | ledger:101: truth_table_row&#40;R06_HW00_WRITE_NOOP, ME=1, WE=1, HW=00, Q retains Q-1; no bits written irrespective of WEM&#41; |
| cycle_fact:42 | ledger:102: truth_table_row&#40;R08_TPR_IDLE, TPR=1 while ME=1, Q retains Q-1; no read/write; ADR/D/WE/WEM changes ignored&#41; |
| cycle_fact:43 | ledger:103: truth_table_row&#40;R10_BISTE_FUNC_CLK, BISTE=1 and functional CLK toggles while TCLKE selects TCLK, BIST result only; functional CLK has no effect &#40;legal ignored input&#41;&#41; |
| cycle_fact:44 | ledger:104: truth_table_row&#40;R11_TCLKE_HIGH, TCLKE toggles while either CLK or TCLK is high, Q/QP/SO=X for one cycle; runt internal clock may corrupt the current address on a write&#41; |
| cycle_fact:45 | ledger:105: truth_table_row&#40;R12_BISTE_HANDOFF, BISTE changes while ME=1 or TME=1, or while selected clock is high, Q/QP=X until one clean inactive cycle; if WE or TWE was active, selected word/bit mask is corrupted&#41; |
| cycle_fact:46 | ledger:106: truth_table_row&#40;R13_SE_IN_DFTMASK, SE_IN=1 with DFTMASK=1, Scan output advances; Q=X; SE_IN scan ownership wins&#41; |
| cycle_fact:47 | ledger:107: truth_table_row&#40;R14_DFTMASK_NO_CLKEN, DFTMASK=1 and DFTCLKEN=0, Q retains Q-1; diagnostic issued&#41; |
| cycle_fact:48 | ledger:108: truth_table_row&#40;R22_CAPT_BISTE0, CAPT=0 while BISTE=0, No effect; comparator state unchanged&#41; |
| cycle_fact:49 | ledger:109: truth_table_row&#40;R23_PIPEME_TPIPEME, PIPEME=1 and TPIPEME=1 simultaneously, QP captures from PIPEME when BISTE=0, from TPIPEME when BISTE=1; non-selected enable ignored&#41; |
| cycle_fact:50 | ledger:110: truth_table_row&#40;R24_POWER_DURING_SCAN, Power mode asserted during scan shift, Deep-mode output convention; scan state not guaranteed; array retention follows selected power mode&#41; |
| cycle_fact:51 | ledger:111: truth_table_row&#40;TRANS_IDLE_ACTIVE, LS=DS=SD=0, POFF inactive, selected enable asserted with setup met, one valid clock edge, Data preserved; normal tCQ behavior&#41; |
| cycle_fact:52 | ledger:112: truth_table_row&#40;TRANS_ACTIVE_IDLE, Deassert ME/TME; complete any TEST1 falling edge; one full inactive clock cycle before ownership/power changes, Data preserved; last Q/QP retained&#41; |
| cycle_fact:53 | ledger:113: truth_table_row&#40;TRANS_IDLE_LS, Assert LS while DS=SD=0 and POFF inactive; minimum dwell tLSENT, Data retained; Q/QP/SO retain prior values&#41; |
| cycle_fact:54 | ledger:114: truth_table_row&#40;TRANS_LS_IDLE, Deassert LS; hold ME=TME=0; tLSEXT before next active clock, Data retained; prior values retained&#41; |
| cycle_fact:55 | ledger:115: truth_table_row&#40;TRANS_ACTIVE_LS, First transition ACTIVE→IDLE required, No direct ACTIVE→LS transition; must go through IDLE&#41; |
| cycle_fact:56 | ledger:116: truth_table_row&#40;TRANS_IDLE_DS, Clocks low; ME=TME=0; LS=SD=0; assert DS; minimum dwell tDSENT, Q/QP/SO forced 0; ROP_DS=1; retained if VDDA remains in retention range&#41; |
| cycle_fact:57 | ledger:117: truth_table_row&#40;TRANS_DS_WAKE_DS, Deassert DS while LS=SD=0 and clocks remain low, Retained; Q=0, QP/SO=X; ROP_DS=1&#41; |
| cycle_fact:58 | ledger:118: truth_table_row&#40;TRANS_WAKE_DS_IDLE, Wait until ROP_DS=0, then one guard cycle; tROPDS + tPGGUARD &#40;tPGGUARD = 2 CLK cycles per Table 6-2&#41;, Outputs become valid after guard; data retained&#41; |
| cycle_fact:59 | ledger:119: truth_table_row&#40;TRANS_DS_SD, Assert SD while clocks remain low; minimum dwell tSDFALL, Destroyed/unknown; outputs forced 0; ROP_SD=1&#41; |
| cycle_fact:60 | ledger:120: truth_table_row&#40;TRANS_IDLE_SD, Clocks low; ME=TME=0; LS=DS=0; assert SD; minimum dwell tSDENT, Destroyed/unknown upon assertion; Q/QP/SO forced 0; ROP_SD=1&#41; |
| cycle_fact:61 | ledger:121: truth_table_row&#40;TRANS_SD_WAKE_SD, Restore supplies, then deassert SD; keep all enables low, Unknown; initialization/BIST required; Q=0, QP/SO=X; ROP_SD=1&#41; |
| cycle_fact:62 | ledger:122: truth_table_row&#40;TRANS_WAKE_SD_IDLE, Wait until ROP_SD=0, then apply tPGGUARD; tROPSD + tPGGUARD, Outputs valid electrically, data unknown until written&#41; |
| cycle_fact:63 | ledger:123: truth_table_row&#40;TRANS_IDLE_POFF_RET, Embedded: POFF 00→01; periphery clock stopped; minimum dwell tPOFFENT, Q/QP/SO=X after periphery supply collapse; retained if VDDA valid&#41; |
| cycle_fact:64 | ledger:124: truth_table_row&#40;TRANS_POFF_RET_IDLE, Restore VDD first, wait tVDDSTB, then remove POFF; tVDDSTB + tPGGUARD, Retained; X until periphery is stable&#41; |
| cycle_fact:65 | ledger:125: truth_table_row&#40;TRANS_IDLE_POFF_SD, POFF 00→11 with clocks/enables inactive; minimum dwell tPOFFENT, Destroyed; Q/QP/SO=X&#41; |
| cycle_fact:66 | ledger:126: truth_table_row&#40;TRANS_LS_DS, Deassert LS, wait tLSEXT, then assert DS, Retained; last Q then forced 0&#41; |
| cycle_fact:67 | ledger:127: truth_table_row&#40;TRANS_DS_LS, Complete DS→WAKE_DS→IDLE, then assert LS, Retained; per DS wake sequence&#41; |
| cycle_fact:68 | ledger:128: truth_table_row&#40;TRANS_IDLE_SCAN, Both clocks low; BISTE=0; assert SE_IN; then enable DFT clock; one clock-low phase, Array preserved; SO follows scan timing; Q not functionally updated&#41; |
| cycle_fact:69 | ledger:129: truth_table_row&#40;TRANS_IDLE_BIST, Both clocks low; SE_IN=0; establish TCLKE; assert BISTE; wait one inactive selected-clock cycle, Preserved until BIST writes; BIST owns all muxed inputs&#41; |
| cycle_fact:70 | ledger:130: truth_table_row&#40;TRANS_SCAN_BIST_IDLE, Deassert DFTCLKEN/TME first; selected clock low; deassert owner; wait one inactive cycle, As modified by test; last test outputs may persist&#41; |
| cycle_fact:71 | ledger:131: truth_table_row&#40;TRANS_POWER_OWNER_REENTRY, Any powered/power state to another owner or power state without passing through IDLE, X or deeper-mode clamp; illegal&#41; |
| fact:ddf-c9f8fbf1 | The datasheet states the pipelined read output follows the regular output with a latency of one clock cycle &#40;PIPEME/TPIPEME description&#41;. |
| fact:ddf-17baa9ce | The functional wrapper models every scan chain &#40;Q_L/Q_H/D_L/D_H/CNTR&#41; as a one-stage pass-through of its input when SE_IN=1, so one logical shift traverses a chain in the model under test. |
| directive:0 | Verify mission-mode read and write operations |
| directive:1 | Verify the scan shift path |
| directive:2 | Verify BIST-mode operation |
| directive:3 | Verify the deep-sleep/shutdown retention sequence |

Every pin in the inventory above is also citable evidence as `pin:<NAME>`.

## Evidence gaps

- No deck model: pin directions come from the logged pin facts only. The corner rules read those same logged directions.
