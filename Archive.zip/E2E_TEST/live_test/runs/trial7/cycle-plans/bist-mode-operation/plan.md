# Cycle Plan — bist-mode-operation

- **Corner:** bist-mode-operation
- **Run root:** /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- **Corpus digest:** bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- **Outcome:** plan

## Cycle-count table

| phase | count | rationale |
|---|---|---|
| BIN | 3 | Entry prelude per `cycle_fact:69` (TRANS_IDLE_BIST): BINCYCLE1 establishes the idle state with both clocks low, SE_IN=0, TCLKE=1 selecting the BIST clock, BISTE=0; BINCYCLE2 asserts BISTE=1 with clocks low and ME=TME=0 (clean handoff per `cycle_fact:45` R12); BINCYCLE3 is the one inactive selected-clock cycle (TCLK low) that completes the ownership-handoff guard. b=3 because the entry sequence has three distinct evidence-backed steps; b=2 would drop the guard cycle. |
| SYM | 2 | BIST-mode operations through the muxed BIST port (`cycle_fact:25`): SYMCYCLE1 performs a full-word BIST write (TME=1, TWE=1, THW=11, TWEM=H, TD symbolic, TADR symbolic), SYMCYCLE2 performs a full-word BIST read of the same address (TME=1, TWE=0, THW=11). s=2 because the corner exercises one write and one read; the read observes the write. |
| FLUSH | 3 | FLUSHCYCLE1 propagates the read result to default comparison (launch SYMCYCLE2 + pipeline_depth 1) while deasserting TME so no later operation overwrites Q; FLUSHCYCLE2 completes the owner deassertion by deasserting BISTE with TME=ME=0 and TCLK low (`cycle_fact:70`, `cycle_fact:45`); FLUSHCYCLE3 is the "wait one inactive cycle" after the owner deassertion that completes the TRANS_SCAN_BIST_IDLE exit (`cycle_fact:70`). f=3 because the read needs one propagation cycle, the owner deassertion needs one, and the post-deassertion inactive cycle needs one. |

## Segment table — BIN

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | idle prelude | establish idle state: both clocks low, SE_IN=0, TCLKE=1 selects the BIST clock, BISTE=0, ME=TME=0, power modes quiet | `CLK=1'b0`, `TCLK=1'b0`, `SE_IN=1'b0`, `TCLKE=1'b1`, `BISTE=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:69`, `cycle_fact:0`, `cycle_fact:45`, `cycle_fact:40` |
| BINCYCLE2 | BISTE assertion | assert BISTE=1 with clocks low and ME=TME=0 so the handoff is clean (R12) | `BISTE=1'b1` | `cycle_fact:69`, `cycle_fact:25`, `cycle_fact:45` |
| BINCYCLE3 | handoff guard | one inactive selected-clock cycle (TCLK low) after BISTE assertion completes the ownership handoff | `TCLK=1'b0` | `cycle_fact:69`, `cycle_fact:45` |

## Segment table — SYM

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | BIST write | BIST port writes a full word: TME=1, TWE=1, THW=11, TWEM=H, TD symbolic (write data), TADR symbolic (address); TCLKE=1, BISTE=1, SE_IN=0, power quiet held | `TME=1'b1`, `TWE=1'b1`, `THW=2'b11`, `TWEM=1'b1`, `TCLKE=1'b1`, `BISTE=1'b1`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:25`, `cycle_fact:10`, `cycle_fact:40` |
| SYMCYCLE2 | BIST read | BIST port reads a full word from the same address: TME=1, TWE=0, THW=11; TADR held at the same symbol as the write; power quiet held | `TME=1'b1`, `TWE=1'b0`, `THW=2'b11`, `TCLKE=1'b1`, `BISTE=1'b1`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:25`, `cycle_fact:6`, `cycle_fact:40` |

## Segment table — FLUSH

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | read propagation | deassert TME so no further operation occurs; Q retains the read data and the read result reaches default comparison; TCLK low, ME=0, SE_IN=0 | `TME=1'b0`, `TWE=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `SE_IN=1'b0`, `TCLKE=1'b1`, `BISTE=1'b1`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:52`, `cycle_fact:46`, `cycle_fact:70`, `cycle_fact:40` |
| FLUSHCYCLE2 | owner deassertion | deassert BISTE with TME=0, ME=0, TCLK low (clean handoff per R12) | `BISTE=1'b0`, `TCLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:70`, `cycle_fact:45`, `cycle_fact:40` |
| FLUSHCYCLE3 | exit wait | one inactive cycle after the owner deassertion completes the TRANS_SCAN_BIST_IDLE exit | `BISTE=1'b0`, `TCLK=1'b0`, `TME=1'b0`, `ME=1'b0`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:70`, `cycle_fact:40` |

## Observability table

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| BIST write | SYMCYCLE1 (j=1) | FLUSHCYCLE1 | Array[addr]=data (full word) | observed through the read: SYMCYCLE2 reads the same address (TADR symbolic_static), so a failed write returns stale array data instead of the written data |
| BIST read | SYMCYCLE2 (j=2) | FLUSHCYCLE1 | Q=read data (full word) | TME=0 in FLUSH so no later operation overwrites Q (`cycle_fact:52`); SE_IN=0 so scan does not overwrite (`cycle_fact:46`); BISTE deassertion in FLUSHCYCLE2 is clean (TME=0, ME=0, TCLK low) per `cycle_fact:45`, and FLUSHCYCLE3 holds the inactive state so nothing re-drives Q before comparison |
| BIST entry handoff | BINCYCLE2 | SYMCYCLE1 | BIST port owns the muxed memory inputs | BISTE=1 and TCLKE=1 held stable through SYM; handoff clean (clocks low, ME=TME=0) per `cycle_fact:69`, `cycle_fact:45` |
| BIST exit handoff | FLUSHCYCLE1 | FLUSHCYCLE3 | clean exit to idle | TME=0, ME=0, TCLK low during BISTE deassertion per `cycle_fact:70`, `cycle_fact:45`; the post-deassertion inactive cycle (FLUSHCYCLE3) completes the exit |

A1 arithmetic: write j=1 → s−j+f = 2−1+3 = 4 ≥ pipeline_depth 1 (`fact:ddf-c9f8fbf1`). read j=2 → s−j+f = 2−2+3 = 3 ≥ 1. Both hold.

## Symbolic-treatment table

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| CLK | BIN | literal 0 | functional CLK toggling in BIN | entry requires both clocks low | `cycle_fact:69` |
| TCLK | BIN, FLUSH | literal 0 | TCLK toggling in BIN/FLUSH | entry/exit require the selected clock inactive; R12 handoff guard | `cycle_fact:69`, `cycle_fact:70`, `cycle_fact:45` |
| SE_IN | BIN, SYM, FLUSH | literal 0 | scan paths | BIST entry requires SE_IN=0; scan ownership would invalidate BIST ops and overwrite Q | `cycle_fact:69`, `cycle_fact:46` |
| TCLKE | BIN, SYM, FLUSH | literal 1 | TCLKE transition space (selecting CLK) | TCLKE selects the BIST clock; R11 requires it stable while a clock is high | `cycle_fact:25`, `cycle_fact:69`, `cycle_fact:44` |
| BISTE | BIN, SYM, FLUSH | literal 0→1→1→0 | BISTE=0 (functional-mode) paths | directive:2 requires BIST-mode operation; BISTE=H selects the BIST port | `directive:2`, `cycle_fact:25` |
| ME | BIN, FLUSH | literal 0 | functional ME toggling during handoff | R12: BISTE change while ME=1 → X | `cycle_fact:45` |
| TME | BIN | literal 0 | TME toggling in BIN | R12: BISTE change while TME=1 → X | `cycle_fact:45` |
| TME | SYM | literal 1 | TME=0 (no-op) paths | BIST read and write both require TME=1 | `cycle_fact:6`, `cycle_fact:10` |
| TWE | SYM | literal 1 (SYM1), 0 (SYM2) | TWE transition space | write then read | `cycle_fact:10`, `cycle_fact:6` |
| THW | SYM | literal 11 | half-word paths | full-word read/write | `cycle_fact:6`, `cycle_fact:10` |
| TWEM | SYM1 | literal H | masked-write paths | write mask enable | `cycle_fact:10` |
| LS, DS, SD | all | literal 0 | power modes during BIST | R05 forbids any rising CLK/TCLK while DS/SD/POFF is active (`cycle_fact:40`); TCLK is unconstrained in SYM, so the power pins must stay quiet to keep the forbidden combination unreachable | `cycle_fact:40` |
| POFF | all | literal 00 | POFF != 00 (periphery-off modes) | R05 forbids rising CLK/TCLK while POFF is active (`cycle_fact:40`) | `cycle_fact:40` |
| TADR | whole run | symbolic_static | TADR transition space | write→read same-address relation; the read must observe the address written | `cycle_fact:10`, `cycle_fact:6` |

TD (write data) and TCLK (in SYM) are left unconstrained — the strongest coverage ESP gives. The functional-port pins (ME in SYM, WE, ADR, D, WEM, HW) are left unconstrained because the BIST port owns the memory in BIST mode (`cycle_fact:25`).

## Assumptions

- TCLK is driven by the testbench in SYM to provide the operation clock edges; the plan does not constrain TCLK in SYM (it is an exploration pin). The BIST read/write execute on the testbench's TCLK edges. Because TCLK is unconstrained in SYM, the power pins are held quiet (LS=DS=SD=0, POFF=00) so the R05-forbidden combination (rising TCLK while a power mode is active) is never reachable.
- THW is 2 bits (half-word select, HW=LL/LH/HL/HH), so THW=2'b11 selects the full word (`cycle_fact:6`, `cycle_fact:10`). THW's encoding is inferred from HW by analogy (no catalog row states THW's encoding directly).
- No reset pin exists and no `reset_latency_cycles` is declared; the BIN prelude establishes the idle state directly per `cycle_fact:69`, not via reset.
- The TADR write==read same-address relation is expressed with `symbolic_static` on TADR (one symbol for the whole run). No `testbench_declarations.sv` is emitted: the R11/R12 handoff guards are expressed by holding TCLKE/BISTE stable and driving clocks low with `set_constraint`, and the TADR relation by `symbolic_static`.
- The exit includes one inactive cycle after the BISTE deassertion (FLUSHCYCLE3), completing the "deassert owner; wait one inactive cycle" of `cycle_fact:70`.

## Limitations

- Half-word BIST reads/writes (THW=LH/HL) are not exercised; only full-word (THW=11).
- Masked BIST writes (TWEM=L) are not exercised.
- The TADR transition space is not explored (`symbolic_static`).
- Functional-port operation in BIST mode is not exercised (the functional port is ignored per `cycle_fact:25`).
- The full scan exit (DFTCLKEN deassertion) is not exercised; the BIST exit handoff is completed per `cycle_fact:70`. No scan/DFT-shift directive touches this corner, so A3 does not apply.

## Coverage argument

- **catches:** a BIST write that fails to write the array (the read returns stale data instead of the written data); a BIST read that returns wrong data at Q; a broken BISTE ownership handoff (X on Q per `cycle_fact:45`); a TCLKE muxing error (R11, `cycle_fact:44`); a functional-port leak into BIST mode (violation of `cycle_fact:25`); a scan-ownership collision (SE_IN=1 overwriting Q per `cycle_fact:46`); a clock rise while a power mode is active (R05, `cycle_fact:40`) — kept unreachable by the power-quiet holds.
- **misses:** half-word and masked-write BIST operations; TADR-transition-dependent faults; functional-mode faults (those belong to the mission-mode-read-write corner). These misses are acceptable because the corner's scope is full-word BIST read/write semantics and the ownership handoff, and the excluded classes are either separate corners or explicitly out of the directive's scope (`directive:2`).
