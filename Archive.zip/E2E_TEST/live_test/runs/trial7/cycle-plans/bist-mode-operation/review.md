# Review — bist-mode-operation

- corner: bist-mode-operation
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## correct

- **A1 arithmetic verified.** Write at SYMCYCLE1 (j=1): `s - j + f = 2 - 1 + 2 = 3 >= pipeline_depth 1` (`fact:ddf-c9f8fbf1`). Read at SYMCYCLE2 (j=2): `s - j + f = 2 - 2 + 2 = 2 >= 1`. Both hold.
- **TADR write==read same-address relation is expressed.** `set_constraint {TADR} -symbolic_static` holds one symbol for the whole run, so the write at SYMCYCLE1 and the read at SYMCYCLE2 target the same address and the read observes the written value. The lost TADR transition space is disclosed in the symbolic-treatment table (plan.md line 64).
- **Exit handoff mostly matches the evidence.** TME is deasserted in FLUSHCYCLE1, BISTE is deasserted in FLUSHCYCLE2 with TME=0, ME=0, TCLK low — consistent with `cycle_fact:70` (deassert TME first, selected clock low, deassert owner) and `cycle_fact:45` (R12: BISTE change while TME=0, ME=0, clock low is clean).
- **Faithful lowering.** constraints.tcl matches plan.md: BIN (CLK/TCLK/SE_IN/TCLKE/ME/TME per-cycle, BISTE 0 then 1), SYM (TCLKE/BISTE/SE_IN/TME/THW held, TWE/TWEM per-cycle, TADR symbolic_static), FLUSH (TME/TWE/TCLK/ME/SE_IN/TCLKE held, BISTE 1 then 0). No drift between plan and Tcl.
- **B4 mutation coverage.** A BIST write that fails to write the array is caught (the read returns stale data); a broken BISTE ownership handoff (X on Q per `cycle_fact:45`) and a TCLKE muxing error (`cycle_fact:44`) are reachable.

## missing

- **Family E — DS/SD/POFF left unconstrained allows the R05-forbidden combination to be reachable.** `cycle_fact:40` (R05) explicitly labels any rising CLK/TCLK while DS, SD, or POFF is active an "illegal clock event". In this corner TCLK is unconstrained in SYM (can rise) and DS/SD/POFF are left unconstrained (can be active), so the forbidden combination is reachable. The scan corner constrains power modes quiet during scan (`cycle_fact:50`); this corner should do the same during BIST (hold LS/DS/SD=0, POFF=00) or document a soft-policy deviation explaining why the R05-violating subspace does not undermine the BIST objective. Not plan-invalidating (the BIST operations are reachable in the power-quiet subspace), but an explicitly forbidden combination is left reachable.
- **Minor — exit handoff omits the "wait one inactive cycle" after BISTE deassertion.** `cycle_fact:70` requires "deassert owner; wait one inactive cycle". The plan deasserts BISTE in FLUSHCYCLE2 and ends there, so the post-deassertion wait cycle is absent. The clean-handoff claim (R12) is still supported by the TME=0/ME=0/TCLK-low conditions, but the full exit sequence of `cycle_fact:70` is not completed. Smallest correction: add one flush cycle after BISTE deassertion, or scope the exit claim to the R12 clean-change condition only.

## user-review

- **THW=2'b11 full-word semantics are inferred from HW, not directly evidenced for THW.** The plan cites `cycle_fact:6`/`cycle_fact:10` (HW rows) for THW=11. THW is the BIST half-word select per fact 135, so the analogy is reasonable, but no catalog row states THW's encoding directly. If THW encoding differs from HW, the full-word assumption breaks.
- **TCLK unconstrained in SYM means the BIST operations execute only in the TCLK-toggling subspace.** The plan assumes the testbench drives TCLK (plan.md line 70); in traces where TCLK stays 0 no operation executes. The operations are reachable, so this is not a soundness defect, but the observability claim is subspace-scoped and the plan does not explicitly disclose it.
- **symbolic_static on TADR is a routing judgment call.** The guide reserves `symbolic_static` for stable configuration inputs; the write==read relation is a cross-cycle equality the guide would route to a declaration file. `symbolic_static` faithfully expresses the relation (one symbol held across the run) and the plan discloses the lost transition space, so it is defensible, but it is not the guide's canonical use.

## cross-corner

- `cross-corner:` Power-mode pins (LS/DS/SD/POFF) are left unconstrained here, allowing the R05-forbidden combination (TCLK rising while a power mode is active) to be reachable; mission-mode-read-write and scan-shift-path hold them quiet, and deep-sleep-shutdown-retention drives them per-cycle. This is the notable divergence — the other three corners respect R05, this one does not.
- `cross-corner:` Same-address observability is handled two ways: this corner forces the relation with `symbolic_static` on TADR; mission-mode-read-write leaves ADR unconstrained and scopes the write→read claim to the same-address subspace. Both defensible; deliberate divergence.
- `cross-corner:` CLK/TCLK handling diverges across corners. This corner holds CLK=0 in BIN and TCLK=0 in BIN/FLUSH with TCLK unconstrained in SYM; scan-shift-path holds both 0 throughout; mission-mode-read-write leaves both unconstrained; deep-sleep-shutdown-retention drives CLK per-cycle and TCLK=0 throughout. Deliberate per-corner mode differences.
- `cross-corner:` `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) is used consistently in this corner, mission-mode-read-write, and deep-sleep-shutdown-retention; `scan_chain_length=1` (`fact:ddf-17baa9ce`) is used in scan-shift-path.
