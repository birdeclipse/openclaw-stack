# constraints.tcl — bist-mode-operation (revised per review)
# Lowered from plan.md (corpus digest bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9).
# Values/conditions are Verilog expressions. Pins exactly as the inventory spells them.
# Revision: power pins held quiet (LS=DS=SD=0, POFF=00) so the R05-forbidden
# combination (rising TCLK while a power mode is active) is unreachable; the
# exit now includes the post-BISTE-deassertion inactive cycle (f=3).
# No testbench_declarations.sv: the TADR write==read relation is expressed with
# -symbolic_static, and the R11/R12 handoff guards by holding TCLKE/BISTE stable and
# driving clocks low. See plan.md Assumptions.

# --- testbench cycle counts (b=3, s=2, f=3) ---
set_app_var testbench_binary_cycles  3
set_app_var testbench_symbolic_cycles 2
set_app_var testbench_flush_cycles   3

# --- BIN: entry prelude (cycle_fact:69, cycle_fact:0, cycle_fact:45) ---
# Both clocks low, SE_IN=0, TCLKE=1 selects the BIST clock, ME=TME=0 for a clean handoff,
# power pins quiet (R05, cycle_fact:40).
set_constraint {CLK}   -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {TCLK}  -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {SE_IN} -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {TCLKE} -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b1}
set_constraint {ME}    -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {TME}   -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {LS}    -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {DS}    -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {SD}    -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {1'b0}
set_constraint {POFF}  -cycle {BINCYCLE1 BINCYCLE2 BINCYCLE3} -set {2'b00}
# BISTE: idle in BINCYCLE1, assert in BINCYCLE2, hold through the guard cycle BINCYCLE3.
set_constraint {BISTE} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BISTE} -cycle {BINCYCLE2 BINCYCLE3} -set {1'b1}

# --- SYM: BIST write then read (cycle_fact:25, cycle_fact:10, cycle_fact:6) ---
# TCLKE=1, BISTE=1, SE_IN=0 held stable through both symbolic cycles; power quiet.
set_constraint {TCLKE} -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b1}
set_constraint {BISTE} -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b1}
set_constraint {SE_IN} -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b0}
set_constraint {LS}    -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b0}
set_constraint {DS}    -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b0}
set_constraint {SD}    -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b0}
set_constraint {POFF}  -cycle {SYMCYCLE1 SYMCYCLE2} -set {2'b00}
# TME=1 for both read and write; THW=11 full word.
set_constraint {TME}   -cycle {SYMCYCLE1 SYMCYCLE2} -set {1'b1}
set_constraint {THW}   -cycle {SYMCYCLE1 SYMCYCLE2} -set {2'b11}
# SYMCYCLE1 write: TWE=1, TWEM=H. SYMCYCLE2 read: TWE=0.
set_constraint {TWE}   -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {TWEM}  -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {TWE}   -cycle {SYMCYCLE2} -set {1'b0}
# TADR held at one symbol for the whole run so the read observes the written address.
set_constraint {TADR}  -symbolic_static

# --- FLUSH: read propagation + exit handoff (cycle_fact:52, cycle_fact:46, cycle_fact:70, cycle_fact:45) ---
# Deassert TME so no later operation overwrites Q; TCLK low; ME=0, SE_IN=0; power quiet.
set_constraint {TME}   -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {TWE}   -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {TCLK}  -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {ME}    -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {SE_IN} -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {TCLKE} -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b1}
set_constraint {LS}    -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {DS}    -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {SD}    -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
set_constraint {POFF}  -cycle {FLUSHCYCLE1 FLUSHCYCLE2 FLUSHCYCLE3} -set {2'b00}
# BISTE held in FLUSHCYCLE1, deasserted in FLUSHCYCLE2, held inactive in FLUSHCYCLE3
# (the post-deassertion inactive cycle completes the exit per cycle_fact:70).
set_constraint {BISTE} -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {BISTE} -cycle {FLUSHCYCLE2 FLUSHCYCLE3} -set {1'b0}
