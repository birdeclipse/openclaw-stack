# Cross-corner summary — trial7

Corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7

## Divergences between corners

| divergence | corners | deliberate? | note |
|---|---|---|---|
| CLK/TCLK treatment | mission-mode-read-write leaves both unconstrained; scan-shift-path holds both 0 throughout; bist-mode-operation holds CLK=0 in BIN and TCLK=0 in BIN/FLUSH with TCLK unconstrained in SYM; deep-sleep-shutdown-retention drives CLK per-cycle (0 in powered-down cycles, 1 in ACTIVE/IDLE) and TCLK=0 throughout | Yes | each corner implements the clock discipline its mode entry requires: mission-mode needs free functional clock edges; scan entry requires both clocks low (`cycle_fact:68`); BIST entry requires clocks low with TCLK free in the operation cycles; deep-sleep requires clocks quiescent while DS/SD is active (`cycle_fact:40`) |
| Power pins LS/DS/SD/POFF | mission-mode-read-write and scan-shift-path hold them quiet (NORMAL mode / R24); deep-sleep-shutdown-retention drives them per-cycle (the corner's whole subject); bist-mode-operation held them quiet after review (was left unconstrained) | Yes | the interrogator flagged bist-mode-operation's unconstrained power pins as allowing the R05-forbidden combination (rising TCLK while a power mode is active) to be reachable; the plan was revised to hold LS=DS=SD=0, POFF=00 during BIST, aligning it with the other corners' R05 discipline |
| Same-address observability | mission-mode-read-write leaves ADR unconstrained and scopes the write→read claim to the ADR1=ADR2 subspace; bist-mode-operation forces the write==read relation with `symbolic_static` on TADR | Yes | two defensible encodings of the same requirement; mission-mode preserves the full address space (claim scoped), BIST concretizes the relation with a held symbol (lost transition space disclosed) |
| Scalar usage | `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) used in mission-mode-read-write, bist-mode-operation, deep-sleep-shutdown-retention; `scan_chain_length=1` (`fact:ddf-17baa9ce`) used in scan-shift-path | Yes | consistent; no corner contradicts another on either scalar |
| Pre/entry guards | scan-shift-path, bist-mode-operation, deep-sleep-shutdown-retention all enter their mode from an IDLE prelude (`cycle_fact:68`/`69`/`56`+`60`) with enables deasserted and clocks managed; mission-mode-read-write enters the functional mode with a two-cycle inactive prelude | Yes | A5 does not bind (no reset pin), so each BIN phase is the mode-entry sequencing its corner needs |

## Interrogator cross-corner findings and disposition

- `cross-corner:` CLK/TCLK divergence — deliberate per-corner mode differences; no revision needed.
- `cross-corner:` power-pin divergence — the only finding that was not purely deliberate: bist-mode-operation left power pins unconstrained while the other three corners respect R05. Revised: power-quiet holds added to bist-mode-operation.
- `cross-corner:` same-address observability handled two ways (unconstrained-ADR-subspace vs `symbolic_static` TADR) — deliberate divergence, recorded above.
- `cross-corner:` scalar consistency — confirmed consistent across corners.

## Roster-scope note

The survey's certified selection also lists the built-in corners `low-power-sequence` (directive_named via directive:3), `scan-dft` (directive_named via directives:1 and 2), and `redundancy` (candidate via the CRE/FCA/FRA/RRE pin-name rule). The user's request names four specific behaviors, which map to the four dispatched corners: mission-mode-read-write, scan-shift-path, bist-mode-operation, deep-sleep-shutdown-retention. `low-power-sequence` and `scan-dft` are the built-in aliases of the two user-named custom corners (deep-sleep retention and scan shift respectively) and are subsumed by them; `redundancy` was not requested and was not dispatched. These are roster-scope decisions, not plan divergences.
