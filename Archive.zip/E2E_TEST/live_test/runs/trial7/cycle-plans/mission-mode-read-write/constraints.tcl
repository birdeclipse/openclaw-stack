# ---------------------------------------------------------------------------
# Mission-mode read/write corner — lowered constraints
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
# Corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
#
# Transliteration of plan.md (mission-mode-read-write). Values and conditions
# are Verilog expressions; widths are exact; pins are spelled exactly as the
# survey inventory lists them. Targets are primary inputs only — Q/QP are
# outputs and are observed, never driven.
# ---------------------------------------------------------------------------

# --- Testbench cycle counts (derived in plan.md: b=2, s=2, f=1) ------------
set_app_var testbench_binary_cycles  2
set_app_var testbench_symbolic_cycles 2
set_app_var testbench_flush_cycles   1

# --- Mode pins, held across the run (mission mode) --------------------------
# BISTE=0: functional port owns the memory (cycle_fact:24)
set_constraint {BISTE} -set {1'b0}
# SE_IN=0: mission mode, not scan (cycle_fact:24, cycle_fact:68)
set_constraint {SE_IN} -set {1'b0}
# LS=DS=SD=0, POFF=00: NORMAL mode (cycle_fact:12)
set_constraint {LS}    -set {1'b0}
set_constraint {DS}    -set {1'b0}
set_constraint {SD}    -set {1'b0}
set_constraint {POFF}  -set {2'b00}
# TPR=L: TPR=H disables read/write (cycle_fact:2, cycle_fact:42)
set_constraint {TPR}   -set {1'b0}

# --- ME: inactive prelude, active operations, inactive return --------------
# ME=0 in the binary prelude: one full inactive clock cycle before the first
# operation (cycle_fact:52)
set_constraint {ME} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {ME} -cycle {BINCYCLE2} -set {1'b0}
# ME=1 in the operation cycles: read and write require ME=H (cycle_fact:6,
# cycle_fact:10)
set_constraint {ME} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {ME} -cycle {SYMCYCLE2} -set {1'b1}
# ME=0 in the flush phase: return to inactive (cycle_fact:52)
set_constraint {ME} -cycle {FLUSHCYCLE1} -set {1'b0}

# --- WE: write in SYMCYCLE1, read in SYMCYCLE2 -----------------------------
# WE=1 in SYMCYCLE1: a write requires WE=H (cycle_fact:10)
set_constraint {WE} -cycle {SYMCYCLE1} -set {1'b1}
# WE=0 in SYMCYCLE2: a read requires WE=L (cycle_fact:6)
set_constraint {WE} -cycle {SYMCYCLE2} -set {1'b0}

# HW, WEM, ADR, D are left unconstrained (esp-default): they are the pins this
# corner exists to explore, and the causal sequence does not require specific
# values for them. No constraint is emitted.
