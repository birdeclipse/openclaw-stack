# Cycle Plan — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 2 | mission-mode entry and one full inactive-clock hold before the first operation |
| SYM | 2 | write at SYMCYCLE1, read at SYMCYCLE2, covering the write→read observability with all HW/WEM variants |
| FLUSH | 1 | propagate the read at SYMCYCLE2's QP (pipeline_depth=1) to default comparison |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1-2 | mission-mode entry | establish functional ownership and hold one full inactive clock cycle | `BISTE=1'b0`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`, `ME=1'b0` | `cycle_fact:24`, `cycle_fact:12`, `cycle_fact:2`, `cycle_fact:52` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | write | launch a write: ME=H, WE=H; HW/WEM/ADR/D unconstrained to explore full/masked/half-word/no-op variants | `ME=1'b1`, `WE=1'b1` | `cycle_fact:10`, `cycle_fact:8`, `cycle_fact:9`, `cycle_fact:11`, `cycle_fact:41` |
| SYMCYCLE2 | read | launch a read: ME=H, WE=L; HW/ADR unconstrained to explore read variants | `ME=1'b1`, `WE=1'b0` | `cycle_fact:6` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | QP propagation | propagate the read at SYMCYCLE2's QP (pipeline_depth=1); return ME to inactive | `ME=1'b0` | `fact:ddf-c9f8fbf1`, `cycle_fact:52` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Full-width write (HW=11, WEM=H) | SYMCYCLE1 (j=1) | cycle 3 (QP) | Array[ADR]=D at cycle 1 (`cycle_fact:10`); the read at SYMCYCLE2 outputs the committed value on Q at cycle 2 and QP at cycle 3 | The write commits to the array at cycle 1; the read at cycle 2 reads the committed value; no operation intervenes between the write and the read, so the array value is intact when the read samples it |
| Masked write (WEM=L) | SYMCYCLE1 (j=1) | cycle 3 (QP) | No bits written (`cycle_fact:11`); the read at SYMCYCLE2 reads the unchanged array | The masked write writes nothing; the array is unchanged and the read at cycle 2 samples the prior value |
| Half-word write lower (HW=01) | SYMCYCLE1 (j=1) | cycle 3 (QP) | Array[L]=D[L] at cycle 1 (`cycle_fact:8`); the read at SYMCYCLE2 reads the committed lower half | The lower half is written at cycle 1; the read at cycle 2 samples the committed lower half before any later write |
| Half-word write upper (HW=10) | SYMCYCLE1 (j=1) | cycle 3 (QP) | Array[H]=D[H] at cycle 1 (`cycle_fact:9`); the read at SYMCYCLE2 reads the committed upper half | The upper half is written at cycle 1; the read at cycle 2 samples the committed upper half before any later write |
| HW=00 write no-op | SYMCYCLE1 (j=1) | cycle 3 (QP) | No bits written (`cycle_fact:41`); the read at SYMCYCLE2 reads the unchanged array | The no-op writes nothing; the array is unchanged and the read at cycle 2 samples the prior value |
| Full-width read (HW=11) | SYMCYCLE2 (j=2) | cycle 3 (QP) | Q=mem[ADR] at cycle 2 (`cycle_fact:6`); QP at cycle 3 | The read's Q is registered at cycle 2 (depth 0); QP at cycle 3 (depth 1); the flush phase holds ME=0 so no later operation overwrites Q/QP before comparison |

A1 check (comparison cycle >= launch cycle + pipeline_depth):
- Write at SYMCYCLE1 (j=1): effect reaches comparison via the read's QP at cycle 3. `s - j + f = 2 - 1 + 1 = 2 >= 1` (QP path, `fact:ddf-c9f8fbf1`). The Q path (depth 0) is observed at cycle 2: `2 - 1 + 1 = 2 >= 0`.
- Read at SYMCYCLE2 (j=2): Q at cycle 2 (depth 0), QP at cycle 3 (depth 1). `s - j + f = 2 - 2 + 1 = 1 >= 1` (QP path). Q path: `1 >= 0`.

The write→read observability holds for the same-address subspace of the unconstrained ADR space; ESP explores the full ADR space including the same-address case.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | all | literal 0 | BISTE=1 (BIST mode) | mission mode requires BISTE=0; the functional port owns the memory | `cycle_fact:24` |
| SE_IN | all | literal 0 | SE_IN=1 (scan mode) | mission mode requires SE_IN=0; scan ownership is excluded from this corner | `cycle_fact:24`, `cycle_fact:68` |
| LS | all | literal 0 | LS=1 (light sleep) | NORMAL mode requires LS=0 | `cycle_fact:12` |
| DS | all | literal 0 | DS=1 (deep sleep) | NORMAL mode requires DS=0 | `cycle_fact:12` |
| SD | all | literal 0 | SD=1 (shutdown) | NORMAL mode requires SD=0 | `cycle_fact:12` |
| POFF | all | literal 00 | POFF=01/11 (periphery/array off) | NORMAL mode requires POFF=00 | `cycle_fact:12` |
| TPR | all | literal 0 | TPR=1 (idle/disabled) | TPR=H disables read/write | `cycle_fact:2`, `cycle_fact:42` |
| ME | BIN, FLUSH | literal 0 | ME=1 (active) in the prelude and return | one full inactive clock cycle before/after operations | `cycle_fact:52` |
| ME | SYM | literal 1 | ME=0 (disabled) in the operation cycles | read and write operations require ME=H | `cycle_fact:6`, `cycle_fact:10` |
| WE | SYMCYCLE1 | literal 1 | WE=0 (read) in the write cycle | a write requires WE=H | `cycle_fact:10` |
| WE | SYMCYCLE2 | literal 0 | WE=1 (write) in the read cycle | a read requires WE=L | `cycle_fact:6` |

HW, WEM, ADR, D are left unconstrained (no demotion): they are the pins this corner exists to explore, and the causal sequence does not require specific values for them.

## Assumptions

- **TEST1 is left unconstrained.** No catalog row states a TEST1 value, so no constraint is emitted; leaving TEST1 unconstrained is the strongest coverage the corpus supports. The memory-function truth table (Table 2-11 in the datasheet) carries the note that its rows assume TEST1=L; that note is a source observation that was not logged as an operation row or pin value, so the plan does not bind TEST1 on its strength. The operations are therefore verified across the full TEST1 value space, including the TEST1=0 subspace the table describes.
- **ADR is unconstrained.** The write at SYMCYCLE1 and read at SYMCYCLE2 may target different addresses; the write→read observability holds in the same-address subspace, which ESP explores across the full ADR space.
- **The binary phase is the power/ownership prelude.** There is no reset pin and no `reset_latency_cycles` scalar in the corpus, so A5's `b >= reset_latency_cycles` does not bind; the binary phase instead performs the mode-entry work the design requires before mission-mode operations are legal (`cycle_fact:52`).
- **The Q path is depth 0, the QP path is depth 1.** `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) is the QP path latency; the Q path's registered output is observable in its own launch cycle.

## Limitations

- The schedule exercises a single write→read pair (write at SYMCYCLE1, read at SYMCYCLE2). A write at SYMCYCLE2 has no subsequent read, so its write→read observability is not exercised; this is acceptable because the directive's focus — a write observable to a following read — is covered by the write at SYMCYCLE1.
- TEST1 is unconstrained; if TEST1=1 disables read/write, those traces do not exercise the operations, but the TEST1=0 subspace does.
- The QP path is observed only for the read at SYMCYCLE2 (QP at FLUSHCYCLE1); the write's effect is observed via that read's Q and QP.
- BIST, scan, and power-mode operations are excluded by the mission-mode pin holds; those belong to other corners.

## Coverage

- catches: a write not committed to the array before a following read (no-bypass violation); masked-write behavior (WEM=L writes nothing, `cycle_fact:11`); half-word write behavior (HW=01/10 write only one half, `cycle_fact:8`/`cycle_fact:9`); full-width write and read (HW=11, `cycle_fact:10`/`cycle_fact:6`); HW=00 write no-op (`cycle_fact:41`); the QP pipeline (depth 1, `fact:ddf-c9f8fbf1`); and the read/write control decode (ME/WE/HW/WEM) across the unconstrained variant space.
- misses: multi-cycle write→read sequences beyond one pair; BIST/scan-mode operations and power-mode transitions (excluded by the mission-mode pin holds, and owned by other corners); a write at SYMCYCLE2 with no following read. These are acceptable because the directive's focus is the single write→read observability with masked and half-word variants, which the schedule covers.
