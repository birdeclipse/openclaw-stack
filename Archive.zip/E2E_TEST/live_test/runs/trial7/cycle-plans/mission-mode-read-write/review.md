# Review — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## correct

- **A1 arithmetic verified.** Write at SYMCYCLE1 (j=1): `s - j + f = 2 - 1 + 1 = 2 >= pipeline_depth 1` (QP path, `fact:ddf-c9f8fbf1`); Q path `2 >= 0`. Read at SYMCYCLE2 (j=2): `s - j + f = 2 - 2 + 1 = 1 >= 1` (QP path); Q path `1 >= 0`. Both hold. The plan names `j` per operation and shows the numbers.
- **Same-address subspace disclosure is honest.** ADR is left unconstrained in both SYMCYCLE1 and SYMCYCLE2, so ESP explores the full ADR pair space including the ADR1=ADR2 subspace; the write→read observability claim is explicitly scoped to that subspace (plan.md line 50, 73). This is the correct treatment — the corner's defining pins (HW/WEM/ADR/D) stay unconstrained and the observability claim is not overstated.
- **Mode-pin holds are justified per-cycle.** BISTE=0 (`cycle_fact:24`), SE_IN=0 (`cycle_fact:24`, `cycle_fact:68`), LS/DS/SD=0 and POFF=00 (NORMAL mode, `cycle_fact:12`), TPR=0 (`cycle_fact:2`, `cycle_fact:42`) are all mission-mode-defining for the whole corner, so the run-wide holds are each grounded in a cited operation row.
- **ME/WE per-cycle values justified.** ME=1 in SYM (`cycle_fact:6`, `cycle_fact:10`), ME=0 in BIN/FLUSH (`cycle_fact:52`), WE=1 in SYMCYCLE1 (`cycle_fact:10`), WE=0 in SYMCYCLE2 (`cycle_fact:6`). Each value is tied to a cited row.
- **Faithful lowering.** constraints.tcl matches plan.md: ME per-cycle (BINCYCLE1-2=0, SYMCYCLE1-2=1, FLUSHCYCLE1=0), WE per-cycle (SYM1=1, SYM2=0), mode pins held run-wide. No drift between plan and Tcl. HW/WEM/ADR/D correctly left unconstrained (no constraint emitted).
- **B4 mutation coverage.** A write that fails to commit to the array is caught in the same-address subspace: the read at SYMCYCLE2 returns stale data instead of the written value. Masked-write (`cycle_fact:11`), half-word (`cycle_fact:8`/`cycle_fact:9`), and HW=00 no-op (`cycle_fact:41`) variants are all reachable through the unconstrained HW/WEM space.

## missing

- **Minor citation defect (not plan-invalidating).** Assumptions (plan.md line 72) asserts "mission mode requires TEST1=L" as design context with no catalog ref. No constraint depends on it (the plan correctly refrains from emitting one because no catalog row states a TEST1 value), so it does not invalidate the plan, but it is an uncited design claim. If it is a real design fact it should be logged; if it is not in the corpus it is an unlogged assertion. Smallest correction: cite a catalog row for the TEST1 claim or drop the claim and state only that TEST1 is left unconstrained.

## user-review

- **ME=0 held for two BIN cycles when `cycle_fact:52` requires one full inactive clock cycle.** BINCYCLE1 establishes the mode pins and BINCYCLE2 holds ME=0 as the inactive cycle; both cycles drive ME=0. This is harmless over-provisioning (ME=0 is the idle state, no operation is excluded, no false pass), but the plan's b=2 rationale could be tightened to one mode-entry cycle plus one inactive hold.
- **The TEST1 claim is a judgment call.** Uncited but harmless because no constraint depends on it; the plan's decision to leave TEST1 unconstrained is the strongest coverage the corpus supports.

## cross-corner

- `cross-corner:` CLK/TCLK handling diverges across corners. This corner leaves CLK/TCLK unconstrained (mission mode, functional clock free); scan-shift-path holds both 0 throughout; bist-mode-operation holds CLK=0 in BIN and TCLK=0 in BIN/FLUSH with TCLK unconstrained in SYM; deep-sleep-shutdown-retention drives CLK per-cycle and TCLK=0 throughout. These are deliberate per-corner mode differences, not a defect.
- `cross-corner:` Same-address observability is handled two ways: this corner leaves ADR unconstrained and scopes the write→read claim to the same-address subspace; bist-mode-operation forces the relation with `symbolic_static` on TADR. Both are defensible; the divergence is deliberate.
- `cross-corner:` Power-mode pins (LS/DS/SD/POFF) are held quiet in this corner and in scan-shift-path, driven per-cycle in deep-sleep-shutdown-retention, and left unconstrained in bist-mode-operation — where the unconstrained power modes allow the R05-forbidden combination (TCLK rising while a power mode is active) to be reachable. See bist-mode-operation review.
- `cross-corner:` `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) is used consistently in this corner, bist-mode-operation, and deep-sleep-shutdown-retention; `scan_chain_length=1` (`fact:ddf-17baa9ce`) is used in scan-shift-path.
