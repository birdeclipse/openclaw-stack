# Cycle Plan — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | Mode-entry prelude for TRANS_IDLE_SCAN (`cycle_fact:68`): (1) establish legal IDLE with quiet conditions, (2) assert SE_IN, (3) enable the DFT clock. Three distinct sequential state changes, each its own cycle. No reset pin exists, so A5 does not bind; these are the entry cycles, not a reset hold. |
| SYM | 1 | The scan shift traversal in SYMCYCLE1: SE_IN held, DFT clock active, SI_* values symbolic (a distinct symbol per cycle), SO_* reflects the shift result. s=1 because the shift is the operation this corner exists to explore, and a SYM cycle is where an unconstrained SI_* is unambiguously symbolic (`esp-default`); s=0 would leave SI_* outside any symbolic phase. |
| FLUSH | 1 | One full chain traversal, per A3: `scan_chain_length` = 1 (`fact:ddf-17baa9ce`), so A3 requires f >= 1 with SE_IN driven in every flush cycle. FLUSHCYCLE1 holds SE_IN and the DFT clock active with SI_* still symbolic, so the shift result stays on SO_* for default comparison. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE quiet | Establish legal IDLE: both clocks low, BISTE=0, DFTCLKEN=0, DFTMASK=0, power modes quiet, SE_IN deasserted | `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:0`, `cycle_fact:12`, `cycle_fact:47`, `cycle_fact:68` |
| BINCYCLE2 | assert SE_IN | Assert the scan owner SE_IN (entry step 1 of TRANS_IDLE_SCAN); DFT clock still off | `SE_IN=1'b1`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0` | `cycle_fact:68`, `cycle_fact:47` |
| BINCYCLE3 | enable DFT clock | Enable the DFT clock (entry step 2 of TRANS_IDLE_SCAN); one clock-low phase begins | `DFTCLKEN=1'b1`, `SE_IN=1'b1`, `DFTMASK=1'b0` | `cycle_fact:68`, `cycle_fact:46` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | shift traversal | One full chain traversal: SE_IN held, DFT clock active, DFTMASK quiet, power quiet; SI_* symbolic values shift to SO_* across each chain (Q_L/Q_H/D_L/D_H/CNTR) | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `DFTMASK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0`, `TCLK=1'b0`; SI_* unconstrained (symbolic) | `cycle_fact:68`, `fact:ddf-17baa9ce`, `cycle_fact:46`, `cycle_fact:50` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | shift traversal (A3 hold) | Hold the shift through the one-cycle chain traversal: SE_IN driven in every flush cycle (A3), DFT clock active, SI_* still symbolic, SO_* observed | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `DFTMASK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0`, `TCLK=1'b0`; SI_* unconstrained (symbolic) | `cycle_fact:68`, `fact:ddf-17baa9ce`, `cycle_fact:46`, `cycle_fact:50` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| scan shift (SI_* → SO_*) | SYMCYCLE1 (j=1) | SYMCYCLE1 and FLUSHCYCLE1 | SO_* = SI_* for each chain (Q_L/Q_H/D_L/D_H/CNTR) via the one-stage pass-through | SO_* is an output reflecting SI_* whenever SE_IN=1 (SO = SE_IN ? SI : 0, `fact:ddf-17baa9ce`); the pass-through is depth 0, so SO_* reflects the symbolic SI_* in SYMCYCLE1 itself, and FLUSHCYCLE1 (the last cycle, SE_IN still held) re-presents it at default comparison with nothing later re-driving SO_* |

A1: the shift is launched in SYMCYCLE1 (j=1); `s - j + f = 1 - 1 + 1 = 1 >= 1`. The pipeline depth relevant to the scan path is the chain length = 1 (`fact:ddf-17baa9ce`). Holds.

A3: `f = 1 >= scan_chain_length = 1` (`fact:ddf-17baa9ce`). SE_IN is driven with a value in FLUSHCYCLE1 (the only flush cycle). Holds.

A5: no reset pin and no `reset_latency_cycles` scalar exist in the corpus; the BIN phase is the mode-entry prelude (b = 3, `cycle_fact:68`), not a reset hold.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| SE_IN | BIN2-3, SYM, FLUSH | literal 1 | SE_IN=0 during the shift (would disable the shift) | scan owner must be asserted for the shift; this corner's own definition requires SE_IN to be the only owner with DFTMASK quiet (function_corner fact 134) | `cycle_fact:68` |
| DFTCLKEN | BIN3, SYM, FLUSH | literal 1 | DFT clock off during the shift (would disable the shift) | DFT clock must be enabled for the shift | `cycle_fact:68` |
| DFTMASK | all | literal 0 | DFTMASK=1 (synchronous write-through, scan-output collision) | the corner's own definition (function_corner fact 134) requires DFTMASK to be quiet during the shift; R13 (`cycle_fact:46`) defines the collision behavior (scan output advances, Q=X) and R14 (`cycle_fact:47`) defines the write-through behavior — neither forbids the combination, but both confirm it is outside this corner's scope | `cycle_fact:46`, `cycle_fact:47` |
| BISTE | all | literal 0 | BISTE=1 (BIST ownership) | SE_IN must be the only owner; BISTE=1 selects the BIST port | `cycle_fact:68`, `cycle_fact:25` |
| LS, DS, SD | all | literal 0 | power modes during scan (illegal) | R24 forbids power mode during scan shift | `cycle_fact:50`, `cycle_fact:12` |
| POFF | all | literal 00 | POFF != 00 (power modes) | R24 forbids power mode during scan shift | `cycle_fact:50`, `cycle_fact:12` |
| CLK, TCLK | all | literal 0 | clock activity during the scan entry and shift | cycle_fact:68 requires both clocks low for the scan entry and the one clock-low shift phase | `cycle_fact:68` |

SI_* (SI_Q_L, SI_Q_H, SI_D_L, SI_D_H, SI_CNTR) are left unconstrained (symbolic) — they are the shift data this corner exists to explore. No row needed (default, strongest coverage).

## Assumptions

- The scan chain length is 1 (`fact:ddf-17baa9ce`), so one flush cycle covers the full traversal. If the physical chain were longer, f would need to increase.
- The shift is a one-stage pass-through (SO = SE_IN ? SI : 0), so the shift effect is observed in the same cycle SI_* is applied with SE_IN=1.
- The DFT clock is enabled via DFTCLKEN while the base clocks CLK/TCLK are held low, per cycle_fact:68 ("enable DFT clock; one clock-low phase").
- No reset pin exists; the design enters scan from the IDLE state without a reset prelude.
- The functional port (ME, WE, ADR, D, WEM) is inert during scan (cycle_fact:68 "Q not functionally updated"), so those pins are left unconstrained.

## Limitations

- The exit transition TRANS_SCAN_BIST_IDLE (`cycle_fact:70`) is not exercised; the schedule ends in the legal scan state (SE_IN=1, DFTCLKEN=1, DFTMASK=0, power quiet) with the shift effect already compared.
- Power-mode transitions and DFTMASK behavior are held quiet (not explored) — R24/R13/R14 define them as illegal or out-of-scope during scan, and this corner is about the shift path.
- The read/write data path (including the PIPEME pipeline, `fact:ddf-c9f8fbf1`) and the BIST path are not exercised.
- Multi-cycle chain traversal (chain length > 1) is not exercised; the model under test is a one-stage pass-through.

## Coverage

- catches: a defect where a scan chain does not pass SI to SO when SE_IN=1 (broken pass-through, wrong polarity, SE_IN not gating correctly); a defect where SE_IN ownership is violated (BISTE or a power mode interfering with the shift); a defect where DFTMASK corrupts the shift; a defect where the chain length is wrong (SO would not match SI in the single shift cycle).
- misses: the scan→IDLE exit transition; power-mode and DFTMASK behavior during scan (illegal or out of scope per R24/R13/R14); the functional read/write and BIST data paths; multi-cycle chain traversal. These are acceptable because the corner is scoped to the shift path and the model is a one-stage pass-through.
