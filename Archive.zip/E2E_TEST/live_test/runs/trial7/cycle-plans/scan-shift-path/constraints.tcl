# ---------------------------------------------------------------------------
# scan-shift-path corner — lowered constraints (revised per review)
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
# Corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
#
# Revision: s=0 -> s=1; the shift now occupies SYMCYCLE1 where SI_* is
# unambiguously symbolic, with FLUSHCYCLE1 holding the shift (A3).
# Values/conditions are Verilog expressions; widths exact; pins spelled
# exactly as the survey inventory lists them; targets are primary inputs
# only (SO_* are outputs, observed, never set).
# ---------------------------------------------------------------------------

# --- testbench cycle counts (b=3, s=1, f=1) ---
set_app_var testbench_binary_cycles  3
set_app_var testbench_symbolic_cycles 1
set_app_var testbench_flush_cycles   1

# --- SE_IN: scan owner. IDLE (0), then asserted for the shift. ---
#   BINCYCLE1: IDLE, SE_IN deasserted (cycle_fact:0, cycle_fact:68)
set_constraint {SE_IN} -cycle {BINCYCLE1} -set {1'b0}
#   BINCYCLE2: assert SE_IN (entry step 1 of TRANS_IDLE_SCAN, cycle_fact:68)
set_constraint {SE_IN} -cycle {BINCYCLE2} -set {1'b1}
#   BINCYCLE3: hold SE_IN (cycle_fact:68)
set_constraint {SE_IN} -cycle {BINCYCLE3} -set {1'b1}
#   SYMCYCLE1: shift traversal, SE_IN held (cycle_fact:68)
set_constraint {SE_IN} -cycle {SYMCYCLE1} -set {1'b1}
#   FLUSHCYCLE1: hold SE_IN for the shift traversal (A3; cycle_fact:68)
set_constraint {SE_IN} -cycle {FLUSHCYCLE1} -set {1'b1}

# --- DFTCLKEN: DFT clock enable. Off in IDLE, enabled for the shift. ---
#   BINCYCLE1-2: DFT clock off (cycle_fact:0 IDLE DFTCLKEN=L; cycle_fact:68
#                "assert SE_IN; then enable DFT clock")
set_constraint {DFTCLKEN} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE2} -set {1'b0}
#   BINCYCLE3: enable DFT clock (entry step 2, cycle_fact:68)
set_constraint {DFTCLKEN} -cycle {BINCYCLE3} -set {1'b1}
#   SYMCYCLE1, FLUSHCYCLE1: DFT clock active for the shift (cycle_fact:68)
set_constraint {DFTCLKEN} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {FLUSHCYCLE1} -set {1'b1}

# --- DFTMASK: must be quiet (0) in every cycle. ---
#   The corner's own definition (function_corner fact 134) requires DFTMASK to
#   be quiet during the scan shift; R13 (cycle_fact:46) and R14 (cycle_fact:47)
#   define the collision/write-through behaviors that DFTMASK=1 would invoke.
set_constraint {DFTMASK} -set {1'b0}

# --- BISTE: must be 0 — SE_IN must be the only owner. ---
#   cycle_fact:68 requires BISTE=0 for the scan entry; cycle_fact:25 shows
#   BISTE=1 selects the BIST port (would violate SE_IN-only ownership).
set_constraint {BISTE} -set {1'b0}

# --- Power modes quiet — R24 forbids power mode during scan shift. ---
#   cycle_fact:50 (R24); cycle_fact:12 NORMAL mode has LS=DS=SD=0, POFF=00.
set_constraint {LS}  -set {1'b0}
set_constraint {DS}  -set {1'b0}
set_constraint {SD}  -set {1'b0}
set_constraint {POFF} -set {2'b00}

# --- Clocks low — cycle_fact:68 requires both clocks low for the scan entry
#     and the one clock-low shift phase. ---
set_constraint {CLK}  -set {1'b0}
set_constraint {TCLK} -set {1'b0}

# --- SI_* (SI_Q_L, SI_Q_H, SI_D_L, SI_D_H, SI_CNTR) are left unconstrained
#     (symbolic) — they are the shift data this corner exists to explore.
#     SO_* (SO_Q_L, SO_Q_H, SO_D_L, SO_D_H, SO_CNTR) are outputs: observed,
#     never driven. ---
