# Review — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## correct

- **A3 arithmetic verified.** `f = 1 >= scan_chain_length = 1` (`fact:ddf-17baa9ce`). SE_IN is driven with a value in FLUSHCYCLE1, the only flush cycle, so shift-enable is held in every flush cycle. Coverage is per cycle and the single flush cycle is covered.
- **CLK/TCLK held 0 is consistent with the one-stage pass-through model.** `cycle_fact:68` requires "both clocks low" for the scan entry and "one clock-low phase" for the shift; holding CLK=0 and TCLK=0 throughout while DFTCLKEN=1 enables the DFT clock is consistent with `fact:ddf-17baa9ce` (SO = SE_IN ? SI : 0). The F2 clock constraint is evidence-backed.
- **Faithful lowering.** constraints.tcl matches plan.md: SE_IN per-cycle (BIN1=0, BIN2-3=1, FLUSH=1), DFTCLKEN per-cycle (BIN1-2=0, BIN3=1, FLUSH=1), DFTMASK/BISTE/power/clocks held run-wide. SI_* correctly left unconstrained. No drift between plan and Tcl.
- **Mode-pin holds justified.** BISTE=0 for SE_IN-only ownership (`cycle_fact:68`, `cycle_fact:25`); LS/DS/SD=0, POFF=00 for power-quiet scan (`cycle_fact:50`, `cycle_fact:12`).
- **B4 mutation coverage.** A broken pass-through (SO != SI when SE_IN=1), wrong polarity, or SE_IN not gating correctly would be caught at SO_* in the shift cycle.

## missing

- **PLAN-INVALIDATING — s=0 with the shift in FLUSH leaves SI_* not unambiguously symbolic.** The plan claims (plan.md line 13, 58) that "the SI_* values are fully symbolic in the single flush cycle." The guide's model does not support this: FLUSHCYCLE "performs concrete logical events" (guide.md line 138), and "When `s = 0` there is no symbolic launch and observability is `f` alone" (guide.md line 406). With s=0 there is no symbolic phase at all, so an unconstrained SI_* in FLUSHCYCLE1 is not established as symbolic — the corner's defining pins (SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR) are the shift data this corner exists to explore, and the plan's own s=0 contradicts the claim that they are explored. The shift is the operation being verified, not a propagation of pending state, so it belongs in a SYM cycle. Smallest correction: set s=1, place the shift in SYMCYCLE1 with SI_* unconstrained (symbolic), drive SE_IN=1 and DFTCLKEN=1 in SYMCYCLE1 (A3), and set f=0 or 1 (the pass-through is depth 0, so SO_* reflects SI_* in the launch cycle).
- **Minor — DFTMASK=0 justification misreads R13/R14 as prohibitions.** The symbolic-treatment row (plan.md line 52) claims "R13 forbids SE_IN=1 with DFTMASK=1; R14 forbids DFTMASK=1 with DFTCLKEN=0." `cycle_fact:46` (R13) defines the behavior when both are 1 ("Scan output advances; Q=X; SE_IN scan ownership wins") and `cycle_fact:47` (R14) defines behavior ("Q retains Q-1; diagnostic issued") — neither is a prohibition. The DFTMASK=0 hold is still justified, but by the corner's own definition (fact 134: "power modes/DFTMASK must be quiet"), which the plan should cite instead of misreading R13/R14. Not plan-invalidating (the constraint stands), but the stated justification is false.

## user-review

- none material.

## cross-corner

- `cross-corner:` CLK/TCLK handling diverges across corners. This corner holds both 0 throughout; mission-mode-read-write leaves both unconstrained; bist-mode-operation holds CLK=0 in BIN and TCLK=0 in BIN/FLUSH with TCLK unconstrained in SYM; deep-sleep-shutdown-retention drives CLK per-cycle and TCLK=0 throughout. Deliberate per-corner mode differences.
- `cross-corner:` Power-mode pins (LS/DS/SD/POFF) are held quiet here and in mission-mode-read-write, driven per-cycle in deep-sleep-shutdown-retention, and left unconstrained in bist-mode-operation — where the unconstrained power modes allow the R05-forbidden combination (TCLK rising while a power mode is active) to be reachable. See bist-mode-operation review.
- `cross-corner:` `scan_chain_length=1` (`fact:ddf-17baa9ce`) is used here; `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) is used in mission-mode-read-write, bist-mode-operation, and deep-sleep-shutdown-retention.
