# ---------------------------------------------------------------------------
# deep-sleep-shutdown-retention — lowered constraints (revised per review)
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
# Corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
#
# Revision: read-back moved to BINCYCLE9 and observed at Q (depth 0) BEFORE the
# SD path; WAKE guards doubled to tPGGUARD = 2 CLK cycles each; ADR/WEM widths
# fixed (ADR[13:0], WEM[31:0]).
# Values and conditions are Verilog expressions. Primary inputs only;
# outputs (Q/QP/ROP_DS/ROP_SD/SO_*) are never driven.
# ---------------------------------------------------------------------------

# Cycle counts (app vars, from plan.md Cycle counts)
set_app_var testbench_binary_cycles 9
set_app_var testbench_symbolic_cycles 7
set_app_var testbench_flush_cycles  1

# ---------------------------------------------------------------------------
# BIN phase
# ---------------------------------------------------------------------------

# BINCYCLE1: functional full-word write in ACTIVE (cycle_fact:10, 12, 24, 26)
set_constraint {ME}    -cycle {BINCYCLE1} -set {1'b1}
set_constraint {WE}    -cycle {BINCYCLE1} -set {1'b1}
set_constraint {WEM}   -cycle {BINCYCLE1} -set {32'hFFFFFFFF}
set_constraint {HW}    -cycle {BINCYCLE1} -set {2'b11}
set_constraint {D}     -cycle {BINCYCLE1} -set {32'hA5A5A5A5}
set_constraint {ADR}   -cycle {BINCYCLE1} -set {14'h0000}
set_constraint {LS}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}  -cycle {BINCYCLE1} -set {2'b00}
set_constraint {BC0}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BC1}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BC2}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BISTE} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TME}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {CLK}   -cycle {BINCYCLE1} -set {1'b1}
set_constraint {TCLK}  -cycle {BINCYCLE1} -set {1'b0}

# BINCYCLE2: ACTIVE->IDLE, deassert ME, one inactive clock cycle (cycle_fact:52)
set_constraint {ME}   -cycle {BINCYCLE2} -set {1'b0}
set_constraint {TME}  -cycle {BINCYCLE2} -set {1'b0}
set_constraint {CLK}  -cycle {BINCYCLE2} -set {1'b1}

# BINCYCLE3: IDLE->DS entry, clocks low, LS=SD=0, assert DS (cycle_fact:56, 40, 39)
set_constraint {CLK}  -cycle {BINCYCLE3} -set {1'b0}
set_constraint {TCLK} -cycle {BINCYCLE3} -set {1'b0}
set_constraint {ME}   -cycle {BINCYCLE3} -set {1'b0}
set_constraint {TME}  -cycle {BINCYCLE3} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE3} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE3} -set {1'b0}
set_constraint {DS}   -cycle {BINCYCLE3} -set {1'b1}
set_constraint {POFF} -cycle {BINCYCLE3} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE3} -set {1'b0}

# BINCYCLE4: DS dwell, hold DS, outputs forced 0, ROP_DS=1 (cycle_fact:14, 40, 39)
set_constraint {DS}   -cycle {BINCYCLE4} -set {1'b1}
set_constraint {CLK}  -cycle {BINCYCLE4} -set {1'b0}
set_constraint {TCLK} -cycle {BINCYCLE4} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE4} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE4} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE4} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE4} -set {1'b0}

# BINCYCLE5: DS->WAKE_DS, deassert DS, clocks low (cycle_fact:15, 57, 40, 39)
set_constraint {DS}   -cycle {BINCYCLE5} -set {1'b0}
set_constraint {CLK}  -cycle {BINCYCLE5} -set {1'b0}
set_constraint {TCLK} -cycle {BINCYCLE5} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE5} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE5} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE5} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE5} -set {1'b0}

# BINCYCLE6-7: WAKE_DS->IDLE guard, ROP_DS=0 then tPGGUARD=2 CLK cycles (cycle_fact:58, 15)
set_constraint {DS}   -cycle {BINCYCLE6 BINCYCLE7} -set {1'b0}
set_constraint {CLK}  -cycle {BINCYCLE6 BINCYCLE7} -set {1'b1}
set_constraint {TCLK} -cycle {BINCYCLE6 BINCYCLE7} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE6 BINCYCLE7} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE6 BINCYCLE7} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE6 BINCYCLE7} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE6 BINCYCLE7} -set {1'b0}

# BINCYCLE8: IDLE->ACTIVE re-entry (cycle_fact:51, 12)
set_constraint {ME}   -cycle {BINCYCLE8} -set {1'b1}
set_constraint {TME}  -cycle {BINCYCLE8} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE8} -set {1'b0}
set_constraint {DS}   -cycle {BINCYCLE8} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE8} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE8} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE8} -set {1'b0}
set_constraint {CLK}  -cycle {BINCYCLE8} -set {1'b1}

# BINCYCLE9: retention read-back in ACTIVE; Q observed here (depth 0), before SD (cycle_fact:6, 12)
set_constraint {ME}   -cycle {BINCYCLE9} -set {1'b1}
set_constraint {WE}   -cycle {BINCYCLE9} -set {1'b0}
set_constraint {HW}   -cycle {BINCYCLE9} -set {2'b11}
set_constraint {ADR}  -cycle {BINCYCLE9} -set {14'h0000}
set_constraint {LS}   -cycle {BINCYCLE9} -set {1'b0}
set_constraint {DS}   -cycle {BINCYCLE9} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE9} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE9} -set {2'b00}
set_constraint {BC0}  -cycle {BINCYCLE9} -set {1'b0}
set_constraint {CLK}  -cycle {BINCYCLE9} -set {1'b1}

# ---------------------------------------------------------------------------
# SYM phase
# ---------------------------------------------------------------------------

# SYMCYCLE1: ACTIVE->IDLE, deassert ME (cycle_fact:52)
set_constraint {ME}   -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {CLK}  -cycle {SYMCYCLE1} -set {1'b1}

# SYMCYCLE2: IDLE->SD entry, clocks low, LS=DS=0, assert SD (cycle_fact:60, 40, 38, 39)
set_constraint {CLK}  -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {ME}   -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {SD}   -cycle {SYMCYCLE2} -set {1'b1}
set_constraint {POFF} -cycle {SYMCYCLE2} -set {2'b00}

# SYMCYCLE3: SD dwell, hold SD, outputs forced 0, ROP_SD=1 (cycle_fact:18, 40, 38, 39)
set_constraint {SD}   -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {CLK}  -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE3} -set {2'b00}

# SYMCYCLE4: SD->WAKE_SD, deassert SD, keep enables low (cycle_fact:19, 61, 40, 38, 39)
set_constraint {SD}   -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {CLK}  -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {ME}   -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE4} -set {2'b00}

# SYMCYCLE5-6: WAKE_SD->IDLE guard, ROP_SD=0 then tPGGUARD=2 CLK cycles (cycle_fact:62, 19)
set_constraint {SD}   -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {CLK}  -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b1}
set_constraint {TCLK} -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {ME}   -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE5 SYMCYCLE6} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE5 SYMCYCLE6} -set {2'b00}

# SYMCYCLE7: IDLE dwell (cycle_fact:0, 12)
set_constraint {ME}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {SD}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE7} -set {2'b00}
set_constraint {CLK}  -cycle {SYMCYCLE7} -set {1'b1}

# ---------------------------------------------------------------------------
# FLUSH phase
# ---------------------------------------------------------------------------

# FLUSHCYCLE1: propagate SD wake guard to comparison (cycle_fact:0, 12)
set_constraint {ME}   -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {TME}  -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}   -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}   -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}   -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF} -cycle {FLUSHCYCLE1} -set {2'b00}
set_constraint {CLK}  -cycle {FLUSHCYCLE1} -set {1'b1}
