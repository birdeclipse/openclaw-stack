# Cycle Plan — deep-sleep-shutdown-retention

- corner: deep-sleep-shutdown-retention
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 9 | Concrete power-mode-entry sequencing plus the seed write and the retention read-back. BIN=9 because the DS retention round-trip needs: (1) a functional full-word write in ACTIVE (`cycle_fact:10`), (2) ACTIVE→IDLE (`cycle_fact:52`), (3) IDLE→DS entry with clocks low and enables deasserted (`cycle_fact:56`), (4) a DS dwell holding DS asserted (`cycle_fact:14`), (5) DS→WAKE_DS deassertion (`cycle_fact:15`), (6)-(7) two WAKE_DS→IDLE guard cycles — `tPGGUARD = 2 CLK cycles` (`cycle_fact:58`), (8) IDLE→ACTIVE re-entry (`cycle_fact:51`), and (9) the retention read-back in ACTIVE (`cycle_fact:6`), whose Q is observed in the launch cycle (depth 0) before the SD path. BIN=8 would drop one guard cycle; BIN=9 is the first count that completes the DS round-trip with the full 2-cycle guard. |
| SYM | 7 | The shutdown path and its wake. SYM=7 because the sequence needs: (1) ACTIVE→IDLE (`cycle_fact:52`), (2) IDLE→SD entry with clocks low and enables deasserted (`cycle_fact:60`), (3) an SD dwell holding SD asserted with outputs forced 0 and ROP_SD=1 (`cycle_fact:18`), (4) SD→WAKE_SD deassertion keeping enables low (`cycle_fact:61`), (5)-(6) two WAKE_SD→IDLE guard cycles — `tPGGUARD = 2 CLK cycles` (`cycle_fact:62`), and (7) an IDLE dwell so the SD-path effect reaches comparison. SYM=6 would drop one guard cycle; SYM=7 is the first count with both guards. |
| FLUSH | 1 | One concrete IDLE cycle carrying the SD wake guard completion to ESP's default comparison. The deepest in-flight effect is the WAKE_SD→IDLE guard completed in SYMCYCLE6, propagated here. No scan chain is shifted, so A3 does not apply. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | seed write | Write the retained word: full-word write at a fixed address in ACTIVE mode. | `ME=1'b1`, `WE=1'b1`, `WEM=32'hFFFFFFFF`, `HW=2'b11`, `D=32'hA5A5A5A5`, `ADR=14'h0000`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0`, `BISTE=1'b0`, `TME=1'b0`, `CLK=1'b1`, `TCLK=1'b0` | `cycle_fact:10`, `cycle_fact:12`, `cycle_fact:24`, `cycle_fact:26` |
| BINCYCLE2 | ACTIVE→IDLE | Deassert the memory enable and hold one full inactive clock cycle before any power change. | `ME=1'b0`, `TME=1'b0`, `CLK=1'b1` | `cycle_fact:52` |
| BINCYCLE3 | IDLE→DS entry | Assert DS with clocks low and all other power/enable pins quiet. | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `SD=1'b0`, `DS=1'b1`, `POFF=2'b00`, `BC0=1'b0` | `cycle_fact:56`, `cycle_fact:40`, `cycle_fact:39` |
| BINCYCLE4 | DS dwell | Hold DS asserted; outputs forced 0, ROP_DS=1, array retained. | `DS=1'b1`, `CLK=1'b0`, `TCLK=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0` | `cycle_fact:14`, `cycle_fact:40`, `cycle_fact:39` |
| BINCYCLE5 | DS→WAKE_DS | Deassert DS while clocks remain low and LS=SD=0. | `DS=1'b0`, `CLK=1'b0`, `TCLK=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0` | `cycle_fact:15`, `cycle_fact:57`, `cycle_fact:40`, `cycle_fact:39` |
| BINCYCLE6-7 | WAKE_DS→IDLE guard | Wait until ROP_DS=0, then the `tPGGUARD = 2 CLK cycles` guard. | `DS=1'b0`, `CLK=1'b1`, `TCLK=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0` | `cycle_fact:58`, `cycle_fact:15` |
| BINCYCLE8 | IDLE→ACTIVE | Re-enter ACTIVE with the selected enable asserted and setup met. | `ME=1'b1`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0`, `CLK=1'b1` | `cycle_fact:51`, `cycle_fact:12` |
| BINCYCLE9 | retention read-back | Read the written word back in ACTIVE; Q is observed in this launch cycle (depth 0), before the SD path begins. | `ME=1'b1`, `WE=1'b0`, `HW=2'b11`, `ADR=14'h0000`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0`, `CLK=1'b1` | `cycle_fact:6`, `cycle_fact:12` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | ACTIVE→IDLE | Deassert the memory enable and hold one full inactive clock cycle before the SD entry. | `ME=1'b0`, `TME=1'b0`, `CLK=1'b1` | `cycle_fact:52` |
| SYMCYCLE2 | IDLE→SD entry | Assert SD with clocks low and all other power/enable pins quiet. | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b1`, `POFF=2'b00` | `cycle_fact:60`, `cycle_fact:40`, `cycle_fact:38`, `cycle_fact:39` |
| SYMCYCLE3 | SD dwell | Hold SD asserted; outputs forced 0, ROP_SD=1, array destroyed/unknown. | `SD=1'b1`, `CLK=1'b0`, `TCLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:18`, `cycle_fact:40`, `cycle_fact:38`, `cycle_fact:39` |
| SYMCYCLE4 | SD→WAKE_SD | Deassert SD while keeping all enables low. | `SD=1'b0`, `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:19`, `cycle_fact:61`, `cycle_fact:40`, `cycle_fact:38`, `cycle_fact:39` |
| SYMCYCLE5-6 | WAKE_SD→IDLE guard | Wait until ROP_SD=0, then the `tPGGUARD = 2 CLK cycles` guard; outputs valid electrically, data unknown until written. | `SD=1'b0`, `CLK=1'b1`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:62`, `cycle_fact:19` |
| SYMCYCLE7 | IDLE dwell | Hold IDLE so the SD wake guard effect reaches comparison. | `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b1` | `cycle_fact:0`, `cycle_fact:12` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | propagate to comparison | One concrete IDLE cycle carrying the SD wake guard completion to ESP's default comparison. | `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b1` | `cycle_fact:0`, `cycle_fact:12` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Functional write (seed) | BINCYCLE1 | BINCYCLE9 | Array[ADR]=D at the addressed location (`cycle_fact:10`). | The write is the only write in the schedule; no later cycle re-drives D or WE. The array is retained through DS (`cycle_fact:14`, `cycle_fact:56`) and re-read in BINCYCLE9. |
| DS retention read-back | BINCYCLE9 | BINCYCLE9 | Q = full word read from the addressed location (`cycle_fact:6`), proving the array survived DS. | The read-back's Q path is depth 0 (`fact:ddf-c9f8fbf1` describes the QP path latency; the Q path's registered output is observable in its launch cycle), so Q is observed and compared at BINCYCLE9 itself, per-cycle reference-vs-implementation, BEFORE the SD path begins in SYMCYCLE2. The SD dwell (SYMCYCLE3) forces Q=0 (`cycle_fact:18`), but that is after the read-back's comparison cycle. A1: cycles available from the launch to comparison = (run length − BINCYCLE9 + 1) = (17 − 9 + 1) = 9 >= pipeline_depth 1. |
| IDLE→DS entry | BINCYCLE3 | BINCYCLE4 | DS asserted with clocks low; outputs forced 0, ROP_DS=1 (`cycle_fact:14`, `cycle_fact:56`). | DS is held through BINCYCLE4; ROP_DS=1 is intact because DS remains asserted and no clock rises while DS is active (`cycle_fact:40`). |
| DS→WAKE_DS | BINCYCLE5 | BINCYCLE6 | DS deasserted; ROP_DS=0 (`cycle_fact:15`). | ROP_DS=0 is held through the two guard cycles BINCYCLE6-7 (`cycle_fact:58`); no later cycle re-asserts DS before comparison. |
| IDLE→SD entry | SYMCYCLE2 | SYMCYCLE3 | SD asserted with clocks low; outputs forced 0, ROP_SD=1 (`cycle_fact:18`, `cycle_fact:60`). | SD is held through SYMCYCLE3; ROP_SD=1 is intact because SD remains asserted and no clock rises while SD is active (`cycle_fact:40`). |
| SD→WAKE_SD | SYMCYCLE4 | FLUSHCYCLE1 | SD deasserted; ROP_SD=0, outputs valid electrically, data unknown until written (`cycle_fact:19`, `cycle_fact:61`, `cycle_fact:62`). | The two guard cycles complete in SYMCYCLE6 and the effect propagates through SYMCYCLE7 into FLUSHCYCLE1. The SD path is destructive (`cycle_fact:18`, `cycle_fact:60`), so the observable is ROP_SD deassertion plus the guard, not data — data is unknown until written (`cycle_fact:61`, `cycle_fact:62`). A1: launch j=SYMCYCLE4, cycles to comparison = (7−4)+1 = 4 >= pipeline_depth 1. |

A1 arithmetic:
- Retention read-back at BINCYCLE9: Q path depth 0, observed and compared in the launch cycle (before the SD path forces Q=0 in SYMCYCLE3). The QP path would carry it one cycle later (depth 1, `fact:ddf-c9f8fbf1`), but the read-back's Q comparison does not depend on QP.
- SD wake at SYMCYCLE4 (j=4): `s - j + f = 7 - 4 + 1 = 4 >= 1` (pipeline_depth, `fact:ddf-c9f8fbf1`). Holds.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| CLK | BIN, SYM | literal (per-cycle) | No clock toggling during powered-down states. | R05 forbids any rising CLK while DS/SD/POFF is active (`cycle_fact:40`); the DS/SD entry transitions require clocks low (`cycle_fact:56`, `cycle_fact:60`). CLK is driven high only in ACTIVE/IDLE cycles where a clock edge is legal. | `cycle_fact:40`, `cycle_fact:56`, `cycle_fact:60` |
| TCLK | BIN, SYM | literal (per-cycle) | No TCLK toggling during powered-down states. | R05 forbids any rising TCLK while DS/SD/POFF is active (`cycle_fact:40`); TCLK is held low throughout because BISTE=0 and the functional port owns the memory (`cycle_fact:24`). | `cycle_fact:40`, `cycle_fact:24` |
| DS | BIN | literal (per-cycle) | No DS transition space within the DS dwell. | The DS entry/exit is the corner's core sequence: assert DS (`cycle_fact:56`), hold it (`cycle_fact:14`), deassert it (`cycle_fact:15`). Each cycle's DS value is the one the transition requires. | `cycle_fact:56`, `cycle_fact:14`, `cycle_fact:15` |
| SD | SYM | literal (per-cycle) | No SD transition space within the SD dwell. | The SD entry/exit is the corner's core sequence: assert SD (`cycle_fact:60`), hold it (`cycle_fact:18`), deassert it (`cycle_fact:19`, `cycle_fact:61`). Each cycle's SD value is the one the transition requires. | `cycle_fact:60`, `cycle_fact:18`, `cycle_fact:19`, `cycle_fact:61` |
| LS | BIN, SYM | literal (per-cycle) | No LS overlap with DS/SD. | R02 forbids LS=1 with DS=1 or SD=1 (`cycle_fact:39`); LS is held 0 throughout the powered-down states and their entries. | `cycle_fact:39` |
| POFF | BIN, SYM | literal (per-cycle) | No POFF power-down during the DS/SD sequence. | POFF=00 is the normal/periphery-on state required for DS and SD entry (`cycle_fact:12`, `cycle_fact:14`, `cycle_fact:18`); POFF is not part of this corner's sequence. | `cycle_fact:12`, `cycle_fact:14`, `cycle_fact:18` |
| BC0 | BIN | literal (per-cycle) | No BC0=1 (no-bias) DS option explored. | DS retention requires array bias: BC0=0 with BC1/BC2 selecting the bias path (`cycle_fact:33`, `cycle_fact:34`, `cycle_fact:35`); BC0=1 bypasses bias (`cycle_fact:36`) and would not exercise the retained-array path this corner verifies. | `cycle_fact:33`, `cycle_fact:34`, `cycle_fact:35`, `cycle_fact:36` |
| BC1, BC2 | BIN | unconstrained in the DS dwell | none in the DS dwell — the bias-encoding options remain explorable. | BC1/BC2 are the corner's exploration pins for DS bias encoding (`cycle_fact:33`, `cycle_fact:34`, `cycle_fact:35`); they are left unconstrained in the DS dwell cycles so ESP explores all bias options. In BINCYCLE1 they are driven 0 to establish a clean ACTIVE bias baseline (`cycle_fact:26`). | `cycle_fact:33`, `cycle_fact:34`, `cycle_fact:35`, `cycle_fact:26` |
| ME | BIN, SYM | literal (per-cycle) | No ME transition space during powered-down states. | ME must be 0 during DS/SD entry (`cycle_fact:56`, `cycle_fact:60`) and during IDLE (`cycle_fact:52`); ME=1 is required for the write and read-back (`cycle_fact:10`, `cycle_fact:6`). Each cycle's ME value is the one the transition requires. | `cycle_fact:56`, `cycle_fact:60`, `cycle_fact:52`, `cycle_fact:10`, `cycle_fact:6` |
| TME | BIN, SYM | literal (per-cycle) | No BIST-mode ownership during the sequence. | TME=0 throughout because BISTE=0 and the functional port owns the memory (`cycle_fact:24`); TME must be 0 during DS/SD entry (`cycle_fact:56`, `cycle_fact:60`). | `cycle_fact:24`, `cycle_fact:56`, `cycle_fact:60` |
| BISTE | BIN | literal (per-cycle) | No BIST-mode ownership during the sequence. | BISTE=0 throughout because the functional port owns the memory (`cycle_fact:24`); BISTE=1 would hand ownership to the BIST port (`cycle_fact:25`), which this corner does not exercise. | `cycle_fact:24`, `cycle_fact:25` |
| WE | BIN | literal (per-cycle) | No WE transition space outside the write. | WE=1 only in the seed write (`cycle_fact:10`); WE=0 in the read-back (`cycle_fact:6`) and in IDLE (`cycle_fact:0`). | `cycle_fact:10`, `cycle_fact:6`, `cycle_fact:0` |
| WEM | BIN | literal (per-cycle) | No WEM transition space outside the write. | WEM=all-ones in the seed write (`cycle_fact:10`); WEM is a don't-care in the read-back (`cycle_fact:6`). | `cycle_fact:10`, `cycle_fact:6` |
| HW | BIN | literal (per-cycle) | No half-word read/write options explored. | HW=11 selects the full-word write (`cycle_fact:10`) and full-word read (`cycle_fact:6`); the corner verifies full-word retention. | `cycle_fact:10`, `cycle_fact:6` |
| ADR | BIN | literal (per-cycle) | No address-space exploration. | ADR is driven to a single chosen address (14 bits, ADR[13:0], per the RTL wrapper port list) so the write and read-back target the same location; the corner verifies retention at that address, not address decode. | `cycle_fact:10`, `cycle_fact:6` |
| D | BIN | literal (per-cycle) | No data-space exploration. | D is driven to a fixed 32-bit pattern in the seed write (`cycle_fact:10`); D is a don't-care in the read-back (`cycle_fact:6`). | `cycle_fact:10`, `cycle_fact:6` |

## Assumptions

- The chosen address for the seed write and the retention read-back is a single fixed value (ADR driven to a constant, ADR[13:0] per the RTL wrapper port list at E2E_TEST/live_test/design/rtl/sram_1p2m_n3a_wrapper.sv:41). D is 32 bits (D[31:0], wrapper line 42), WEM 32 bits (wrapper line 43), HW 2 bits (wrapper line 44). These widths are design context from the RTL, not stated in the survey catalog; the constraints use them.
- BC1/BC2 are left unconstrained in the DS dwell so ESP explores all DS bias-encoding options (`cycle_fact:33`, `cycle_fact:34`, `cycle_fact:35`), including the non-retentive BC1=BC2=0 debug encoding. Reference and implementation receive the same bias straps, so the per-cycle comparison holds in every subspace; the retention read-back verifies the retained path in the retentive-bias subspaces.
- The DS and SD dwells are one cycle each. The evidence states minimum dwells (tDSENT, tSDENT) as timing parameters, not cycle counts; one logical cycle per dwell is the minimum the transition system requires to observe the forced-output and ROP effects.
- The WAKE_DS→IDLE and WAKE_SD→IDLE guards are two cycles each, matching `tPGGUARD = 2 CLK cycles` (`cycle_fact:58`, `cycle_fact:62`).
- CLK is driven high in ACTIVE/IDLE cycles and low in powered-down cycles. This is a per-cycle decision required by R05 (`cycle_fact:40`) and the DS/SD entry transitions (`cycle_fact:56`, `cycle_fact:60`); it is not a phase-wide hold, so `set_constraint` per-cycle scoping suffices and no declaration file is needed.
- The read-back is compared per-cycle at BINCYCLE9 (Q path depth 0) before the SD path begins; the default reference-vs-implementation comparison applies at each cycle.

## Limitations

- The SD path is destructive: data is unknown until written after wake (`cycle_fact:61`, `cycle_fact:62`). This corner observes the SD path via ROP_SD deassertion plus the guard, not via data read-back; data integrity through SD is not verifiable by this schedule.
- The corner does not exercise POFF power-down (`cycle_fact:22`, `cycle_fact:23`, `cycle_fact:63`, `cycle_fact:64`, `cycle_fact:65`); POFF is held at 00 throughout. POFF retention is a separate sequence.
- The corner does not exercise LS (`cycle_fact:13`, `cycle_fact:53`, `cycle_fact:54`); LS is held 0 throughout to satisfy R02 (`cycle_fact:39`).
- The corner does not exercise the DS→SD direct transition (`cycle_fact:59`); it exercises IDLE→SD (`cycle_fact:60`) as the destructive path. The DS→SD path is noted in the roster fact but is not separately scheduled.
- The corner does not exercise BIST-mode ownership (`cycle_fact:25`); BISTE is held 0 throughout.
- The corner does not exercise scan (`cycle_fact:68`); SE_IN is left unconstrained and no scan chain is shifted, so A3 does not apply.
- ADR and D are fixed; address-decode and data-space faults are not explored by this corner.

## Coverage

- catches: a defect that drops the retained array during DS (the read-back at BINCYCLE9 would not match the written word); a defect that fails to force Q/QP/SO to 0 or ROP_DS to 1 during DS (`cycle_fact:14`); a defect that fails to deassert ROP_DS on DS exit (`cycle_fact:15`); a defect that fails to force Q/QP/SO to 0 or ROP_SD to 1 during SD (`cycle_fact:18`); a defect that fails to deassert ROP_SD on SD exit (`cycle_fact:19`); a defect that allows a clock to rise while DS/SD is active (R05, `cycle_fact:40`); a defect that allows LS to overlap DS/SD (R02, `cycle_fact:39`) or SD to overlap DS (R01, `cycle_fact:38`).
- misses: data integrity through the destructive SD path (data is unknown until written, `cycle_fact:61`, `cycle_fact:62`); POFF power-down retention (`cycle_fact:63`, `cycle_fact:64`, `cycle_fact:65`); LS retention (`cycle_fact:53`); the DS→SD direct transition (`cycle_fact:59`); address-decode and data-space coverage (ADR and D are fixed); BIST-mode and scan ownership. These are outside this corner's scope and are covered by other roster corners or are not verifiable by a retention schedule.
