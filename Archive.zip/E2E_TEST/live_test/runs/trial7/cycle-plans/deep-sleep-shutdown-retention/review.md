# Review — deep-sleep-shutdown-retention

- corner: deep-sleep-shutdown-retention
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial7
- corpus digest: bad82d5d404109e43e1c2cecfa60e5f6dbdbfd3d1877e1ca845f796ba260a9b9
- outcome: plan

## correct

- **SD-path observability is correctly scoped to ROP_SD deassertion + guard, not data.** The plan (plan.md line 55, 88) observes the SD path via ROP_SD deassertion plus the guard, not via data read-back, because SD is destructive and data is unknown until written (`cycle_fact:61`, `cycle_fact:62`). This is the correct scoping.
- **R05 is respected.** CLK is driven low in every powered-down cycle and high only in ACTIVE/IDLE cycles where a clock edge is legal (`cycle_fact:40`); TCLK is held low throughout. The per-cycle clock treatment is evidence-backed.
- **Faithful lowering.** constraints.tcl matches plan.md cycle by cycle across BIN (8), SYM (6), and FLUSH (1): ME/WE/WEM/HW/D/ADR/BC0/BC1/BC2/BISTE/TME/CLK/TCLK per-cycle values all match the plan's segment tables. No drift between plan and Tcl.
- **ADR/D concretization is disclosed with justification.** ADR is driven to one address and D to a fixed pattern so the write and read-back target the same location; the plan states this is a retention corner, not an address/data-decode corner (plan.md line 75-76, 80). The lost address/data space is named.
- **ROP_DS/ROP_SD observability is intact.** IDLE→DS entry (ROP_DS=1 at BINCYCLE4), DS→WAKE_DS (ROP_DS=0 at BINCYCLE6), IDLE→SD entry (ROP_SD=1 at SYMCYCLE3), SD→WAKE_SD (ROP_SD=0 at FLUSHCYCLE1) are all observed at cycles where nothing re-drives the ROP outputs before comparison.

## missing

- **PLAN-INVALIDATING — the DS retention read-back is overwritten by the SD path before comparison.** The read-back at BINCYCLE8 produces Q = mem[ADR]. Execution order is BIN → SYM → FLUSH, and the SD dwell (SYMCYCLE2-3) forces Q=0 and QP=0 (`cycle_fact:18`), so by FLUSHCYCLE1 — where the plan claims the read-back is compared (plan.md line 51) — Q and QP are 0, not the read-back value. The plan's claim that "the read-back is compared before the SD path begins in SYMCYCLE2" is false: FLUSHCYCLE1 is after the SD path. The DS retention observability (the corner's core: data survives DS) does not reach comparison intact. Smallest correction: observe the read-back at BINCYCLE8 (Q, depth 0) so it is compared before the SD path, or reorder the schedule so the read-back is the last operation before comparison (e.g., run the SD path first, then the DS retention round-trip with the read-back last).
- **A4 — WAKE guards are under-counted.** The plan models the WAKE_DS→IDLE guard as one cycle (BINCYCLE6) and the WAKE_SD→IDLE guard as one cycle (SYMCYCLE5), but `cycle_fact:58` and `cycle_fact:62` state `tPGGUARD = 2 CLK cycles`. The plan's justification (plan.md line 83: "one logical cycle ... is the minimum the transition system requires") contradicts the evidence, which quantifies the guard as 2 CLK cycles. This is an A4 under-count: the wake transition may not complete before the next operation. Smallest correction: provide two guard cycles each (or cite evidence that one logical cycle suffices despite the stated tPGGUARD).
- **Minor — ADR/D widths are assumed without corpus evidence.** The plan drives ADR=8'h00 and D=32'hA5A5A5A5 (constraints.tcl lines 25, 24), but the survey pin inventory does not state ADR or D widths. If the actual widths differ, the constraints are wrong. Smallest correction: log the ADR and D widths, or leave the widths to the testbench and state the assumption.

## user-review

- **ADR/D concretization is a coverage tradeoff.** Driving ADR and D to fixed values means address-decode and data-space faults are not explored by this corner. This is justified for a retention corner (the focus is whether the array survives DS, not decode), and the plan discloses it, but it is a deliberate narrowing the engineer should be aware of.

## cross-corner

- `cross-corner:` CLK/TCLK handling diverges across corners. This corner drives CLK per-cycle and TCLK=0 throughout; scan-shift-path holds both 0 throughout; mission-mode-read-write leaves both unconstrained; bist-mode-operation holds CLK=0 in BIN and TCLK=0 in BIN/FLUSH with TCLK unconstrained in SYM. Deliberate per-corner mode differences.
- `cross-corner:` Power-mode pins (LS/DS/SD/POFF) are driven per-cycle here; mission-mode-read-write and scan-shift-path hold them quiet; bist-mode-operation leaves them unconstrained — where the unconstrained power modes allow the R05-forbidden combination (TCLK rising while a power mode is active) to be reachable. See bist-mode-operation review.
- `cross-corner:` `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) is used consistently in this corner, mission-mode-read-write, and bist-mode-operation; `scan_chain_length=1` (`fact:ddf-17baa9ce`) is used in scan-shift-path.
