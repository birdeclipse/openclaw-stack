# Cycle Plan — redundancy

- corner: redundancy
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: unresolved

## Missing facts

| required fact | what it blocks | why | evidence examined |
|---|---|---|---|
| A functional repair model whose redirect is observable — the repair pins (CRE1, CRE2, FCA1, FCA2, RRE, FRA) actually redirect the addressed access to a spare element, with that redirect visible on Q/QP/SO | Any redundancy witness. The corner exists to verify that repair redirects the access to the spare element; without an observable redirect, no schedule can distinguish a repaired access from an unrepaired one, so no sound witness exists | The wrapper models the repair pins as observed-but-unused: they feed a `_unused` bitwise-and and have no functional effect on Q/QP/SO. The repair function tables describe the intended redirect (column repair CRE1/CRE2/FCA1/FCA2, row repair RRE/FRA) but the catalog carries no evidence the wrapper implements it. A plan that held repair pins stable would only verify that repair pins do not disturb a mission access (trivially true, not redundancy); a plan that left them symbolic would explore illegal repair combinations with no observable effect (vacuous). Neither is a redundancy witness | Driver's design context: wrapper repair pins feed a `_unused` bitwise-and (RTL lines 182-185), so repair has no functional effect on Q/QP/SO. Repair function tables `cycle_fact:26`-`cycle_fact:31` (column repair Normal/Left/Right/Both; row repair Normal/Repair) describe the intended redirect. No catalog row evidences the wrapper implementing it |
| The R20 static-repair-control rule — repair controls must not change while ME=1 or within the repair setup/hold aperture | Constraining repair pins to legal values during the access, and knowing which repair-control transitions are legal to explore in a redundancy witness | The catalog lacks an R20 row. Without it, the legality of changing a repair control during an access is unknown, so a plan cannot separate legal from illegal repair stimulus. This is a gap to note, not a value to guess | Evidence catalog rows R01-R24 (`cycle_fact:44`-`cycle_fact:56`, `cycle_fact:72`-`cycle_fact:74`); no R20 row is present among them |

## Assumptions

- The driver's design context is authoritative for the wrapper's repair modelling: the repair pins are observed but not modelled, feeding a `_unused` bitwise-and with no functional effect on Q/QP/SO. This is the basis for the primary missing fact.
- The instance is two-col-repair (CRE1/CRE2/FCA1/FCA2, 6-bit faulty column addresses) plus a single row-repair element (RRE/FRA, 8-bit faulty row address), so RRE is a single bit and the R19 "RRE1=RRE2=1 with equal addresses" illegality does not arise on this instance (`cycle_fact:30`-`cycle_fact:31` describe a single row-repair element).
- No reset pin exists on this design, so the A5 reset-prelude arithmetic does not bind here; no `reset_latency_cycles` scalar is logged.
- `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) and `scan_chain_length=1` (`fact:ddf-43efd23b`) are logged, but neither is exercised by this corner because no witness is planned.

## Limitations

- No cycle schedule is produced. The corner's core behaviour — repair redirecting the access to a spare element — is unobservable against the wrapper model, so any schedule would be either vacuous (repair pins symbolic, no observable effect) or a mission read/write witness mislabelled as redundancy (repair pins held stable, trivially undisturbed). Neither is a sound redundancy witness, so none is lowered.
- The repair function tables (`cycle_fact:26`-`cycle_fact:31`) describe the intended redirect behaviour of the physical design, but that behaviour is not implemented in the wrapper under test. A plan citing those tables as the witness's expected effect would be asserting behaviour the model cannot produce.
- The R20 static-repair-control rule is absent from the catalog; its absence is noted as a gap, not filled with a guessed value.
- This corner is certified on the pin-name rule alone (roster row: "pin-name rule matched CRE1, CRE2, FCA1, FCA2, FRA, RRE"); no user directive names it. That is a reason to plan conservatively and disclose scope, which this unresolved outcome does.

## Coverage

- catches: none can be argued. A redundancy witness would expose mutations in the repair redirect path (a spare element not selected, a faulty column/row not redirected, a wrong spare address), but the wrapper does not implement that path, so no schedule against this model can expose such a defect.
- misses: the entire repair redirect behaviour — column repair selection (CRE1/CRE2/FCA1/FCA2) and row repair selection (RRE/FRA) — is unobservable against the wrapper. This is not acceptable for the corner's purpose; it is the reason the outcome is `unresolved` rather than `plan`. The missing fact (a functional repair model whose redirect is observable) must be supplied before a redundancy witness can be planned.
