# Cycle Plan — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish mission mode before any symbolic operation. The design has no reset pin and no `reset_latency_cycles` scalar, so A5 does not bind; the prelude's job is mode entry only. One cycle drives every mode-defining pin to its NORMAL mission-mode value (`cycle_fact:12`, `cycle_fact:24`), so the first SYM cycle starts in a legal mission-mode state. `b=1` and not `b=0` because the mode pins must be asserted before the first symbolic operation is legal. |
| SYM | 3 | Explore the mission-mode read/write operation and transition space. The explore pins (ME, WE, ADR, D, WEM, HW, PIPEME) stay at esp-default (distinct symbol per cycle), so ESP explores the full value and transition space of read, write, half-word, masked-write, and no-op behaviour. Three cycles give room for the write-then-read same-ADR corner (write at N, read at N+1) and for the 1-cycle pipelined output QP to be observed. |
| FLUSH | 1 | Propagate the last symbolic cycle's pending pipeline state to default comparison. QP carries the 1-cycle pipelined read output (`fact:ddf-c9f8fbf1`), so a read launched at SYMCYCLE3 has its QP value valid at FLUSHCYCLE1. `f=1` makes that value reach comparison; `f=0` would leave the final read's pipelined output unobserved. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | mode prelude | Establish mission mode: functional port owns the memory, normal power state, CLK selected, no scan/BIST/DFT, no clock-gating, no power-down. | `BISTE=1'b0`, `DFTCLKEN=1'b0`, `TEST1=1'b0`, `TCLKE=1'b0`, `TPR=1'b0`, `SE_IN=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:24`, `cycle_fact:12`, `cycle_fact:72`, `cycle_fact:53`, `cycle_fact:3` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1-3 | read/write exploration | Explore the mission-mode read/write operation and transition space. The explore pins ME, WE, ADR, D, WEM, HW, PIPEME are left at esp-default (distinct symbol per cycle), so ESP explores full-word and half-word reads (`cycle_fact:6,4,5`), HW=LL read hold (`cycle_fact:3`), full and half-word writes (`cycle_fact:10,8,9`), HW=LL write no-op (`cycle_fact:7`), masked write WEM=L (`cycle_fact:11`), and the legal HW=00 write no-op (`cycle_fact:47`). The write-then-read same-ADR corner is reachable because ADR is unconstrained and may hold the same value across consecutive cycles. | mode pins held at BIN values: `BISTE=1'b0`, `DFTCLKEN=1'b0`, `TEST1=1'b0`, `TCLKE=1'b0`, `TPR=1'b0`, `SE_IN=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`; explore pins ME, WE, ADR, D, WEM, HW, PIPEME unconstrained | `cycle_fact:24`, `cycle_fact:12`, `cycle_fact:6`, `cycle_fact:10`, `cycle_fact:11`, `cycle_fact:47` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | pipeline settle | Let the last symbolic cycle's pending pipeline state reach default comparison. QP carries the 1-cycle pipelined read output (`fact:ddf-c9f8fbf1`), so a read launched at SYMCYCLE3 has its QP value valid here. No new stimulus: explore pins return to unconstrained, mode pins stay at mission values so the compared state is still mission mode. | mode pins held at BIN values (as in SYM); explore pins unconstrained | `fact:ddf-c9f8fbf1`, `cycle_fact:24` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| WRITE (full/half/HW=LL no-op/masked) | SYMCYCLE1 | FLUSHCYCLE1 | Write commits to the array at cycle 1 (`cycle_fact:10,8,9,7,11`); Q retains Q-1 during a write (`cycle_fact:10`). The written word is held in the array and read back by the SYMCYCLE2 read on the same ADR. | The array holds the written value; no later cycle overwrites it before the SYMCYCLE2 read samples it. The write's commit is not overwritten because the explore pins are unconstrained and ESP explores the same-ADR write-then-read path. |
| READ (full/half/HW=LL hold) | SYMCYCLE2 | FLUSHCYCLE1 | Q reflects the addressed word at cycle 2 (`cycle_fact:6,4,5`); QP reflects it at cycle 3. observability = s - j + f = 3 - 2 + 1 = 2 >= pipeline_depth 1. | Q is the direct output with no additional CLK latency (`fact:ddf-c9f8fbf1`); nothing re-drives Q between cycle 2 and comparison. |
| READ (full/half/HW=LL hold) | SYMCYCLE3 | FLUSHCYCLE1 | Q reflects the addressed word at cycle 3; QP reflects it at FLUSHCYCLE1. observability = s - j + f = 3 - 3 + 1 = 1 >= pipeline_depth 1. | QP's 1-cycle pipelined value is valid at FLUSHCYCLE1 (`fact:ddf-c9f8fbf1`); the flush cycle carries it to comparison. |
| Write-then-read same ADR | write SYMCYCLE1, read SYMCYCLE2 | FLUSHCYCLE1 | The write commits at cycle 1; the cycle-2 read on the same ADR returns the written word (datasheet Table 4-3 corner). | ADR is unconstrained, so ESP explores the same-ADR consecutive-cycle path; the write's committed value is intact in the array when the cycle-2 read samples it. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | SYM, FLUSH | literal `1'b0` | BIST-mode operation (BISTE=1) and its transition into/out of mission mode | directive:0 names mission-mode read/write; mission mode requires BISTE=L so the functional port owns the memory (`cycle_fact:24`). BIST is a separate roster corner. | `directive:0`, `cycle_fact:24` |
| DFTCLKEN | SYM, FLUSH | literal `1'b0` | DFT clock-enable behaviour | Mission mode uses the functional port; DFTCLKEN is not among the active mission pins (`cycle_fact:24`). Scan/DFT is a separate roster corner. | `directive:0`, `cycle_fact:24` |
| TEST1 | SYM, FLUSH | literal `1'b0` | TEST1-driven test behaviour | Mission-mode read/write rows all carry TEST1=L (`cycle_fact:3-11`). | `directive:0`, `cycle_fact:3` |
| TCLKE | SYM, FLUSH | literal `1'b0` | TCLK clock selection | Mission mode selects the functional CLK; TCLKE=0 selects CLK. TCLKE=1 while CLK/TCLK high is illegal (`cycle_fact:50`). | `directive:0`, `cycle_fact:50` |
| TPR | SYM, FLUSH | literal `1'b0` | clock-gated idle (TPR=1 while ME=1) | Every mission-mode READ/WRITE row requires TPR=L (`cycle_fact:3-11`); TPR=1 while ME=1 is a legal idle that ignores ADR/D/WE/WEM (`cycle_fact:48`), which would defeat the read/write exploration. | `directive:0`, `cycle_fact:3`, `cycle_fact:48` |
| SE_IN | SYM, FLUSH | literal `1'b0` | scan shift operation | Mission mode has SE_IN=0; scan is a separate roster corner (`cycle_fact:72`). SE_IN=1 with DFTMASK=1 is illegal (`cycle_fact:52`). | `directive:0`, `cycle_fact:72` |
| DFTMASK | SYM, FLUSH | literal `1'b0` | DFT masking behaviour | DFTMASK=1 with DFTCLKEN=0 is illegal (`cycle_fact:53`); mission mode keeps DFTMASK=0. | `directive:0`, `cycle_fact:53` |
| LS, DS, SD | SYM, FLUSH | literal `1'b0` | light-sleep, deep-sleep, shutdown modes | Mission-mode NORMAL requires LS=DS=SD=0 (`cycle_fact:12`); power modes are separate roster corners. | `directive:0`, `cycle_fact:12` |
| POFF | SYM, FLUSH | literal `2'b00` | periphery-off power modes | Mission-mode NORMAL requires POFF=00 (`cycle_fact:12`); power modes are separate roster corners. | `directive:0`, `cycle_fact:12` |

## Assumptions

- No reset pin exists and no `reset_latency_cycles` scalar was stated, so the BIN phase is a mode-entry prelude only, not a reset hold. A5 does not bind; `b=1` establishes mission mode and is not credited with reset behaviour (`cycle_fact:12`, `cycle_fact:24`).
- The mode-defining pins are static configuration inputs that take effect immediately; one BIN cycle asserting them is sufficient to make the first SYM operation legal. This is the conservative reading — no evidence guarantees a longer mode-entry dwell for mission mode.
- BC0 is left unconstrained (free) across all phases: `cycle_fact:12` lists BC0=0/1 in NORMAL mode, so it does not define mission read/write legality and is not a mode pin to hold.
- Clocks CLK/TCLK are left unconstrained; the plan reasons about logical cycles only, per the guide's clock policy.
- The write-then-read same-ADR corner is reachable because ADR is unconstrained and ESP explores the same-value-across-consecutive-cycles path; no constraint forces it, and no constraint forbids it.

## Limitations

- The corner does not explore BIST, scan, power-down, or repair behaviour — those are separate roster corners and their mode pins are held at mission-mode values here.
- The corner does not drive or constrain any output (Q, QP, SO_*, ROP_*); ESP's default reference-versus-implementation comparison is the contract.
- The corner does not force WEM or HW to customary values; the masked-write (`cycle_fact:11`) and HW=00 no-op (`cycle_fact:47`) remain reachable within the unconstrained explore space.
- The corner does not verify the pipelined QP path beyond the 1-cycle latency declared (`fact:ddf-c9f8fbf1`); deeper pipeline behaviour is not part of this design's evidence.

## Coverage

- catches: full-word and half-word read data paths (`cycle_fact:6,4,5`); full-word and half-word write commit paths (`cycle_fact:10,8,9`); HW=LL read hold and write no-op (`cycle_fact:3,7`); masked write with WEM=L (`cycle_fact:11`); legal HW=00 write no-op (`cycle_fact:47`); the write-then-read same-ADR corner (write commits at cycle N, cycle-N+1 read returns the written word); the 1-cycle pipelined QP output (`fact:ddf-c9f8fbf1`); mode-pin gating that would corrupt a mission-mode access (e.g. TPR=1 idle, power-down forcing Q=0).
- misses: BIST, scan, power-down, and repair behaviour (separate corners); illegal-mode combinations that the held mode pins exclude (e.g. BISTE=1, SE_IN=1, DS/SD/POFF active) — these are intentionally excluded because the directive names mission mode and the sibling corners own them.
