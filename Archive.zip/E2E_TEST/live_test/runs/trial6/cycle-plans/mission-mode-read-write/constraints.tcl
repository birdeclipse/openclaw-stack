# ---------------------------------------------------------------------------
# mission-mode-read-write corner constraints
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
# Corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
#
# Transliteration of cycle-plans/mission-mode-read-write/plan.md.
#
# The mode-defining pins are held at their NORMAL mission-mode values across
# the whole run (BIN prelude, SYM exploration, FLUSH settle), so the corner
# stays in mission mode and the read/write operations are legal. The explore
# pins (ME, WE, ADR, D, WEM, HW, PIPEME) are left unconstrained so ESP
# explores their full value and transition space.
# ---------------------------------------------------------------------------

# --- testbench cycle counts (derived in plan.md) ---
set_app_var testbench_binary_cycles   1
set_app_var testbench_symbolic_cycles 3
set_app_var testbench_flush_cycles    1

# --- mode pins: mission-mode NORMAL values, held for the whole run ---
# BISTE=L so the functional port owns the memory (cycle_fact:24)
set_constraint {BISTE} -set {1'b0}
# DFTCLKEN=L: not among the active mission pins (cycle_fact:24)
set_constraint {DFTCLKEN} -set {1'b0}
# TEST1=L: mission-mode read/write rows carry TEST1=L (cycle_fact:3)
set_constraint {TEST1} -set {1'b0}
# TCLKE=0 selects the functional CLK (cycle_fact:50)
set_constraint {TCLKE} -set {1'b0}
# TPR=L required for READ/WRITE (cycle_fact:3); TPR=1 while ME=1 is idle (cycle_fact:48)
set_constraint {TPR} -set {1'b0}
# SE_IN=0: mission mode; scan is a separate corner (cycle_fact:72)
set_constraint {SE_IN} -set {1'b0}
# DFTMASK=0: DFTMASK=1 with DFTCLKEN=0 is illegal (cycle_fact:53)
set_constraint {DFTMASK} -set {1'b0}
# LS=DS=SD=0: NORMAL mode (cycle_fact:12)
set_constraint {LS} -set {1'b0}
set_constraint {DS} -set {1'b0}
set_constraint {SD} -set {1'b0}
# POFF=00: NORMAL mode (cycle_fact:12)
set_constraint {POFF} -set {2'b00}
