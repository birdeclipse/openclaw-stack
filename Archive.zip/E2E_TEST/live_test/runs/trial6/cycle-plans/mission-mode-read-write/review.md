# Review — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## correct

- **A1 holds for every operation, recomputed from the plan's own counts (b=1, s=3, f=1, pipeline_depth=1).** WRITE at SYMCYCLE1: `s-j+f = 3-1+1 = 3 >= 1`. READ at SYMCYCLE2: `3-2+1 = 2 >= 1`. READ at SYMCYCLE3: `3-3+1 = 1 >= 1`. The plan names `j` for every row and shows the arithmetic; the SYMCYCLE3 row is the tightest and still clears the depth by exactly 1, which is correct because QP's 1-cycle pipelined value is valid at FLUSHCYCLE1 (`fact:ddf-c9f8fbf1`).
- **A5 correctly handled as non-binding.** No reset pin exists and no `reset_latency_cycles` scalar was stated; the plan does not invent one and does not credit INIT with reset or mode work. `b=1` is a mode-entry prelude only, and the plan states the conservative assumption that mode pins take effect immediately with no evidence of a longer dwell. This is the correct treatment of an unbound scalar — it is not silently picked.
- **A3 correctly N/A.** No chain is shifted in this corner; SE_IN is held low as a mission-mode value, not exercised.
- **Selectors are sound.** BINCYCLE1, SYMCYCLE1-3, FLUSHCYCLE1 are 1-based, each end inside its phase count, listed in monotone (phase, start) order, and non-overlapping. No pin receives two values in one cycle.
- **Authorability holds.** Every driven pin (BISTE, DFTCLKEN, TEST1, TCLKE, TPR, SE_IN, DFTMASK, LS, DS, SD, POFF) is a primary input spelled exactly as the inventory spells it. Every value is justified by a cited operation row (`cycle_fact:24` for BISTE/DFTCLKEN, `cycle_fact:3` for TEST1/TPR, `cycle_fact:50` for TCLKE, `cycle_fact:12` for LS/DS/SD/POFF, `cycle_fact:53` for DFTMASK). No output is driven.
- **Coverage classification is correct and disclosed.** The eleven mode pins are bound in every SYM cycle — a demotion — and each has a symbolic-treatment row naming the lost scenario class (BIST, scan, DFT, power modes, clock-gated idle) and why the loss is acceptable (separate roster corners; mission mode requires these values). The explore pins ME, WE, ADR, D, WEM, HW, PIPEME are left unconstrained, which is the strongest coverage and needs no row. BC0 is correctly left free (`cycle_fact:12` lists BC0=0/1 in NORMAL).
- **Citations resolve.** Every ref (cycle_fact:3,6,10,11,12,24,47,48,50,52,53,72; fact:ddf-c9f8fbf1; directive:0) is in the survey's Evidence catalog. The header cites the corpus digest.
- **The constraints.tcl faithfully transliterates the plan.** All eleven mode pins are held with `set_constraint {PIN} -set {value}` with no cycle selector, applying across BIN/SYM/FLUSH, matching the plan's "held for the whole run." The testbench cycle counts (1/3/1) match. No constraint appears in the Tcl that is absent from the plan, and none is missing.
- **The causal story is sound.** BIN establishes mission mode; SYM explores the read/write space with mode pins held; FLUSH lets the SYMCYCLE3 read's QP value reach comparison. The write-then-read same-ADR path is reachable because ADR is unconstrained (ESP explores the same-value-across-consecutive-cycles path); the plan correctly frames this as reachable, not forced.

## missing

- none.

## user-review

- **The write-then-read same-ADR observation is path-dependent, not guaranteed.** Because ADR is unconstrained, ESP explores both the same-ADR and different-ADR consecutive-cycle paths; the observability row "the cycle-2 read on the same ADR returns the written word" holds only on the same-ADR path. This is acceptable for a symbolic corner (the path is explored, and the plan's assumption section discloses it), but the engineer should read the write-then-read row as a reachable-path claim, not a forced observation. If a guaranteed write-then-read witness were wanted, ADR would need to be held `symbolic_static` across SYMCYCLE1-2 — a capacity trade the plan did not make, and does not need to make for this directive.
- **SE_IN=0's primary citation is weak.** The plan's justification cites `cycle_fact:72` (TRANS_IDLE_SCAN), which describes scan *entry* and does not directly state that mission mode requires SE_IN=0; the mission-mode read/write rows carry SE_IN=X (don't care). The stronger support is `cycle_fact:52` (SE_IN=1 with DFTMASK=1 illegal) plus the fact that scan is a separate roster corner. The hold is correct for a mission-mode corner; only the citation strength is worth tightening.
- **TPR=0 excludes a legal mission-mode state.** `cycle_fact:48` documents TPR=1 while ME=1 as a legal clock-gated idle. The plan excludes it because it would defeat read/write exploration, and documents this in the symbolic-treatment row. This is a defensible scope choice for a read/write directive, but it is a deliberate exclusion of a legal state — the engineer should confirm that excluding clock-gated idle from this corner is intended (it is not covered by any sibling corner's plan either).
