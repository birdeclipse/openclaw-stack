# Cycle Plan — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | legal IDLE→SCAN entry prelude, derived from `cycle_fact:72` TRANS_IDLE_SCAN: (1) hold the legal IDLE state with clocks low, BISTE=0, DFTMASK=0, power normal; (2) assert SE_IN; (3) then enable the DFT clock (DFTCLKEN=1). Three distinct sequential steps, so b=3 and not b-1. `reset_latency_cycles` is not declared in the corpus, so A5 binds b only to this mode-entry sequencing, which these three cycles cover. |
| SYM | 1 | the scan shift operation space: SE_IN=1 and DFTCLKEN=1 active (the shift condition from `cycle_fact:72`), SI_* left symbolic as the explore pins. One symbolic cycle launches the shift; the pass-through is combinational so the shift edge is the launch. |
| FLUSH | 1 | one full chain traversal. `scan_chain_length` is declared 1 (`fact:ddf-43efd23b`), so A3 requires f >= 1; f=1 satisfies it. SE_IN is driven with a value in every flush cycle 1..f (FLUSHCYCLE1 drives SE_IN=1), per cycle not per segment. |

Derivation of the total schedule: BIN=3 (entry) + SYM=1 (shift launch) + FLUSH=1 (traversal) = 5 logical cycles. The shift effect (SI→SO) is combinational in the wrapper (`fact:ddf-43efd23b`), so it appears in the same logical cycle as the shift edge; the flush cycle holds SE_IN so the shifted value is still present at default comparison.

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE hold | hold the legal IDLE state before scan entry: clocks low, BISTE=0, DFTMASK=0, power normal, SE_IN=0, DFTCLKEN=0 | `BISTE=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `SE_IN=1'b0`, `DFTCLKEN=1'b0` | `cycle_fact:0`, `cycle_fact:12`, `cycle_fact:25`, `cycle_fact:52`, `cycle_fact:53`, `cycle_fact:56` |
| BINCYCLE2 | assert SE_IN | assert the scan-shift enable while still in the low-clock, BISTE=0 entry state | `SE_IN=1'b1`; hold `BISTE=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `DFTCLKEN=1'b0` | `cycle_fact:72`, `cycle_fact:25`, `cycle_fact:52`, `cycle_fact:56` |
| BINCYCLE3 | enable DFT clock | enable the DFT clock so the shift edge can occur; SE_IN already asserted | `DFTCLKEN=1'b1`; hold `SE_IN=1'b1`, `BISTE=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:72`, `cycle_fact:25`, `cycle_fact:52`, `cycle_fact:56` |

The BIN prelude establishes the legal IDLE→SCAN entry exactly as `cycle_fact:72` sequences it: hold IDLE, assert SE_IN, then enable the DFT clock. `reset_latency_cycles` is not declared, so no reset hold is credited here; the three cycles are the mode-entry sequencing A5 counts in b. CLK/TCLK are left unconstrained — "both clocks low" is a logical-cycle claim about the entry state, not a clock constraint (`cycle_fact:72`).

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | shift launch | launch the scan shift: SE_IN=1 and DFTCLKEN=1 active so the shift edge propagates each chain's SI to its SO; SI_* left symbolic as the explore pins | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`; `SI_Q_L`, `SI_Q_H`, `SI_D_L`, `SI_D_H`, `SI_CNTR` unconstrained (symbolic) | `cycle_fact:72`, `cycle_fact:25`, `cycle_fact:52`, `cycle_fact:56`, `pin:SI_Q_L`, `pin:SI_Q_H`, `pin:SI_D_L`, `pin:SI_D_H`, `pin:SI_CNTR` |

The shift condition is SE_IN=1 with the DFT clock enabled (`cycle_fact:72`). The SI_* pins are the pins this corner exists to explore — the shift value must vary — so they stay at ESP's symbolic default (a distinct symbol per cycle, full value and transition space). The wrapper's pass-through `SO = SE_IN ? SI : 1'b0` (`fact:ddf-43efd23b`) is combinational, so the shift edge in SYMCYCLE1 makes SO reflect SI in the same logical cycle.

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | chain traversal | one full chain traversal: SE_IN held at 1 so each chain's shifted SI value remains on its SO at default comparison; DFTCLKEN held at 1 to keep the DFT clock active | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`; `SI_*` unconstrained (symbolic) | `cycle_fact:72`, `cycle_fact:25`, `cycle_fact:52`, `cycle_fact:56`, `fact:ddf-43efd23b` |

A3: f=1 >= scan_chain_length=1 (`fact:ddf-43efd23b`), and SE_IN is driven with a value in every flush cycle 1..f — FLUSHCYCLE1 drives SE_IN=1. The exit sequence of `cycle_fact:74` (deassert DFTCLKEN, then SE_IN) is deliberately NOT executed within this plan: deasserting SE_IN would drive SO to 0 (`SO = SE_IN ? SI : 0`), destroying the shifted value before comparison. The plan ends with SE_IN still held, so the shifted value is intact at default comparison.

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| scan shift, chain Q_L | SYMCYCLE1 | FLUSHCYCLE1 | SO_Q_L = SI_Q_L (pass-through `SO = SE_IN ? SI : 0`) | SE_IN held at 1 through FLUSHCYCLE1; no later cycle deasserts SE_IN or re-drives SI_Q_L, so SO_Q_L still carries the shifted value at comparison |
| scan shift, chain Q_H | SYMCYCLE1 | FLUSHCYCLE1 | SO_Q_H = SI_Q_H | same: SE_IN held, SI_Q_H not re-driven |
| scan shift, chain D_L | SYMCYCLE1 | FLUSHCYCLE1 | SO_D_L = SI_D_L | same |
| scan shift, chain D_H | SYMCYCLE1 | FLUSHCYCLE1 | SO_D_H = SI_D_H | same |
| scan shift, chain CNTR | SYMCYCLE1 | FLUSHCYCLE1 | SO_CNTR = SI_CNTR | same |

A1 reasoning: the scan pass-through is combinational in the wrapper (`fact:ddf-43efd23b`), so the shift effect on SO appears in the same logical cycle as the shift edge — it does not cross the registered stage that `pipeline_depth=1` (`fact:ddf-c9f8fbf1`) describes (that depth governs the pipelined read output, not the scan path). Even under the conservative registered interpretation, the shift launches in SYMCYCLE1 (j=1) with s=1, f=1, giving s - j + f = 1 - 1 + 1 = 1 >= pipeline_depth (1), so A1 holds either way. The SO_* outputs are observed by ESP's default reference-versus-implementation comparison; they are never driven or constrained (`pin:SO_Q_L`, `pin:SO_Q_H`, `pin:SO_D_L`, `pin:SO_D_H`, `pin:SO_CNTR`). Q is not functionally updated in scan mode (`cycle_fact:72`), so no Q comparison is claimed.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| SE_IN | BIN2-3, SYM1, FLUSH1 | literal 1 | SE_IN=0 transitions during the shift | SE_IN=1 is the shift-enable condition (`cycle_fact:72`); A3 requires it held in every flush cycle; SE_IN=0 would disable the shift (`SO=0`), so it is not part of the shift operation | `cycle_fact:72`, `fact:ddf-43efd23b` |
| DFTCLKEN | BIN3, SYM1, FLUSH1 | literal 1 | DFTCLKEN=0 during the shift | DFTCLKEN=1 enables the DFT clock for the shift (`cycle_fact:72`); DFTCLKEN=0 would stop the shift edge | `cycle_fact:72` |
| BISTE | BIN1-3, SYM1, FLUSH1 | literal 0 | BISTE=1 during scan | scan is a separate owner from BIST; BISTE=0 is required for the functional/scan port to own the memory (`cycle_fact:25`), and the scan entry requires BISTE=0 (`cycle_fact:72`) | `cycle_fact:25`, `cycle_fact:72` |
| DFTMASK | BIN1-3, SYM1, FLUSH1 | literal 0 | DFTMASK=1 during scan | SE_IN=1 with DFTMASK=1 is illegal (R13, `cycle_fact:52`); DFTMASK=1 with DFTCLKEN=0 is illegal (R14, `cycle_fact:53`); both illegal states are excluded by holding DFTMASK=0 | `cycle_fact:52`, `cycle_fact:53` |
| LS, DS, SD | BIN1-3, SYM1, FLUSH1 | literal 0 | power modes during scan | power mode asserted during scan shift is illegal (R24, `cycle_fact:56`); normal mode requires LS=DS=SD=0 (`cycle_fact:12`) | `cycle_fact:56`, `cycle_fact:12` |
| POFF | BIN1-3, SYM1, FLUSH1 | literal 00 | POFF power-down during scan | power mode asserted during scan shift is illegal (R24, `cycle_fact:56`); normal mode requires POFF=00 (`cycle_fact:12`) | `cycle_fact:56`, `cycle_fact:12` |

The SI_* pins (SI_Q_L, SI_Q_H, SI_D_L, SI_D_H, SI_CNTR) are the pins this corner exists to explore and are left unconstrained — ESP's symbolic default, a distinct symbol per cycle with full value and transition space. They need no row. The SO_* outputs are observed, never driven. CLK/TCLK are left unconstrained: "both clocks low" in the entry is a logical-cycle claim, not a clock constraint (`cycle_fact:72`).

## Assumptions

- The scan pass-through is combinational in the wrapper: `SO = SE_IN ? SI : 1'b0` for each of the five chains (`fact:ddf-43efd23b`). The shift effect therefore appears in the same logical cycle as the shift edge, and one logical shift traverses a chain (scan_chain_length=1).
- "Both clocks low" in the IDLE→SCAN entry (`cycle_fact:72`) is a logical-cycle claim about the entry state, not a clock constraint; CLK/TCLK remain unconstrained. This is the conservative reading — no clock pin is bound.
- `reset_latency_cycles` is not declared in the corpus, so no reset hold is credited to BIN; the three BIN cycles are the mode-entry sequencing A5 counts in b.
- The plan ends with SE_IN still asserted (the exit of `cycle_fact:74` is not executed within the plan) so the shifted value survives to comparison. This is a deliberate schedule boundary, not an omission.

## Limitations

- The plan verifies the wrapper's pass-through scan model (`fact:ddf-43efd23b`), not the macro's physical scan chains. The physical chain lengths are undeclared anywhere in the corpus; verifying them would require those lengths and is out of scope for this corner. This is a scope limit and an ask for the run owner, not a hidden assumption.
- The scan-dft corner (certified under the same `directive:1`) owns the broader DFT/write-through surface; this corner covers only the shift path per se (SI→SO across one traversal) and does not broaden into BIST or write-through.
- Q is not functionally updated in scan mode (`cycle_fact:72`); no Q comparison is claimed.
- The exit sequence (deassert DFTCLKEN, then SE_IN, wait one inactive cycle) is not exercised within this plan; it would destroy the shifted value before comparison. Exercising the exit is a separate concern.

## Coverage

- catches: a broken pass-through in any of the five chains (SO not equal to SI when SE_IN=1), a scan-enable that fails to gate the pass-through (SO not forced to 0 when SE_IN=0), a chain whose SO is stuck or shorted, and an illegal power-mode or DFTMASK interaction that corrupts the scan output. Because SI_* are symbolic, every SI value is explored against the pass-through, so a mutation that drops or inverts any bit of any chain's shift path is exposed at default comparison on the corresponding SO_* output.
- misses: the physical scan chains (undeclared length, out of scope), the scan exit sequence, and the broader DFT/BIST surface owned by the scan-dft corner. These are acceptable here because the corner is scoped to the wrapper's shift path per se.
