# Review — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## correct

- **A3 holds, recomputed from the plan's own counts.** `scan_chain_length=1` (`fact:ddf-43efd23b`), `f=1`, so `f >= scan_chain_length` is satisfied. SE_IN is driven with a value in every flush cycle 1..f: FLUSHCYCLE1 drives SE_IN=1. The plan explicitly addresses the per-cycle (not per-segment) requirement and the fact that deasserting SE_IN would drive SO to 0 (`SO = SE_IN ? SI : 0`), destroying the shifted value — so it deliberately ends with SE_IN held. This is the correct A3 application on a custom corner that shifts a chain.
- **A1 holds.** The pass-through is combinational (`fact:ddf-43efd23b`), so the shift effect appears in the same logical cycle as the shift edge. Even under the conservative registered interpretation, `s - j + f = 1 - 1 + 1 = 1 >= pipeline_depth 1`. The plan names `j=1` and shows the arithmetic.
- **A5 correctly handled.** No `reset_latency_cycles` scalar is declared; the plan does not invent one and does not credit INIT. `b=3` is derived from the three sequential steps of `cycle_fact:72` (hold IDLE, assert SE_IN, then enable DFT clock), each with its own BIN segment row. This is a grounded mode-entry prelude, not padding.
- **Selectors are sound.** BINCYCLE1-3, SYMCYCLE1, FLUSHCYCLE1 are 1-based, each end inside its phase count, monotone, non-overlapping. No pin receives two values in one cycle.
- **Authorability holds.** Every driven pin (SE_IN, DFTCLKEN, BISTE, DFTMASK, LS, DS, SD, POFF) is a primary input spelled as the inventory spells it. Every value is justified by a cited row: SE_IN/DFTCLKEN by `cycle_fact:72`, BISTE by `cycle_fact:25`/`cycle_fact:72`, DFTMASK by `cycle_fact:52`/`cycle_fact:53`, power pins by `cycle_fact:56`/`cycle_fact:12`. No output is driven.
- **Coverage classification is correct and disclosed.** The control pins bound in the single SYM cycle (SE_IN, DFTCLKEN, BISTE, DFTMASK, LS, DS, SD, POFF) each have a symbolic-treatment row naming the lost scenario class and why the loss is acceptable (SE_IN=0 would disable the shift; DFTMASK=1 is illegal with SE_IN=1; power during scan is illegal per R24). The SI_* pins — the pins this corner exists to explore — are left unconstrained, which is the strongest coverage and needs no row.
- **Citations resolve.** Every ref (cycle_fact:0,12,25,52,53,56,72,74; fact:ddf-43efd23b; pin:SI_*, pin:SO_*) is in the survey's Evidence catalog. The header cites the corpus digest.
- **The constraints.tcl faithfully transliterates the plan.** The per-cycle SE_IN/DFTCLKEN sequence (SE_IN=0 in BIN1, SE_IN=1 in BIN2, DFTCLKEN=1 in BIN3, both held in SYM1 and FLUSH1) matches the plan's segment tables exactly. Testbench counts (3/1/1) match. No constraint appears in the Tcl that is absent from the plan, and none is missing.
- **The causal story is sound.** BIN establishes the legal IDLE→SCAN entry per `cycle_fact:72`; SYM launches the shift with SE_IN=1 and DFTCLKEN=1; FLUSH holds SE_IN so the pass-through is still active at comparison. The mutation probes (broken pass-through, ungated SO, stuck chain) all change SO under SE_IN=1 and reach default comparison on the SO_* outputs.

## missing

- none.

## user-review

- **The observability prose slightly overstates what the flush holds.** The plan says "no later cycle re-drives SI_Q_L, so SO_Q_L still carries the shifted value at comparison." But SI_* are unconstrained in FLUSH, so they are re-driven with fresh symbols; SO_Q_L at FLUSHCYCLE1 carries the FLUSH SI value, not the SYMCYCLE1 SI value. This does not undermine the corner — the pass-through relation SO=SI is checked per-cycle in both SYM and FLUSH, so a broken pass-through is exposed either way — but the "value intact" phrasing is imprecise. The engineer should read the flush as a re-check of the pass-through under SE_IN=1, not as a hold of the SYM value.
- **The FLUSH cycle is arguably redundant for a combinational path.** Because the pass-through is combinational, the shift effect is already present and compared in SYMCYCLE1; the flush re-checks it. This is not a defect — A3 requires `f >= scan_chain_length` and the plan satisfies it — but the engineer should know the flush is an A3-driven hold, not a propagation requirement.
- **The physical chain lengths are undeclared.** The plan verifies the wrapper's pass-through model (`fact:ddf-43efd23b`, scan_chain_length=1), not the macro's physical chains, and names this as a scope limit and an ask for the run owner. This is an honest limitation, not a hidden assumption — but it means this corner's "one full chain traversal" is a traversal of the wrapper's one-stage model, and a physical chain longer than 1 would not be caught here.
