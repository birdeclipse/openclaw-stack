# ---------------------------------------------------------------------------
# scan-shift-path corner constraints — run trial6
# corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
#
# Faithful transliteration of cycle-plans/scan-shift-path/plan.md.
# Schedule: BIN=3 (IDLE->SCAN entry), SYM=1 (shift launch), FLUSH=1 (traversal).
# All targets are primary inputs from the survey inventory. SO_* outputs are
# observed by ESP default comparison, never constrained. SI_* are the explore
# pins and stay unconstrained (symbolic). CLK/TCLK stay unconstrained.
# ---------------------------------------------------------------------------

# --- testbench cycle counts (derived in plan.md Cycle counts) ---
set_app_var testbench_binary_cycles 3
set_app_var testbench_symbolic_cycles 1
set_app_var testbench_flush_cycles  1

# --- BINCYCLE1: hold legal IDLE state (cycle_fact:0, cycle_fact:12,
#     cycle_fact:25, cycle_fact:52, cycle_fact:53, cycle_fact:56) ---
set_constraint {BISTE}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTMASK} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}    -cycle {BINCYCLE1} -set {2'b00}
set_constraint {SE_IN}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN}-cycle {BINCYCLE1} -set {1'b0}

# --- BINCYCLE2: assert SE_IN (cycle_fact:72); hold entry state ---
set_constraint {SE_IN}   -cycle {BINCYCLE2} -set {1'b1}
set_constraint {BISTE}   -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DFTMASK} -cycle {BINCYCLE2} -set {1'b0}
set_constraint {LS}      -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DS}      -cycle {BINCYCLE2} -set {1'b0}
set_constraint {SD}      -cycle {BINCYCLE2} -set {1'b0}
set_constraint {POFF}    -cycle {BINCYCLE2} -set {2'b00}
set_constraint {DFTCLKEN}-cycle {BINCYCLE2} -set {1'b0}

# --- BINCYCLE3: enable DFT clock (cycle_fact:72); hold SE_IN and entry state ---
set_constraint {DFTCLKEN}-cycle {BINCYCLE3} -set {1'b1}
set_constraint {SE_IN}   -cycle {BINCYCLE3} -set {1'b1}
set_constraint {BISTE}   -cycle {BINCYCLE3} -set {1'b0}
set_constraint {DFTMASK} -cycle {BINCYCLE3} -set {1'b0}
set_constraint {LS}      -cycle {BINCYCLE3} -set {1'b0}
set_constraint {DS}      -cycle {BINCYCLE3} -set {1'b0}
set_constraint {SD}      -cycle {BINCYCLE3} -set {1'b0}
set_constraint {POFF}    -cycle {BINCYCLE3} -set {2'b00}

# --- SYMCYCLE1: shift launch (cycle_fact:72, cycle_fact:25, cycle_fact:52,
#     cycle_fact:56). SI_* left unconstrained (explore pins). ---
set_constraint {SE_IN}   -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN}-cycle {SYMCYCLE1} -set {1'b1}
set_constraint {BISTE}   -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DFTMASK} -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}      -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}      -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}      -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}    -cycle {SYMCYCLE1} -set {2'b00}

# --- FLUSHCYCLE1: one full chain traversal, SE_IN held (A3: f >= 1,
#     SE_IN driven in every flush cycle; cycle_fact:72, fact:ddf-43efd23b).
#     SI_* left unconstrained. ---
set_constraint {SE_IN}   -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN}-cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {BISTE}   -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DFTMASK} -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}      -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}      -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}      -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF}    -cycle {FLUSHCYCLE1} -set {2'b00}
