# Cycle Plan — low-power-sequence

- corner: low-power-sequence
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish legal IDLE before the first transition: all power pins deasserted (LS=DS=SD=0, POFF=00), CLK low, DFT disabled (DFTCLKEN=L, BISTE=L). No reset pin and no `reset_latency_cycles` scalar exist in the corpus, so A5 binds nothing; the single cycle gives the design a grounded legal-IDLE state to launch T1 from (`cycle_fact:0`, `cycle_fact:12`). b=1 because one cycle is sufficient to hold the legal-idle combination and there is no reset latency to settle. |
| SYM | 25 | The 8-transition mode lattice, each transition's dwell being the minimum one cycle (Assumption A1) plus the transition cycle itself, returning to IDLE between transitions so each starts from legal IDLE. T1 IDLE→ACTIVE→IDLE (2), T2 IDLE→LS→IDLE (2), T3 IDLE→DS→WAKE_DS→IDLE (4, incl. tPGGUARD=2), T4 IDLE→SD→WAKE_SD→IDLE (4, incl. tPGGUARD=2), T5 LS→DS sequenced (4: re-enter LS, deassert LS, tLSEXT wait, assert DS), T6 DS→SD + exit to IDLE (4), T7 IDLE→POFF_RET→IDLE (4, incl. tVDDSTB + tPGGUARD=2), T8 IDLE→POFF_SD final (1). Sum = 2+2+4+4+4+4+4+1 = 25. |
| FLUSH | 1 | One final comparison cycle after the last transition (POFF_SD) confirming the destructive forced-Q=0 state is identical in reference and implementation. Also satisfies A1 for the mission read launched at SYM1: available cycles s−j+f = 25−1+1 = 25 ≥ pipeline_depth=1 (`fact:ddf-c9f8fbf1`). No other pipeline state is pending at the end of SYM, so f=1 is sufficient. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | legal IDLE | Hold the legal-idle combination so the first transition launches from a grounded state: all power pins deasserted, clocks low, DFT disabled, mission enables off. | `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `DFTCLKEN=1'b0`, `BISTE=1'b0`, `ME=1'b0`, `TME=1'b0`, `SE_IN=1'b0`, `TPR=1'b0` | `cycle_fact:0`, `cycle_fact:12`, `pin:CLK`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF`, `pin:DFTCLKEN`, `pin:BISTE`, `pin:ME`, `pin:TME`, `pin:SE_IN`, `pin:TPR` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | T1 IDLE→ACTIVE | Mission read launch: assert ME, CLK high, HW=HH for full-word read, all power pins off. This is the corner's only pipeline-launching access (A1 applies). | `ME=1'b1`, `CLK=1'b1`, `HW=2'b11`, `WE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:57`, `cycle_fact:6`, `cycle_fact:12`, `fact:ddf-c9f8fbf1` |
| SYMCYCLE2 | T1 ACTIVE→IDLE | Deassert ME, one full inactive clock cycle before ownership/power changes; last Q/QP retained. | `ME=1'b0`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:58` |
| SYMCYCLE3 | T2 IDLE→LS | Assert LS while DS=SD=0 and POFF inactive; Q/QP/SO retain prior values. | `LS=1'b1`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:59`, `cycle_fact:13` |
| SYMCYCLE4 | T2 LS→IDLE | Deassert LS, hold ME=TME=0, tLSEXT before next active clock; prior values retained. | `LS=1'b0`, `ME=1'b0`, `TME=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:60` |
| SYMCYCLE5 | T3 IDLE→DS | Clocks low, ME=TME=0, LS=SD=0, assert DS; Q/QP/SO forced 0, ROP_DS=1. | `DS=1'b1`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:61`, `cycle_fact:14` |
| SYMCYCLE6 | T3 DS→WAKE_DS | Deassert DS while LS=SD=0 and clocks remain low; Q=0, QP/SO=X, ROP_DS=1. | `DS=1'b0`, `CLK=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:62`, `cycle_fact:15` |
| SYMCYCLE7-8 | T3 WAKE_DS→IDLE | Wait until ROP_DS=0, then tPGGUARD=2 CLK cycles; outputs become valid after guard. | `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:63` |
| SYMCYCLE9 | T4 IDLE→SD | Clocks low, ME=TME=0, LS=DS=0, assert SD; Q/QP/SO forced 0, ROP_SD=1. | `SD=1'b1`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:65`, `cycle_fact:18` |
| SYMCYCLE10 | T4 SD→WAKE_SD | Restore supplies, deassert SD, keep all enables low; Q=0, QP/SO=X, ROP_SD=1. | `SD=1'b0`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:66`, `cycle_fact:19` |
| SYMCYCLE11-12 | T4 WAKE_SD→IDLE | Wait until ROP_SD=0, then apply tPGGUARD=2; data unknown until written, outputs valid electrically. | `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:67` |
| SYMCYCLE13 | T5 IDLE→LS | Re-enter LS to set up the sequenced LS→DS entry. | `LS=1'b1`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:59`, `cycle_fact:13` |
| SYMCYCLE14 | T5 LS→DS step 1 | Deassert LS (tLSEXT begins). | `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:71` |
| SYMCYCLE15 | T5 LS→DS step 2 | Hold tLSEXT wait before asserting DS. | `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:71` |
| SYMCYCLE16 | T5 LS→DS step 3 | Assert DS; retained, last Q then forced 0, ROP_DS=1. | `DS=1'b1`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:71`, `cycle_fact:14` |
| SYMCYCLE17 | T6 DS→SD | Assert SD while clocks remain low; outputs forced 0, ROP_SD=1. Sequenced entry authorized by transition row 64 even though steady-state SD&DS is flagged illegal (R01) — recorded in Limitations. | `SD=1'b1`, `DS=1'b1`, `CLK=1'b0`, `LS=1'b0`, `POFF=2'b00` | `cycle_fact:64`, `cycle_fact:44` |
| SYMCYCLE18 | T6 SD→WAKE_SD | Deassert SD, keep enables low; Q=0, QP/SO=X, ROP_SD=1. | `SD=1'b0`, `DS=1'b0`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `POFF=2'b00` | `cycle_fact:66`, `cycle_fact:19` |
| SYMCYCLE19-20 | T6 WAKE_SD→IDLE | Wait until ROP_SD=0, then tPGGUARD=2; outputs valid electrically. | `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:67` |
| SYMCYCLE21 | T7 IDLE→POFF_RET | POFF 00→01 (Embedded); periphery clock stopped, Q/QP/SO=X after periphery supply collapse; retained if VDDA valid. | `POFF=2'b01`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0` | `cycle_fact:68`, `cycle_fact:22` |
| SYMCYCLE22 | T7 POFF_RET→IDLE step 1 | Restore VDD, wait tVDDSTB, then remove POFF; X until periphery stable. | `POFF=2'b00`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0` | `cycle_fact:69` |
| SYMCYCLE23-24 | T7 POFF_RET→IDLE step 2 | tPGGUARD=2 guard cycles after POFF removal; retained, outputs valid after guard. | `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:69`, `cycle_fact:63` |
| SYMCYCLE25 | T8 IDLE→POFF_SD (final) | POFF 00→11 with clocks/enables inactive; destroyed, Q/QP/SO=X. Final state — no exit. | `POFF=2'b11`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `ME=1'b0`, `TME=1'b0` | `cycle_fact:70`, `cycle_fact:23` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | final comparison | Hold the POFF_SD destructive state one more cycle so the forced-Q=0 output is compared in reference and implementation at default comparison. No pipeline state is pending (the SYM1 read reached comparison at SYM2). | `POFF=2'b11`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0` | `cycle_fact:23`, `cycle_fact:70` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| T1 mission read (IDLE→ACTIVE) | SYMCYCLE1 | SYMCYCLE2 | Full-word read of addressed location appears on pipelined Q one cycle later (pipeline_depth=1). | The read launches at SYM1; its pipelined output is valid at SYM2, where ME is deasserted but cycle_fact:58 retains the last Q/QP. No later cycle re-drives Q before comparison. A1: s−j+f = 25−1+1 = 25 ≥ 1. |
| T1 ACTIVE→IDLE | SYMCYCLE2 | SYMCYCLE2 | ME deasserted, one inactive cycle; data preserved, last Q/QP retained. | The retained Q/QP is compared at SYM2 before any power-down forces Q to 0. |
| T2 IDLE→LS | SYMCYCLE3 | SYMCYCLE3 | LS asserted; Q/QP/SO retain prior values (Xdec power gate, source bias). | LS is a mode pin; its effect (retention) is observed at SYM3 while Q/QP still hold prior values. |
| T2 LS→IDLE | SYMCYCLE4 | SYMCYCLE4 | LS deasserted, tLSEXT before next active clock; prior values retained. | Retention observed at SYM4; no active clock yet, so no overwrite. |
| T3 IDLE→DS | SYMCYCLE5 | SYMCYCLE5 | DS asserted; Q/QP/SO forced 0, ROP_DS=1. | ROP_DS<=DS (RTL 164-167) is combinational; ROP_DS=1 and forced Q=0 are compared at SYM5. |
| T3 DS→WAKE_DS | SYMCYCLE6 | SYMCYCLE6 | DS deasserted, clocks low; Q=0, QP/SO=X, ROP_DS=1. | ROP_DS still 1 (retention handshake) compared at SYM6. |
| T3 WAKE_DS→IDLE | SYMCYCLE7 | SYMCYCLE9 | ROP_DS falls to 0, then tPGGUARD=2; outputs valid after guard. | ROP_DS=0 and valid outputs compared at SYM9 after the 2-cycle guard; no re-entry into DS before comparison. |
| T4 IDLE→SD | SYMCYCLE9 | SYMCYCLE9 | SD asserted; Q/QP/SO forced 0, ROP_SD=1. | ROP_SD<=SD combinational; ROP_SD=1 and forced Q=0 compared at SYM9. |
| T4 SD→WAKE_SD | SYMCYCLE10 | SYMCYCLE10 | SD deasserted, enables low; Q=0, QP/SO=X, ROP_SD=1. | ROP_SD still 1 compared at SYM10. |
| T4 WAKE_SD→IDLE | SYMCYCLE11 | SYMCYCLE13 | ROP_SD falls to 0, then tPGGUARD=2; outputs valid electrically. | ROP_SD=0 compared at SYM13 after the 2-cycle guard. |
| T5 LS→DS sequenced | SYMCYCLE13-16 | SYMCYCLE16 | LS deasserted, tLSEXT wait, then DS asserted; retained, last Q then forced 0, ROP_DS=1. | ROP_DS=1 and forced Q=0 compared at SYM16; the sequenced entry is complete before comparison. |
| T6 DS→SD | SYMCYCLE17 | SYMCYCLE17 | SD asserted while DS still high (sequenced); outputs forced 0, ROP_SD=1. | ROP_SD=1 and forced Q=0 compared at SYM17. R01 tension recorded in Limitations. |
| T6 SD→WAKE_SD + exit | SYMCYCLE18-20 | SYMCYCLE20 | SD deasserted, ROP_SD falls, tPGGUARD=2; outputs valid electrically. | ROP_SD=0 compared at SYM20 after guard. |
| T7 IDLE→POFF_RET | SYMCYCLE21 | SYMCYCLE21 | POFF 00→01; periphery clock stopped, Q/QP/SO=X after supply collapse; retained if VDDA valid. | POFF=01 mode and X outputs compared at SYM21. |
| T7 POFF_RET→IDLE | SYMCYCLE22-24 | SYMCYCLE24 | VDD restored, POFF removed, tVDDSTB + tPGGUARD=2; retained, outputs valid after guard. | Retained data and valid outputs compared at SYM24 after the guard. |
| T8 IDLE→POFF_SD (final) | SYMCYCLE25 | FLUSHCYCLE1 | POFF 00→11 destructive; Q/QP/SO=X, forced 0. | The destructive forced-Q=0 state is held through FLUSHCYCLE1 and compared there; no later cycle re-drives it. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| LS | SYM | literal per segment | Within-phase LS transitions beyond the sequenced lattice | LS is a corner explore pin; the directive requires sequencing the mode transitions, so LS is held per segment to the value each transition row names. Each hold is a disclosed demotion with its transition row. | `directive:3`, `cycle_fact:59`, `cycle_fact:60`, `cycle_fact:71` |
| DS | SYM | literal per segment | Within-phase DS transitions beyond the sequenced lattice | DS is a corner explore pin; held per segment to sequence IDLE→DS, DS→WAKE_DS, LS→DS, DS→SD. Each hold disclosed with its transition row. | `directive:3`, `cycle_fact:61`, `cycle_fact:62`, `cycle_fact:71`, `cycle_fact:64` |
| SD | SYM | literal per segment | Within-phase SD transitions beyond the sequenced lattice | SD is a corner explore pin; held per segment to sequence IDLE→SD, SD→WAKE_SD, DS→SD. Each hold disclosed with its transition row. | `directive:3`, `cycle_fact:65`, `cycle_fact:66`, `cycle_fact:64` |
| POFF | SYM | literal per segment | Within-phase POFF transitions beyond the sequenced lattice | POFF is a corner explore pin; held per segment to sequence IDLE→POFF_RET, POFF_RET→IDLE, IDLE→POFF_SD. Each hold disclosed with its transition row. | `directive:3`, `cycle_fact:68`, `cycle_fact:69`, `cycle_fact:70` |
| CLK | SYM | literal low in powered-down dwells | Rising-clock events during DS/SD/POFF dwells | R05 forbids any rising CLK/TCLK while DS, SD, or POFF is active; the transition rows require clocks low during powered-down dwells. CLK is otherwise unconstrained (T1 read uses CLK high). | `cycle_fact:46`, `cycle_fact:61`, `cycle_fact:65`, `cycle_fact:64`, `cycle_fact:68`, `cycle_fact:70` |
| ME | SYM | literal per segment | ME transitions beyond the mission access and idle holds | ME is asserted only for the T1 mission read (SYM1) and held low elsewhere to keep the design in legal idle/powered-down states. | `cycle_fact:57`, `cycle_fact:58`, `cycle_fact:61`, `cycle_fact:65` |
| TME | SYM | literal low | TME transitions | TME held low so the functional port owns the memory (BISTE=0) and no BIST handoff occurs during the mode lattice. | `cycle_fact:24`, `cycle_fact:61`, `cycle_fact:65` |
| BISTE | SYM | literal low | BIST-mode ownership | BISTE held low so the functional port owns the memory throughout the mode sequence; BIST is another corner's work. | `cycle_fact:24`, `cycle_fact:0` |
| SE_IN | SYM | literal low | Scan-shift ownership | SE_IN held low so no scan shift interferes with the mode transitions; scan is another corner's work. | `cycle_fact:0`, `cycle_fact:72` |
| TPR | SYM | literal low | Clock-gated idle (TPR=1) scenario | TPR held low so the mission read at SYM1 is a real read, not a clock-gated idle. | `cycle_fact:6`, `cycle_fact:48` |
| BC0/BC1/BC2 | SYM | literal (BC0=0, BC1=0, BC2=0) | Source-bias encodings (BC1/BC2 bias, BC0 bypass) | Bias straps bound to the debug/no-bias encoding so the mode transitions are observed without array-bias side effects; the bias encodings are not this corner's explore surface. | `cycle_fact:32`, `cycle_fact:33`, `cycle_fact:38` |
| D, ADR | SYM | capacity-reduced (literal) | Data and address value/transition space | Capacity-reduction trigger fires (SYM=25 > ~8). Data and address are reduced first per the preferred order; the mode lattice does not depend on their values. Lost scenario class: data-dependent read/write behavior, which belongs to mission-mode-read-write. | `cycle_fact:6`, `cycle_fact:10` |
| HW | SYM | literal (HW=2'b11) | Half-word read/write scenarios | HW bound to full-word so the T1 read is a full-word read; half-word scenarios belong to mission-mode-read-write. | `cycle_fact:6` |
| WE, WEM | SYM | literal low | Write scenarios | WE/WEM held low so no write occurs during the mode lattice; writes belong to mission-mode-read-write. | `cycle_fact:6`, `cycle_fact:7` |

## Assumptions

- **A1 — minimum dwell.** Each transition's dwell is taken as the minimum one cycle. The corpus gives no numeric dwell for most transitions (only tPGGUARD=2 in `cycle_fact:63`/`cycle_fact:67`); tLSEXT, tDSENT, tSDENT, tSDFALL, tPOFFENT, tVDDSTB are named but not quantified. One cycle per dwell is the conservative minimum; a longer dwell would only add cycles, never remove a required one. (`cycle_fact:57`, `cycle_fact:59`, `cycle_fact:61`, `cycle_fact:65`, `cycle_fact:68`, `cycle_fact:70`, `cycle_fact:71`)
- **A2 — tVDDSTB.** The POFF_RET→IDLE exit (`cycle_fact:69`) names tVDDSTB + tPGGUARD; tVDDSTB is unquantified, so it is taken as one cycle plus the 2-cycle tPGGUARD.
- **A3 — bias straps.** BC0/BC1/BC2 bound to the debug/no-bias encoding (BC0=0, BC1=0, BC2=0) so the mode transitions are observed without array-bias side effects. This is a legal encoding per `cycle_fact:33`/`cycle_fact:38`.
- **A4 — no reset.** The design has no reset pin and no `reset_latency_cycles` scalar; BIN establishes legal IDLE by holding the idle combination rather than by a reset prelude.

## Limitations

- **Scoping.** This corner owns the MODE-TRANSITION SEQUENCE surface of Table 3-9 (IDLE→ACTIVE→IDLE, IDLE→LS→IDLE, IDLE→DS→WAKE_DS→IDLE, IDLE→SD→WAKE_SD, DS→SD, LS→DS, retentive/destructive POFF entry/exit). The DS/SD RETENTION-data witness (write→DS→wake→read-back, SD destruction) is owned by the certified corner `deep-sleep-shutdown-retention` and is NOT re-authored here. This plan does not write data into the array and does not read it back across a DS/SD dwell; it observes the mode-transition and ROP_DS/ROP_SD handshake surface only.
- **R01 tension (T6 DS→SD).** `cycle_fact:64` (TRANS_DS_SD) authorizes asserting SD while DS is still high as a sequenced entry, even though steady-state SD&DS is flagged illegal by R01 (`cycle_fact:44`). The plan follows the transition row's authorization for the single sequenced cycle (SYM17) and records the tension; the steady-state illegal combination is not held.
- **R02 tension (T5 LS→DS).** `cycle_fact:45` (R02) flags DS=1 and LS=1 as illegal; the sequenced LS→DS entry deasserts LS (SYM14) and waits tLSEXT (SYM15) before asserting DS (SYM16), so LS and DS are never simultaneously high. The transition row `cycle_fact:71` authorizes this sequence.
- **Capacity reduction.** D, ADR, HW, WE, WEM are concretized to reduce capacity for the long SYM phase; data-dependent read/write behavior is not explored here (belongs to mission-mode-read-write).
- **No numeric dwells.** tLSEXT, tDSENT, tSDENT, tSDFALL, tPOFFENT, tVDDSTB are unquantified in the corpus; each is taken as one cycle (Assumption A1/A2). A plan that needed exact timing margins would require those scalars.

## Coverage

- catches: a mode-transition defect in any of the eight sequenced transitions — a power pin that fails to force Q/QP/SO to 0 on DS/SD/POFF entry, a ROP_DS/ROP_SD ready handshake that does not assert on entry or deassert on wake, a tPGGUARD guard that is too short (outputs not valid after the guard), a sequenced LS→DS or DS→SD entry that violates the deassert-then-assert ordering, a retentive POFF that destroys data instead of retaining it, a destructive POFF_SD that retains instead of destroying, and a rising clock during a powered-down dwell (R05) that produces an illegal output event.
- misses: the retention-data witness (write→DS→wake→read-back, SD destruction) — owned by `deep-sleep-shutdown-retention`; data-dependent read/write behavior — owned by `mission-mode-read-write`; scan-shift and BIST ownership — owned by `scan-dft`/`bist-mode-operation`; source-bias encodings (BC1/BC2) — not this corner's explore surface. These are acceptable because each is the explicit scope of another certified corner.
