# ESP input constraints for corner: low-power-sequence
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
# Corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
# Outcome: plan
#
# Faithful transliteration of cycle-plans/low-power-sequence/plan.md.
# All relations are single-cycle per-segment holds, expressible with
# set_constraint -cycle; no relation is routed to the declaration-file path.
# Values and conditions are Verilog expressions, never Tcl.
# Only primary inputs from the survey inventory are constrained; outputs
# (Q, QP, ROP_DS, ROP_SD) are observed, never driven.

# ---- Testbench cycle counts (b/s/f) ----
set_app_var testbench_bin_cycles 1
set_app_var testbench_sym_cycles 25
set_app_var testbench_flush_cycles 1

# ---- BIN phase: establish legal IDLE (BINCYCLE1) ----
set_constraint {CLK}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}        -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}        -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}        -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}      -cycle {BINCYCLE1} -set {2'b00}
set_constraint {DFTCLKEN}  -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BISTE}     -cycle {BINCYCLE1} -set {1'b0}
set_constraint {ME}        -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TME}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SE_IN}     -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TPR}       -cycle {BINCYCLE1} -set {1'b0}

# ---- SYM phase ----
# T1 IDLE->ACTIVE (SYMCYCLE1): mission read launch, ME high, CLK high, HW=HH
set_constraint {ME}        -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {HW}        -cycle {SYMCYCLE1} -set {2'b11}
set_constraint {WE}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE1} -set {2'b00}
set_constraint {TPR}       -cycle {SYMCYCLE1} -set {1'b0}

# T1 ACTIVE->IDLE (SYMCYCLE2): deassert ME, one inactive cycle
set_constraint {ME}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE2} -set {2'b00}

# T2 IDLE->LS (SYMCYCLE3): assert LS
set_constraint {LS}        -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {DS}        -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE3} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE3} -set {1'b0}

# T2 LS->IDLE (SYMCYCLE4): deassert LS, hold ME=TME=0
set_constraint {LS}        -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE4} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE4} -set {1'b0}

# T3 IDLE->DS (SYMCYCLE5): assert DS, clocks low, ME=TME=0
set_constraint {DS}        -cycle {SYMCYCLE5} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE5} -set {2'b00}

# T3 DS->WAKE_DS (SYMCYCLE6): deassert DS, clocks low
set_constraint {DS}        -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE6} -set {2'b00}

# T3 WAKE_DS->IDLE (SYMCYCLE7-8): tPGGUARD=2, clocks low, all power off
set_constraint {CLK}       -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE7} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE8} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE8} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE8} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE8} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE8} -set {2'b00}

# T4 IDLE->SD (SYMCYCLE9): assert SD, clocks low, ME=TME=0
set_constraint {SD}        -cycle {SYMCYCLE9} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE9} -set {2'b00}

# T4 SD->WAKE_SD (SYMCYCLE10): deassert SD, enables low
set_constraint {SD}        -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE10} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE10} -set {2'b00}

# T4 WAKE_SD->IDLE (SYMCYCLE11-12): tPGGUARD=2, clocks low, all power off
set_constraint {CLK}       -cycle {SYMCYCLE11} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE11} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE11} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE11} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE11} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE12} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE12} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE12} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE12} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE12} -set {2'b00}

# T5 IDLE->LS (SYMCYCLE13): re-enter LS for sequenced LS->DS
set_constraint {LS}        -cycle {SYMCYCLE13} -set {1'b1}
set_constraint {DS}        -cycle {SYMCYCLE13} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE13} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE13} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE13} -set {1'b0}

# T5 LS->DS step 1 (SYMCYCLE14): deassert LS, tLSEXT begins
set_constraint {LS}        -cycle {SYMCYCLE14} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE14} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE14} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE14} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE14} -set {1'b0}

# T5 LS->DS step 2 (SYMCYCLE15): hold tLSEXT wait before asserting DS
set_constraint {LS}        -cycle {SYMCYCLE15} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE15} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE15} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE15} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE15} -set {1'b0}

# T5 LS->DS step 3 (SYMCYCLE16): assert DS
set_constraint {DS}        -cycle {SYMCYCLE16} -set {1'b1}
set_constraint {LS}        -cycle {SYMCYCLE16} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE16} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE16} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE16} -set {1'b0}

# T6 DS->SD (SYMCYCLE17): assert SD while DS still high (sequenced entry, R01 tension)
set_constraint {SD}        -cycle {SYMCYCLE17} -set {1'b1}
set_constraint {DS}        -cycle {SYMCYCLE17} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE17} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE17} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE17} -set {2'b00}

# T6 SD->WAKE_SD (SYMCYCLE18): deassert SD, keep enables low
set_constraint {SD}        -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE18} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE18} -set {2'b00}

# T6 WAKE_SD->IDLE (SYMCYCLE19-20): tPGGUARD=2, clocks low, all power off
set_constraint {CLK}       -cycle {SYMCYCLE19} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE19} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE19} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE19} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE19} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE20} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE20} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE20} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE20} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE20} -set {2'b00}

# T7 IDLE->POFF_RET (SYMCYCLE21): POFF 00->01, clocks low
set_constraint {POFF}      -cycle {SYMCYCLE21} -set {2'b01}
set_constraint {CLK}       -cycle {SYMCYCLE21} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE21} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE21} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE21} -set {1'b0}

# T7 POFF_RET->IDLE step 1 (SYMCYCLE22): restore VDD, remove POFF
set_constraint {POFF}      -cycle {SYMCYCLE22} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE22} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE22} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE22} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE22} -set {1'b0}

# T7 POFF_RET->IDLE step 2 (SYMCYCLE23-24): tPGGUARD=2, clocks low, all power off
set_constraint {CLK}       -cycle {SYMCYCLE23} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE23} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE23} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE23} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE23} -set {2'b00}
set_constraint {CLK}       -cycle {SYMCYCLE24} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE24} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE24} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE24} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE24} -set {2'b00}

# T8 IDLE->POFF_SD (SYMCYCLE25): POFF 00->11 destructive, final state
set_constraint {POFF}      -cycle {SYMCYCLE25} -set {2'b11}
set_constraint {CLK}       -cycle {SYMCYCLE25} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE25} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE25} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE25} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE25} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE25} -set {1'b0}

# ---- Capacity reduction and bias straps (disclosed in plan Symbolic treatment) ----
# SYM=25 > ~8 triggers the capacity-reduction rule. Data (D) and address (ADR)
# are reduced first per the preferred order; the mode lattice does not depend
# on their values. Bias straps BC0/BC1/BC2 bound to the debug/no-bias encoding.
# WEM held low so no masked write occurs. Each is a phase-wide hold justified
# by capacity reduction / legal-idle bias, disclosed in the plan.
set_constraint {D}         -cycle {SYMCYCLE1-25} -set {1'b0}
set_constraint {ADR}       -cycle {SYMCYCLE1-25} -set {1'b0}
set_constraint {BC0}       -cycle {SYMCYCLE1-25} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE1-25} -set {1'b0}
set_constraint {BC2}       -cycle {SYMCYCLE1-25} -set {1'b0}
set_constraint {WEM}       -cycle {SYMCYCLE1-25} -set {1'b0}

# ---- FLUSH phase: final comparison (FLUSHCYCLE1), hold POFF_SD destructive state ----
set_constraint {POFF}      -cycle {FLUSHCYCLE1} -set {2'b11}
set_constraint {CLK}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}        -cycle {FLUSHCYCLE1} -set {1'b0}
