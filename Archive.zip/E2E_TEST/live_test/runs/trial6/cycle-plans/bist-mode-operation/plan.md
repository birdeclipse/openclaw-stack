# Cycle Plan — bist-mode-operation

- corner: bist-mode-operation
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan
- directive: directive:2 ("Verify BIST-mode operation")

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 4 | BIST mode entry. BINCYCLE1 establishes the idle/NORMAL state (power pins off, SE_IN=0, ME=TME=0, both clocks low). BINCYCLE2 establishes TCLKE=1 while both clocks are low (R11). BINCYCLE3 asserts BISTE=1 while ME=TME=0 and the selected clock is low (R12). BINCYCLE4 waits one inactive selected-clock cycle after BISTE assertion, as the entry sequence requires. b=4 because the entry is four distinct legal transitions; b-1=3 would skip the required inactive-clock wait. |
| SYM | 2 | BIST write (SYMCYCLE1) then BIST read (SYMCYCLE2) of the same TADR. s=2 because the witness needs one write cycle and one read cycle; s-1=1 would omit the write and leave nothing to read back. |
| FLUSH | 1 | QP pipeline propagation. FLUSHCYCLE1 samples q_int into qp_int with TPIPEME=1 (pipeline_depth=1). f=1 because the read value needs one pipeline cycle to reach QP; f-1=0 would leave QP holding its prior value and the pipelined read unobserved. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | idle state | establish NORMAL power mode, SE_IN=0, ME=TME=0, both clocks low, so the memory is idle and the BIST entry preconditions hold | `LS=1'b0, DS=1'b0, SD=1'b0, POFF=2'b00, SE_IN=1'b0, ME=1'b0, TME=1'b0, TPR=1'b0, DFTMASK=1'b0, DFTCLKEN=1'b0, CLK=1'b0, TCLK=1'b0` | cycle_fact:12, cycle_fact:73 |
| BINCYCLE2 | clock select | establish TCLKE=1 (select TCLK as the BIST clock) while both CLK and TCLK are low | `TCLKE=1'b1, CLK=1'b0, TCLK=1'b0` | cycle_fact:73, cycle_fact:50 |
| BINCYCLE3 | BIST assert | assert BISTE=1 while ME=TME=0 and the selected clock is low | `BISTE=1'b1, ME=1'b0, TME=1'b0, CLK=1'b0, TCLK=1'b0` | cycle_fact:73, cycle_fact:51 |
| BINCYCLE4 | entry settle | wait one inactive selected-clock cycle after BISTE assertion | `CLK=1'b0, TCLK=1'b0` | cycle_fact:73 |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | BIST write | write TD to TADR on a TCLK edge; the BIST port owns the memory (BISTE=1) | `TME=1'b1, TWE=1'b1, TWEM=1'b1, THW=2'b11, TADR=<sym_static>, TD=<sym_static>` | cycle_fact:25, cycle_fact:10 |
| SYMCYCLE2 | BIST read | read TADR onto Q on a TCLK edge; same TADR as the write so the written value is read back | `TME=1'b1, TWE=1'b0, THW=2'b11, TADR=<sym_static>` | cycle_fact:25, cycle_fact:6 |

Mode-defining holds carried into every SYM cycle (justified per-cycle because every SYM cycle is a BIST operation that requires them): `BISTE=1'b1, TCLKE=1'b1, SE_IN=1'b0, LS=1'b0, DS=1'b0, SD=1'b0, POFF=2'b00, TPR=1'b0, DFTMASK=1'b0, DFTCLKEN=1'b0`. `TADR` is `symbolic_static` across SYMCYCLE1-2 (one symbol, same address for write and read); `TD` is `symbolic_static` in SYMCYCLE1 (one symbol, well-defined write data).

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | QP pipeline | sample q_int into qp_int with TPIPEME=1 so QP shows the BIST read value; TME=0 so no new operation overwrites Q | `TPIPEME=1'b1, TME=1'b0` | fact:ddf-c9f8fbf1, cycle_fact:55 |

Mode-defining holds carried into FLUSHCYCLE1: `BISTE=1'b1, TCLKE=1'b1, SE_IN=1'b0, LS=1'b0, DS=1'b0, SD=1'b0, POFF=2'b00, TPR=1'b0, DFTMASK=1'b0, DFTCLKEN=1'b0`.

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| BIST write (TADR=A, TD=D) | SYMCYCLE1 | end of FLUSHCYCLE1 | array[A] = D | The write's effect is on the internal array, not directly compared; it is observed through the read in SYMCYCLE2, which reaches Q at end of SYMCYCLE2 and QP at end of FLUSHCYCLE1. A1: s-j+f = 2-1+1 = 2 >= pipeline_depth=1. |
| BIST read (TADR=A) | SYMCYCLE2 | end of FLUSHCYCLE1 | Q = array[A] = D | Q holds the read value from end of SYMCYCLE2; TME=0 in FLUSHCYCLE1 prevents any new read/write from overwriting Q. A1: s-j+f = 2-2+1 = 1 >= pipeline_depth=1. |
| QP pipeline | FLUSHCYCLE1 | end of FLUSHCYCLE1 | QP = q_int = D | TPIPEME=1 samples q_int (the read value) into qp_int at the FLUSHCYCLE1 edge; no later cycle re-drives QP before comparison. |

A3 does not apply: BIST-mode operation in the wrapper is port access (TME/TWE/TADR/TD/TWEM/TCLK), not scan shift. `scan_chain_length=1` (fact:ddf-43efd23b) governs the scan chains (Q_L/Q_H/D_L/D_H/CNTR), which this corner never shifts.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | all | literal 1 | BISTE=0 and BISTE-toggling paths | corner's defining condition: with BISTE=1 the BIST port owns the memory | cycle_fact:25 |
| TCLKE | all | literal 1 | TCLKE toggling, CLK-selected BIST | BIST port's designated clock is TCLK; entry requires establishing TCLKE | cycle_fact:73, cycle_fact:25 |
| SE_IN | all | literal 0 | scan-shift paths | BIST entry requires SE_IN=0; keeps memory in functional (non-scan) mode | cycle_fact:73, cycle_fact:52 |
| LS, DS, SD | all | literal 0 | power-down modes | NORMAL power mode required for legal operations | cycle_fact:12 |
| POFF | all | literal 00 | POFF modes | NORMAL power mode | cycle_fact:12 |
| TPR | all | literal 0 | TPR=1 mission-disable paths | functional gate; BIST rows on the T-port are selected by BISTE, TPR only gates the mission path | cycle_fact:2 |
| DFTMASK, DFTCLKEN | all | literal 0 | DFT write-through paths | not exercising write-through; avoids illegal DFTMASK=1/DFTCLKEN=0 state | cycle_fact:53 |
| ME | BIN | literal 0 | functional operations during entry | R12 requires ME=0 when BISTE changes | cycle_fact:51 |
| TME | SYM1-2 | literal 1 | TME=0 no-op paths in the operation window | memory enable for BIST operations | cycle_fact:25 |
| TME | FLUSH1 | literal 0 | a second operation in the flush cycle | preserves the Q read value for comparison | cycle_fact:6 |
| TWE | SYM1 | literal 1 | TWE=0 in the write cycle | write enable | cycle_fact:10 |
| TWE | SYM2 | literal 0 | TWE=1 in the read cycle | read enable | cycle_fact:6 |
| TWEM | SYM1 | literal 1 | masked-write paths | write mask enables the write | cycle_fact:10 |
| THW | SYM1-2 | literal 11 | half-word paths | full-word write and read | cycle_fact:10, cycle_fact:6 |
| TADR | SYM1-2 | symbolic_static | TADR transition between write and read | write-then-read of the same address is the witness | cycle_fact:10, cycle_fact:6 |
| TD | SYM1 | symbolic_static | TD transition during the write | well-defined write data | cycle_fact:10 || TPIPEME | FLUSH1 | literal 1 | TPIPEME=0 paths (QP holds prior) | QP observability requires sampling q_int | fact:ddf-c9f8fbf1, cycle_fact:55 |
| CLK, TCLK | BIN | literal 0 | clock toggling during entry | legal entry requires both clocks low | cycle_fact:73, cycle_fact:50, cycle_fact:51 |

Pins left unconstrained (strongest coverage, no row needed): CAPT, STICKY, CD (capture/compare path — no observable effect in the wrapper, which routes them to `_unused`); ADR, D, WEM, WE, HW, PIPEME, ME (in SYM/FLUSH) and the other functional-port pins (not selected while BISTE=1); CLK, TCLK in SYM/FLUSH.

Lowering note: `-symbolic_static` holds a pin at one symbol for the entire simulation (no `-cycle`/`-if`). For TADR and TD this is equivalent to the phase-scoped intent above, because both pins are don't-cares outside their relevant cycles (TADR is only sampled during the BIST write/read in SYMCYCLE1-2; TD is only sampled during the write in SYMCYCLE1).

## Assumptions

- The wrapper's behavioral model routes CD/CAPT/STICKY into `_unused`; the comparison register is not modelled, so the capture/compare path has no observable effect on Q/QP. CAPT/STICKY/CD are therefore left unconstrained (symbolic) — constraining them would reduce coverage with no observability gain.
- TCLKE=1 is held across the plan to select TCLK as the BIST clock. The BIST port's designated clock is TCLK (cycle_fact:25), and the entry sequence requires establishing TCLKE (cycle_fact:73). The CLK-selected BIST configuration (TCLKE=0 with BISTE=1) is not this corner's focus.
- TPR=0 is held conservatively. In BIST mode the memory enable is TME (sel_me = BISTE ? TME : ME), so TPR gates only the mission path and is a don't-care; holding it at 0 prevents any mission-path interaction.
- The write in SYMCYCLE1 completes at the TCLK edge; the read in SYMCYCLE2 reads the updated array (synchronous SRAM behavior, one cycle between write and read).
- CLK/TCLK are constrained low only during the BIN entry (legal-entry requirement); they are unconstrained in SYM/FLUSH, where the BIST operations explore clock behavior freely.

## Limitations

- The capture/compare path (CD/CAPT/STICKY) is not modelled in the wrapper (routed to `_unused`), so its operation cannot be observed on Q/QP. This corner's observable witness is the BIST write/read on Q/QP; the capture/compare register behavior is outside what this design can demonstrate.
- A3 (scan arithmetic) does not apply: BIST-mode operation is port access, not scan shift. `scan_chain_length=1` (fact:ddf-43efd23b) governs the scan chains, which this corner never shifts.
- The corner exercises a single write-then-read of one address; TADR and TD are held symbolic_static, so address/data transition spaces between operations are not explored.
- Half-word (THW=LH/HL) and masked-write (TWEM=0) BIST paths are not explored (THW=HH, TWEM=1).
- Power-down modes during BIST and scan-shift behavior are not explored (SE_IN=0, NORMAL power held).

## Coverage

- catches: BIST ownership-mux errors (wrong pin selected when BISTE=1 — e.g. ME instead of TME, ADR instead of TADR, D instead of TD, WEM instead of TWEM); BIST write/read data-path errors (TD not written to TADR, or not read back onto Q); QP pipeline-enable errors (TPIPEME not sampling q_int); BIST clock-selection errors (TCLKE not selecting TCLK); illegal-entry violations (BISTE/TCLKE asserted with clocks high or ME/TME=1).
- misses: capture/compare register behavior (not modelled in the wrapper); scan-shift behavior (a different corner); power-down modes during BIST; half-word and masked-write BIST operations. These are acceptable because the wrapper does not model the comparison register, scan shift is owned by the scan corners, and the corner's witness is a full-word BIST write-then-read.
