# ---------------------------------------------------------------------------
# bist-mode-operation — constraints
#
# Corner: BIST-mode operation. With BISTE=1 the BIST port (TME/TWE/TADR/TD/
# TWEM/TCLK) owns the memory, exercising a BIST write then a BIST read of the
# same TADR, observable on Q/QP at default comparison.
#
# Cycle counts (derived in plan.md):
#   BIN=4  BIST mode entry (idle state, TCLKE, BISTE, inactive-clock wait)
#   SYM=2  BIST write (SYMCYCLE1), BIST read (SYMCYCLE2)
#   FLUSH=1  QP pipeline propagation (TPIPEME=1)
# ---------------------------------------------------------------------------
set_app_var testbench_binary_cycles 4
set_app_var testbench_symbolic_cycles 2
set_app_var testbench_flush_cycles 1

# --- Mode-defining holds (all phases) --------------------------------------
# SE_IN=0: BIST entry requires it; keeps memory in functional (non-scan) mode.
#   cycle_fact:73, cycle_fact:52
set_constraint {SE_IN} -set {1'b0}
# NORMAL power mode: LS=DS=SD=0, POFF=00.  cycle_fact:12
set_constraint {LS} -set {1'b0}
set_constraint {DS} -set {1'b0}
set_constraint {SD} -set {1'b0}
set_constraint {POFF} -set {2'b00}
# TPR=0: functional gate; BIST rows on the T-port are selected by BISTE.
#   cycle_fact:2
set_constraint {TPR} -set {1'b0}
# DFTMASK/DFTCLKEN=0: not exercising write-through; avoids illegal
#   DFTMASK=1/DFTCLKEN=0 state.  cycle_fact:53
set_constraint {DFTMASK} -set {1'b0}
set_constraint {DFTCLKEN} -set {1'b0}

# --- BIST clock select: TCLKE=1 from BINCYCLE2 onward ----------------------
# Establish TCLKE while both clocks low (R11); BIST port clocked by TCLK.
#   cycle_fact:73, cycle_fact:50, cycle_fact:25
set_constraint {TCLKE} -set {1'b1} -cycle BINCYCLE2
set_constraint {TCLKE} -set {1'b1} -cycle BINCYCLE3
set_constraint {TCLKE} -set {1'b1} -cycle BINCYCLE4
set_constraint {TCLKE} -set {1'b1} -cycle SYMCYCLE1
set_constraint {TCLKE} -set {1'b1} -cycle SYMCYCLE2
set_constraint {TCLKE} -set {1'b1} -cycle FLUSHCYCLE1

# --- BIST ownership: BISTE=1 from BINCYCLE3 onward -------------------------
# Assert BISTE while ME=TME=0 and selected clock low (R12).  cycle_fact:73,
#   cycle_fact:51, cycle_fact:25
set_constraint {BISTE} -set {1'b1} -cycle BINCYCLE3
set_constraint {BISTE} -set {1'b1} -cycle BINCYCLE4
set_constraint {BISTE} -set {1'b1} -cycle SYMCYCLE1
set_constraint {BISTE} -set {1'b1} -cycle SYMCYCLE2
set_constraint {BISTE} -set {1'b1} -cycle FLUSHCYCLE1

# --- BIN entry: both clocks low, ME=0, TME=0 -------------------------------
# Legal entry requires both clocks low; ME=TME=0 keeps the memory idle and
# satisfies R12's precondition for the BISTE change.  cycle_fact:73,
#   cycle_fact:51
set_constraint {CLK} -set {1'b0} -if {inno_cycle_mode == "BINCYCLE"}
set_constraint {TCLK} -set {1'b0} -if {inno_cycle_mode == "BINCYCLE"}
set_constraint {ME} -set {1'b0} -if {inno_cycle_mode == "BINCYCLE"}
set_constraint {TME} -set {1'b0} -if {inno_cycle_mode == "BINCYCLE"}

# --- SYM: BIST write then BIST read ----------------------------------------
# TME=1: memory enable for BIST operations.  cycle_fact:25
set_constraint {TME} -set {1'b1} -if {inno_cycle_mode == "SYMCYCLE"}
# SYMCYCLE1: BIST write (TWE=1, TWEM=1, THW=HH).  cycle_fact:10
set_constraint {TWE} -set {1'b1} -cycle SYMCYCLE1
set_constraint {TWEM} -set {1'b1} -cycle SYMCYCLE1
set_constraint {THW} -set {2'b11} -cycle SYMCYCLE1
# SYMCYCLE2: BIST read (TWE=0, THW=HH).  cycle_fact:6
set_constraint {TWE} -set {1'b0} -cycle SYMCYCLE2
set_constraint {THW} -set {2'b11} -cycle SYMCYCLE2

# --- FLUSH: QP pipeline, no new operation ----------------------------------
# TME=0: no new operation overwrites Q.  cycle_fact:6
set_constraint {TME} -set {1'b0} -if {inno_cycle_mode == "FLUSHCYCLE"}
# TPIPEME=1: sample q_int into qp_int so QP shows the BIST read value.
#   fact:ddf-c9f8fbf1, cycle_fact:55
set_constraint {TPIPEME} -set {1'b1} -cycle FLUSHCYCLE1

# --- symbolic_static: same address for write/read, well-defined write data --
# TADR: one symbol across the simulation, so the write and read hit the same
#   address.  cycle_fact:10, cycle_fact:6
set_constraint {TADR} -symbolic_static
# TD: one symbol, the well-defined write data.  cycle_fact:10
set_constraint {TD} -symbolic_static
