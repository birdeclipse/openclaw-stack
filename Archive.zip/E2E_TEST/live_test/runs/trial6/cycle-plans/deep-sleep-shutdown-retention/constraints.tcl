# ESP input constraints — corner: deep-sleep-shutdown-retention
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
# Corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
# Outcome: plan
#
# Faithful transliteration of cycle-plans/deep-sleep-shutdown-retention/plan.md.
# Values and conditions are Verilog expressions; only design input pins are
# constrained. Outputs (Q, QP, ROP_DS, ROP_SD, SO_*) are observed, never driven.
#
# Cycle counts (b/s/f) from the plan's Cycle counts table:
#   BIN=2  legal-idle prelude
#   SYM=9  write -> DS entry/hold/wake -> guard -> read-back
#   FLUSH=8 read-back propagation + destructive SD path

set_app_var testbench_bin_cycles   2
set_app_var testbench_sym_cycles   9
set_app_var testbench_flush_cycles 8

# ---------------------------------------------------------------------------
# BIN phase — legal-idle prelude (plan Binary phase, BINCYCLE1-2)
# ---------------------------------------------------------------------------
# Legal NORMAL/IDLE: all power pins deasserted, functional port idle, clocks
# low, no scan, no BIST. (cycle_fact:12, cycle_fact:0, cycle_fact:24,
# cycle_fact:72)
set_constraint {LS}        -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {DS}        -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {SD}        -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {POFF}      -cycle {BINCYCLE1-2} -set {2'b00}
set_constraint {ME}        -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {TME}       -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {BISTE}     -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {SE_IN}     -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {DFTCLKEN}  -cycle {BINCYCLE1-2} -set {1'b0}
set_constraint {CLK}       -cycle {BINCYCLE1-2} -set {1'b0}

# ---------------------------------------------------------------------------
# SYM phase — the retention witness (plan Symbolic phase)
# ---------------------------------------------------------------------------

# SYMCYCLE1 — write launch: full-word write of symbolic D to symbolic ADR.
# NORMAL mode, functional port owns memory. (cycle_fact:10, cycle_fact:24,
# cycle_fact:12)
set_constraint {ME}        -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {WE}        -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {WEM}       -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {HW}        -cycle {SYMCYCLE1} -set {2'b11}
set_constraint {TPR}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {LS}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE1} -set {2'b00}
set_constraint {TME}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {BISTE}     -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SE_IN}     -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN}  -cycle {SYMCYCLE1} -set {1'b0}
# D left unconstrained (symbolic data space). ADR symbolic_static so the
# read-back reads the same address the write used (plan Symbolic treatment).

# SYMCYCLE2 — idle settle: deassert write enables, one inactive clock cycle
# before the power change. (cycle_fact:58)
set_constraint {ME}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {WE}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE2} -set {2'b00}

# SYMCYCLE3 — DS entry: assert DS, clocks low, ME=TME=0, LS=SD=0, DS array
# bias via BC1. (cycle_fact:61, cycle_fact:14, cycle_fact:39, cycle_fact:46)
set_constraint {DS}        -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {ME}        -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {TME}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE3} -set {2'b00}
set_constraint {BC0}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {BC2}       -cycle {SYMCYCLE3} -set {1'b0}

# SYMCYCLE4 — DS hold: DS held, clocks low. (cycle_fact:14, cycle_fact:46)
set_constraint {DS}        -cycle {SYMCYCLE4} -set {1'b1}
set_constraint {CLK}       -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {BC0}       -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE4} -set {1'b1}
set_constraint {BC2}       -cycle {SYMCYCLE4} -set {1'b0}

# SYMCYCLE5 — wake: deassert DS into WAKE_DS, clocks low, LS=SD=0.
# (cycle_fact:62, cycle_fact:46)
set_constraint {DS}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {LS}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {BC0}       -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE5} -set {1'b1}
set_constraint {BC2}       -cycle {SYMCYCLE5} -set {1'b0}

# SYMCYCLE6 — wait ROP_DS=0 (tROPDS), clocks low. (cycle_fact:63)
set_constraint {CLK}       -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {BC0}       -cycle {SYMCYCLE6} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE6} -set {1'b1}
set_constraint {BC2}       -cycle {SYMCYCLE6} -set {1'b0}

# SYMCYCLE7-8 — tPGGUARD = 2 CLK cycles after ROP_DS=0, clocks held low
# (conservative, R05). (cycle_fact:63, cycle_fact:46)
set_constraint {CLK}       -cycle {SYMCYCLE7-8} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE7-8} -set {1'b0}
set_constraint {BC0}       -cycle {SYMCYCLE7-8} -set {1'b0}
set_constraint {BC1}       -cycle {SYMCYCLE7-8} -set {1'b1}
set_constraint {BC2}       -cycle {SYMCYCLE7-8} -set {1'b0}

# SYMCYCLE9 — read-back launch: full-word read of the same symbolic ADR.
# NORMAL mode, WE=0. (cycle_fact:6, cycle_fact:24, cycle_fact:12)
set_constraint {ME}        -cycle {SYMCYCLE9} -set {1'b1}
set_constraint {WE}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {HW}        -cycle {SYMCYCLE9} -set {2'b11}
set_constraint {TPR}       -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {CLK}       -cycle {SYMCYCLE9} -set {1'b1}
set_constraint {LS}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {DS}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {SD}        -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {POFF}      -cycle {SYMCYCLE9} -set {2'b00}
set_constraint {TME}       -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {BISTE}     -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {SE_IN}     -cycle {SYMCYCLE9} -set {1'b0}
set_constraint {DFTCLKEN}  -cycle {SYMCYCLE9} -set {1'b0}

# ADR symbolic_static across the SYM phase: one symbol reused for the write
# (SYMCYCLE1) and the read-back (SYMCYCLE9), guaranteeing write-address ==
# read-address while exploring the address space. (plan Symbolic treatment;
# cycle_fact:14, cycle_fact:61)
set_constraint {ADR} -symbolic_static

# ---------------------------------------------------------------------------
# FLUSH phase — read-back propagation + destructive SD path (plan Flush phase)
# ---------------------------------------------------------------------------

# FLUSHCYCLE1 — read-back propagation: rising edge propagates the pipelined
# read Q (pipeline_depth=1) to default comparison. (fact:ddf-c9f8fbf1,
# cycle_fact:6, cycle_fact:0)
set_constraint {CLK}       -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {ME}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {WE}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}        -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF}      -cycle {FLUSHCYCLE1} -set {2'b00}

# FLUSHCYCLE2 — idle settle after the read, before the power change.
# (cycle_fact:58)
set_constraint {CLK}       -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {ME}        -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {WE}        -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {LS}        -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {DS}        -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {SD}        -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {POFF}      -cycle {FLUSHCYCLE2} -set {2'b00}

# FLUSHCYCLE3 — SD entry: assert SD, clocks low, ME=TME=0, LS=DS=0.
# Destructive. (cycle_fact:65, cycle_fact:18, cycle_fact:46)
set_constraint {SD}        -cycle {FLUSHCYCLE3} -set {1'b1}
set_constraint {CLK}       -cycle {FLUSHCYCLE3} -set {1'b0}
set_constraint {ME}        -cycle {FLUSHCYCLE3} -set {1'b0}
set_constraint {TME}       -cycle {FLUSHCYCLE3} -set {1'b0}
set_constraint {LS}        -cycle {FLUSHCYCLE3} -set {1'b0}
set_constraint {DS}        -cycle {FLUSHCYCLE3} -set {1'b0}
set_constraint {POFF}      -cycle {FLUSHCYCLE3} -set {2'b00}

# FLUSHCYCLE4 — SD hold: SD held, clocks low. (cycle_fact:18, cycle_fact:46)
set_constraint {SD}        -cycle {FLUSHCYCLE4} -set {1'b1}
set_constraint {CLK}       -cycle {FLUSHCYCLE4} -set {1'b0}

# FLUSHCYCLE5 — wake SD: deassert SD into WAKE_SD, clocks low, enables low.
# (cycle_fact:66, cycle_fact:46)
set_constraint {SD}        -cycle {FLUSHCYCLE5} -set {1'b0}
set_constraint {CLK}       -cycle {FLUSHCYCLE5} -set {1'b0}
set_constraint {LS}        -cycle {FLUSHCYCLE5} -set {1'b0}
set_constraint {DS}        -cycle {FLUSHCYCLE5} -set {1'b0}

# FLUSHCYCLE6 — wait ROP_SD=0 (tROPSD), clocks low. (cycle_fact:67)
set_constraint {CLK}       -cycle {FLUSHCYCLE6} -set {1'b0}
set_constraint {SD}        -cycle {FLUSHCYCLE6} -set {1'b0}

# FLUSHCYCLE7-8 — tPGGUARD = 2 CLK cycles after ROP_SD=0, clocks held low
# (conservative, R05). (cycle_fact:67, cycle_fact:46)
set_constraint {CLK}       -cycle {FLUSHCYCLE7-8} -set {1'b0}
set_constraint {SD}        -cycle {FLUSHCYCLE7-8} -set {1'b0}
