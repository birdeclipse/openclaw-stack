# Cycle Plan — deep-sleep-shutdown-retention

- corner: deep-sleep-shutdown-retention
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 2 | Establish legal IDLE and settle. No reset pin and no `reset_latency_cycles` scalar exist, so A5's `b >= reset_latency_cycles` is vacuous; the prelude instead grounds the mode-entry sequencing A5 requires before the corner's first operation is legal: BINCYCLE1 drives all power pins to legal idle (LS=DS=SD=0, POFF=00) with enables low and clocks low (`cycle_fact:12`, `cycle_fact:0`), BINCYCLE2 holds that idle one more cycle so the mode is stable before the write. b=2, not 1, because the write must launch from a settled legal NORMAL mode. |
| SYM | 9 | The retention witness: write launch (SYMCYCLE1), idle settle (2), DS entry (3), DS hold (4), wake (5), wait ROP_DS=0 (6), tPGGUARD guard 1-2 (7-8), read-back launch (9). Each cycle is one logical transition of the DS retention sequence (`cycle_fact:61,62,63,14,6`). s=9 because the sequence needs all nine steps; the read-back is the last symbolic launch so its pipelined Q reaches comparison in FLUSH. |
| FLUSH | 8 | Read-back propagation plus the destructive SD path. FLUSHCYCLE1 is the rising edge that propagates the pipelined read Q (pipeline_depth=1, `fact:ddf-c9f8fbf1`) to default comparison; FLUSHCYCLE2 is the idle settle after the read (`cycle_fact:58`); FLUSHCYCLE3-8 run the SD path: SD entry (3), SD hold (4), wake SD (5), wait ROP_SD=0 (6), tPGGUARD guard 1-2 (7-8) (`cycle_fact:65,18,66,67`). f=8 because the read-back comparison must precede the SD forced-0 and the SD path needs its own 6-cycle sequence. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1-2 | legal-idle prelude | Establish legal NORMAL/IDLE mode and hold it one cycle so the write launches from a settled mode. All power pins deasserted, functional port idle, clocks low, no scan, no BIST. | `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `ME=1'b0`, `TME=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`, `CLK=1'b0` | `cycle_fact:12`, `cycle_fact:0`, `cycle_fact:24`, `cycle_fact:72`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF`, `pin:ME`, `pin:TME`, `pin:BISTE`, `pin:SE_IN`, `pin:DFTCLKEN`, `pin:CLK` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | write launch | Full-word write of symbolic data D to the symbolic address ADR. NORMAL mode, functional port owns memory. | `ME=1'b1`, `WE=1'b1`, `WEM=1'b1`, `HW=2'b11`, `TPR=1'b0`, `CLK=1'b1`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TME=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`; `D` unconstrained (symbolic), `ADR` symbolic_static | `cycle_fact:10`, `cycle_fact:24`, `cycle_fact:12`, `pin:ME`, `pin:WE`, `pin:WEM`, `pin:HW`, `pin:TPR`, `pin:CLK`, `pin:D`, `pin:ADR` |
| SYMCYCLE2 | idle settle | Deassert write enables; one full inactive clock cycle before the power change (TRANS_ACTIVE_IDLE). | `ME=1'b0`, `WE=1'b0`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:58`, `pin:ME`, `pin:WE`, `pin:CLK` |
| SYMCYCLE3 | DS entry | Assert DS with clocks low, ME=TME=0, LS=SD=0. Q/QP/SO forced 0, ROP_DS=1; data retained if VDDA in retention range. Apply DS array bias via BC1. | `DS=1'b1`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BC0=1'b0`, `BC1=1'b1`, `BC2=1'b0` | `cycle_fact:61`, `cycle_fact:14`, `cycle_fact:39`, `cycle_fact:46`, `pin:DS`, `pin:CLK`, `pin:BC0`, `pin:BC1`, `pin:BC2` |
| SYMCYCLE4 | DS hold | Dwell in DS with DS held and clocks low; outputs stay forced 0, ROP_DS=1. | `DS=1'b1`, `CLK=1'b0`, `BC0=1'b0`, `BC1=1'b1`, `BC2=1'b0` | `cycle_fact:14`, `cycle_fact:46`, `pin:DS`, `pin:CLK` |
| SYMCYCLE5 | wake | Deassert DS into WAKE_DS with clocks low, LS=SD=0. Q=0, QP/SO=X, ROP_DS=1; data retained. | `DS=1'b0`, `CLK=1'b0`, `LS=1'b0`, `SD=1'b0`, `BC0=1'b0`, `BC1=1'b1`, `BC2=1'b0` | `cycle_fact:62`, `cycle_fact:46`, `pin:DS`, `pin:CLK` |
| SYMCYCLE6 | wait ROP_DS=0 | Wait for ROP_DS to deassert (tROPDS); clocks low. | `CLK=1'b0`, `DS=1'b0`, `BC0=1'b0`, `BC1=1'b1`, `BC2=1'b0` | `cycle_fact:63`, `pin:CLK` |
| SYMCYCLE7-8 | guard | tPGGUARD = 2 CLK cycles after ROP_DS=0 before outputs become valid; clocks held low (conservative, R05). | `CLK=1'b0`, `DS=1'b0`, `BC0=1'b0`, `BC1=1'b1`, `BC2=1'b0` | `cycle_fact:63`, `cycle_fact:46`, `pin:CLK` |
| SYMCYCLE9 | read-back launch | Full-word read of the same symbolic address ADR. NORMAL mode, WE=0. Q reads the retained data. | `ME=1'b1`, `WE=1'b0`, `HW=2'b11`, `TPR=1'b0`, `CLK=1'b1`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TME=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`; `ADR` symbolic_static (same symbol as write) | `cycle_fact:6`, `cycle_fact:24`, `cycle_fact:12`, `pin:ME`, `pin:WE`, `pin:HW`, `pin:TPR`, `pin:CLK`, `pin:ADR` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | read-back propagation | Rising edge propagates the pipelined read Q (pipeline_depth=1) to default comparison; Q shows the retained data D. This is the comparison cycle for the write+retention+read-back witness. | `CLK=1'b1`, `ME=1'b0`, `WE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `fact:ddf-c9f8fbf1`, `cycle_fact:6`, `cycle_fact:0`, `pin:CLK` |
| FLUSHCYCLE2 | idle settle | One full inactive clock cycle after the read before the power change (TRANS_ACTIVE_IDLE). | `CLK=1'b0`, `ME=1'b0`, `WE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:58`, `pin:CLK` |
| FLUSHCYCLE3 | SD entry | Assert SD with clocks low, ME=TME=0, LS=DS=0. Destructive: Q/QP/SO forced 0, ROP_SD=1. | `SD=1'b1`, `CLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00` | `cycle_fact:65`, `cycle_fact:18`, `cycle_fact:46`, `pin:SD`, `pin:CLK` |
| FLUSHCYCLE4 | SD hold | Dwell in SD with SD held and clocks low; outputs stay forced 0, ROP_SD=1. | `SD=1'b1`, `CLK=1'b0` | `cycle_fact:18`, `cycle_fact:46`, `pin:SD`, `pin:CLK` |
| FLUSHCYCLE5 | wake SD | Deassert SD into WAKE_SD with clocks low, enables low. Q=0, QP/SO=X, ROP_SD=1; data unknown (destructive). | `SD=1'b0`, `CLK=1'b0`, `LS=1'b0`, `DS=1'b0` | `cycle_fact:66`, `cycle_fact:46`, `pin:SD`, `pin:CLK` |
| FLUSHCYCLE6 | wait ROP_SD=0 | Wait for ROP_SD to deassert (tROPSD); clocks low. | `CLK=1'b0`, `SD=1'b0` | `cycle_fact:67`, `pin:CLK` |
| FLUSHCYCLE7-8 | guard | tPGGUARD = 2 CLK cycles after ROP_SD=0; clocks held low (conservative, R05). | `CLK=1'b0`, `SD=1'b0` | `cycle_fact:67`, `cycle_fact:46`, `pin:CLK` |

## Observability

Comparison model: ESP's default reference-versus-implementation comparison applies per-cycle on the outputs Q, ROP_DS, ROP_SD (and QP/SO where the mode table states a value). Outputs are observed, never driven. The pipelined read Q follows the read launch by `pipeline_depth=1` (`fact:ddf-c9f8fbf1`), so a read launched in SYMCYCLE9 is compared at FLUSHCYCLE1.

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Write (mission) | SYMCYCLE1 | FLUSHCYCLE1 | Array[ADR]=D (symbolic data written to symbolic address) | The array is never cleared by DS (retention, `cycle_fact:61` "retained if VDDA remains in retention range"); the read-back at SYMCYCLE9 reads the same symbolic address ADR (`symbolic_static`) and its pipelined Q at FLUSHCYCLE1 shows D. Nothing overwrites the array between write and read-back. |
| DS entry | SYMCYCLE3 | SYMCYCLE3 | Q/QP/SO forced 0, ROP_DS=1 | DS asserted with clocks low; the mode table forces the outputs (`cycle_fact:14`). No later cycle re-drives Q before this per-cycle comparison. |
| DS retention | SYMCYCLE3-4 | FLUSHCYCLE1 | Data retained through the DS dwell | The array is never cleared by DS; the read-back at FLUSHCYCLE1 reads the retained D at the same address. |
| Wake (DS→WAKE_DS) | SYMCYCLE5 | SYMCYCLE5 | Q=0, QP/SO=X, ROP_DS=1 | DS deasserted with clocks low; wake mode table (`cycle_fact:62`). |
| ROP_DS deassert | SYMCYCLE6 | SYMCYCLE6 | ROP_DS=0 (tROPDS) | ROP_DS deasserts after the wake; observed per-cycle (`cycle_fact:63`). |
| Read-back | SYMCYCLE9 | FLUSHCYCLE1 | Q = retained D (full-word read of ADR) | Pipelined Q appears at FLUSHCYCLE1 (`fact:ddf-c9f8fbf1`); the read-back reads the same symbolic address ADR as the write, so Q shows the retained D. FLUSHCYCLE1 precedes the SD forced-0 at FLUSHCYCLE3, so the read value is compared before SD destroys it. |
| SD entry | FLUSHCYCLE3 | FLUSHCYCLE3 | Q/QP/SO forced 0, ROP_SD=1; data destroyed | SD asserted with clocks low; destructive mode table (`cycle_fact:18`). Data survival is NOT claimed here — SD destroys data (`cycle_fact:65-67`). |
| Wake SD (SD→WAKE_SD) | FLUSHCYCLE5 | FLUSHCYCLE5 | Q=0, QP/SO=X, ROP_SD=1 | SD deasserted with clocks low; wake mode table (`cycle_fact:66`). |
| ROP_SD deassert | FLUSHCYCLE6 | FLUSHCYCLE6 | ROP_SD=0 (tROPSD) | ROP_SD deasserts after the wake; observed per-cycle (`cycle_fact:67`). |

A1 check: write launched SYMCYCLE1 (j=1), cycles available `s - j + f = 9 - 1 + 8 = 16 >= 1` (`fact:ddf-c9f8fbf1`). Read-back launched SYMCYCLE9 (j=9), cycles available `s - j + f = 9 - 9 + 8 = 8 >= 1`. Both satisfy `pipeline_depth=1`. A3 (scan) does not apply — this corner shifts no chain. A5 (reset) is vacuous — no `reset_latency_cycles` scalar; BIN=2 grounds the legal-idle prelude.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| ADR | SYM | `symbolic_static` | ADR's within-phase transition space (all 9 SYM cycles hold one symbol) | The retention witness requires the read-back to read the SAME address the write used; one reused symbol guarantees write-address == read-address while still exploring the address space. ADR is don't-care during the DS dwell (periphery shutdown), so holding it still loses no legal transition there. | `cycle_fact:14`, `cycle_fact:61`, `pin:ADR` |
| D | SYM | unconstrained (SYMCYCLE1) | none | Write data is fully symbolic in the write cycle to explore the data space; the read-back compares the retained D. | `cycle_fact:10`, `pin:D` |
| DS | SYM | literal per-cycle | DS transition space outside the sequenced entry/hold/wake | Directive-required: directive:3 asks for the DS retention sequence, so DS is asserted (SYMCYCLE3-4), deasserted (SYMCYCLE5), held low (SYMCYCLE6-9). Each value is the mode transition the sequence needs. | `directive:3`, `cycle_fact:61`, `cycle_fact:62`, `cycle_fact:14`, `pin:DS` |
| SD | FLUSH | literal per-cycle | SD transition space outside the sequenced entry/hold/wake | Directive-required: directive:3 asks for the destructive SD path, so SD is asserted (FLUSHCYCLE3-4), deasserted (FLUSHCYCLE5), held low (FLUSHCYCLE6-8). | `directive:3`, `cycle_fact:65`, `cycle_fact:66`, `cycle_fact:18`, `pin:SD` |
| LS | BIN/SYM/FLUSH | literal 0 | LS transition space | LS must be 0 for DS and SD entry (`cycle_fact:61`, `cycle_fact:65`) and for legal idle (`cycle_fact:12`); R02 forbids LS overlapping DS/SD (`cycle_fact:45`). | `cycle_fact:61`, `cycle_fact:65`, `cycle_fact:45`, `pin:LS` |
| POFF | BIN/SYM/FLUSH | literal 00 | POFF transition space | NORMAL, DS, and SD modes all use POFF=00 (`cycle_fact:12`, `cycle_fact:14`, `cycle_fact:18`); the corner does not exercise POFF modes. | `cycle_fact:12`, `cycle_fact:14`, `cycle_fact:18`, `pin:POFF` |
| ME | BIN/SYM/FLUSH | literal per-cycle | ME transition space outside write/read/idle | ME=1 only in the write (SYMCYCLE1) and read-back (SYMCYCLE9) launches (`cycle_fact:10`, `cycle_fact:6`); ME=0 in idle and DS/SD entry (`cycle_fact:61`, `cycle_fact:65`). | `cycle_fact:10`, `cycle_fact:6`, `cycle_fact:61`, `cycle_fact:65`, `pin:ME` |
| TME | BIN/SYM/FLUSH | literal 0 | TME transition space | Functional port owns the memory with BISTE=0 (`cycle_fact:24`); TME=0 required for DS/SD entry (`cycle_fact:61`, `cycle_fact:65`). | `cycle_fact:24`, `cycle_fact:61`, `cycle_fact:65`, `pin:TME` |
| BISTE | BIN/SYM/FLUSH | literal 0 | BIST transition space | Functional port owns the memory (`cycle_fact:24`); BIST-mode operation is another corner's work. | `cycle_fact:24`, `pin:BISTE` |
| SE_IN | BIN/SYM/FLUSH | literal 0 | scan transition space | No scan in this corner; SE_IN=0 keeps the functional port in control (`cycle_fact:72`); R24 forbids power during scan (`cycle_fact:56`). | `cycle_fact:72`, `cycle_fact:56`, `pin:SE_IN` |
| DFTCLKEN | BIN/SYM/FLUSH | literal 0 | DFT clock-enable transition space | Legal idle requires DFTCLKEN=L (`cycle_fact:0`); no DFT in this corner. | `cycle_fact:0`, `pin:DFTCLKEN` |
| TPR | SYM | literal 0 | TPR transition space | Write and read require TPR=L (`cycle_fact:10`, `cycle_fact:6`). | `cycle_fact:10`, `cycle_fact:6`, `pin:TPR` |
| HW | SYM | literal 11 | HW transition space | Full-word write and read use HW=HH (`cycle_fact:10`, `cycle_fact:6`); the corner verifies full-word retention. | `cycle_fact:10`, `cycle_fact:6`, `pin:HW` |
| WE | SYM | literal per-cycle | WE transition space outside write/read | WE=1 in the write (SYMCYCLE1, `cycle_fact:10`), WE=0 in the read-back (SYMCYCLE9, `cycle_fact:6`) and idle. | `cycle_fact:10`, `cycle_fact:6`, `pin:WE` |
| WEM | SYM | literal 1 (SYMCYCLE1) | WEM transition space | Full-word write requires WEM=H (`cycle_fact:10`); WEM is don't-care in read (`cycle_fact:6`). | `cycle_fact:10`, `cycle_fact:6`, `pin:WEM` |
| BC0/BC1/BC2 | SYM (SYMCYCLE3-8) | literal 0/1/0 | bias-strap transition space during DS | DS with array bias via BC1 (`cycle_fact:39`) is the recommended legal encoding for retention; directive:3 asks for the retention sequence, so the bias that guarantees retention is applied during DS. | `cycle_fact:39`, `directive:3`, `pin:BC0`, `pin:BC1`, `pin:BC2` |
| CLK | BIN/SYM/FLUSH | literal per-cycle | CLK transition space in powered-down dwells | R05 forbids any rising CLK while DS/SD/POFF active (`cycle_fact:46`); the transition rows require clocks low during DS/SD entry and dwell (`cycle_fact:61`, `cycle_fact:65`). CLK=H only for the write (SYMCYCLE1) and read-back (SYMCYCLE9) launches and the read propagation (FLUSHCYCLE1). | `cycle_fact:46`, `cycle_fact:61`, `cycle_fact:65`, `pin:CLK` |

## Assumptions

- **Retention through DS.** The array is never cleared by DS, so a write before DS entry is readable after WAKE_DS→IDLE. This is the design context the corner rests on (`cycle_fact:61` "retained if VDDA remains in retention range"); the plan assumes VDDA stays in the retention range throughout the DS dwell.
- **CLK held low through the guard cycles.** The tPGGUARD=2 CLK cycles after ROP_DS=0 (`cycle_fact:63`) are held with CLK low as a conservative choice (R05 forbids rising clocks while power modes are active, `cycle_fact:46`). The guard is a settling-time measure, not a clock-event requirement; holding CLK low is harmless and avoids any ambiguity about a rising edge during wake.
- **Bias straps bound only during DS.** BC0=0/BC1=1/BC2=0 (`cycle_fact:39`) are applied only in SYMCYCLE3-8 (DS entry through guard). In NORMAL mode they are don't-care (`cycle_fact:32`) and in SD they are irrelevant (`cycle_fact:43`), so they are left unconstrained there.
- **No reset pin.** The design has no reset and no `reset_latency_cycles` scalar; BIN=2 grounds the legal-idle prelude rather than a reset hold.
- **Full-word access.** HW=HH is used for both write and read-back so the whole word is written and read; the corner verifies full-word retention.

## Limitations

- **SD data survival is not verified.** The SD path is destructive (`cycle_fact:65-67`); its observability is the ROP_SD sequencing and the forced-0 outputs, not data survival. Data after SD is unknown until written.
- **POFF modes are not exercised.** The corner covers DS and SD only; POFF=00 is held throughout (`cycle_fact:12,14,18`). POFF retentive/destructive modes (`cycle_fact:22,23`) belong to the low-power-sequence corner.
- **LS is not exercised.** LS=0 throughout; the LS→DS transition (`cycle_fact:71`) belongs to the low-power-sequence corner.
- **BIST and scan are excluded.** BISTE=0 and SE_IN=0 throughout; those are other corners' work.
- **The write data space is explored symbolically, but the address space is held to one symbol** (`symbolic_static` on ADR) so the write and read-back hit the same address. Address-to-address retention differences are not individually enumerated.
- **No multi-cycle history relations are routed to the declaration file.** All constraints in this plan are expressible as `set_constraint`; no `testbench_declarations.sv` is produced.

## Coverage

- catches: a write that fails to store D at ADR (read-back Q would not equal D); a DS entry that fails to force Q/QP/SO to 0 or assert ROP_DS; a DS dwell that loses the retained data (read-back Q would not equal D); a wake that fails to deassert ROP_DS; a read-back that reads the wrong address (symbolic_static ADR mismatch would surface as Q != D); an SD entry that fails to force Q to 0 or assert ROP_SD; a wake-SD that fails to deassert ROP_SD; a rising clock during a powered-down dwell (R05 violation would corrupt the forced outputs).
- misses: SD data survival (destructive by design, `cycle_fact:65-67`); POFF retentive/destructive modes (`cycle_fact:22,23`); LS retention and LS→DS (`cycle_fact:71`); BIST and scan paths; per-address retention differences (ADR held to one symbol). These are excluded because they belong to other certified corners or are outside this corner's DS/SD retention witness.
