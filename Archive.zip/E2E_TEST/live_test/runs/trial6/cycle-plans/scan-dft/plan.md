# Cycle Plan — scan-dft

- corner: scan-dft
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial6
- corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | IDLE->SCAN entry prelude. `cycle_fact:72` (TRANS_IDLE_SCAN) requires, in order: both clocks low and BISTE=0 (IDLE baseline), assert SE_IN, then enable the DFT clock. Three concrete steps -> b=3. No reset prelude is required: the corner starts from IDLE, not from reset, so `reset_latency_cycles` (unbound in the catalog) does not bound b. |
| SYM | 3 | The DFT surface's two symbolic operations plus the transition between them. SYMCYCLE1 exercises the scan output pass-through (SO_* = SE_IN ? SI_* : 1'b0, `cycle_fact:72`, RTL 174-179) with SI_* symbolic. SYMCYCLE2 transitions the DFT owner from scan (SE_IN=1) to write-through (SE_IN=0, DFTMASK=1) — R13 (`cycle_fact:52`) forbids SE_IN=1 with DFTMASK=1, so the owner handoff needs its own cycle. SYMCYCLE3 performs the synchronous write-through capture (q_int = sel_d on the clock edge, RTL 153-156) with the D bus symbolic. |
| FLUSH | 2 | SCAN->IDLE exit plus propagation. `cycle_fact:74` (TRANS_SCAN_BIST_IDLE) requires: deassert DFTCLKEN first, selected clock low, deassert owner, then wait one inactive cycle. Two concrete steps -> f=2. A3: f=2 >= scan_chain_length=1 (`fact:ddf-43efd23b`), and SE_IN is driven (0) in every flush cycle. The write-through effect (q_int=sel_d) reaches Q through pipeline_depth=1 (`fact:ddf-c9f8fbf1`) by FLUSHCYCLE1. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE baseline | Establish legal IDLE: functional mode (BISTE=0), no power mode (LS=DS=SD=0, POFF=00), active clocking (TPR=0), DFT clock off (DFTCLKEN=0), DFTMASK=0 (R14 forbids DFTMASK=1 with DFTCLKEN=0). SE_IN=0 as a clean pre-scan baseline. | `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `SE_IN=1'b0` | `cycle_fact:24`, `cycle_fact:12`, `cycle_fact:0`, `cycle_fact:53`, `cycle_fact:72` |
| BINCYCLE2 | assert SE_IN | Assert the scan owner per `cycle_fact:72` ("assert SE_IN"). DFTMASK=0 because R13 (`cycle_fact:52`) forbids SE_IN=1 with DFTMASK=1. DFTCLKEN still 0 (the DFT clock is enabled next). | `SE_IN=1'b1`, `DFTMASK=1'b0`, `DFTCLKEN=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:72`, `cycle_fact:52`, `cycle_fact:56` |
| BINCYCLE3 | enable DFT clock | Enable the DFT clock per `cycle_fact:72` ("then enable the DFT clock"). Now in SCAN mode: SE_IN=1, DFTCLKEN=1, DFTMASK=0 (R13). | `DFTCLKEN=1'b1`, `SE_IN=1'b1`, `DFTMASK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:72`, `cycle_fact:52`, `cycle_fact:56` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | scan output pass-through | Exercise the scan chain outputs: with SE_IN=1, DFTMASK=0, DFTCLKEN=1, each SO_* follows its SI_* (SO_* = SE_IN ? SI_* : 1'b0, RTL 174-179). SI_* left unconstrained (symbolic scan data). One-stage chain (`fact:ddf-43efd23b`), so one shift traverses it. | `SE_IN=1'b1`, `DFTMASK=1'b0`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`; SI_* unconstrained | `cycle_fact:72`, `cycle_fact:52`, `cycle_fact:56`, `fact:ddf-43efd23b` |
| SYMCYCLE2 | owner handoff to write-through | Deassert the scan owner and assert the DFT write-through enable. R13 (`cycle_fact:52`) forbids SE_IN=1 with DFTMASK=1, so SE_IN must drop to 0 before DFTMASK rises to 1. R14 (`cycle_fact:53`) requires DFTCLKEN=1 whenever DFTMASK=1, so DFTCLKEN stays 1. | `SE_IN=1'b0`, `DFTMASK=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:52`, `cycle_fact:53`, `cycle_fact:56` |
| SYMCYCLE3 | write-through capture | Synchronous write-through: DFTMASK=1 with DFTCLKEN=1 makes q_int capture sel_d on the clock edge, independent of ME/WE (RTL 153-156). With BISTE=0, sel_d = D (`cycle_fact:24`), so D is left unconstrained (symbolic write-through data). ME/WE/HW left unconstrained to explore the write-through's independence from normal write control. | `DFTMASK=1'b1`, `DFTCLKEN=1'b1`, `SE_IN=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`; D unconstrained | `cycle_fact:53`, `cycle_fact:24`, `cycle_fact:56` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | exit scan, deassert DFT | Begin SCAN->IDLE exit per `cycle_fact:74`: deassert DFTCLKEN first, selected clock low, deassert owner. DFTMASK drops to 0 with DFTCLKEN (R14, `cycle_fact:53`, forbids DFTMASK=1 with DFTCLKEN=0). SE_IN already 0. q_int holds its captured value; the write-through effect (q_int=sel_d) reaches Q through pipeline_depth=1 (`fact:ddf-c9f8fbf1`). | `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `SE_IN=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:74`, `cycle_fact:53`, `fact:ddf-c9f8fbf1` |
| FLUSHCYCLE2 | one inactive cycle | Complete the exit per `cycle_fact:74` ("wait one inactive cycle"). Back in IDLE. SE_IN driven (0) in this flush cycle, satisfying A3's per-cycle shift-enable coverage. | `SE_IN=1'b0`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0` | `cycle_fact:74`, `cycle_fact:53` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| scan output pass-through | SYMCYCLE1 | SYMCYCLE1 | SO_* = SI_* (combinational pass-through, RTL 174-179) | SO_* is a combinational function of SE_IN and SI_*; with SE_IN=1 held, SO_* tracks SI_* in the same cycle. A1: s - 1 + f = 3 - 1 + 2 = 4 >= pipeline_depth=1 (`fact:ddf-c9f8fbf1`). |
| DFT write-through | SYMCYCLE3 | FLUSHCYCLE1 | q_int captures sel_d (= D, since BISTE=0) on the SYMCYCLE3 clock edge, independent of ME/WE (RTL 153-156); Q reflects q_int | q_int holds its captured value through the exit: FLUSHCYCLE1 deasserts DFTCLKEN/DFTMASK (no new capture, R14 satisfied), and no later cycle re-drives q_int. Q reflects q_int through pipeline_depth=1. A1: s - 3 + f = 3 - 3 + 2 = 2 >= 1. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | all | literal 0 | BIST-mode exploration (BISTE=1) | Scan entry requires BISTE=0 (`cycle_fact:72`); BISTE=0 selects functional port ownership (`cycle_fact:24`). BIST-mode operation is bist-mode-operation's corner. | `cycle_fact:72`, `cycle_fact:24` |
| LS, DS, SD, POFF | all | literal 0/00 | power-mode exploration (LS/DS/SD/POFF) | R24 (`cycle_fact:56`) forbids power mode during scan shift; run-owner directive keeps these normal throughout the DFT sequence. Power-mode sequencing is low-power-sequence's corner. | `cycle_fact:56` |
| TPR | all | literal 0 | clock-gated idle (TPR=1) | TPR=1 is DISABLED/clock-gated idle (`cycle_fact:2`); TPR=0 keeps the design active so the write-through capture and scan pass-through can occur. | `cycle_fact:2`, `cycle_fact:12` |
| SE_IN | BIN/SYM/FLUSH | literal per cycle | scan-owner transition space | SE_IN is the scan owner: asserted for entry and pass-through (`cycle_fact:72`), deasserted for the write-through (R13, `cycle_fact:52`) and exit (`cycle_fact:74`). This is the DFT control the corner exists to sequence. | `cycle_fact:72`, `cycle_fact:52`, `cycle_fact:74` |
| DFTMASK | BIN/SYM/FLUSH | literal per cycle | DFTMASK transition space | DFTMASK=0 during scan (R13, `cycle_fact:52`), DFTMASK=1 during write-through (RTL 153-156), DFTMASK=0 on exit (R14, `cycle_fact:53`). DFT write-through control. | `cycle_fact:52`, `cycle_fact:53` |
| DFTCLKEN | BIN/SYM/FLUSH | literal per cycle | DFTCLKEN transition space | DFTCLKEN=0 in IDLE/exit, DFTCLKEN=1 in scan and write-through (`cycle_fact:72`, `cycle_fact:74`). DFT clock enable. | `cycle_fact:72`, `cycle_fact:74` |
| SI_* | SYM | unconstrained | none | SI_* are the symbolic scan data carried by the pass-through (SO_* = SI_*). Left free for strongest coverage. | `fact:ddf-43efd23b` |
| D | SYM | unconstrained | none | D is the symbolic write-through data (sel_d = D with BISTE=0). Left free for strongest coverage. | `cycle_fact:24` |
| ME, WE, HW, WEM | SYM | unconstrained | none | The write-through is independent of ME/WE (RTL 153-156); leaving them free explores that independence. | `cycle_fact:53` |

## Assumptions

- **Clocks left unconstrained.** Per the run-owner directive, CLK/TCLK stay unconstrained. `cycle_fact:72` states scan entry requires both clocks low; that precondition is left to the unconstrained clock space, so the entry is reachable when both clocks happen to be low, and the write-through capture occurs on the rising edge of whichever clock is selected. This is a deliberate run-owner choice, not a legality claim.
- **No reset prelude.** The corner starts from IDLE (`cycle_fact:72`), not from reset. `reset_latency_cycles` is unbound in the catalog and does not bound b; b=3 is the IDLE->SCAN mode-entry sequence.
- **sel_d = D.** With BISTE=0, the functional port owns the memory (`cycle_fact:24`), so the write-through's sel_d is the D bus, not TD. TD is left unconstrained (not selected).
- **Power pins held normal throughout.** R24 (`cycle_fact:56`) forbids power mode during scan shift; the run-owner directive extends this hold across the whole DFT sequence, including the write-through cycles where R24 does not strictly apply. This is a conservative choice recorded here.
- **SE_IN=0 in BINCYCLE1.** `cycle_fact:0` (IDLE) lists SE_IN as don't-care; SE_IN=0 is chosen as a clean pre-scan baseline so the entry's "assert SE_IN" step is unambiguous.

## Limitations

- **Scope split across the roster.** The roster certifies scan-shift-path (owns the bare shift traversal) and bist-mode-operation (owns the BIST muxed-port operation). This corner is scoped to the DFT/ATPG scan surface: the synchronous write-through path (SE_IN/DFTCLKEN/DFTMASK), the scan chain outputs (SO_* pass-through), IDLE->SCAN->IDLE entry/exit, and R13/R14/R24 legality. It does NOT duplicate the full shift traversal (scan-shift-path's) nor the BIST port operation (bist-mode-operation's).
- **Inherent overlap with scan-shift-path on the pass-through.** Because scan_chain_length=1 (`fact:ddf-43efd23b`), the single-cycle SO_* = SI_* pass-through exercised here IS a full chain traversal. The overlap is inherent to a one-stage chain; the run owner reconciles scope across the roster. This corner frames it as scan-output observability within the DFT surface, not as the shift-traversal witness.
- **Write-through observability is internal-state mediated.** The write-through's effect (q_int = sel_d) is internal; it is observed at Q through pipeline_depth=1. The plan does not drive or assert Q — it relies on ESP's default reference-vs-implementation comparison.
- **BIST-mode operation not covered here.** BISTE=1, the BIST port (TME/TWE/TADR/TD/TWEM/TCLK), and the capture/compare path (CD/CAPT/STICKY) are bist-mode-operation's corner and are deliberately excluded.

## Coverage

- catches: a defect in the DFT write-through path (q_int failing to capture sel_d when DFTMASK=1 and DFTCLKEN=1, or capturing when it should not); a defect in the scan output pass-through (SO_* not following SI_* when SE_IN=1, or not forced to 0 when SE_IN=0); a legality violation (SE_IN=1 with DFTMASK=1, DFTMASK=1 with DFTCLKEN=0, or a power mode during scan) that the reference model rejects but the implementation allows; a broken IDLE->SCAN->IDLE entry/exit sequence.
- misses: BIST-mode operation (BISTE=1, BIST port, capture/compare) — owned by bist-mode-operation; the full multi-cycle shift traversal semantics beyond the one-stage pass-through — owned by scan-shift-path; power-mode retention/sequencing — owned by low-power-sequence; mission-mode read/write — owned by mission-mode-read-write. These exclusions are deliberate scope splits across the certified roster, not coverage gaps in this corner.
