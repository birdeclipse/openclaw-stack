# ---------------------------------------------------------------------------
# scan-dft corner constraints — lowered from cycle-plans/scan-dft/plan.md
# corpus digest: 60976b1a6e996c6f10023b130a0a24fcc790185126162ba39d8dec0235b0b304
#
# This is a faithful transliteration of the plan's segment tables. Every
# value and condition is a Verilog expression. Only design input pins are
# constrained; Q and SO_* (outputs) are never driven or constrained.
#
# Cycle counts (b=3, s=3, f=2) are emitted as app vars below.
# ---------------------------------------------------------------------------

# --- testbench cycle counts (plan.md Cycle counts) -------------------------
set_app_var testbench_binary_cycles 3
set_app_var testbench_symbolic_cycles 3
set_app_var testbench_flush_cycles  2

# --- BIN phase: IDLE->SCAN entry -------------------------------------------

# BINCYCLE1 — IDLE baseline (cycle_fact:24, cycle_fact:12, cycle_fact:0,
#             cycle_fact:53, cycle_fact:72)
set_constraint {BISTE}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE1} -set {2'b00}
set_constraint {TPR}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTMASK}  -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SE_IN}    -cycle {BINCYCLE1} -set {1'b0}

# BINCYCLE2 — assert SE_IN (cycle_fact:72, cycle_fact:52, cycle_fact:56)
set_constraint {SE_IN}    -cycle {BINCYCLE2} -set {1'b1}
set_constraint {DFTMASK}  -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE2} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE2} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE2} -set {2'b00}
set_constraint {TPR}      -cycle {BINCYCLE2} -set {1'b0}

# BINCYCLE3 — enable DFT clock (cycle_fact:72, cycle_fact:52, cycle_fact:56)
set_constraint {DFTCLKEN} -cycle {BINCYCLE3} -set {1'b1}
set_constraint {SE_IN}    -cycle {BINCYCLE3} -set {1'b1}
set_constraint {DFTMASK}  -cycle {BINCYCLE3} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE3} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE3} -set {2'b00}
set_constraint {TPR}      -cycle {BINCYCLE3} -set {1'b0}

# --- SYM phase: DFT surface ------------------------------------------------

# SYMCYCLE1 — scan output pass-through (cycle_fact:72, cycle_fact:52,
#             cycle_fact:56, fact:ddf-43efd23b). SI_* left unconstrained
#             (symbolic scan data).
set_constraint {SE_IN}    -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTMASK}  -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {BISTE}    -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE1} -set {2'b00}
set_constraint {TPR}      -cycle {SYMCYCLE1} -set {1'b0}

# SYMCYCLE2 — owner handoff to write-through (cycle_fact:52, cycle_fact:53,
#             cycle_fact:56)
set_constraint {SE_IN}    -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DFTMASK}  -cycle {SYMCYCLE2} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE2} -set {1'b1}
set_constraint {BISTE}    -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE2} -set {2'b00}
set_constraint {TPR}      -cycle {SYMCYCLE2} -set {1'b0}

# SYMCYCLE3 — write-through capture (cycle_fact:53, cycle_fact:24,
#             cycle_fact:56). D left unconstrained (symbolic write-through
#             data, sel_d = D with BISTE=0). ME/WE/HW/WEM left unconstrained
#             to explore the write-through's independence from normal write
#             control.
set_constraint {DFTMASK}  -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {SE_IN}    -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {BISTE}    -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE3} -set {2'b00}
set_constraint {TPR}      -cycle {SYMCYCLE3} -set {1'b0}

# --- FLUSH phase: SCAN->IDLE exit ------------------------------------------

# FLUSHCYCLE1 — exit scan, deassert DFT (cycle_fact:74, cycle_fact:53,
#               fact:ddf-c9f8fbf1)
set_constraint {DFTCLKEN} -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DFTMASK}  -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SE_IN}    -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {BISTE}    -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {FLUSHCYCLE1} -set {2'b00}
set_constraint {TPR}      -cycle {FLUSHCYCLE1} -set {1'b0}

# FLUSHCYCLE2 — one inactive cycle (cycle_fact:74, cycle_fact:53)
set_constraint {SE_IN}    -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {DFTMASK}  -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {BISTE}    -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {LS}       -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {DS}       -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {SD}       -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {POFF}     -cycle {FLUSHCYCLE2} -set {2'b00}
set_constraint {TPR}      -cycle {FLUSHCYCLE2} -set {1'b0}
