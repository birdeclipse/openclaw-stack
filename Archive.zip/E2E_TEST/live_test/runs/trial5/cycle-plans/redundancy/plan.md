# Cycle Plan — redundancy

- corner: redundancy
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 2 | Establish the IDLE/NORMAL prelude: BINCYCLE1 drives the legal NORMAL-mode control values (BISTE=0, LS=0, DS=0, SD=0, POFF=2'b00, TPR=0, ME=0) per `cycle_fact:12` (NORMAL) and `cycle_fact:22` (NORMAL_MODE, functional path owns the macro when BISTE=L); BINCYCLE2 holds/settles those values so the mode is stable before the first symbolic access. `b=2` because the prelude needs one cycle to assert the NORMAL control set and one to settle it; there is no reset pin and no `reset_latency_cycles` scalar in the corpus, so A5's reset-hold rule does not bind here — the two cycles are the mode-entry prelude, not a reset hold. |
| SYM | 2 | Explore the repair-selection space held stable while a legal NORMAL-mode access runs. SYMCYCLE1 launches a WRITE (ME=1, TPR=0, HW=2'b11, WE=1, WEM=32'hFFFFFFFF, D=symbolic, ADR=14'h0000) per `cycle_fact:10`; SYMCYCLE2 launches a READ of the same address (ME=1, TPR=0, HW=2'b11, WE=0, ADR=14'h0000) per `cycle_fact:6` and `cycle_fact:101` (write-then-read-same-addr). The repair pins CRE1/CRE2/FCA1/FCA2/RRE/FRA are held `symbolic_static` across both cycles so the whole selection value space is explored while held still, satisfying `cycle_fact:69` (R20: repair pins must be stable while ME=1). |
| FLUSH | 1 | Hold the access quiescent (ME=0, power off, repair pins stable) so the read result launched at SYMCYCLE2 propagates to default comparison. A1: read launched at j=2, `s - j + f = 2 - 2 + 1 = 1 >= pipeline_depth = 1` (`fact:ddf-fcddfcd0`). |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | NORMAL prelude | Assert the legal NORMAL-mode control set so the macro is in IDLE/NORMAL before any access; functional path owns the macro (BISTE=L). | `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`, `ME=1'b0` | `cycle_fact:12`, `cycle_fact:22`, `pin:BISTE`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF`, `pin:TPR`, `pin:ME` |
| BINCYCLE2 | settle | Hold the NORMAL control set one more cycle so the mode is stable before the first symbolic access; no access is launched here. | `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`, `ME=1'b0` | `cycle_fact:12`, `cycle_fact:22` |

The DFT/scan pins are held inactive across the whole access so it is a legal NORMAL-mode access and `q_int` is not clamped: `DFTCLKEN=1'b0`, `SE_IN=1'b0` (`cycle_fact:12`, `cycle_fact:44`). These are driven in the symbolic phase rows below, not here, because the access they protect begins in SYM.

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | WRITE | Launch a full-width write to ADR=14'h0000 so the array holds a known symbolic value at that address; repair selection is held stable while ME=1. | `ME=1'b1`, `TPR=1'b0`, `HW=2'b11`, `WE=1'b1`, `WEM=32'hFFFFFFFF`, `D=<symbolic>`, `ADR=14'h0000`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `DFTCLKEN=1'b0`, `SE_IN=1'b0` | `cycle_fact:10`, `cycle_fact:12`, `cycle_fact:22`, `cycle_fact:44` |
| SYMCYCLE2 | READ | Launch a read of the same address ADR=14'h0000 so the written value is read back; repair selection still held stable while ME=1. | `ME=1'b1`, `TPR=1'b0`, `HW=2'b11`, `WE=1'b0`, `ADR=14'h0000`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `DFTCLKEN=1'b0`, `SE_IN=1'b0` | `cycle_fact:6`, `cycle_fact:101`, `cycle_fact:12`, `cycle_fact:22`, `cycle_fact:44` |

The repair pins CRE1/CRE2/FCA1/FCA2/RRE/FRA are held `symbolic_static` across SYMCYCLE1-2 (one symbol, stable) — see the Symbolic treatment table. They are not listed as "pins driven" here because they are not given a literal value; their stable-symbolic treatment is a separate constraint.

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | quiesce | Deassert ME so the access is quiescent and the read result propagates to default comparison; power stays off and repair pins stay stable so no later cycle re-drives the value. | `ME=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `TPR=1'b0`, `DFTCLKEN=1'b0`, `SE_IN=1'b0` | `cycle_fact:1`, `cycle_fact:12`, `cycle_fact:44` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| WRITE to ADR=14'h0000 | SYMCYCLE1 (j=1) | FLUSHCYCLE1 | Array[14'h0000] = D (full-width, HW=2'b11, WEM=all-ones) per `cycle_fact:10` | The write is a state update to the array, not a pipeline output; it is not overwritten before the read because SYMCYCLE2 reads the same address (`cycle_fact:101`) and FLUSHCYCLE1 launches no further write (ME=0). |
| READ of ADR=14'h0000 | SYMCYCLE2 (j=2) | FLUSHCYCLE1 | Q = output of addressed location, no CLK latency per `cycle_fact:6`; returns the value written at SYMCYCLE1 per `cycle_fact:101` | A1: `s - j + f = 2 - 2 + 1 = 1 >= pipeline_depth = 1` (`fact:ddf-fcddfcd0`). The read result reaches default comparison in FLUSHCYCLE1; no later cycle re-drives Q or the read path, and ME=0 in FLUSH keeps the access quiescent so the value is not disturbed. |

The repair-selection value space is explored by the `symbolic_static` treatment of CRE1/CRE2/FCA1/FCA2/RRE/FRA across SYM; the selection is held stable while ME=1 (`cycle_fact:69`), so the comparison observes the read under every legal stable selection.
