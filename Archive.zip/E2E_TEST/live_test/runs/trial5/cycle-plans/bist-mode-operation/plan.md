# Cycle Plan — bist-mode-operation

- corner: bist-mode-operation
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | Establish IDLE (both clocks low, enables quiet, power off), then perform the BIST ownership handoff: establish TCLKE, assert BISTE, and wait one inactive selected-clock cycle. `cycle_fact:92` requires both clocks low, SE_IN=0, TCLKE established, BISTE asserted, then one inactive selected-clock cycle before BIST owns the muxed inputs. `cycle_fact:60` (R11) requires TCLKE change only with both clocks low; `cycle_fact:61` (R12) requires BISTE change only with the selected clock low and ME/TME=0. Three cycles: (1) IDLE establish, (2) TCLKE=1 + BISTE=1, (3) one inactive selected-clock cycle. |
| SYM | 6 | Explore the BIST operation space under BIST ownership: BIST read/write (TME/TWE/TADR/TD/TWEM/THW), compare capture (CAPT/STICKY), and pipeline (TPIPEME). `cycle_fact:23` names the active BIST pins; `cycle_fact:48`/`49` define BIST read/write; `cycle_fact:106-108` define compare capture; `cycle_fact:47`/`72` define the BIST pipeline. s=6 keeps the phase within the ~8-cycle capacity trigger range while giving the last BIST read enough cycles to propagate (A1: s - j + f >= 1). |
| FLUSH | 3 | Propagate the last BIST operation's effect to default comparison (pipeline_depth=1, `fact:ddf-fcddfcd0`), then exit BIST->IDLE: deassert TME first, selected clock low, deassert BISTE, wait one inactive cycle. `cycle_fact:93` requires deasserting TME first, selected clock low, deassert BISTE, then one inactive cycle; `cycle_fact:61` (R12) requires BISTE change with ME=0/TME=0 and selected clock low. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE establish | Hold both clocks low, all enables quiet, power off, so the macro sits in IDLE before any ownership handoff. | `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:92`, `cycle_fact:74`, `cycle_fact:0` |
| BINCYCLE2 | Ownership handoff | Establish TCLKE=1 (selecting TCLK as the BIST clock) and assert BISTE=1, both with both clocks low and ME/TME=0. | `TCLKE=1'b1`, `BISTE=1'b1`, `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0` | `cycle_fact:92`, `cycle_fact:60`, `cycle_fact:61` |
| BINCYCLE3 | Inactive selected-clock wait | Wait one inactive selected-clock cycle (TCLK low, TME=0) so BIST ownership is fully established before any BIST operation. | `TCLK=1'b0`, `TME=1'b0`, `BISTE=1'b1`, `TCLKE=1'b1` | `cycle_fact:92` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1-6 | BIST operation space | Under BIST ownership (BISTE=1, TCLKE=1, SE_IN=0, power modes inactive), TCLK toggles to clock BIST operations. The BIST read/write space (TME, TWE, TADR, TD, TWEM, THW), compare capture (CAPT, STICKY), and pipeline (TPIPEME) are left unconstrained so ESP explores their full value and transition space. | `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:23`, `cycle_fact:48`, `cycle_fact:49`, `cycle_fact:106`, `cycle_fact:107`, `cycle_fact:108`, `cycle_fact:47`, `cycle_fact:72` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | Last BIST read propagation | Hold BIST ownership one more cycle so the last BIST operation's effect (a BIST read presenting mem[TADR] on Q, or a pipeline capture on QP) reaches default comparison. pipeline_depth=1, so one cycle after the last SYM launch suffices (A1: s - j + f >= 1). | `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b0`, `TWE=1'b0` | `cycle_fact:48`, `fact:ddf-fcddfcd0`, `cycle_fact:47` |
| FLUSHCYCLE2 | BIST exit — deassert TME | Deassert TME first (selected clock low, ME=0) so the BIST port releases the macro before BISTE is dropped. | `TME=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `BISTE=1'b1` | `cycle_fact:93`, `cycle_fact:61` |
| FLUSHCYCLE3 | BIST exit — deassert BISTE, wait inactive | With TME=0, ME=0, and the selected clock low, deassert BISTE and wait one inactive cycle to return to IDLE. | `BISTE=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0` | `cycle_fact:93`, `cycle_fact:61` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| BIST read (TME=1, TWE=0) | SYMCYCLE j (1..6) | FLUSHCYCLE1 (s - j + f >= 1) | q_int captures mem[TADR] on the TCLK edge and presents it on Q through the read path (`cycle_fact:48`). | Q is a primary output observed at default comparison; nothing re-drives it after the read. The BIST exit (FLUSHCYCLE2-3) deasserts TME/BISTE with the selected clock low, so no later access overwrites Q before comparison. |
| BIST pipeline capture (TPIPEME=1) | SYMCYCLE j | FLUSHCYCLE1 (s - j + f >= 1) | QP follows Q one cycle later when TPIPEME=1 under BISTE=1 (`cycle_fact:47`, `fact:ddf-fcddfcd0`). | QP is a primary output; the pipeline capture is registered on the TCLK edge and retained until the next enabled capture. The BIST exit holds the selected clock low, so QP is not overwritten before comparison. |
| BIST write (TME=1, TWE=1) | SYMCYCLE j | via a later BIST read | mem[TADR] is updated per TWEM/THW mask (`cycle_fact:49`). | A write's effect is not directly observable on a primary output; it is observable only through a subsequent BIST read of the same address. The schedule keeps the BIST read/write space symbolic across SYMCYCLE1-6, so ESP can pair a write with a later read of the same TADR and observe the updated value on Q. |
| BIST compare capture (CAPT/STICKY) | SYMCYCLE j | not a primary output | The comparison register stores the comparison result per CAPT/STICKY semantics (`cycle_fact:106-108`). | This is INTERNAL state, not a primary output. Its effect is not directly observable at default comparison; it is observable only through the BIST read/write path it gates. This is stated plainly: the compare-capture register's own contents are not compared. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | BIN, SYM, FLUSH | literal (1 in SYM/FLUSH1-2, 0 in FLUSH3) | BISTE transition space within the phase | BISTE is the ownership pin this corner exists to exercise; it must be held 1 across the BIST operation space and dropped only at the legal BIST->IDLE exit. `cycle_fact:92` requires BISTE asserted for BIST ownership; `cycle_fact:93`/`61` require it deasserted with ME=0/TME=0 and the selected clock low. | `cycle_fact:92`, `cycle_fact:93`, `cycle_fact:61` |
| TCLKE | BIN, SYM, FLUSH | literal (1) | TCLKE transition space | TCLKE selects TCLK as the BIST clock; it must be established before BISTE and held through the BIST phase. `cycle_fact:92` requires TCLKE established; `cycle_fact:60` (R11) forbids toggling it while either clock is high. | `cycle_fact:92`, `cycle_fact:60` |
| SE_IN | BIN, SYM, FLUSH | literal (0) | scan ownership space | SE_IN=0 is required for BIST entry (`cycle_fact:92`); scan ownership is a different corner (scan-shift-path). Holding SE_IN=0 keeps BIST ownership exclusive. | `cycle_fact:92` |
| LS, DS, SD, POFF | BIN, SYM, FLUSH | literal (0 / 2'b00) | power-mode transition space | If any power mode asserted, q_int is clamped to 0 (`cycle_fact:44`), destroying BIST read observability on Q. Power modes are exercised by the low-power-sequence and deep-sleep-shutdown-retention corners. | `cycle_fact:44`, `cycle_fact:74` |
| ME | BIN, FLUSH | literal (0) | functional-path enable space | ME must be 0 at the BIST exit (`cycle_fact:61` R12 requires BISTE change with ME=0). In SYM, ME is left unconstrained: under BISTE=1, sel_me = TME (`cycle_fact:23`), so ME has no effect on the BIST port. | `cycle_fact:61`, `cycle_fact:23` |
| CLK | BIN, SYM, FLUSH | literal (0) | functional clock events | Under BISTE=1 with TCLKE selecting TCLK, the functional CLK has no effect (`cycle_fact:59` R10). CLK is held low so it cannot interfere with the BIST clock. | `cycle_fact:59` |
| TCLK | BIN, FLUSH | literal (0) | TCLK transition space in BIN/FLUSH | Both clocks must be low for the BIST entry handoff (`cycle_fact:92`) and the BIST exit (`cycle_fact:93`). In SYM, TCLK is left unconstrained so it toggles to clock BIST operations. | `cycle_fact:92`, `cycle_fact:93` |

## Assumptions

- **No reset pin and no `reset_latency_cycles` scalar exist in the corpus.** The survey's scalar list carries only `fact:ddf-fcddfcd0` (pipeline_depth=1). The BIN phase therefore establishes IDLE directly (both clocks low, enables quiet, power off) rather than a reset prelude; A5's `b >= reset_latency_cycles` does not apply because no such scalar is declared. `cycle_fact:92` and `cycle_fact:74` define the IDLE entry.
- **pipeline_depth = 1** (`fact:ddf-fcddfcd0`). A1 is satisfied for the last BIST read launched in SYMCYCLE6: `s - j + f = 6 - 6 + 3 = 3 >= 1`. For a read launched in SYMCYCLE1: `6 - 1 + 3 = 8 >= 1`.
- **ME is left unconstrained in SYM** because under BISTE=1, `sel_me = TME` (`cycle_fact:23`); ME has no effect on the BIST port. It is bound to 0 only at the BIST exit where `cycle_fact:61` requires it.
- **TCLK is left unconstrained in SYM** so it toggles to clock BIST operations; it is bound to 0 in BIN and FLUSH where the entry/exit handoffs require both clocks low.
- **The BIST compare-capture register (CAPT/STICKY) is internal state.** Its contents are not a primary output and are not compared at default comparison; only the BIST read/write path it gates is observable. This is a limitation of the design's observability, not a schedule gap.

## Limitations

- **BIST compare-capture register contents are not directly observable.** The CAPT/STICKY comparison result (`cycle_fact:106-108`) is stored in internal state; the schedule observes only the BIST read/write path on Q/QP. A defect confined to the comparison register's own storage would not be exposed by this schedule.
- **A BIST write's effect is observable only through a later BIST read of the same address.** The schedule keeps the BIST read/write space symbolic across SYMCYCLE1-6 so ESP can pair a write with a later read, but a write whose address is never re-read is not observed.
- **The functional CLK is held low throughout.** Under BISTE=1 with TCLKE selecting TCLK, CLK has no effect (`cycle_fact:59` R10), so this is not a coverage loss for the BIST corner; functional-clock behavior belongs to mission-mode-read-write.
- **Power modes are held inactive.** Power-mode behavior belongs to low-power-sequence and deep-sleep-shutdown-retention; here they are held off so q_int is not clamped to 0 (`cycle_fact:44`).

## Coverage

- **catches:** a BIST read that fails to present mem[TADR] on Q (`cycle_fact:48`); a BIST pipeline capture that fails to make QP follow Q one cycle later (`cycle_fact:47`, `fact:ddf-fcddfcd0`); a BIST write that fails to update mem[TADR] per TWEM/THW mask (`cycle_fact:49`); an illegal BISTE/TCLKE handoff that toggles with a clock high or an enable active (`cycle_fact:60`, `cycle_fact:61`); an owner jump that bypasses IDLE (`cycle_fact:94`); a functional CLK that wrongly affects the macro under BISTE=1 (`cycle_fact:59`); a power mode that wrongly clamps q_int during BIST (`cycle_fact:44`).
- **misses:** defects confined to the internal compare-capture register's own storage (not a primary output); a BIST write whose address is never re-read; functional-clock and power-mode behavior (owned by other corners). These are acceptable because the BIST corner's contract is the BIST read/write path and its ownership handoff, both of which are fully exercised and observed.





