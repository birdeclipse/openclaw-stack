# Cycle Plan — deep-sleep-shutdown-retention

- corner: deep-sleep-shutdown-retention
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish IDLE: all power-mode pins deasserted (LS=DS=SD=0, POFF=00), functional ownership asserted (ME=0, TME=0, BISTE=0), clocks low. This is the prelude the DS/SD round trip must start from (`cycle_fact:74` IDLE_TO_ACTIVE requires LS=DS=SD=0 and POFF inactive; `cycle_fact:12` NORMAL requires LS=DS=SD=0, POFF=00). One cycle suffices because there is no reset pin and no `reset_latency_cycles` scalar in the corpus — the prelude is IDLE establishment, not reset. |
| SYM | 12 | The DS/SD retention round trip: seed write, IDLE->DS, DS hold, DS->WAKE_DS, WAKE_DS->IDLE (guard), post-DS read-back, return to IDLE, IDLE->SD, SD hold, SD->WAKE_SD, WAKE_SD->IDLE (guard), post-SD write. Each step is one cycle; the two wake sequences each consume one cycle for ROP to fall plus one guard cycle (`cycle_fact:81`, `cycle_fact:85`). |
| FLUSH | 1 | Hold IDLE (ME=0, power off) so the final post-SD write effect reaches ESP's default comparison. The last launched operation is the post-SD write at SYMCYCLE12; with `s=12`, `f=1`, observability is `s - j + f = 12 - 12 + 1 = 1 >= pipeline_depth` (A1, depth 1). |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE establishment | Establish the IDLE state the DS/SD round trip must start from: all power-mode pins deasserted, functional ownership inactive, clocks low. | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:74`, `cycle_fact:12`, `cycle_fact:22` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | seed write | Write a symbolic value to ADR=14'h0000 so the post-DS read-back has a stored value to return. Full write: ME=1, WE=1, TPR=0, HW=2'b11, WEM=32'hFFFFFFFF, D symbolic, ADR=14'h0000. Q=Q-1 on write. | `ME=1'b1`, `WE=1'b1`, `TPR=1'b0`, `HW=2'b11`, `WEM=32'hFFFFFFFF`, `D=<symbolic>`, `ADR=14'h0000` | `cycle_fact:10`, `cycle_fact:49` |
| SYMCYCLE2 | IDLE->DS | Enter Deep Sleep from IDLE: assert DS, deassert ME, LS, SD; clocks low. Q/QP/SO forced 0, ROP_DS=1, data retained. | `DS=1'b1`, `ME=1'b0`, `LS=1'b0`, `SD=1'b0`, `CLK=1'b0` | `cycle_fact:79` |
| SYMCYCLE3 | DS hold | Hold Deep Sleep one cycle: DS=1, ME=0, SD=0, POFF=00, CLK=0. Q=0, QP=0, SO=0, ROP_DS=1. | `DS=1'b1`, `ME=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:14` |
| SYMCYCLE4 | DS->WAKE_DS | Deassert DS, keep clocks low. Q=0, QP/SO=X, ROP_DS=1. | `DS=1'b0`, `CLK=1'b0` | `cycle_fact:80` |
| SYMCYCLE5 | WAKE_DS->IDLE | Wait for ROP_DS to fall to 0, then one guard cycle with CLK toggling. ROP_DS is an output, observed never driven. | `CLK=1'b1` (guard toggle) | `cycle_fact:81` |
| SYMCYCLE6 | post-DS read-back | The retention witness: read ADR=14'h0000. ME=1, WE=0, TPR=0, HW=2'b11. Q returns the value written at SYMCYCLE1. | `ME=1'b1`, `WE=1'b0`, `TPR=1'b0`, `HW=2'b11`, `ADR=14'h0000` | `cycle_fact:96`, `cycle_fact:6`, `cycle_fact:101` |
| SYMCYCLE7 | return to IDLE | Deassert ME; one inactive cycle before ownership/power change. | `ME=1'b0` | `cycle_fact:75` |
| SYMCYCLE8 | IDLE->SD | Enter Shutdown from IDLE: assert SD, deassert ME, LS, DS; clocks low. Q/QP/SO forced 0, ROP_SD=1, data destroyed/unknown. | `SD=1'b1`, `ME=1'b0`, `LS=1'b0`, `DS=1'b0`, `CLK=1'b0` | `cycle_fact:83` |
| SYMCYCLE9 | SD hold | Hold Shutdown one cycle: SD=1, ME=0, DS=0, POFF=00, CLK=0. Q=0, QP=0, SO=0, ROP_SD=1. | `SD=1'b1`, `ME=1'b0`, `DS=1'b0`, `POFF=2'b00`, `CLK=1'b0` | `cycle_fact:18` |
| SYMCYCLE10 | SD->WAKE_SD | Deassert SD, keep enables low. Q=0, QP/SO=X, ROP_SD=1, data unknown. | `SD=1'b0`, `CLK=1'b0` | `cycle_fact:84` |
| SYMCYCLE11 | WAKE_SD->IDLE | Wait for ROP_SD to fall to 0, then one guard cycle with CLK toggling. ROP_SD is an output, observed never driven. | `CLK=1'b1` (guard toggle) | `cycle_fact:85` |
| SYMCYCLE12 | post-SD write | Only-write-is-legal after SD wake: write V2 to ADR=14'h0000. ME=1, WE=1, TPR=0, HW=2'b11, WEM=32'hFFFFFFFF, D=V2. No post-SD read-back: reading is data-unknown (`cycle_fact:98`). | `ME=1'b1`, `WE=1'b1`, `TPR=1'b0`, `HW=2'b11`, `WEM=32'hFFFFFFFF`, `D=32'hV2`, `ADR=14'h0000` | `cycle_fact:10`, `cycle_fact:98` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | IDLE hold | Hold IDLE (ME=0, power off) so the post-SD write launched at SYMCYCLE12 propagates to default comparison. | `ME=1'b0`, `CLK=1'b0` | `cycle_fact:75`, `cycle_fact:12` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| seed write (SYMCYCLE1) | SYMCYCLE1 | SYMCYCLE6 | Array[14'h0000] = D (symbolic) | The write stores into the array; the array is not touched by the DS hold (retention, `cycle_fact:14`) or the DS wake (`cycle_fact:80`), so the value is intact when the post-DS read-back at SYMCYCLE6 reads it back. |
| post-DS read-back (SYMCYCLE6) | SYMCYCLE6 | SYMCYCLE6 | Q = stored value at ADR=14'h0000 | READ with ME=1, WE=0, HW=2'b11 returns Q=Q with no CLK latency (`cycle_fact:6`); the value was written at SYMCYCLE1 and retained through DS (`cycle_fact:96`). A1: `s - j + f = 12 - 6 + 1 = 7 >= 1`. |
| IDLE->DS entry (SYMCYCLE2) | SYMCYCLE2 | SYMCYCLE2 | Q/QP/SO forced 0, ROP_DS=1 | DS asserted with clocks low and ME=LS=SD=0 (`cycle_fact:79`); the forced-0 clamp is the observable effect of entering DS. |
| DS->WAKE_DS->IDLE (SYMCYCLE4-5) | SYMCYCLE4 | SYMCYCLE5 | ROP_DS falls to 0, then guard cycle restores valid outputs | ROP_DS follows DS (`cycle_fact:45`); after deassert, one cycle for ROP_DS=0 plus one guard cycle (`cycle_fact:81`). ROP_DS is observed, never driven. |
| IDLE->SD entry (SYMCYCLE8) | SYMCYCLE8 | SYMCYCLE8 | Q/QP/SO forced 0, ROP_SD=1 | SD asserted with clocks low and ME=LS=DS=0 (`cycle_fact:83`); the forced-0 clamp is the observable effect of entering SD. |
| SD->WAKE_SD->IDLE (SYMCYCLE10-11) | SYMCYCLE10 | SYMCYCLE11 | ROP_SD falls to 0, then guard cycle restores valid outputs | ROP_SD follows SD (`cycle_fact:45`); after deassert, one cycle for ROP_SD=0 plus one guard cycle (`cycle_fact:85`). ROP_SD is observed, never driven. |
| post-SD write (SYMCYCLE12) | SYMCYCLE12 | FLUSHCYCLE1 | Array[14'h0000] = V2 | The write is the only legal post-SD access (`cycle_fact:98`); it establishes validity for the written bits. A1: `s - j + f = 12 - 12 + 1 = 1 >= 1`. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| ADR | SYM | literal `14'h0000` | every other address | The seed write and the post-DS read-back must share one address for the retention witness to be meaningful (`cycle_fact:101` write-then-read same ADR). A single address is a deliberate reduction so the write and read-back align. | `cycle_fact:101`, `cycle_fact:96` |
| D | SYM (SYMCYCLE1) | symbolic | none (distinct symbol) | The seed write value is left symbolic so the read-back comparison exercises the full data space. | `cycle_fact:10` |
| D | SYM (SYMCYCLE12) | literal `32'hV2` | other data values | The post-SD write is a concrete re-establishment of validity; a single value suffices to exercise the only-legal-write rule. | `cycle_fact:98` |
| CLK | SYM (guard cycles 5, 11) | literal `1'b1` | clock low in those cycles | The wake guard cycle requires a clock toggle to restore valid outputs (`cycle_fact:81`, `cycle_fact:85`). In all power-down/transition cycles CLK is held low per `cycle_fact:54` R05. | `cycle_fact:81`, `cycle_fact:85`, `cycle_fact:54` |
| ME | SYM | literal per cycle | ME transition space | ME is driven to the value each operation requires (write/read/off); this is the functional ownership pin and is driven only where an operation occupies the cycle. | `cycle_fact:10`, `cycle_fact:6`, `cycle_fact:75` |
| WE | SYM | literal per cycle | WE transition space | WE=1 for writes, WE=0 for the read; driven only in the cycles the operation occupies. | `cycle_fact:10`, `cycle_fact:6` |
| HW | SYM | literal `2'b11` | other half-select values | Full-width write and read require both halves enabled (`cycle_fact:10`, `cycle_fact:6`). | `cycle_fact:10`, `cycle_fact:6` |
| WEM | SYM | literal `32'hFFFFFFFF` | masked-write combinations | Full write requires all bits unmasked (`cycle_fact:10`). | `cycle_fact:10` |
| TPR | SYM | literal `1'b0` | TPR-gated idle | TPR=0 is required for read/write operations (`cycle_fact:6`, `cycle_fact:10`). | `cycle_fact:6`, `cycle_fact:10` |
| DS | SYM | literal per cycle | DS transition space | DS is the mode pin this corner exists to explore; it is driven only in the cycles the DS sequence occupies (assert at 2, hold at 3, deassert at 4), and left unconstrained elsewhere. | `cycle_fact:79`, `cycle_fact:14`, `cycle_fact:80` |
| SD | SYM | literal per cycle | SD transition space | SD is the mode pin this corner exists to explore; it is driven only in the cycles the SD sequence occupies (assert at 8, hold at 9, deassert at 10), and left unconstrained elsewhere. | `cycle_fact:83`, `cycle_fact:18`, `cycle_fact:84` |
| LS | SYM | literal `1'b0` | LS mode | LS must be deasserted for DS/SD entry (`cycle_fact:79`, `cycle_fact:83`); LS+DS/SD overlap is illegal (`cycle_fact:51` R02). | `cycle_fact:79`, `cycle_fact:83`, `cycle_fact:51` |
| POFF | SYM | literal `2'b00` | periphery-off modes | POFF=00 is the normal-mode value (`cycle_fact:12`); DS/SD hold with POFF=00 (`cycle_fact:14`, `cycle_fact:18`). POFF+SD overlap is illegal (`cycle_fact:53` R04). | `cycle_fact:12`, `cycle_fact:14`, `cycle_fact:18`, `cycle_fact:53` |
| BISTE | SYM | literal `1'b0` | BIST ownership | Functional ownership requires BISTE=0 (`cycle_fact:22`); BISTE handoff while ME=1 is illegal (`cycle_fact:61` R12). | `cycle_fact:22`, `cycle_fact:61` |
| TME | SYM | literal `1'b0` | BIST port | TME=0 keeps the functional port in ownership (`cycle_fact:22`); IDLE-to-power transitions require ME=TME=0 (`cycle_fact:79`, `cycle_fact:83`). | `cycle_fact:22`, `cycle_fact:79`, `cycle_fact:83` |

## Assumptions

- **No reset pin, no `reset_latency_cycles` scalar.** The corpus carries no reset pin and no reset-latency scalar, so the prelude is IDLE establishment, not reset. BIN=1 establishes IDLE; A5 does not apply because there is no reset to hold. This is a recorded assumption, not an invented scalar.
- **`pipeline_depth` is 1.** The corpus declares no `pipeline_depth` scalar; the only declared scalar is `fact:ddf-fcddfcd0` (QP follows Q with one-cycle latency). For the read/write operations in this corner the output Q is combinational from the addressed location (`cycle_fact:6` "no CLK latency"), so the effective depth for the operations launched here is 1. A1 is checked against depth 1.
- **ADR=14'h0000 is a legal implemented address.** The corpus does not state the array depth; ADR=14'h0000 is assumed to be a legal location (not an unimplemented address, which would be illegal per `cycle_fact:70` R21). This is a deliberate single-address reduction so the write and read-back share one address.
- **D=V2 at SYMCYCLE12 is a concrete value.** The post-SD write uses a fixed value V2 to re-establish validity; the exact value is not load-bearing because no read-back follows it.
- **CLK toggles only in guard cycles.** In every power-down/transition cycle CLK is held low per `cycle_fact:54` R05 (rising clock during power-down is illegal). The guard cycles at SYMCYCLE5 and SYMCYCLE11 toggle CLK to restore valid outputs per `cycle_fact:81`/`cycle_fact:85`.

## Limitations

- **SD data destruction is not modeled by the collateral.** The RTL clamps `q_int` to 0 on power-down (`cycle_fact:44`) but never clears the array; the datasheet says SD destroys/unknowns contents (`cycle_fact:18`, `cycle_fact:83`, `cycle_fact:84`, `cycle_fact:98`). This cycle witness verifies the output clamping, the ROP_DS/ROP_SD wake handshake, and (for DS) the retention read-back returning the written value. It does **not** claim to verify retention through SD — the SD data-destruction is a datasheet behavioral claim the collateral does not model.
- **No post-SD read-back.** Reading after SD wake is legal electrically but data-unknown (`cycle_fact:98`); the plan deliberately performs only the post-SD write, which is the point of the only-write-legal rule.
- **Single address.** Only ADR=14'h0000 is exercised; address-decode and other-address retention are not covered by this corner.
- **ROP_DS/ROP_SD are observed, never driven.** The wake handshake is verified by observing these outputs fall to 0; the plan does not assert expected values on them (outputs are never driven per the authorability rules).

## Coverage

- **catches:** a DS entry that fails to clamp Q/QP/SO to 0 (`cycle_fact:79`); a DS hold that fails to retain the array so the post-DS read-back returns the wrong value (`cycle_fact:14`, `cycle_fact:96`); a wake sequence that fails to restore valid outputs after the guard cycle (`cycle_fact:81`); an SD entry that fails to clamp outputs (`cycle_fact:83`); a post-SD access that reads instead of writing (data-unknown, `cycle_fact:98`); an illegal overlap such as SD+DS (`cycle_fact:50` R01), DS/SD+LS (`cycle_fact:51` R02), or a rising clock during power-down (`cycle_fact:54` R05).
- **misses:** retention through SD (the collateral does not model data destruction, so no witness can expose a failure to destroy); other addresses; masked-write combinations; periphery-off (POFF) modes; BIST/scan ownership. These are acceptable because the corner is scoped to the DS/SD retention round trip, and the other ownership/power corners are planned separately.

