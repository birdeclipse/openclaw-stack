# Cycle Plan — low-power-sequence

- corner: low-power-sequence
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish IDLE as the prelude to every power-mode transition. The design has no reset pin and no `reset_latency_cycles` scalar, so the prelude is IDLE establishment, not reset (A5). One cycle suffices: drive all power pins off (`LS=DS=SD=0`, `POFF=2'b00`), `ME=TME=0`, `BISTE=0` (functional path owns the macro), clocks low. `b=1` because `IDLE_TO_ACTIVE` requires power modes off and `NORMAL_MODE` requires `BISTE=L`; one cycle of these values establishes the legal IDLE/NORMAL state from which every entry below is legal (`cycle_fact:74`, `cycle_fact:12`, `cycle_fact:22`). |
| SYM | 11 | Walk the power-mode family compactly: LS round trip (entry/hold/exit), the sequenced LS->DS transition, DS round trip (entry/hold/wake/guard), SD round trip (entry/hold/wake/guard). Each power state gets one entry cycle (assert the power pin, `ME=TME=0`, clocks low), one hold cycle (witness `Q/QP/SO`/`ROP` behavior), then exit/wake (deassert the pin, one cycle for `ROP` to fall) and one guard cycle (`tPGGUARD`). `s=11` because the family needs 3 (LS) + 1 (LS->DS step) + 4 (DS) + 4 (SD) = 12 cycle-slots, and the LS exit cycle doubles as the first step of the LS->DS sequence, collapsing to 11. The POFF=01 and POFF=11 destructive entries are dropped rather than padding past the `s<=12` target; they are recorded as limitations. |
| FLUSH | 1 | Hold IDLE (all power pins off, `ME=0`) so the last wake's effect — the design returned to IDLE with outputs valid — reaches ESP's default comparison. `f=1` because the final SD guard cycle already returned the design to IDLE and the pipeline depth is 1 (`fact:ddf-fcddfcd0`); one flush cycle propagates the last transition's effect to comparison. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE establishment | Establish the legal IDLE/NORMAL state from which every power-mode entry below is legal: all power pins off, functional path owns the macro, clocks quiescent. This is the prelude for the whole corner; the design has no reset pin, so this is IDLE establishment, not reset (A5). | `ME=1'b0`, `TME=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:74`, `cycle_fact:12`, `cycle_fact:22`, `pin:ME`, `pin:TME`, `pin:BISTE`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF`, `pin:CLK`, `pin:TCLK` |

`b=1` and not `b-1=0` because the IDLE state must be *established* before any power-mode entry is legal: `IDLE_TO_ACTIVE` requires `LS=DS=SD=0` and `POFF` inactive (`cycle_fact:74`), and `NORMAL_MODE` requires `BISTE=L` for the functional path to own the macro (`cycle_fact:22`). One cycle of these values is the minimum that makes the first `SYMCYCLE1` LS entry legal. No reset latency applies — there is no reset pin and no `reset_latency_cycles` scalar in the corpus.
