# Cycle Plan — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | Establish the IDLE prelude that makes scan entry legal, then assert the two scan-ownership enables in the order the guard sequence requires. BINCYCLE1 holds both clocks low, BISTE=0, power off, ME=0 (cycle_fact:91 requires both clocks low and BISTE=0 before scan; cycle_fact:74 requires power off and ME deasserted for IDLE). BINCYCLE2 asserts SE_IN=1 (cycle_fact:91: assert SE_IN first). BINCYCLE3 enables DFTCLKEN=1 (cycle_fact:91: then enable the DFT clock). Three cycles, not two, because SE_IN and DFTCLKEN are asserted in separate cycles in the documented order — collapsing them would skip the guard step the corner exists to exercise. |
| SYM | 2 | The shift space. SE_IN=1 and DFTCLKEN=1 held; the five scan-data inputs SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR are left unconstrained (symbolic) so the pass-through effect SO_* = SI_* (cycle_fact:42) is explored over their full value and transition space. BISTE=0 and power off held during shift (cycle_fact:91; cycle_fact:73 R24 forbids power during scan). The SCAN->IDLE exit occupies the last SYM cycles: deassert DFTCLKEN first, selected clock low, deassert SE_IN, wait one inactive cycle (cycle_fact:93). s=2 is the minimum that both shifts a pass-through value and demonstrates the exit guard; the pass-through chain is one cycle per shift (cycle_fact:42), so no deeper shift depth is required by the RTL under verification. |
| FLUSH | 1 | SE_IN=1 held in every flush cycle (A3; directive:1 requests shift). f=1 because scan_chain_length is UNBOUND in the corpus and the design under verification is the RTL wrapper whose five chains (Q_L/Q_H/D_L/D_H/CNTR) are combinational pass-through, one cycle per shift (cycle_fact:42). The flush shift (SE_IN=1, DFTCLKEN=1) re-enters the shift legally (cycle_fact:91) and propagates the pass-through effect to default comparison. The datasheet's unstated physical scan-chain length is recorded as an open question in Limitations; no larger number is silently assumed. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE prelude | Hold both clocks low, BISTE=0, power off, ME=0 so the macro sits in IDLE with no owner and no power mode, the state from which scan entry is legal. | `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `ME=1'b0` | `cycle_fact:91`, `cycle_fact:74`, `cycle_fact:0` |
| BINCYCLE2 | assert scan ownership | Assert SE_IN=1 while clocks remain low and BISTE=0, the first step of the IDLE->SCAN guard sequence. | `SE_IN=1'b1` | `cycle_fact:91` |
| BINCYCLE3 | enable DFT clock | Enable DFTCLKEN=1, the second step of the IDLE->SCAN guard sequence, entering the shift space. | `DFTCLKEN=1'b1` | `cycle_fact:91` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | shift space | Hold SE_IN=1 and DFTCLKEN=1; leave the five scan-data inputs SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR unconstrained (symbolic) so the pass-through SO_* = SI_* is explored over their full value and transition space. BISTE=0 and power off held during shift. | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:42`, `cycle_fact:91`, `cycle_fact:73` |
| SYMCYCLE2 | SCAN->IDLE exit | Demonstrate the exit guard: deassert DFTCLKEN first, selected clock low, deassert SE_IN, wait one inactive cycle. This is the SCAN->IDLE guard sequence the corner exists for. | `DFTCLKEN=1'b0`, `SE_IN=1'b0` | `cycle_fact:93` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | re-enter shift, propagate | Drive SE_IN=1 (held in every flush cycle, per A3 and directive:1) with DFTCLKEN=1, re-entering the shift legally (cycle_fact:91) and propagating the pass-through effect SO_* = SI_* to default comparison. BISTE=0 and power off held. | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:91`, `cycle_fact:42`, `cycle_fact:73`, `directive:1` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Scan shift pass-through (SO_* = SI_*) | SYMCYCLE1 | FLUSHCYCLE1 | With SE_IN=1, each SO_* output equals its SI_* input combinationally (cycle_fact:42). The symbolic SI_* values set in SYMCYCLE1 are observed on SO_* in the same cycle and again in FLUSHCYCLE1. | The pass-through is combinational (cycle_fact:42), so the effect is present in the launch cycle itself. FLUSHCYCLE1 re-enters the shift with SE_IN=1 and DFTCLKEN=1 (cycle_fact:91), so the same pass-through relation is active at default comparison; nothing between SYMCYCLE1 and FLUSHCYCLE1 re-drives the SI_* pins or deasserts SE_IN in a way that would clear the observed value. |
| SCAN->IDLE exit guard | SYMCYCLE2 | FLUSHCYCLE1 | Deassert DFTCLKEN first, selected clock low, deassert SE_IN, wait one inactive cycle (cycle_fact:93) — the legal exit from scan back to IDLE. | The exit completes within SYMCYCLE2. FLUSHCYCLE1 then re-enters the shift legally (cycle_fact:91), so the exit sequence is not left mid-transition at comparison; the guard ordering (DFTCLKEN before SE_IN) is preserved and observable as a legal re-entry. |
| Array preserved through scan | SYMCYCLE1 | FLUSHCYCLE1 | During scan, Q is not functionally updated and the array is preserved (cycle_fact:91). | No functional read/write is launched: ME=0 throughout (BINCYCLE1), BISTE=0, and the scan ownership (SE_IN=1) holds the array untouched (cycle_fact:91). Power off is held (cycle_fact:73 R24), so no power-mode clamp disturbs the array. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| SE_IN | SYM, FLUSH | literal 1'b1 (SYM), literal 1'b1 (FLUSH) | The SE_IN=0 (non-scan) value and its transitions within the shift/flush phases | The corner exists to explore the scan shift path; SE_IN=1 is the scan-ownership assertion required for the shift (cycle_fact:91) and is held in every flush cycle per A3 and directive:1. The SE_IN=0 state is exercised in BINCYCLE1 and SYMCYCLE2 (the exit guard), so the transition space is not wholly lost. | `cycle_fact:91`, `directive:1` |
| DFTCLKEN | SYM, FLUSH | literal 1'b1 (SYM), literal 1'b1 (FLUSH) | The DFTCLKEN=0 value and its transitions within the shift/flush phases | DFTCLKEN=1 enables the DFT clock during shift (cycle_fact:91); the exit guard deasserts it in SYMCYCLE2 (cycle_fact:93), so the deassertion transition is exercised. | `cycle_fact:91`, `cycle_fact:93` |
| BISTE | BIN, SYM, FLUSH | literal 1'b0 | The BISTE=1 (BIST ownership) value and its transitions | BISTE=0 is required during scan (cycle_fact:91); BIST ownership is a separate corner (bist-mode-operation), not this one. | `cycle_fact:91` |
| LS, DS, SD, POFF | BIN, SYM, FLUSH | literal 1'b0 / 2'b00 | The power-mode values and their transitions | Power off is required for IDLE (cycle_fact:74) and power during scan is illegal (cycle_fact:73 R24). Power modes are separate corners (low-power-sequence, deep-sleep-shutdown-retention). | `cycle_fact:74`, `cycle_fact:73` |
| ME | BIN | literal 1'b0 | The ME=1 (functional access) value | ME=0 holds the macro in IDLE with no functional owner before scan (cycle_fact:74, cycle_fact:0); functional access is a separate corner (mission-mode-read-write). | `cycle_fact:74`, `cycle_fact:0` |
| CLK, TCLK | BIN | literal 1'b0 | Clock toggling in the prelude | Both clocks low is required before scan entry (cycle_fact:91). Clocks are left unconstrained in SYM/FLUSH (no clock constraint emitted there), preserving clock-event freedom during the shift. | `cycle_fact:91` |

## Assumptions

- The design under verification is the RTL wrapper whose five scan chains (Q_L/Q_H/D_L/D_H/CNTR) are modelled as combinational pass-through, one cycle per shift (cycle_fact:42). The flush phase is sized to this RTL model, not to any physical scan-chain length.
- The SCAN->IDLE exit guard (cycle_fact:93) is exercised in SYMCYCLE2 and the shift is re-entered in FLUSHCYCLE1; the re-entry is legal because SE_IN=1 with DFTCLKEN=1 is the documented scan-entry state (cycle_fact:91).
- DFTMASK is left unconstrained (symbolic default) throughout; the plan does not assert it, so the illegal SE_IN=1-with-DFTMASK=1 combination (cycle_fact:62 R13) and the DFTMASK-without-DFTCLKEN combination (cycle_fact:63 R14) are not driven by this plan. They remain in the symbolic space only if the symbolic engine explores them; the plan does not force them.

## Limitations

- **Physical scan-chain length is unbound in the corpus.** No `scan_chain_length` scalar was logged. The flush phase is sized to the RTL pass-through model (one cycle per shift, cycle_fact:42). If the physical macro's scan chains are longer than one stage, this plan under-cycles the flush phase for the physical design. This is an open question for the run owner; no larger number was silently assumed.
- The plan exercises the shift pass-through and the IDLE->SCAN->IDLE guard sequence. It does not exercise BIST ownership (BISTE=1), functional read/write (ME=1), or power modes (LS/DS/SD/POFF) — those are separate corners (bist-mode-operation, mission-mode-read-write, low-power-sequence, deep-sleep-shutdown-retention).
- The plan does not drive DFTMASK, so the DFTMASK write-through behaviour (cycle_fact:46, cycle_fact:105) is not exercised here; it belongs to the scan-dft corner.

## Coverage

- **catches:** A defect that breaks the SO_* = SI_* pass-through relation under SE_IN=1 (cycle_fact:42) — e.g. a scan chain that does not propagate, a wrong SO_* mapping, or an SE_IN gating error — would surface at default comparison in SYMCYCLE1 and FLUSHCYCLE1. A defect that breaks the IDLE->SCAN entry guard (SE_IN before DFTCLKEN, both clocks low, BISTE=0, cycle_fact:91) or the SCAN->IDLE exit guard (DFTCLKEN before SE_IN, one inactive cycle, cycle_fact:93) would surface in the BIN/SYM sequencing. A defect that lets power mode or functional access disturb the array during scan (cycle_fact:73 R24, cycle_fact:91) would surface because ME=0 and power off are held throughout.
- **misses:** A physical scan-chain length greater than one stage (unbound scalar) would not be fully traversed by f=1; this is recorded in Limitations. BIST ownership, functional read/write, and power-mode behaviour are not exercised here — they are the subject of their own corners. DFTMASK write-through is not exercised — it belongs to the scan-dft corner.
