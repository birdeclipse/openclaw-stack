# ---------------------------------------------------------------------------
# mission-mode-read-write corner constraints
# Lowered from cycle-plans/mission-mode-read-write/plan.md
# Corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
#
# This file transliterates the plan; it never extends it. Every constraint
# below is a mode-defining binding justified in plan.md's Symbolic treatment
# table. The explore pins (ME, WE, ADR, D, WEM, HW, PIPEME) are deliberately
# left unconstrained (esp-default, distinct symbol per SYMCYCLE).
# ---------------------------------------------------------------------------

# Cycle counts (from plan.md Cycle counts)
set_app_var testbench_binary_cycles  1
set_app_var testbench_symbolic_cycles 4
set_app_var testbench_flush_cycles   1

# --- Mode-defining bindings (NORMAL mission mode, held across the whole run) ---
# Each is justified in plan.md Symbolic treatment; all are primary inputs.

# NORMAL mode: power pins off (cycle_fact:12). DS/SD/POFF=1 clamp q_int to 0
# (cycle_fact:44), destroying the read observation.
set_constraint {LS}       -set {1'b0}
set_constraint {DS}       -set {1'b0}
set_constraint {SD}       -set {1'b0}
set_constraint {POFF}     -set {2'b00}

# NORMAL_MODE: functional path owns the macro (cycle_fact:22); BISTE=1 gives
# BIST ownership (cycle_fact:23); TCLKE=1 selects TCLK as the functional clock.
set_constraint {BISTE}    -set {1'b0}
set_constraint {TCLKE}    -set {1'b0}

# READ/WRITE/MASK rows all have TPR=L (cycle_fact:3-11); TPR=1 gates off the
# access (cycle_fact:57).
set_constraint {TPR}      -set {1'b0}

# Mission mode, not scan (cycle_fact:91); SE_IN=1 with DFTMASK=1 gives scan
# ownership and Q=X (cycle_fact:62).
set_constraint {SE_IN}    -set {1'b0}

# DFTMASK=1 with DFTCLKEN=1 makes q_int capture sel_d irrespective of ME/WE
# (cycle_fact:46), corrupting the read observation.
set_constraint {DFTMASK}  -set {1'b0}

# TEST_RNM=1 holds the array in idle/precharge containment (cycle_fact:64);
# TEST1=1 changes read timing to bypass mode (cycle_fact:110).
set_constraint {TEST_RNM} -set {1'b0}
set_constraint {TEST1}    -set {1'b0}
