# Cycle Plan — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan
- corner justification: directive_named — `directive:0` ("Verify mission-mode read and write operations")

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish the NORMAL mission-mode prelude (IDLE): hold the mode-defining pins at their NORMAL values so the macro is in NORMAL mode before the first symbolic operation. No reset pin exists and no `reset_latency_cycles` scalar was stated, so A5 binds no hold count; the mode-defining pins are combinational mode selects that take effect immediately, so one cycle establishes the mode. |
| SYM | 4 | Explore the mission read/write operation and transition space. The explore pins (ME, WE, ADR, D, WEM, HW, PIPEME) are left at esp-default (distinct symbol per SYMCYCLE), so ESP explores the full read/write value AND transition space across 4 consecutive cycles. This covers every single-cycle operation (READ/WRITE/MASK with HW=11/01/10, fully/partially masked writes) and every 2-cycle sequence (write-then-read same ADR, read-then-write same ADR, back-to-back different-address reads, PIPEME one-cycle pulse + pipeline capture). |
| FLUSH | 1 | Propagate the last sym cycle's QP (pipeline stage). A read in SYMCYCLE4 with PIPEME=1 produces QP in FLUSHCYCLE1 (`pipeline_depth`=1, `fact:ddf-fcddfcd0`). f=1 satisfies A1 for QP. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | mode prelude | Establish NORMAL mission mode (IDLE): hold the mode-defining pins at their NORMAL values so the macro is in NORMAL mode, ready for the first symbolic read/write. | `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `BISTE=1'b0`, `TCLKE=1'b0`, `TPR=1'b0`, `SE_IN=1'b0`, `DFTMASK=1'b0`, `TEST_RNM=1'b0`, `TEST1=1'b0` | `cycle_fact:12`, `cycle_fact:22`, `cycle_fact:44` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1-4 | read/write space | Explore the mission read/write operation and transition space. The explore pins (ME, WE, ADR, D, WEM, HW, PIPEME) are left at esp-default (distinct symbol per cycle), so ESP explores the full read/write value AND transition space. The mode-defining pins are held at their NORMAL values (global bindings, see Symbolic treatment). | ME, WE, ADR, D, WEM, HW, PIPEME free (esp-default); mode-defining pins held | `cycle_fact:4`, `cycle_fact:5`, `cycle_fact:6`, `cycle_fact:8`, `cycle_fact:9`, `cycle_fact:10`, `cycle_fact:11`, `cycle_fact:47`, `cycle_fact:99`, `cycle_fact:100`, `cycle_fact:101`, `cycle_fact:102`, `cycle_fact:103`, `cycle_fact:104` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | QP propagation | Propagate the last sym cycle's QP (pipeline stage). A read in SYMCYCLE4 with PIPEME=1 produces QP in FLUSHCYCLE1. Mode-defining pins held. | mode-defining pins held | `cycle_fact:47`, `fact:ddf-fcddfcd0` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| READ (HW=11/01/10) | SYMCYCLE j (j=1..4) | Q in cycle j; QP in cycle j+1 (if PIPEME=1) | Q = mem[ADR] (cycle_fact:6); QP = Q one cycle later (cycle_fact:47) | Q is registered (q_int) with no CLK latency (cycle_fact:6); mode-defining pins held so no power-down clamp (cycle_fact:44) and no DFT write-through (cycle_fact:46) overwrites Q before comparison |
| WRITE (HW=11/01/10) | SYMCYCLE j | array updated in cycle j; observable via subsequent read of same ADR (cycle_fact:101) | mem[ADR] = D for enabled halves (cycle_fact:8,9,10) | write-then-read same ADR within the sym phase returns the written data (cycle_fact:101) |
| MASK | SYMCYCLE j | array unchanged in cycle j | write masked, no memory change (cycle_fact:11) | Q retains Q-1 (cycle_fact:11) |
| write-then-read same ADR | write SYMCYCLE N, read SYMCYCLE N+1 | read in cycle N+1 | read returns newly written bits and preserved masked bits (cycle_fact:101) | no bypass implied; read of same ADR in the next cycle returns the written data (cycle_fact:101) |
| read-then-write same ADR | read SYMCYCLE N, write SYMCYCLE N+1 | Q from read in cycle N; write changes array at N+1 | Q from read remains visible until output policy updates; write changes array (cycle_fact:102) | Q retains the read value until the next output update (cycle_fact:102) |
| back-to-back different-address reads | read A SYMCYCLE N, read B SYMCYCLE N+1 | Q presents A then B (cycle_fact:103) | Q = mem[A] then mem[B] (cycle_fact:103) | Q registered, no latency (cycle_fact:6) |
| fully/partially masked writes | SYMCYCLE j | array updated for unmasked bits | only bits with WEM=1 and HW half enabled written (cycle_fact:99,100) | write-then-read same ADR returns written and preserved bits (cycle_fact:101) |
| PIPEME one-cycle pulse | SYMCYCLE j (PIPEME=1) | QP in cycle j+1 | QP captures exactly one result (cycle_fact:104) | QP registered, captures q_int when PIPEME=1 (cycle_fact:47) |
| pipeline capture | SYMCYCLE j (PIPEME=1) | QP in cycle j+1 | QP = Q one cycle later (cycle_fact:47) | QP registered; A1: s - j + f = 4 - 4 + 1 = 1 >= pipeline_depth=1 (fact:ddf-fcddfcd0) |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| LS | whole run | literal 1'b0 | light-sleep mode (cycle_fact:13) and its output-retention behavior (cycle_fact:109) | NORMAL mode requires LS=0 (cycle_fact:12); corner is mission read/write | `cycle_fact:12`, `cycle_fact:13` |
| DS | whole run | literal 1'b0 | deep-sleep mode (cycle_fact:14-17) | DS=1 clamps q_int to 0 (cycle_fact:44), destroying the read observation; NORMAL mode requires DS=0 (cycle_fact:12) | `cycle_fact:12`, `cycle_fact:44` |
| SD | whole run | literal 1'b0 | shutdown mode (cycle_fact:18-19) | SD=1 clamps q_int to 0 (cycle_fact:44), destroying the read observation; NORMAL mode requires SD=0 (cycle_fact:12) | `cycle_fact:12`, `cycle_fact:44` |
| POFF | whole run | literal 2'b00 | periphery-off modes (cycle_fact:20-21) | POFF[0] or POFF[1]=1 clamps q_int to 0 (cycle_fact:44), destroying the read observation; NORMAL mode requires POFF=00 (cycle_fact:12) | `cycle_fact:12`, `cycle_fact:44` |
| BISTE | whole run | literal 1'b0 | BIST mode (cycle_fact:23) | NORMAL_MODE requires BISTE=L (cycle_fact:22); BISTE=1 gives BIST ownership, ignoring the functional pins (cycle_fact:23) | `cycle_fact:22`, `cycle_fact:23` |
| TCLKE | whole run | literal 1'b0 | TCLK clock selection | NORMAL_MODE lists CLK as the active functional clock (cycle_fact:22); TCLKE=1 selects TCLK as the functional clock, moving the read/write off CLK | `cycle_fact:22` |
| TPR | whole run | literal 1'b0 | TPR clock-gated idle (cycle_fact:57) | READ/WRITE/MASK rows all have TPR=L (cycle_fact:3-11); TPR=1 gates off the access (cycle_fact:57), making the read/write observation nondeterministic | `cycle_fact:3`, `cycle_fact:57` |
| SE_IN | whole run | literal 1'b0 | scan mode (cycle_fact:91) | mission mode, not scan; SE_IN=1 with DFTMASK=1 gives scan ownership and Q=X (cycle_fact:62) | `cycle_fact:62`, `cycle_fact:91` |
| DFTMASK | whole run | literal 1'b0 | DFT write-through (cycle_fact:46, 105) | DFTMASK=1 with DFTCLKEN=1 makes q_int capture sel_d irrespective of ME/WE (cycle_fact:46), corrupting the read observation | `cycle_fact:46`, `cycle_fact:105` |
| TEST_RNM | whole run | literal 1'b0 | TEST_RNM idle/precharge containment (cycle_fact:64) | TEST_RNM=1 holds the array in idle/precharge containment, preventing normal access (cycle_fact:64) | `cycle_fact:64` |
| TEST1 | whole run | literal 1'b0 | TEST1 read-bypass (cycle_fact:110) | TEST1=1 changes read timing to bypass mode (cycle_fact:110), making the read observation nondeterministic | `cycle_fact:110` |

## Assumptions

- DFTCLKEN is left unconstrained. It only affects q_int when DFTMASK=1 (cycle_fact:46); since DFTMASK=0 is bound, DFTCLKEN is a don't-care for the read/write observation.
- The BIST-port pins (TME, TWE, TADR, TD, TWEM, THW, TPIPEME, CAPT, STICKY, CD) and scan data inputs (SI_Q_L, SI_Q_H, SI_D_L, SI_D_H, SI_CNTR) are left unconstrained. They are ignored when BISTE=0 (cycle_fact:22, 23) and SE_IN=0 (cycle_fact:42), respectively.
- The bias pins (BC0, BC1, BC2) are left unconstrained. With SD=DS=LS=0 bound, they are in NORMAL bias mode regardless of value (cycle_fact:30).
- CLK and TCLK are left unconstrained (primary clocks, guide's default). The read/write operations are clocked by CLK (via sel_clk when TCLKE=0); leaving CLK free lets ESP explore clock behavior while the read/write still occurs on clock edges.
- b=1 is sufficient because no reset pin exists and no `reset_latency_cycles` scalar was stated; the mode-defining pins are combinational mode selects that take effect immediately.

## Limitations

- Power-mode transitions (LS/DS/SD/POFF) are excluded by the mode-defining bindings; they are the low-power-sequence corner's work.
- BIST operations are excluded by BISTE=0; they are the bist-mode-operation corner's work.
- Scan operations are excluded by SE_IN=0; they are the scan-dft and scan-shift-path corners' work.
- Repair operations are excluded; the RTL does not model the repair pins (CRE1/CRE2/FCA1/FCA2/RRE/FRA), and the redundancy corner is separate work.
- Spec-vs-RTL discrepancies not modelled in the RTL: RME/RM (cycle_fact:66 R17: RM changes with ME=1 → Q=X), RA/WA/WPULSE (cycle_fact:67 R18: reserved values), and repair-change (cycle_fact:69 R20) are left unconstrained because the RTL does not model them affecting q_int. The plan does not constrain RM to idle-only.
- DFT write-through (cycle_fact:46, 105) is excluded by DFTMASK=0; it is not part of mission read/write.

## Coverage

- catches:
  - Read data corruption (Q = wrong mem value) — exposed by READ operations (cycle_fact:6).
  - Write data corruption (mem = wrong D) — exposed by write-then-read same ADR (cycle_fact:101).
  - Masked-write corruption (masked bits written) — exposed by fully/partially masked writes (cycle_fact:99,100).
  - HW half-word selection errors — exposed by READ/WRITE with HW=01/10 (cycle_fact:4,5,8,9).
  - Pipeline capture errors (QP wrong) — exposed by PIPEME pulse and pipeline capture (cycle_fact:47,104).
  - Write-then-read / read-then-write ordering errors — exposed by the 2-cycle sequences (cycle_fact:101,102).
  - Back-to-back read decode errors — exposed by different-address reads (cycle_fact:103).
- misses:
  - Power-mode transitions (LS/DS/SD/POFF) — excluded by mode-defining bindings; separate corner (low-power-sequence).
  - BIST operations — excluded by BISTE=0; separate corner (bist-mode-operation).
  - Scan operations — excluded by SE_IN=0; separate corner (scan-dft, scan-shift-path).
  - Repair operations — excluded; separate corner (redundancy).
  - DFT write-through — excluded by DFTMASK=0; not part of mission read/write.
  - TPR clock-gated idle — excluded by TPR=0; not part of mission read/write.
