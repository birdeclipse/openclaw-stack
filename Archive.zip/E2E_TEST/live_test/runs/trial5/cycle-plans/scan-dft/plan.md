# Cycle Plan — scan-dft

- corner: scan-dft
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial5
- corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | Establish the IDLE state (both clocks low, BISTE=0, power off, ME=0), then assert SE_IN, then enable DFTCLKEN — the concrete IDLE->SCAN entry sequence of `cycle_fact:91`. Three cycles because the entry is three ordered steps: IDLE establish, SE_IN assert, DFT clock enable. |
| SYM | 4 | The shift space: SE_IN=1 and DFTCLKEN=1 held while the scan-data pins SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR are left symbolic (the pins this corner explores), plus one DFTMASK write-through cycle, plus the SCAN->IDLE ownership round trip (deassert DFTCLKEN, selected clock low, deassert SE_IN, one inactive cycle) per `cycle_fact:93`. |
| FLUSH | 1 | Re-enter the shift (SE_IN=1, DFTCLKEN=1) and propagate the pass-through effect to default comparison. `f >= scan_chain_length`; `scan_chain_length` is UNBOUND in the corpus, and the design under verification is the RTL wrapper whose chains are combinational pass-through (`cycle_fact:42`: one cycle per shift), so `f=1` covers one full traversal. Shift-enable is driven in every flush cycle (A3). |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE establish | Hold both clocks low, BISTE=0, power off (LS=DS=SD=0, POFF=2'b00), ME=0 so the macro sits in IDLE with no functional access. | `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `ME=1'b0` | `cycle_fact:91`, `cycle_fact:74`, `pin:CLK`, `pin:TCLK`, `pin:BISTE`, `pin:SE_IN`, `pin:DFTCLKEN`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF`, `pin:ME` |
| BINCYCLE2 | assert SE_IN | Assert scan ownership while both clocks remain low and BISTE=0, per the IDLE->SCAN entry. | `SE_IN=1'b1` | `cycle_fact:91`, `pin:SE_IN` |
| BINCYCLE3 | enable DFT clock | Enable the DFT clock (DFTCLKEN=1) to begin the shift; SO follows scan timing. | `DFTCLKEN=1'b1` | `cycle_fact:91`, `pin:DFTCLKEN` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1-2 | shift space | Hold SE_IN=1 and DFTCLKEN=1 while the scan-data pins SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR are left unconstrained (symbolic) — the pins this corner exists to explore. SO_* are outputs observed, never driven. BISTE stays 0 and power stays off during shift. | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:42`, `cycle_fact:91`, `cycle_fact:73`, `pin:SE_IN`, `pin:DFTCLKEN`, `pin:BISTE`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF` |
| SYMCYCLE3 | DFTMASK write-through | Exercise the DFTMASK write-through: DFTMASK=1, DFTCLKEN=1, SE_IN=0, so Q captures D synchronously while the array is unchanged. This cycle must not overlap the shift (SE_IN=1 with DFTMASK=1 is illegal, `cycle_fact:62` R13) and DFTMASK=1 requires DFTCLKEN=1 (`cycle_fact:63` R14). | `DFTMASK=1'b1`, `DFTCLKEN=1'b1`, `SE_IN=1'b0` | `cycle_fact:46`, `cycle_fact:105`, `cycle_fact:62`, `cycle_fact:63`, `pin:DFTMASK`, `pin:DFTCLKEN`, `pin:SE_IN` |
| SYMCYCLE4 | SCAN->IDLE exit | Ownership round trip: deassert DFTCLKEN first, selected clock low, deassert SE_IN, wait one inactive cycle. This returns the macro to IDLE with the array preserved. | `DFTCLKEN=1'b0`, `SE_IN=1'b0` | `cycle_fact:93`, `pin:DFTCLKEN`, `pin:SE_IN` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | shift re-entry | Re-enter the shift (SE_IN=1, DFTCLKEN=1) so the pass-through effect of the symbolic scan-data pins propagates to ESP's default comparison. Shift-enable is driven in this flush cycle (A3: coverage per cycle). Re-entry is legal per `cycle_fact:91`. | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:91`, `cycle_fact:42`, `cycle_fact:73`, `pin:SE_IN`, `pin:DFTCLKEN`, `pin:BISTE`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Scan shift pass-through | SYMCYCLE1-2 | FLUSHCYCLE1 | With SE_IN=1, SO_* = SI_* combinational pass-through (`cycle_fact:42`). The symbolic scan-data values on SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR appear on SO_Q_L/SO_Q_H/SO_D_L/SO_D_H/SO_CNTR. | The pass-through is combinational (`cycle_fact:42`), so the effect is present in every cycle SE_IN=1. The flush re-enters the shift with SE_IN=1 and DFTCLKEN=1, so the pass-through is live at default comparison. No later cycle re-drives the scan-data pins (they stay unconstrained), and no power mode is asserted during shift (`cycle_fact:73` R24), so the SO_* values are not clamped. |
| DFTMASK write-through | SYMCYCLE3 | FLUSHCYCLE1 | With DFTMASK=1, DFTCLKEN=1, SE_IN=0, Q captures D synchronously while the array is unchanged (`cycle_fact:46`, `cycle_fact:105`). | The write-through is a synchronous capture on the clock edge in SYMCYCLE3; the captured Q value persists through the SCAN->IDLE exit (SYMCYCLE4) and the flush re-entry, and is compared at default comparison. No later cycle overwrites Q before comparison. |
| SCAN->IDLE ownership round trip | SYMCYCLE4 | FLUSHCYCLE1 | Deassert DFTCLKEN first, selected clock low, deassert SE_IN, wait one inactive cycle — the macro returns to IDLE with the array preserved (`cycle_fact:93`). | The exit is a legal ownership transition; the flush re-entry then re-establishes the shift for comparison. The array is preserved throughout (`cycle_fact:91`), so no state is lost that would corrupt the observed pass-through. |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| SE_IN | BIN, SYM, FLUSH | literal | The value space and transition space of SE_IN across the whole schedule | The corner is the scan shift path: SE_IN must be asserted to enter scan (`cycle_fact:91`) and held through the shift and flush (A3). The directive requests shift operation (`directive:1`). | `cycle_fact:91`, `directive:1`, `pin:SE_IN` |
| DFTCLKEN | BIN, SYM, FLUSH | literal | The value space and transition space of DFTCLKEN | The DFT clock must be enabled to shift (`cycle_fact:91`) and deasserted first on exit (`cycle_fact:93`). | `cycle_fact:91`, `cycle_fact:93`, `pin:DFTCLKEN` |
| BISTE | BIN, SYM, FLUSH | literal (0) | The BIST ownership mode | Scan ownership requires BISTE=0 (`cycle_fact:91`); BIST-mode operation is a separate corner (`bist-mode-operation`). | `cycle_fact:91`, `pin:BISTE` |
| LS, DS, SD, POFF | BIN, SYM, FLUSH | literal (power off) | Power-mode transitions during scan | Power asserted during scan is illegal (`cycle_fact:73` R24); IDLE requires power off (`cycle_fact:74`). | `cycle_fact:73`, `cycle_fact:74`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF` |
| DFTMASK | SYMCYCLE3 | literal (1) | DFTMASK value/transition space outside the write-through cycle | The DFTMASK write-through requires DFTMASK=1 with DFTCLKEN=1 and SE_IN=0 (`cycle_fact:46`, `cycle_fact:105`); SE_IN=1 with DFTMASK=1 is illegal (`cycle_fact:62` R13). | `cycle_fact:46`, `cycle_fact:105`, `cycle_fact:62`, `pin:DFTMASK` |
| ME | BINCYCLE1 | literal (0) | Functional access during the prelude | IDLE requires ME=0 so no functional access occurs before scan ownership (`cycle_fact:91`, `cycle_fact:74`). | `cycle_fact:91`, `cycle_fact:74`, `pin:ME` |

The scan-data pins SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR are left unconstrained (symbolic) throughout — they are the pins this corner exists to explore, and no row is needed for them. SO_* are outputs, observed never driven.

## Assumptions

- The design under verification is the RTL wrapper whose scan chains are combinational pass-through (`cycle_fact:42`: SO_* = SI_* when SE_IN=1, one cycle per shift). This is the basis for `f=1`.
- The SCAN->IDLE exit (deassert DFTCLKEN, selected clock low, deassert SE_IN, one inactive cycle) is placed in the last SYM cycle (SYMCYCLE4) and is the ownership round trip of this corner.
- The DFTMASK write-through is exercised in one SYM cycle (SYMCYCLE3) and does not overlap the shift; this is a deliberate, simple treatment of `cycle_fact:46`/`cycle_fact:105`.
- No reset pin exists in the inventory and no `reset_latency_cycles` scalar is declared; no reset prelude is invented.

## Limitations

- **Physical scan-chain length is unstated.** The datasheet's physical scan-chain length is not declared in the corpus (`scan_chain_length` is UNBOUND). The plan uses `f=1` because the RTL wrapper's chains are combinational pass-through (`cycle_fact:42`). If the physical macro has a longer shift-register chain, the flush phase would need `f >= scan_chain_length`; this is an open question for the run owner, not silently padded.
- BIST-mode operation (directive:2) is not exercised here; it is planned by the separate `bist-mode-operation` corner. This corner covers the scan shift path and the DFTMASK write-through only.
- The DFTMASK write-through is exercised once; multi-cycle DFTMASK behavior is not explored.

## Coverage

- **catches:** a broken scan pass-through (SO_* not following SI_* when SE_IN=1), a scan-entry sequencing defect (SE_IN/DFTCLKEN ordering), an illegal power-during-scan path, a DFTMASK write-through defect (Q not capturing D), and a broken SCAN->IDLE exit.
- **misses:** BIST-mode operation (separate corner), physical shift-register chain timing beyond one cycle (unbound `scan_chain_length`), and multi-cycle DFTMASK behavior. These are acceptable because BIST is a separate certified corner and the RTL wrapper's chains are combinational.





