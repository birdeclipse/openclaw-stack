# ---------------------------------------------------------------------------
# scan-dft corner constraints — transliteration of
#   runs/trial5/cycle-plans/scan-dft/plan.md
# Corpus digest: c2fffb196fc8604d4f87df61dbcd4d17974f3b2808c97ed3ba05fe935e80bfc8
#
# Cycle counts (b=3, s=4, f=1) are the plan's own and are emitted as app vars.
# Values and conditions are Verilog expressions, never Tcl.
# Outputs (SO_*) are observed, never driven.
# ---------------------------------------------------------------------------

set_app_var testbench_binary_cycles 3
set_app_var testbench_symbolic_cycles 4
set_app_var testbench_flush_cycles  1

# --- BINCYCLE1: IDLE establish -------------------------------------------
# Both clocks low, BISTE=0, SE_IN=0, DFTCLKEN=0, power off, ME=0.
#   cycle_fact:91 (IDLE_TO_SCAN: both clocks low, BISTE=0)
#   cycle_fact:74 (IDLE requires power off)
set_constraint {CLK}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TCLK}     -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SE_IN}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE1} -set {2'b00}
set_constraint {ME}       -cycle {BINCYCLE1} -set {1'b0}

# --- BINCYCLE2: assert SE_IN ---------------------------------------------
#   cycle_fact:91 (assert SE_IN)
set_constraint {SE_IN}    -cycle {BINCYCLE2} -set {1'b1}

# --- BINCYCLE3: enable DFT clock -----------------------------------------
#   cycle_fact:91 (then enable DFT clock (DFTCLKEN))
set_constraint {DFTCLKEN} -cycle {BINCYCLE3} -set {1'b1}

# --- SYMCYCLE1-2: shift space --------------------------------------------
# SE_IN=1 and DFTCLKEN=1 held; BISTE=0 and power off during shift.
# Scan-data pins SI_Q_L/SI_Q_H/SI_D_L/SI_D_H/SI_CNTR left unconstrained.
#   cycle_fact:42 (SO_* = SI_* pass-through when SE_IN=1)
#   cycle_fact:73 (R24: power during scan illegal)
set_constraint {SE_IN}    -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {BISTE}    -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE1} -set {2'b00}
set_constraint {SE_IN}    -cycle {SYMCYCLE2} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE2} -set {1'b1}
set_constraint {BISTE}    -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE2} -set {2'b00}

# --- SYMCYCLE3: DFTMASK write-through ------------------------------------
# DFTMASK=1, DFTCLKEN=1, SE_IN=0. Must not overlap the shift (R13) and
# requires DFTCLKEN=1 (R14).
#   cycle_fact:46, cycle_fact:105 (DFTMASK write-through)
#   cycle_fact:62 (R13: SE_IN=1 with DFTMASK=1 illegal)
#   cycle_fact:63 (R14: DFTMASK=1 without DFTCLKEN illegal)
set_constraint {DFTMASK}  -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {SE_IN}    -cycle {SYMCYCLE3} -set {1'b0}

# --- SYMCYCLE4: SCAN->IDLE exit ------------------------------------------
# Deassert DFTCLKEN first, then deassert SE_IN, wait one inactive cycle.
#   cycle_fact:93 (SCAN_OR_BIST_TO_IDLE)
set_constraint {DFTCLKEN} -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {SE_IN}    -cycle {SYMCYCLE4} -set {1'b0}

# --- FLUSHCYCLE1: shift re-entry -----------------------------------------
# SE_IN=1 and DFTCLKEN=1 held; BISTE=0 and power off. Shift-enable driven in
# every flush cycle (A3). Re-entry legal per cycle_fact:91.
set_constraint {SE_IN}    -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {BISTE}    -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {FLUSHCYCLE1} -set {2'b00}
