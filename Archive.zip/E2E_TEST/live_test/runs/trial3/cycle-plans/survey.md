# Corner Survey

Schema: esp.corner-roster.v1
Corpus digest: 20c341ee0ffc0b1aacce06b7859f22189d9ef779d28ef60beab33ebee1865eee
Ledger facts: 59 pin(s), 84 operation(s), 1 scalar(s)

## Roster

| Corner | Classification | Reason |
| --- | --- | --- |
| calibration | unresolved | no supporting fact |
| clock-gating | unresolved | no supporting fact |
| idle | unresolved | no supporting fact |
| low-power-sequence | directive_named | directive named the corner: Verify the deep-sleep/shutdown retention sequence |
| mission-mode-read-write | directive_named | directive named the corner: Verify mission-mode read and write operations |
| multi-port-contention | absent | structurally impossible: single-port from typed pins ADR, BC0, BC1, BC2, BISTE, CAPT, CD, CLK, CRE1, CRE2, D, DFTCLKEN, DFTMASK, DS, FCA1, FCA2, FRA, HW, LS, ME, PIPEME, POFF, Q, QP, RA, RM, RME, ROP_DS, ROP_SD, RRE, SD, SE_IN, SI_CNTR, SI_D_H, SI_D_L, SI_Q_H, SI_Q_L, SO_CNTR, SO_D_H, SO_D_L, SO_Q_H, SO_Q_L, STICKY, TADR, TCLK, TCLKE, TD, TEST1, TEST_RNM, THW, TME, TPIPEME, TPR, TWE, TWEM, WA, WE, WEM, WPULSE |
| redundancy | candidate | pin-name rule matched CRE1, CRE2, FCA1, FCA2, FRA, RRE |
| scan-dft | directive_named | directive named the corner: Verify the scan shift path; Verify BIST-mode operation |
| bist-mode-operation | fact_supported | function_corner fact 147: With BISTE asserting BIST ownership and TCLKE selecting TCLK, the BIST port &#40;TME/TWE/TADR/TD/TWEM/THW&#41; drives the macro, and BIST compare capture stores the comparison result per CAPT/STICKY semantics. |
| deep-sleep-shutdown-retention | fact_supported | function_corner fact 148: Deep Sleep gates the periphery and forces Q/QP/SO to 0 while the array retains data &#40;retention met at Vnom-10%&#41;, Shutdown destroys contents, and the ROP_DS/ROP_SD wake sequence &#40;guard cycle, post-wake access rules&#41; restores normal operation. |
| scan-shift-path | fact_supported | function_corner fact 146: With SE_IN asserting scan ownership, data and control shift through the Q/D/control scan chains &#40;SI_* to SO_*&#41; under the DFT clock, and the macro enters and exits scan through the IDLE-&gt;SCAN-&gt;IDLE guard sequence with the array preserved. |

## Certified selection

- mission-mode-read-write
- low-power-sequence
- scan-dft
- bist-mode-operation
- deep-sleep-shutdown-retention
- scan-shift-path
- redundancy

## Pin inventory

| Pin | Direction |
| --- | --- |
| ADR | input |
| BC0 | input |
| BC1 | input |
| BC2 | input |
| BISTE | input |
| CAPT | input |
| CD | input |
| CLK | input |
| CRE1 | input |
| CRE2 | input |
| D | input |
| DFTCLKEN | input |
| DFTMASK | input |
| DS | input |
| FCA1 | input |
| FCA2 | input |
| FRA | input |
| HW | input |
| LS | input |
| ME | input |
| PIPEME | input |
| POFF | input |
| Q | output |
| QP | output |
| RA | input |
| RM | input |
| RME | input |
| ROP_DS | output |
| ROP_SD | output |
| RRE | input |
| SD | input |
| SE_IN | input |
| SI_CNTR | input |
| SI_D_H | input |
| SI_D_L | input |
| SI_Q_H | input |
| SI_Q_L | input |
| SO_CNTR | output |
| SO_D_H | output |
| SO_D_L | output |
| SO_Q_H | output |
| SO_Q_L | output |
| STICKY | input |
| TADR | input |
| TCLK | input |
| TCLKE | input |
| TD | input |
| TEST1 | input |
| TEST_RNM | input |
| THW | input |
| TME | input |
| TPIPEME | input |
| TPR | input |
| TWE | input |
| TWEM | input |
| WA | input |
| WE | input |
| WEM | input |
| WPULSE | input |

## Evidence catalog

| Ref | Evidence |
| --- | --- |
| cycle_fact:0 | ledger:61: truth_table_row&#40;IDLE, CLK=L, ME=X, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1 &#40;remains same state&#41;, NCM &#40;no change in memory contents&#41;&#41; |
| cycle_fact:1 | ledger:62: truth_table_row&#40;DISABLED, CLK=H, ME=L, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, NCM &#40;memory deactivated&#41;&#41; |
| cycle_fact:2 | ledger:63: truth_table_row&#40;DISABLED, CLK=H, ME=X, TPR=H, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, NCM &#40;TPR gates internal toggling&#41;&#41; |
| cycle_fact:3 | ledger:64: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, NCM &#40;both halves disabled by HW=00&#41;&#41; |
| cycle_fact:4 | ledger:65: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH-1/QL &#40;upper half retains, lower half reads&#41;&#41; |
| cycle_fact:5 | ledger:66: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH/QL-1 &#40;lower half retains, upper half reads&#41;&#41; |
| cycle_fact:6 | ledger:67: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q &#40;output of addressed location, no CLK latency&#41;&#41; |
| cycle_fact:7 | ledger:68: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, NCM &#40;both halves disabled&#41;&#41; |
| cycle_fact:8 | ledger:69: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, Array&#91;L&#93;=Data-in&#91;L&#93;&#41; |
| cycle_fact:9 | ledger:70: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, Array&#91;H&#93;=Data-in&#91;H&#93;&#41; |
| cycle_fact:10 | ledger:71: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, Array=Data-in&#41; |
| cycle_fact:11 | ledger:72: truth_table_row&#40;MASK, CLK=H, ME=H, TPR=L, HW=XX, WE=H, WEM=L, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1, NCM &#40;write masked&#41;&#41; |
| cycle_fact:12 | ledger:73: truth_table_row&#40;NORMAL, ME=0/1, HW=hw_val, LS=0, DS=0, SD=0, POFF=00, BC0=0/1, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=QP-1, SO=SO-1 &#40;normal mode&#41;&#41; |
| cycle_fact:13 | ledger:74: truth_table_row&#40;LIGHT_SLEEP, ME=0/1, HW=XX, LS=1, DS=0, SD=0, POFF=00, BC0=0/1, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=QP-1, SO=SO-1 &#40;Xdec power gate, source bias&#41;&#41; |
| cycle_fact:14 | ledger:75: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0→1, SD=0, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:15 | ledger:76: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1→0, SD=0, POFF=00, BC0=0/1, ROP_DS=0, ROP_SD=ROP_SD-1, Q=0, QP=X, SO=X &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:16 | ledger:77: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0→1, SD=1, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:17 | ledger:78: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1→0, SD=1, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:18 | ledger:79: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0→1, POFF=00, BC0=X, ROP_SD=1, ROP_DS=ROP_DS-1, Q=0, QP=0, SO=0 &#40;periphery and array shutdown&#41;&#41; |
| cycle_fact:19 | ledger:80: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1→0, POFF=00, BC0=X, ROP_SD=0, ROP_DS=ROP_DS-1, Q=0, QP=X, SO=X &#40;periphery and array shutdown&#41;&#41; |
| cycle_fact:20 | ledger:81: truth_table_row&#40;STANDARD_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=01, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=X, SO=X &#40;periphery shutdown, source bias, VDD can be floating&#41;&#41; |
| cycle_fact:21 | ledger:82: truth_table_row&#40;SHUTDOWN_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=11, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=X, SO=X &#40;periphery and array shutdown, VDD can be floating&#41;&#41; |
| cycle_fact:22 | ledger:83: truth_table_row&#40;NORMAL_MODE, BISTE=L, Active pins: ME, WE, ADR, D, WEM, CLK &#40;functional path owns the macro&#41;&#41; |
| cycle_fact:23 | ledger:84: truth_table_row&#40;BIST_MODE, BISTE=H, Active pins: TME, TWE, TADR, TD, TWEM, TCLK; TCLKE selects CLK/TCLK clock source&#41; |
| cycle_fact:24 | ledger:85: truth_table_row&#40;COLUMN_REPAIR_NORMAL, CRE1=0, CRE2=0, FCA1=X, FCA2=X, No repair element selected&#41; |
| cycle_fact:25 | ledger:86: truth_table_row&#40;COLUMN_REPAIR_LEFT, CRE1=1, CRE2=0, FCA1=FCA1&#91;n&#93;, FCA2=X, Faulty column on left side replaced by left redundant column&#41; |
| cycle_fact:26 | ledger:87: truth_table_row&#40;COLUMN_REPAIR_RIGHT, CRE1=0, CRE2=1, FCA1=X, FCA2=FCA2&#91;n&#93;, Faulty column on right side replaced by right redundant column&#41; |
| cycle_fact:27 | ledger:88: truth_table_row&#40;COLUMN_REPAIR_BOTH, CRE1=1, CRE2=1, FCA1=FCA1&#91;n&#93;, FCA2=FCA2&#91;n&#93;, Faulty columns on both sides replaced by respective redundant columns&#41; |
| cycle_fact:28 | ledger:89: truth_table_row&#40;ROW_REPAIR_NORMAL, RRE=0, FRA=X, No repair element selected&#41; |
| cycle_fact:29 | ledger:90: truth_table_row&#40;ROW_REPAIR, RRE=1, FRA=FRA&#91;n&#93;, Faulty row replaced by redundant row element&#41; |
| cycle_fact:30 | ledger:91: truth_table_row&#40;BIAS_NORMAL, BC0=0/1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=0, BC0=0/1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=0 — no bias operation&#41; |
| cycle_fact:31 | ledger:92: truth_table_row&#40;BIAS_LS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=0, LS=1, Non-recommended debug mode during LS&#41; |
| cycle_fact:32 | ledger:93: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=0, SD=0, DS=0, LS=1, LS with array bias &#40;BC1=1&#41;&#41; |
| cycle_fact:33 | ledger:94: truth_table_row&#40;BIAS_LS, BC0=0, BC1=0, BC2=1, SD=0, DS=0, LS=1, LS with array bias &#40;BC2=1&#41;&#41; |
| cycle_fact:34 | ledger:95: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=1, SD=0, DS=0, LS=1, LS with array bias &#40;BC1=BC2=1&#41;&#41; |
| cycle_fact:35 | ledger:96: truth_table_row&#40;BIAS_LS_NOBIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=1, LS without array bias &#40;BC0=1&#41;&#41; |
| cycle_fact:36 | ledger:97: truth_table_row&#40;BIAS_DS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=1, LS=0, Non-recommended debug mode during DS&#41; |
| cycle_fact:37 | ledger:98: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=0, SD=0, DS=1, LS=0, DS with array bias &#40;BC1=1&#41;&#41; |
| cycle_fact:38 | ledger:99: truth_table_row&#40;BIAS_DS, BC0=0, BC1=0, BC2=1, SD=0, DS=1, LS=0, DS with array bias &#40;BC2=1&#41;&#41; |
| cycle_fact:39 | ledger:100: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=1, SD=0, DS=1, LS=0, DS with array bias &#40;BC1=BC2=1&#41;&#41; |
| cycle_fact:40 | ledger:101: truth_table_row&#40;BIAS_DS_NOBIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=1, LS=0, DS without array bias &#40;BC0=1&#41;&#41; |
| cycle_fact:41 | ledger:102: truth_table_row&#40;BIAS_SHUTDOWN, BC0=0/1, BC1=0/1, BC2=0/1, SD=1, DS=0, LS=0, Shutdown mode without array retention&#41; |
| cycle_fact:42 | ledger:103: truth_table_row&#40;R01_SD_AND_DS_ILLEGAL, SD=1, DS=1 &#40;Advanced power mode&#41;, Q/QP/SO forced 0; array: Shutdown wins, retention not guaranteed, full SD wake required&#41; |
| cycle_fact:43 | ledger:104: truth_table_row&#40;R02_SLEEP_OVERLAP_ILLEGAL, SD=1 and LS=1, or DS=1 and LS=1 &#40;Advanced power mode&#41;, Q/QP/SO = power-mode value &#40;0 in DS/SD&#41;; array: deeper mode wins, LS must be deasserted before wake&#41; |
| cycle_fact:44 | ledger:105: truth_table_row&#40;R04_POFF_SD_ILLEGAL, POFF=01 with SD=1, or POFF=11 with DS-only request, Q/QP/SO = X; array: destructive mode wins if either request is destructive&#41; |
| cycle_fact:45 | ledger:106: truth_table_row&#40;R05_CLOCK_IN_POWERDOWN_ILLEGAL, Rising CLK or TCLK while DS, SD, or POFF active, No valid output event; powered outputs retain forced value; array follows selected power mode&#41; |
| cycle_fact:46 | ledger:107: truth_table_row&#40;R08_TPR_CLOCKGATED_IDLE, TPR=1, ME=1, Q=Q-1; no read/write, ADR/D/WE/WEM changes ignored&#41; |
| cycle_fact:47 | ledger:108: truth_table_row&#40;R10_BISTE_FUNC_CLK_IGNORED, BISTE=1, TCLKE selects TCLK, functional CLK toggles, BIST result only; functional CLK has no effect&#41; |
| cycle_fact:48 | ledger:109: truth_table_row&#40;R12_BISTE_HANDOFF_ILLEGAL, BISTE changes while ME=1 or TME=1, or while selected clock is high, Q/QP = X until one clean inactive cycle; word/bit mask may be corrupted if WE/TWE active&#41; |
| cycle_fact:49 | ledger:110: truth_table_row&#40;R13_SE_IN_WITH_DFTMASK_ILLEGAL, SE_IN=1, DFTMASK=1, Scan output advances; Q=X; array not accessed, SE_IN scan ownership wins&#41; |
| cycle_fact:50 | ledger:111: truth_table_row&#40;R14_DFTMASK_NO_DFTCLKEN_ILLEGAL, DFTMASK=1, DFTCLKEN=0, Q=Q-1, diagnostic issued; array not accessed&#41; |
| cycle_fact:51 | ledger:112: truth_table_row&#40;R15_TEST_RNM_OVERLAP_ILLEGAL, TEST_RNM=1 with BISTE=1 or SE_IN=1 or DFTMASK=1 or TEST1=1, Q=X; array retained&#41; |
| cycle_fact:52 | ledger:113: truth_table_row&#40;R21_UNIMPL_ADDR_ILLEGAL, ADR encodes an unimplemented location, Q=X; writes ignored, no aliasing&#41; |
| cycle_fact:53 | ledger:114: truth_table_row&#40;R22_CAPT_IN_FUNCTIONAL_IGNORED, CAPT=0, BISTE=0, No effect; comparator state unchanged&#41; |
| cycle_fact:54 | ledger:115: truth_table_row&#40;R23_PIPEME_TPIPEME_SELECT, PIPEME=1, TPIPEME=1, QP captures from PIPEME when BISTE=0, TPIPEME when BISTE=1; non-selected enable ignored&#41; |
| cycle_fact:55 | ledger:116: truth_table_row&#40;R24_POWER_DURING_SCAN_ILLEGAL, Power mode &#40;LS/DS/SD/POFF&#41; asserted during scan shift, Deep-mode output convention; scan state not guaranteed&#41; |
| cycle_fact:56 | ledger:117: truth_table_row&#40;IDLE_TO_ACTIVE, LS=DS=SD=0, POFF inactive, selected enable &#40;ME&#41; asserted with setup met, One valid clock edge; data preserved; normal tCQ behavior&#41; |
| cycle_fact:57 | ledger:118: truth_table_row&#40;ACTIVE_TO_IDLE, Deassert ME/TME; complete any TEST1 falling edge, Last Q/QP retained; data preserved&#41; |
| cycle_fact:58 | ledger:119: truth_table_row&#40;IDLE_TO_LS, Assert LS while DS=SD=0 and POFF inactive; clocks quiescent; ME=TME=0, Q/QP/SO retain prior values; data retained&#41; |
| cycle_fact:59 | ledger:120: truth_table_row&#40;LS_TO_IDLE, Deassert LS; hold ME=TME=0, Prior values retained; data retained&#41; |
| cycle_fact:60 | ledger:121: truth_table_row&#40;IDLE_TO_DS, Clocks low, ME=TME=0, LS=SD=0, assert DS, Q/QP/SO forced 0, ROP_DS=1; data retained if VDDA in retention range&#41; |
| cycle_fact:61 | ledger:122: truth_table_row&#40;DS_TO_WAKE_DS, Deassert DS while LS=SD=0 and clocks remain low, Q=0, QP/SO=X, ROP_DS=1; data retained&#41; |
| cycle_fact:62 | ledger:123: truth_table_row&#40;WAKE_DS_TO_IDLE, Wait until ROP_DS=0, then one guard cycle &#40;tROPDS + tPGGUARD&#41;, Outputs become valid after guard; data retained&#41; |
| cycle_fact:63 | ledger:124: truth_table_row&#40;DS_TO_SD, Assert SD while clocks remain low, Outputs forced 0, ROP_SD=1; data destroyed/unknown&#41; |
| cycle_fact:64 | ledger:125: truth_table_row&#40;IDLE_TO_SD, Clocks low, ME=TME=0, LS=DS=0, assert SD, Q/QP/SO forced 0, ROP_SD=1; data destroyed/unknown&#41; |
| cycle_fact:65 | ledger:126: truth_table_row&#40;SD_TO_WAKE_SD, Restore supplies, then deassert SD; keep all enables low, Q=0, QP/SO=X, ROP_SD=1; data unknown, initialization/BIST required&#41; |
| cycle_fact:66 | ledger:127: truth_table_row&#40;WAKE_SD_TO_IDLE, Wait until ROP_SD=0, then apply tPGGUARD &#40;tROPSD + tPGGUARD&#41;, Outputs valid electrically; data still unknown until written&#41; |
| cycle_fact:67 | ledger:128: truth_table_row&#40;IDLE_TO_SCAN, Both clocks low, BISTE=0, assert SE_IN, then enable DFT clock &#40;DFTCLKEN&#41;, SO follows scan timing; Q not functionally updated; array preserved&#41; |
| cycle_fact:68 | ledger:129: truth_table_row&#40;IDLE_TO_BIST, Both clocks low, SE_IN=0, establish TCLKE, assert BISTE, wait one inactive selected-clock cycle, BIST owns all muxed inputs; data preserved until BIST writes&#41; |
| cycle_fact:69 | ledger:130: truth_table_row&#40;SCAN_OR_BIST_TO_IDLE, Deassert DFTCLKEN or TME first, selected clock low, deassert SE_IN/BISTE, wait one inactive cycle, Last test outputs may persist; deassert DFTCLKEN/TME first, selected clock low, deassert owner, wait one inactive cycle&#41; |
| cycle_fact:70 | ledger:131: truth_table_row&#40;ILLEGAL_STATE_JUMP, Any powered state to another owner or power state without passing through IDLE, X or deeper-mode clamp per Section 3.8&#41; |
| cycle_fact:71 | ledger:132: truth_table_row&#40;POST_WAKE_DS_ACCESS, After DS wake: ROP_DS=0 plus guard cycle &#40;tPGGUARD&#41;, Read returns previously stored data if retention voltage continuously met; write normal&#41; |
| cycle_fact:72 | ledger:133: truth_table_row&#40;POST_WAKE_SD_ACCESS, After SD or destructive POFF wake, Only write, initialization sequence, or destructive BIST is legal; reading before init is legal electrically but data unknown; first write establishes validity&#41; |
| cycle_fact:73 | ledger:134: truth_table_row&#40;POST_WAKE_LS_ACCESS, After LS exit: tLSEXT, Read returns previously stored data; write normal&#41; |
| cycle_fact:74 | ledger:135: truth_table_row&#40;READ_PIPELINE_DFTCLKEN1, DFTCLKEN=1, Pipeline flop input = D/TD XOR WEM/TWEM; clock applied to scan chains independent of PIPEME; QP carries pipeline output&#41; |
| cycle_fact:75 | ledger:136: truth_table_row&#40;READ_PIPELINE_DFTCLKEN0, DFTCLKEN=0, Pipeline flop input = memory output &#40;Q&#41;; clock to flop controlled by PIPEME&#41; |
| cycle_fact:76 | ledger:137: truth_table_row&#40;BIST_CAPTURE_CAPT0_STICKY0, CAPT=0, STICKY=0, BIST compare capture, Latest comparison replaces prior comparison-register contents&#41; |
| cycle_fact:77 | ledger:138: truth_table_row&#40;BIST_CAPTURE_CAPT0_STICKY1, CAPT=0, STICKY=1, BIST compare capture, Latest mismatch ORed with existing sticky failure state&#41; |
| cycle_fact:78 | ledger:139: truth_table_row&#40;BIST_CAPTURE_CAPT1, CAPT=1, BIST compare cycle, Comparison register holds its prior state&#41; |
| cycle_fact:79 | ledger:140: truth_table_row&#40;DFTMASK_WRITE_THROUGH, DFTMASK=1, DFTCLKEN=1, SE_IN=0, Q captures D synchronously; memory array unchanged irrespective of ME/WE&#41; |
| cycle_fact:80 | ledger:141: truth_table_row&#40;WRITE_THEN_READ_SAME_ADDR, Valid write on cycle N, valid read of same ADR on cycle N+1, Read returns newly written bits and preserved masked bits; no bypass implied&#41; |
| cycle_fact:81 | ledger:142: truth_table_row&#40;READ_THEN_WRITE_SAME_ADDR, Read on cycle N, write on same ADR on cycle N+1, Q from read remains visible until normal output policy updates; write changes array at N+1&#41; |
| cycle_fact:82 | ledger:143: truth_table_row&#40;PIPEME_ONE_CYCLE_PULSE, PIPEME=1 for one qualified read edge, then 0, QP captures exactly one result and retains until next enabled pipeline capture&#41; |
| cycle_fact:83 | ledger:144: truth_table_row&#40;BACK_TO_BACK_READS, ADR A on cycle N, ADR B on cycle N+1, ME=1, WE=0, Q presents A then B at respective tCQ; QP presents each one pipeline cycle later when enabled&#41; |
| fact:ddf-57642edf | The pipeline output QP follows the regular output Q with a latency of one clock cycle &#40;datasheet: 'follow the regular output with a latency of one clock cycle'&#41;; RTL: 'One-cycle pipeline stage. QP carries the pipeline result, not Q.' |
| directive:0 | Verify mission-mode read and write operations |
| directive:1 | Verify the scan shift path |
| directive:2 | Verify BIST-mode operation |
| directive:3 | Verify the deep-sleep/shutdown retention sequence |

Every pin in the inventory above is also citable evidence as `pin:<NAME>`.

## Evidence gaps

- No deck model: pin directions come from the logged pin facts only. The corner rules read those same logged directions.
