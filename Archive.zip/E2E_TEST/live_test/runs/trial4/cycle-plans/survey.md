# Corner Survey

Schema: esp.corner-roster.v1
Corpus digest: c17a7e22c4f461acf3260d761916a9b65e5d12e42402888da6f520aba1ece71a
Ledger facts: 59 pin(s), 106 operation(s), 2 scalar(s)

## Roster

| Corner | Classification | Reason |
| --- | --- | --- |
| calibration | unresolved | no supporting fact |
| clock-gating | unresolved | no supporting fact |
| idle | unresolved | no supporting fact |
| low-power-sequence | directive_named | directive named the corner: Verify the deep-sleep/shutdown retention sequence |
| mission-mode-read-write | directive_named | directive named the corner: Verify mission-mode read and write operations |
| multi-port-contention | absent | structurally impossible: single-port from typed pins ADR, BC0, BC1, BC2, BISTE, CAPT, CD, CLK, CRE1, CRE2, D, DFTCLKEN, DFTMASK, DS, FCA1, FCA2, FRA, HW, LS, ME, PIPEME, POFF, Q, QP, RA, RM, RME, ROP_DS, ROP_SD, RRE, SD, SE_IN, SI_CNTR, SI_D_H, SI_D_L, SI_Q_H, SI_Q_L, SO_CNTR, SO_D_H, SO_D_L, SO_Q_H, SO_Q_L, STICKY, TADR, TCLK, TCLKE, TD, TEST1, TEST_RNM, THW, TME, TPIPEME, TPR, TWE, TWEM, WA, WE, WEM, WPULSE |
| redundancy | candidate | pin-name rule matched CRE1, CRE2, FCA1, FCA2, FRA, RRE |
| scan-dft | directive_named | directive named the corner: Verify the scan shift path; Verify BIST-mode operation |
| bist-mode-operation | fact_supported | function_corner fact 63: With BISTE asserting BIST ownership and TCLKE selecting TCLK, the BIST port &#40;TME/TWE/TADR/TD/TWEM/THW&#41; drives the macro; BIST compare capture stores the comparison result per CAPT/STICKY semantics. |
| deep-sleep-shutdown-retention | fact_supported | function_corner fact 64: Deep Sleep gates the periphery and forces Q/QP/SO to 0 while the array retains data; Shutdown destroys contents; the ROP_DS/ROP_SD wake sequence &#40;guard cycle, post-wake access rules&#41; restores normal operation. |
| scan-shift-path | fact_supported | function_corner fact 62: With SE_IN asserting scan ownership, the Q, D and control scan chains shift SI_* through to SO_*, entered and exited via the IDLE-&gt;SCAN-&gt;IDLE guard sequence with the array preserved. |

## Certified selection

- mission-mode-read-write
- low-power-sequence
- scan-dft
- bist-mode-operation
- deep-sleep-shutdown-retention
- scan-shift-path
- redundancy

## Pin inventory

| Pin | Direction |
| --- | --- |
| ADR | input |
| BC0 | input |
| BC1 | input |
| BC2 | input |
| BISTE | input |
| CAPT | input |
| CD | input |
| CLK | input |
| CRE1 | input |
| CRE2 | input |
| D | input |
| DFTCLKEN | input |
| DFTMASK | input |
| DS | input |
| FCA1 | input |
| FCA2 | input |
| FRA | input |
| HW | input |
| LS | input |
| ME | input |
| PIPEME | input |
| POFF | input |
| Q | output |
| QP | output |
| RA | input |
| RM | input |
| RME | input |
| ROP_DS | output |
| ROP_SD | output |
| RRE | input |
| SD | input |
| SE_IN | input |
| SI_CNTR | input |
| SI_D_H | input |
| SI_D_L | input |
| SI_Q_H | input |
| SI_Q_L | input |
| SO_CNTR | output |
| SO_D_H | output |
| SO_D_L | output |
| SO_Q_H | output |
| SO_Q_L | output |
| STICKY | input |
| TADR | input |
| TCLK | input |
| TCLKE | input |
| TD | input |
| TEST1 | input |
| TEST_RNM | input |
| THW | input |
| TME | input |
| TPIPEME | input |
| TPR | input |
| TWE | input |
| TWEM | input |
| WA | input |
| WE | input |
| WEM | input |
| WPULSE | input |

## Evidence catalog

| Ref | Evidence |
| --- | --- |
| cycle_fact:0 | ledger:65: truth_table_row&#40;IDLE, CLK=L, ME=X, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1 &#40;remains same state&#41;, NCM &#40;no change in memory contents&#41;&#41; |
| cycle_fact:1 | ledger:66: truth_table_row&#40;DISABLED, CLK=H, ME=L, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, NCM &#40;memory deactivated&#41;&#41; |
| cycle_fact:2 | ledger:67: truth_table_row&#40;DISABLED, CLK=H, ME=X, TPR=H, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, NCM &#40;TPR gates internal toggling&#41;&#41; |
| cycle_fact:3 | ledger:68: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, NCM &#40;both halves disabled by HW=00&#41;&#41; |
| cycle_fact:4 | ledger:69: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=QH-1/QL &#40;upper half retains, lower half reads&#41;&#41; |
| cycle_fact:5 | ledger:70: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=QH/QL-1 &#40;lower half retains, upper half reads&#41;&#41; |
| cycle_fact:6 | ledger:71: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q &#40;output of addressed location, no CLK latency&#41;&#41; |
| cycle_fact:7 | ledger:72: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, NCM &#40;both halves disabled by HW=00&#41;&#41; |
| cycle_fact:8 | ledger:73: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, Array&#91;L&#93;=Data-in&#91;L&#93; &#40;lower half written&#41;&#41; |
| cycle_fact:9 | ledger:74: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, Array&#91;H&#93;=Data-in&#91;H&#93; &#40;upper half written&#41;&#41; |
| cycle_fact:10 | ledger:75: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, Array=Data-in &#40;both halves written&#41;&#41; |
| cycle_fact:11 | ledger:76: truth_table_row&#40;MASK, CLK=H, ME=H, TPR=L, HW=XX, WE=H, WEM=L, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, TEST1=L, Q=Q-1, NCM &#40;write masked&#41;&#41; |
| cycle_fact:12 | ledger:77: truth_table_row&#40;NORMAL, ME=0/1, HW=hw_val, LS=0, DS=0, SD=0, POFF=00, BC0=0/1, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=QP-1, SO=SO-1 &#40;normal mode&#41;&#41; |
| cycle_fact:13 | ledger:78: truth_table_row&#40;LIGHT_SLEEP, ME=0/1, HW=XX, LS=1, DS=0, SD=0, POFF=00, BC0=0/1, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=QP-1, SO=SO-1 &#40;Xdec power gate, source bias&#41;&#41; |
| cycle_fact:14 | ledger:79: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0-&gt;1, SD=0, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:15 | ledger:80: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1-&gt;0, SD=0, POFF=00, BC0=0/1, ROP_DS=0, ROP_SD=ROP_SD-1, Q=0, QP=X, SO=X &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:16 | ledger:81: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0-&gt;1, SD=1, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:17 | ledger:82: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1-&gt;0, SD=1, POFF=00, BC0=0/1, ROP_DS=1, ROP_SD=ROP_SD-1, Q=0, QP=0, SO=0 &#40;periphery shutdown, source bias&#41;&#41; |
| cycle_fact:18 | ledger:83: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0-&gt;1, POFF=00, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=1, Q=0, QP=0, SO=0 &#40;periphery shutdown, array shutdown&#41;&#41; |
| cycle_fact:19 | ledger:84: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1-&gt;0, POFF=00, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=0, Q=0, QP=X, SO=X &#40;periphery shutdown, array shutdown&#41;&#41; |
| cycle_fact:20 | ledger:85: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0-&gt;1, POFF=00, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=1, Q=0, QP=0, SO=0 &#40;periphery shutdown, array shutdown&#41;&#41; |
| cycle_fact:21 | ledger:86: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1-&gt;0, POFF=00, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=1, Q=0, QP=0, SO=0 &#40;periphery shutdown, array shutdown&#41;&#41; |
| cycle_fact:22 | ledger:87: truth_table_row&#40;STANDARD_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=01, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=X, SO=X &#40;periphery shutdown, source bias, VDD can be floating&#41;&#41; |
| cycle_fact:23 | ledger:88: truth_table_row&#40;SHUTDOWN_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=11, BC0=X, ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1, Q=Q-1, QP=X, SO=X &#40;periphery shutdown, array shutdown, VDD can be floating&#41;&#41; |
| cycle_fact:24 | ledger:89: truth_table_row&#40;NORMAL_MODE, BISTE=L, Active pins: ME, WE, ADR, D, WEM, CLK &#40;functional path owns the macro&#41;&#41; |
| cycle_fact:25 | ledger:90: truth_table_row&#40;BIST_MODE, BISTE=H, Active pins: TME, TWE, TADR, TD, TWEM, TCLK; TCLKE selects CLK/TCLK clock source&#41; |
| cycle_fact:26 | ledger:91: truth_table_row&#40;COLUMN_REPAIR_NORMAL, CRE1=0, CRE2=0, FCA1=X, FCA2=X, No repair element selected&#41; |
| cycle_fact:27 | ledger:92: truth_table_row&#40;COLUMN_REPAIR_LEFT, CRE1=1, CRE2=0, FCA1=FCA1&#91;n&#93;, FCA2=X, Faulty column on left side replaced by left redundant column&#41; |
| cycle_fact:28 | ledger:93: truth_table_row&#40;COLUMN_REPAIR_RIGHT, CRE1=0, CRE2=1, FCA1=X, FCA2=FCA2&#91;n&#93;, Faulty column on right side replaced by right redundant column&#41; |
| cycle_fact:29 | ledger:94: truth_table_row&#40;COLUMN_REPAIR_BOTH, CRE1=1, CRE2=1, FCA1=FCA1&#91;n&#93;, FCA2=FCA2&#91;n&#93;, Faulty column on both sides replaced by respective redundant columns&#41; |
| cycle_fact:30 | ledger:95: truth_table_row&#40;ROW_REPAIR_NORMAL, RRE=0, FRA=X, No repair element selected&#41; |
| cycle_fact:31 | ledger:96: truth_table_row&#40;ROW_REPAIR, RRE=1, FRA=FRA&#91;n&#93;, Faulty row replaced by redundant row element&#41; |
| cycle_fact:32 | ledger:97: truth_table_row&#40;BIAS_NORMAL, BC0=0/1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=0, no bias operation&#41; |
| cycle_fact:33 | ledger:98: truth_table_row&#40;BIAS_LS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=0, LS=1, Non recommended, debug mode during LS&#41; |
| cycle_fact:34 | ledger:99: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=0, SD=0, DS=0, LS=1, LS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:35 | ledger:100: truth_table_row&#40;BIAS_LS, BC0=0, BC1=0, BC2=1, SD=0, DS=0, LS=1, LS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:36 | ledger:101: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=1, SD=0, DS=0, LS=1, LS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:37 | ledger:102: truth_table_row&#40;BIAS_LS_NOBIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=1, LS without array bias &#40;BC0=1 bypasses bias&#41;&#41; |
| cycle_fact:38 | ledger:103: truth_table_row&#40;BIAS_DS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=1, LS=0, Non recommended, debug mode during DS&#41; |
| cycle_fact:39 | ledger:104: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=0, SD=0, DS=1, LS=0, DS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:40 | ledger:105: truth_table_row&#40;BIAS_DS, BC0=0, BC1=0, BC2=1, SD=0, DS=1, LS=0, DS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:41 | ledger:106: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=1, SD=0, DS=1, LS=0, DS with array bias &#40;recommended for Vnom-10% to Vmax&#41;&#41; |
| cycle_fact:42 | ledger:107: truth_table_row&#40;BIAS_DS_NOBIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=1, LS=0, DS without array bias &#40;BC0=1 bypasses bias&#41;&#41; |
| cycle_fact:43 | ledger:108: truth_table_row&#40;BIAS_SHUTDOWN, BC0=0/1, BC1=0/1, BC2=0/1, SD=1, DS=0, LS=0, Shutdown mode without array retention&#41; |
| cycle_fact:44 | ledger:109: truth_table_row&#40;R01_SD_AND_DS_ILLEGAL, SD=1, DS=1 &#40;Advanced power mode&#41;, Q/QP/SO forced 0; array: Shutdown wins, retention not guaranteed, full SD wake sequence required&#41; |
| cycle_fact:45 | ledger:110: truth_table_row&#40;R02_SLEEP_OVERLAP_ILLEGAL, SD=1 and LS=1, or DS=1 and LS=1 &#40;Advanced power mode&#41;, Q/QP/SO = power-mode value &#40;0 in DS/SD&#41;; array: deeper mode wins, LS must be deasserted before wake&#41; |
| cycle_fact:46 | ledger:111: truth_table_row&#40;R03_POFF_BC0_ILLEGAL, Embedded dual rail POFF=2'b10 while BC0=0 &#40;BC0 debug periphery-off mode&#41;, Q/QP/SO = X; array retained; assert BC0 before entering POFF=10&#41; |
| cycle_fact:47 | ledger:112: truth_table_row&#40;R04_POFF_SD_ILLEGAL, Embedded dual rail POFF=2'b01 with SD=1, or POFF=2'b11 with DS-only request &#40;Power transition&#41;, Q/QP/SO = X; array: destructive mode wins if either request is destructive&#41; |
| cycle_fact:48 | ledger:113: truth_table_row&#40;R05_CLOCK_IN_POWERDOWN_ILLEGAL, Any rising CLK/TCLK while DS, SD, or POFF is active &#40;Powered-down state&#41;, No valid output event; powered outputs retain forced value; array follows selected power mode; clock must be quiescent before power-mode assertion&#41; |
| cycle_fact:49 | ledger:114: truth_table_row&#40;R06_HW00_WRITE_NOOP, ME=1, WE=1, HW=00 &#40;Normal write&#41;, Q retains Q-1; no bits written, irrespective of WEM&#41; |
| cycle_fact:50 | ledger:115: truth_table_row&#40;R07_DISABLED_HALF_MASKED_NOOP, ME=1, WE=1, any selected WEM=1, but its corresponding half disabled by HW &#40;Normal write&#41;, Q retains Q-1; disabled-half cells retain data; HW has priority over WEM&#41; |
| cycle_fact:51 | ledger:116: truth_table_row&#40;R08_TPR_CLOCKGATED_IDLE, TPR=1 while ME=1 &#40;Normal access&#41;, Q retains Q-1; no read/write; ADR/D/WE/WEM changes ignored until TPR setup to next active edge is met&#41; |
| cycle_fact:52 | ledger:117: truth_table_row&#40;R09_TPR_APERTURE_ILLEGAL, TPR changes inside its CLK setup/hold aperture while ME=1 &#40;Normal access&#41;, Q=X for current access; write cycle corrupts current selected WEM bits; read does not alter array&#41; |
| cycle_fact:53 | ledger:118: truth_table_row&#40;R10_BISTE_FUNC_CLK_IGNORED, BISTE=1 and functional CLK toggles while TCLKE selects TCLK &#40;BIST mode&#41;, BIST result only; functional CLK has no effect&#41; |
| cycle_fact:54 | ledger:119: truth_table_row&#40;R11_TCLKE_HIGH_SWITCH_ILLEGAL, TCLKE toggles while either CLK or TCLK is high &#40;BIST clock selection&#41;, Q/QP/SO = X for one cycle; a runt internal clock may corrupt the current address on a write; switch only with both clocks low&#41; |
| cycle_fact:55 | ledger:120: truth_table_row&#40;R12_BISTE_HANDOFF_ILLEGAL, BISTE changes while ME=1 or TME=1, or while selected clock is high &#40;Ownership handoff&#41;, Q/QP = X until one clean inactive cycle; if WE or TWE was active, selected word/bit mask is corrupted&#41; |
| cycle_fact:56 | ledger:121: truth_table_row&#40;R13_SE_IN_WITH_DFTMASK_ILLEGAL, SE_IN=1 with DFTMASK=1 &#40;Scan/ATPG&#41;, Scan output advances; Q=X; array not accessed; SE_IN scan ownership wins&#41; |
| cycle_fact:57 | ledger:122: truth_table_row&#40;R14_DFTMASK_NO_DFTCLKEN_ILLEGAL, DFTMASK=1 and DFTCLKEN=0 &#40;Synchronous write-through&#41;, Q retains Q-1; diagnostic issued; array not accessed by DFTMASK&#41; |
| cycle_fact:58 | ledger:123: truth_table_row&#40;R15_TEST_RNM_OVERLAP_ILLEGAL, TEST_RNM=1 with BISTE=1, SE_IN=1, DFTMASK=1, or TEST1=1 &#40;Test modes&#41;, Q=X; array retained; TEST_RNM idle/precharge containment wins below power modes&#41; |
| cycle_fact:59 | ledger:124: truth_table_row&#40;R16_TEST1_INCOMPLETE_CYCLE_ILLEGAL, TEST1=1 and CLK does not have both a valid rising and falling edge &#40;Self-time bypass&#41;, Read Q=X; write completion unknown; current selected word/bit mask is corrupted for a write&#41; |
| cycle_fact:60 | ledger:125: truth_table_row&#40;R17_RM_CHANGE_ILLEGAL, RME or RM changes with ME=1, or less than tRMSTB before an access &#40;Margin control&#41;, Current read Q=X; current selected WEM bits may be corrupted on write; RM must change only in idle&#41; |
| cycle_fact:61 | ledger:126: truth_table_row&#40;R18_ASSIST_DIFFER_ILLEGAL, WA, RA, or WPULSE differs from the table-selected value while not in authorized characterization test mode &#40;Functional operation&#41;, Q may be X; no broad corruption; current accessed word may be disturbed&#41; |
| cycle_fact:62 | ledger:127: truth_table_row&#40;R19_DUAL_ROW_REPAIR_COLLISION_ILLEGAL, RRE1=RRE2=1 and FRA1=FRA2 &#40;Dual row repair&#41;, Q=X on matching address; both repair selections suppressed; no functional write is allowed&#41; |
| cycle_fact:63 | ledger:128: truth_table_row&#40;R20_REPAIR_CHANGE_ILLEGAL, CRE/FCA or RRE/FRA changes while ME=1 or within repair setup/hold aperture &#40;Any functional access&#41;, Q=X on possible match; current logical and spare locations are both pessimistically corrupted for write&#41; |
| cycle_fact:64 | ledger:129: truth_table_row&#40;R21_UNIMPL_ADDR_ILLEGAL, ADR encodes an unimplemented location &#40;Non-power-of-two logical depth&#41;, Q=X; writes are ignored; no aliasing into a legal address is permitted&#41; |
| cycle_fact:65 | ledger:130: truth_table_row&#40;R22_CAPT_IN_FUNCTIONAL_IGNORED, CAPT=0 while BISTE=0 &#40;Functional mode&#41;, No effect; comparator state unchanged&#41; |
| cycle_fact:66 | ledger:131: truth_table_row&#40;R23_PIPEME_TPIPEME_SELECT, PIPEME=1 and TPIPEME=1 simultaneously &#40;BIST-capable instance&#41;, QP captures from PIPEME when BISTE=0, TPIPEME when BISTE=1; non-selected enable is ignored&#41; |
| cycle_fact:67 | ledger:132: truth_table_row&#40;R24_POWER_DURING_SCAN_ILLEGAL, Power mode &#40;LS/DS/SD/POFF&#41; asserted during scan shift &#40;Scan/low-power overlap&#41;, Deep-mode output convention; scan state is not guaranteed; array retention follows selected power mode&#41; |
| cycle_fact:68 | ledger:133: truth_table_row&#40;IDLE_TO_ACTIVE, LS=DS=SD=0, POFF inactive, selected enable &#40;ME&#41; asserted with setup met, One valid clock edge; data preserved; normal tCQ behavior; legal&#41; |
| cycle_fact:69 | ledger:134: truth_table_row&#40;ACTIVE_TO_IDLE, Deassert ME/TME; complete any TEST1 falling edge, One full inactive clock cycle before ownership/power changes; last Q/QP retained; data preserved&#41; |
| cycle_fact:70 | ledger:135: truth_table_row&#40;IDLE_TO_LS, Assert LS while DS=SD=0 and POFF inactive; clocks quiescent; ME=TME=0, Dwell tLSENT; Q/QP/SO retain prior values; data retained&#41; |
| cycle_fact:71 | ledger:136: truth_table_row&#40;LS_TO_IDLE, Deassert LS; hold ME=TME=0, tLSEXT before next active clock; prior values retained; data retained&#41; |
| cycle_fact:72 | ledger:137: truth_table_row&#40;ACTIVE_TO_LS_DIRECT_FORBIDDEN, First transition ACTIVE-&gt;IDLE required, No direct transition; not legal&#41; |
| cycle_fact:73 | ledger:138: truth_table_row&#40;IDLE_TO_DS, Clocks low; ME=TME=0; LS=SD=0; assert DS, Dwell tDSENT; Q/QP/SO forced 0, ROP_DS=1; data retained if VDDA remains in retention range&#41; |
| cycle_fact:74 | ledger:139: truth_table_row&#40;DS_TO_WAKE_DS, Deassert DS while LS=SD=0 and clocks remain low, Immediate state entry; Q=0, QP/SO=X, ROP_DS=1; data retained&#41; |
| cycle_fact:75 | ledger:140: truth_table_row&#40;WAKE_DS_TO_IDLE, Wait until ROP_DS=0, then one guard cycle &#40;tROPDS + tPGGUARD&#41;, Outputs become valid after guard; data retained&#41; |
| cycle_fact:76 | ledger:141: truth_table_row&#40;DS_TO_SD, Assert SD while clocks remain low, Dwell tSDFALL; outputs forced 0, ROP_SD=1; data destroyed/unknown; destructive&#41; |
| cycle_fact:77 | ledger:142: truth_table_row&#40;IDLE_TO_SD, Clocks low; ME=TME=0; LS=DS=0; assert SD, Dwell tSDENT; Q/QP/SO forced 0, ROP_SD=1; data destroyed/unknown upon assertion; destructive&#41; |
| cycle_fact:78 | ledger:143: truth_table_row&#40;SD_TO_WAKE_SD, Restore supplies, then deassert SD; keep all enables low, Immediate state entry; Q=0, QP/SO=X, ROP_SD=1; data unknown, initialization/BIST required&#41; |
| cycle_fact:79 | ledger:144: truth_table_row&#40;WAKE_SD_TO_IDLE, Wait until ROP_SD=0, then apply tPGGUARD &#40;tROPSD + tPGGUARD&#41;, Outputs valid electrically, data still unknown until written&#41; |
| cycle_fact:80 | ledger:145: truth_table_row&#40;IDLE_TO_POFF_RET, Embedded: POFF 00-&gt;01; periphery clock stopped, Dwell tPOFFENT; Q/QP/SO=X after periphery supply collapse; data retained if VDDA valid&#41; |
| cycle_fact:81 | ledger:146: truth_table_row&#40;POFF_RET_TO_IDLE, Restore VDD first, wait tVDDSTB, then remove POFF, Dwell tVDDSTB + tPGGUARD; X until periphery is stable; data retained&#41; |
| cycle_fact:82 | ledger:147: truth_table_row&#40;IDLE_TO_POFF_SD, POFF 00-&gt;11 with clocks/enables inactive, Dwell tPOFFENT; Q/QP/SO=X; data destroyed; destructive&#41; |
| cycle_fact:83 | ledger:148: truth_table_row&#40;LS_TO_DS, Deassert LS, wait tLSEXT, then assert DS, Dwell tLSEXT; data retained; last Q then forced 0; sequenced&#41; |
| cycle_fact:84 | ledger:149: truth_table_row&#40;DS_TO_LS, Complete DS-&gt;WAKE_DS-&gt;IDLE, then assert LS, Full DS wake sequence; data retained; sequenced only&#41; |
| cycle_fact:85 | ledger:150: truth_table_row&#40;IDLE_TO_SCAN, Both clocks low; BISTE=0; assert SE_IN; then enable DFT clock &#40;DFTCLKEN&#41;, One clock-low phase; array preserved; SO follows scan timing; Q not functionally updated&#41; |
| cycle_fact:86 | ledger:151: truth_table_row&#40;IDLE_TO_BIST, Both clocks low; SE_IN=0; establish TCLKE; assert BISTE; wait one inactive selected-clock cycle, One inactive cycle; data preserved until BIST writes; BIST owns all muxed inputs&#41; |
| cycle_fact:87 | ledger:152: truth_table_row&#40;SCAN_OR_BIST_TO_IDLE, Deassert DFTCLKEN/TME first; selected clock low; deassert owner; wait one inactive cycle, One inactive cycle; last test outputs may persist; array as modified by test&#41; |
| cycle_fact:88 | ledger:153: truth_table_row&#40;ANY_STATE_TO_OTHER_NO_GUARD_FORBIDDEN, Any powered state to another owner or power state without passing through IDLE, X or deeper-mode clamp per Section 3.8; not legal&#41; |
| cycle_fact:89 | ledger:154: truth_table_row&#40;POST_WAKE_LS_ACCESS, After LS exit: tLSEXT, then read or write, First-read expectation: previously stored data; write expectation: normal&#41; |
| cycle_fact:90 | ledger:155: truth_table_row&#40;POST_WAKE_DS_ACCESS, After DS wake: ROP_DS=0 plus guard cycle &#40;tPGGUARD&#41;, then read or write, First-read expectation: previously stored data if retention voltage was continuously met; write expectation: normal&#41; |
| cycle_fact:91 | ledger:156: truth_table_row&#40;POST_WAKE_POFF_ACCESS, After retentive POFF: VDD stable, POFF inactive, guard complete, then read or write, First-read expectation: previously stored data if VDDA remained valid; write expectation: normal&#41; |
| cycle_fact:92 | ledger:157: truth_table_row&#40;POST_WAKE_SD_ACCESS, After SD or destructive POFF wake: write, initialization sequence, or destructive BIST only, First-read expectation: X; reading before initialization is legal electrically but data is unknown; write expectation: first write establishes validity only for written WEM/HW bits&#41; |
| cycle_fact:93 | ledger:158: truth_table_row&#40;FULLY_MASKED_WRITE, ME=1, WE=1, all selected-half WEM=0, No memory change; Q and QP retain prior value&#41; |
| cycle_fact:94 | ledger:159: truth_table_row&#40;PARTIALLY_MASKED_WRITE, ME=1, WE=1, mixed WEM, Only bits with both WEM=1 and corresponding HW half enabled are written&#41; |
| cycle_fact:95 | ledger:160: truth_table_row&#40;WRITE_THEN_READ_SAME_ADDR, Valid write on cycle N, valid read of same ADR on cycle N+1, Read returns newly written bits and preserved masked bits; no bypass implied&#41; |
| cycle_fact:96 | ledger:161: truth_table_row&#40;READ_THEN_WRITE_SAME_ADDR, Read on cycle N, write on same ADR on cycle N+1, Q from read remains visible until normal output policy updates; write changes array at N+1&#41; |
| cycle_fact:97 | ledger:162: truth_table_row&#40;BACK_TO_BACK_READS, ADR A on cycle N, ADR B on cycle N+1, ME=1, WE=0, Q presents A then B at respective tCQ; QP presents each one pipeline cycle later when enabled&#41; |
| cycle_fact:98 | ledger:163: truth_table_row&#40;PIPEME_ONE_CYCLE_PULSE, PIPEME=1 for one qualified read edge, then 0, QP captures exactly one result and retains it until next enabled pipeline capture&#41; |
| cycle_fact:99 | ledger:164: truth_table_row&#40;RM_CHANGE_WHILE_IDLE, ME=TME=0, clocks low, RME/RM stable for tRMSTB before next access, Legal; first subsequent access uses new margin timing&#41; |
| cycle_fact:100 | ledger:165: truth_table_row&#40;BIST_CAPTURE_CAPT0_STICKY0, CAPT and STICKY=0 &#40;BIST compare capture&#41;, Latest comparison replaces prior comparison-register contents&#41; |
| cycle_fact:101 | ledger:166: truth_table_row&#40;BIST_CAPTURE_CAPT0_STICKY1, CAPT and STICKY=1 &#40;BIST compare capture&#41;, Latest mismatch is ORed with existing sticky failure state&#41; |
| cycle_fact:102 | ledger:167: truth_table_row&#40;BIST_CAPTURE_CAPT1, CAPT=1 &#40;any BIST compare cycle&#41;, Comparison register holds its prior state&#41; |
| cycle_fact:103 | ledger:168: truth_table_row&#40;TEST1_READ, TEST1=1; rising edge begins access, falling edge terminates it, Q becomes valid only after falling edge plus bypass-mode tCQ&#41; |
| cycle_fact:104 | ledger:169: truth_table_row&#40;DFTMASK_WRITE_THROUGH, DFTMASK=1, DFTCLKEN=1, SE_IN=0, Q captures D synchronously; memory array remains unchanged irrespective of ME/WE&#41; |
| cycle_fact:105 | ledger:170: truth_table_row&#40;OUTPUT_DURING_LIGHT_SLEEP, LS=1 after legal entry, Q/QP/SO retain their pre-sleep values; pin toggles do not cause accesses&#41; |
| fact:ddf-e768c0d3 | the pipeline output QP follows the regular output Q with a latency of one clock cycle, i.e. one registered stage between the read launch and QP |
| fact:ddf-1f84755e | the functional wrapper models every scan chain output as a combinational pass-through of its scan input while SE_IN=1, so one full chain traversal in the reference model is one logical shift |
| directive:0 | Verify mission-mode read and write operations |
| directive:1 | Verify the scan shift path |
| directive:2 | Verify BIST-mode operation |
| directive:3 | Verify the deep-sleep/shutdown retention sequence |

Every pin in the inventory above is also citable evidence as `pin:<NAME>`.

## Evidence gaps

- No deck model: pin directions come from the logged pin facts only. The corner rules read those same logged directions.
