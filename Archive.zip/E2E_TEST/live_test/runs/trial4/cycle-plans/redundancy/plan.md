# Cycle Plan — redundancy

- corner: redundancy
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial4
- corpus digest: c17a7e22c4f461acf3260d761916a9b65e5d12e42402888da6f520aba1ece71a
- outcome: unresolved

## Missing facts

| required fact | what it blocks | why | evidence examined |
|---|---|---|---|
| A reference model (or equivalent oracle) that represents the column/row repair remapping — spare-column substitution selected by `CRE1`/`CRE2`/`FCA1`/`FCA2` and spare-row substitution selected by `RRE`/`FRA` — so that a repair-enabled access can be compared. | Any sound comparison of repair-enabled read/write behaviour, which is the behaviour this corner exists to witness. | The survey states the functional reference wrapper **observes but does not model** `CRE1`/`CRE2`/`FCA1`/`FCA2`/`RRE`/`FRA` ("Repair, margin, assist, and bias controls are observed but not modelled"). With repair enabled and ADR matching the programmed repair target, a correct implementation returns the spare location's data while the reference returns the logical location's data: ESP's default reference-vs-implementation comparison flags a mismatch on a **correct** design. Conversely a dead repair element (enable programmed but no remap) compares clean. The comparison cannot discriminate either way, so it is not a sound witness for the remap. | `cycle_fact:26`, `cycle_fact:27`, `cycle_fact:28`, `cycle_fact:29`, `cycle_fact:30`, `cycle_fact:31`, `cycle_fact:63`, `cycle_fact:6`, `cycle_fact:10`, `cycle_fact:24`, `cycle_fact:12`; survey report (this corpus): wrapper "observed but not modelled" statement; survey Evidence gaps: "No deck model". |
| Widths of the repair-target fields `FCA1`, `FCA2`, `FRA` (which ADR/wordline bit selects the repaired column/row). | Precise constraint lowering of the repair programming (sized literals binding exactly the repair-target bits) in any follow-on plan; the pin inventory lists direction only. | A repair-programming constraint cannot name the bits it binds without the widths, and a slice of the wrong width constrains the wrong bits. Secondary to the row above: needed only once the reference-model question is answered. | `pin:FCA1`, `pin:FCA2`, `pin:FRA`, `pin:CRE1`, `pin:CRE2`, `pin:RRE`; survey pin inventory (direction only). |

## Why this corner is unresolved

**What the corner exists to witness.** The roster classified this corner by pin-name rule on the repair pins, and the repair mode tables define its object: with `CRE1=1`/`FCA1=n` the faulty left column is replaced by the left redundant column (`cycle_fact:27`); with `CRE2=1`/`FCA2=n` the right side (`cycle_fact:28`); with both, both sides (`cycle_fact:29`); with `RRE=1`/`FRA=n` the faulty row is replaced by the redundant row element (`cycle_fact:31`); with all enables deasserted no element is selected (`cycle_fact:26`, `cycle_fact:30`). A sound witness for this corner must put a repair selection in place and compare the remapped access against the documented effect.

**What a sound witness requires.** The remap effect must propagate to ESP's default comparison behaviour at Q. The accesses themselves are ordinary mission-mode READ/WRITE (`cycle_fact:6`, `cycle_fact:10`) inside NORMAL power mode (`cycle_fact:12`) with `BISTE=L` so the functional path owns the macro (`cycle_fact:24`); the launch-to-comparison arithmetic for such accesses is governed by A1 with `pipeline_depth` = 1 (`fact:ddf-e768c0d3`), i.e. comparison at ≥ launch + 1. None of that is the problem. The problem is the oracle for the remap.

**The divergence argument.** The survey states the functional reference wrapper observes but does not model the six repair pins. Three scenarios exhaust the possibilities:

- *Repair disabled* (`CRE1=CRE2=0`, `RRE=0`): the implementation behaves as the logical array, matching the reference. This slice would compare soundly — but it is mission-mode behaviour with repair explicitly off, it witnesses no repair selection, and holding the repair enables at 0 across the phase binds exactly the pins this corner exists to explore. It does not serve the corner.
- *Repair enabled, ADR matches the programmed target*: a correct implementation returns spare-location data; the reference returns logical-location data. Default comparison fails on a correct design. A sound plan cannot configure an expected divergence it is forbidden to mask (no masks, no checker numbers, no expected values), so this region cannot be a witness.
- *Repair enabled, ADR forced away from the programmed target*: the only way to keep the comparison clean is to constrain ADR off the programmed targets — deleting the match scenario, which is the corner's core — and even then the reference gives no oracle that the repair pins had any effect at all: a repair element that is programmed but dead is invisible.

**Legality is not observability.** The repair pins must be programmed in idle and held static while `ME=1` (`cycle_fact:63` R20: changing CRE/FCA or RRE/FRA during an access makes Q=X and pessimistically corrupts both logical and spare locations; one full inactive cycle is owed on exit, `cycle_fact:69`). The plan can drive that envelope faithfully — but the envelope constrains *where* the witness may drive the repair pins, and says nothing about whether the remap's effect can be *observed*. The witness can drive the programming and the accesses around it; the reference model cannot simulate the spare-column/row remapping, so a defect in the repair mux cannot be exposed at Q through the reference model. That is the corner's central defect class, and it is unobservable on this collateral.

**Why unresolved, not plan, not infeasible.** A `plan` outcome would have to claim the repair selection is witnessed; the best sound schedule the collateral supports is repair-disabled mission mode, which demotes the corner's own pins and catches at most a leaky/stuck-on repair enable. That is a different corner, and publishing it as `redundancy` would hand the run owner a green result that says nothing about whether repair works. `infeasible` is also wrong: nothing in ESP semantics or design evidence contradicts the request — ESP can verify repair semantics whenever the collateral models them. The absent fact is the reference model's representation of repair, which is precisely the `unresolved` condition: a soundness-critical fact is missing, named precisely, for the user to answer.

## Cycle counts

none — an unresolved corner publishes no schedule; deriving `b`/`s`/`f` before the Missing-facts questions are answered would invent the witness the collateral cannot support.

## Binary phase

Replaced by the Missing facts table (guide, unresolved form). No reset pin exists in the inventory and `reset_latency_cycles` is unbound/not applicable, so A5 would not bound `b`; the legality envelope for any future schedule (idle entry, repair programming with `ME=0`, one inactive cycle before ownership changes) would be built from `cycle_fact:63` and `cycle_fact:69` — but no schedule is published here.

## Symbolic phase

Replaced by the Missing facts table (guide, unresolved form). For any future schedule the access pins (`ME`, `WE`, `ADR`, `D`, `WEM`, `HW`, `CLK`) would follow `cycle_fact:6`/`cycle_fact:10`/`cycle_fact:12` with `BISTE=L` (`cycle_fact:24`); the repair pins would be the corner's exploration pins and would need a modeling oracle that this corpus does not provide.

## Flush phase

Replaced by the Missing facts table (guide, unresolved form). A3 does not apply — this corner shifts no chain. A1 would apply to any published schedule via `fact:ddf-e768c0d3` (`pipeline_depth` = 1: comparison ≥ launch + 1), and that arithmetic alone cannot rescue the corner because the remap effect is not comparable at all.

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Repair-disabled READ/WRITE (`cycle_fact:26`/`cycle_fact:30` with `CRE1=CRE2=0`, `RRE=0`) | would-be `SYMCYCLE j` | ≥ `j+1` (A1, `fact:ddf-e768c0d3`) | Q shows logical-array data | Sound, but witnesses no repair selection — not the corner's object. |
| Repair-enabled READ/WRITE on a programmed target (`cycle_fact:27`, `cycle_fact:28`, `cycle_fact:29`, `cycle_fact:31`) | would-be `SYMCYCLE j` | **not comparable** | Q shows spare-location data in a correct implementation; reference shows logical data | Diverges on a correct design; no oracle exists to make the remap observable. |

The second row is the corner's reason to exist, and it cannot reach default comparison on this collateral. No schedule is published.

## Symbolic treatment

none — no pin is moved down the coverage lattice, because no schedule is published. (Note for the record: a repair-disabled-only plan would have to bind `CRE1`/`CRE2`/`RRE` to `1'b0` across the phase — the pins this corner exists to explore — which is itself a symptom that the corner's object is absent, not a license to publish it.)

## Assumptions

- The survey statement that the functional reference wrapper observes but does not model `CRE1`/`CRE2`/`FCA1`/`FCA2`/`RRE`/`FRA` is taken as authoritative for this run's reference collateral; the survey's Evidence gaps ("No deck model") mean there is no deck on disk to check it against.
- The dual-row-repair collision rule (`cycle_fact:62` R19, `RRE1=RRE2=1`) is noted as not reachable on this instance: the instance carries one row-repair element (`RRE`/`FRA`), so no second row-repair enable exists to collide. This does not affect the escalation.
- Nothing in this analysis asserts the implementation's repair logic is defective; it asserts the reference collateral cannot represent the remap, so the corner cannot be witnessed soundly on this corpus.

## Limitations

- This escalation covers only the `redundancy` corner. It makes no claim about the other certified corners (`mission-mode-read-write`, `low-power-sequence`, `scan-dft`, `bist-mode-operation`, `deep-sleep-shutdown-retention`, `scan-shift-path`), which are separate witnesses.
- If a future reference collateral models the repair remapping, the corner must be re-surveyed (new corpus digest) and re-planned; this plan's digest binds its citations to the current snapshot.
- No constraints file is lowered: an `unresolved` corner publishes no schedule, and lowering the repair-disabled slice would silently narrow the corner's claim.

## Coverage

- catches (would-be): a sound repair witness would expose wrong-target repair decode (remap on an unprogrammed address), a dead spare element (programmed repair with no remap), and repair/access interleaving violations (`cycle_fact:63`). None of these classes is observable through the current reference collateral.
- misses: the repair remapping itself — the corner's central defect class — because the reference model does not simulate spare-column/row substitution, and the repair-disabled slice that the collateral *can* compare would miss every one of the classes above except a stuck-on/leaky repair enable. Publishing that slice as `plan` would be a silent green result on a design whose repair logic is entirely broken, which is exactly the outcome this escalation exists to prevent.
