# Deck commands

- Model digest: d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085
- Rows: 39 (one per normalized command occurrence)
- Bounds: command_count not reached

| Flow order | Command | Arguments | Resolution | Source span |
|---|---|---|---|---|
| 0 | set_app_var | waveform_format fsdb | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:7-7 |
| 1 | set_app_var | verify_rcdelay_unit fs | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:8-8 |
| 2 | set_app_var | verify_delay_round_multiple 100 | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:9-9 |
| 3 | set_app_var | verify_stop_on_randomize true | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:10-10 |
| 4 | set_app_var | verify_randomize_variables sysmem | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:11-11 |
| 5 | set_app_var | netlist_supply_by_connection off | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:12-12 |
| 6 | set_app_var | parser_verilog latest | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:13-13 |
| 7 | set_app_var | coverage true | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:14-14 |
| 8 | puts | INFO: READ REFERENCE DESIGN | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:16-16 |
| 9 | read_verilog | -r -vcs -sverilog -timescale=1ns/1ps +define+FUNCTIONAL +define+SPEEDSIM +define+SRAM_ADDR_WIDTH=14 +define+SRAM_DATA_WIDTH=32 +incdir+./include design/rtl/sram_1p2m_n3a_wrapper.sv -f design/rtl/filelist.func.f | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:17-17 |
| 10 | puts | INFO: READ IMPLEMENTATION DESIGN | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:18-18 |
| 11 | read_spice | -i design/spice/sram_1p2m_n3a_wrapper.cdl | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:19-19 |
| 12 | set_top_design | -r sram_1p2m_n3a_16384x32m32b_hd | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:22-22 |
| 13 | set_top_design | -i sram_1p2m_n3a_16384x32m32b_hd | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:23-23 |
| 14 | puts | INFO: SET SUPPLY NETS | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:25-25 |
| 15 | source | -echo -verbose sram_1p2m_n3a_16384x32m32b_hd_supplies.tcl | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:26-26 |
| 16 | report_potential_supply | -i > supplies.rpt | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:27-27 |
| 17 | puts | INFO: MATCH DESIGN PORTS | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:29-29 |
| 18 | set_matched_ports | -i VDD | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:30-30 |
| 19 | set_matched_ports | -i VDDA | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:31-31 |
| 20 | set_matched_ports | -i VSS | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:32-32 |
| 21 | match_design_ports | (none) | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:33-33 |
| 22 | report_matched_ports | (none) | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:34-34 |
| 23 | report_unmatched_ports | (none) | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:35-35 |
| 24 | set_simulation_timescale | 1 ns 1 ps | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:38-38 |
| 25 | create_clock | -period 5000 -setup 500 CLK | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:39-39 |
| 26 | report_clock | (none) | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:40-40 |
| 27 | puts | INFO: SOURCE TESTBENCH PIN ATTRIBUTES | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:42-42 |
| 28 | source | -echo -verbose sram_1p2m_n3a_16384x32m32b_hd_pin_attributes.tcl | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:43-43 |
| 29 | puts | INFO: SOURCE WORKER-OWNED CONSTRAINTS | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:45-45 |
| 30 | source | -echo -verbose sram_1p2m_n3a_16384x32m32b_hd_constraints.tcl | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:46-46 |
| 31 | report_process | -i | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:48-48 |
| 32 | set_app_var | testbench_style symbolic | opaque | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:51-51 |
| 33 | current_design | -i sram_1p2m_n3a_16384x32m32b_hd | resolved | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:52-52 |
| 34 | set | BENCH tb_func | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:53-53 |
| 35 | set | TYPE sym | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:54-54 |
| 36 | write_testbench | -replace $BENCH | dynamic | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:55-55 |
| 37 | set_active_testbench | $BENCH.$TYPE | dynamic | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:56-56 |
| 38 | if | ![verify] ␊  if { ![info exists debug_cmd]} {␊    set debug_cmd "debug_design "␊  }␊  eval $debug_cmd␊  report_log␊  report_status␊  quit␊ else ␊  report_assertion_coverage > sva_pass_cov.rpt␊  report_assertion > sva_pass.rpt␊  report_log␊  report_status␊  quit␊ | unknown | E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:58-72 |
