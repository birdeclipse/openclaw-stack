# Setup deck model

- Entry deck: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl
- Builder: esp.setup-model-builder 1
- Parser: esp.setup-static-parser 1
- Model digest: d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085

## Inventory

- Sources: 1
- Commands: 39
- Diagnostics: 14 (error 0, warning 14, info 0)

## Verification setup

- top_design: sram_1p2m_n3a_16384x32m32b_hd -r (E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:22-22)
- top_design: sram_1p2m_n3a_16384x32m32b_hd -i (E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:23-23)
- clock: CLK -period=5000 -setup=500 (E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:39-39)

## Cycle plan facts

none captured

## HDL structure

- Selected top: none captured
- Ports: none captured
- Scanner findings: 1
  - HDL-TOP-DECLARED-MISSING: declared top module was not found in scanned sources (none captured)

## Coverage and unresolved

- BOUNDS-LIMIT-REACHED: 0
- CATALOG-ARGUMENT-UNRESOLVED: 1
- CATALOG-NO-OPTION-SPEC: 9
- DEFERRED-CONTAINED-TCL: 0
- DEFERRED-SEMANTIC-HDL: 0
- DEFERRED-SPICE: 1
- FILELIST-CYCLE: 0
- FILELIST-DEPTH: 0
- FILELIST-UNSUPPORTED-FORM: 0
- HDL-COMPLEX-PORT-TYPE: 0
- HDL-ESCAPED-IDENTIFIER: 0
- HDL-NONANSI-PARTIAL: 0
- HDL-PREPROCESSING-DEPENDENT: 0
- HDL-TOP-AMBIGUOUS: 0
- HDL-TOP-DECLARED-MISSING: 1
- HDL-TOP-INFERRED-SOLE-CANDIDATE: 0
- RV-DYNAMIC-ARGUMENT: 0
- RV-EMBEDDED-OPTION-VECTOR: 0
- SOURCE-MISSING: 0
- SOURCE-ROOT-ESCAPE: 0
- SOURCE-SYMLINK: 0
- TCL-BRACKET-GUARD: 0
- TCL-CONTROL-REGION: 1
- TCL-DYNAMIC: 4
- TCL-UNBALANCED: 0

## Bounds

no bound reached

## Detail documents

- diagnostics.md: 14 rows (one per deterministic diagnostic)
- model-sources.md: 1 row (one per reachable source)
- model-commands.md: 39 rows (one per normalized command occurrence)
- model-boundary.md: 1 row (one per pin the deck names or the boundary exports)
