# Deck boundary

- Model digest: d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085
- Pins: 1 row, 1 off boundary, 0 out of range
- Supplies: 0 rows

## Pins

| Pin | Boundary | Function | Group | Constraint | Timing |
|---|---|---|---|---|---|
| CLK | absent | (none) | (none) | (none) | create_clock -period 5000 -setup 500 |

## Supplies

none captured
