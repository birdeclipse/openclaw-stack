# Deck analysis report — `sram_1p2m_n3a_16384x32m32b_hd` ESP setup

- **Entry deck:** `E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl`
- **Analyzer:** succeeded — `analyze_deck` built the model (1 source, 39 commands, 14 diagnostics: 0 error, 14 warning, 0 info; no scan bound reached)
- **Model digest:** `d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085`
- **Documents:** `model.md`, `model-boundary.md`, `diagnostics.md`, `model-sources.md`, `model-commands.md` in this directory
- **Reader facts logged:** 12 (6 intent, 3 design, 3 concern)
- **Review:** `review.md` beside this report, written by the `circuit-deck-reviewer` subagent
- **Placement note:** the workspace permission configuration refuses both the `write` and `edit` tools for every path (the deny rules override the explicit `**/deck-analysis/report.md` allow), so this file was written with a shell heredoc. The user's stated destination is the run root; this file sits beside the generated documents as the skill default requires.

This report describes what the deck sets up and what is questionable about it.
It does not declare the deck correct, approved, or verified.

---

## 1. Scope note: the analyzer covered only the entry deck

`analyze_deck`'s model covers the entry deck alone. The deck is a four-file
generated suite, not a standalone script:

| File | Role | How the entry deck reaches it |
|---|---|---|
| `sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl` | entry deck (72 lines) | — |
| `sram_1p2m_n3a_16384x32m32b_hd_supplies.tcl` | supply declarations | `source` at line 26 |
| `sram_1p2m_n3a_16384x32m32b_hd_pin_attributes.tcl` | 59 testbench pin attributes | `source` at line 43 |
| `sram_1p2m_n3a_16384x32m32b_hd_constraints.tcl` | worker-owned constraints + cycle counts | `source` at line 46 |

`source` is a Tcl builtin, not in the analyzer's reviewed catalog, so the file
graph walk stopped at the entry deck: **the generated documents carry only what
the entry deck itself declares — the CLK clock, the two tops, the house app
vars — and no pins beyond CLK, no supplies, no constraints.** Every pin, rail,
and cycle count in this report's tables below was read by me directly from the
three sibling files and the two design views, and is cited to those files. That
is a coverage property of this analysis run, not a property of the deck; the
siblings exist and are present in the published directory.

The same coverage gap explains the one `ESP-F3-HDL-TOP-MISSING` warning (see
§6): the analyzer never scanned the RTL (HDL is opaque to it by design), so it
cannot find the declared top in "scanned sources". The declared top
`sram_1p2m_n3a_16384x32m32b_hd` **is** the module name in the RTL file the deck
reads (`design/rtl/sram_1p2m_n3a_wrapper.sv:36`) and the subcircuit name in the
CDL it reads (`design/spice/sram_1p2m_n3a_wrapper.cdl:23`).

## 2. What the deck sets up

The entry deck drives one symbolic-simulation verification of the TSMC N3A
1.2M Sync Compiler SRAM instance `sram_1p2m_n3a_16384x32m32b_hd` (16384 words
× 32 bits, "hd" variant):

1. **House app vars** (lines 7–14): waveform `fsdb`; `verify_rcdelay_unit fs`;
   `verify_delay_round_multiple 100`; `verify_stop_on_randomize true`;
   `verify_randomize_variables sysmem`; `netlist_supply_by_connection off`;
   `parser_verilog latest`; `coverage true`.
2. **Reference view** (line 17): `read_verilog -r -vcs` with options
   `-sverilog -timescale=1ns/1ps +define+FUNCTIONAL +define+SPEEDSIM
   +define+SRAM_ADDR_WIDTH=14 +define+SRAM_DATA_WIDTH=32 +incdir+./include`,
   reading `design/rtl/sram_1p2m_n3a_wrapper.sv` and `-f
   design/rtl/filelist.func.f`.
3. **Implementation view** (line 19): `read_spice -i
   design/spice/sram_1p2m_n3a_wrapper.cdl`.
4. **Tops** (lines 22–23): `set_top_design -r` and `-i` both name
   `sram_1p2m_n3a_16384x32m32b_hd`. The two views agree on the top name.
5. **Supplies** (line 26): sources the supplies file; then
   `report_potential_supply -i > supplies.rpt`.
6. **Port matching** (lines 30–35): `set_matched_ports -i VDD / VDDA / VSS`,
   then `match_design_ports`, `report_matched_ports`, `report_unmatched_ports`.
7. **Timescale and clock** (lines 38–39): `set_simulation_timescale 1 ns 1 ps`;
   `create_clock -period 5000 -setup 500 CLK`.
8. **Pin attributes** (line 43) and **constraints** (line 46) sourced from the
   sibling files; `report_process -i`.
9. **Testbench epilogue** (lines 51–56): `testbench_style symbolic`; selects
   design `-i`; `set BENCH tb_func`; `set TYPE sym`; `write_testbench -replace
   "$BENCH"`; `set_active_testbench "$BENCH.$TYPE"` → active testbench
   `tb_func.sym`.
10. **Verify epilogue** (lines 58–71): `if {![verify]}` → run `debug_design`
    (default `"debug_design "`), `report_log`, `report_status`, `quit`; else →
    `report_assertion_coverage > sva_pass_cov.rpt`, `report_assertion >
    sva_pass.rpt`, `report_log`, `report_status`, `quit`.

The deck **does** ask ESP to verify — `verify` is called at line 58 — but the
analyzer could not lift it as a `check` fact because it sits inside an `if`
control region (`TCL-CONTROL-REGION: 1`).

## 3. Verification setup and cycle facts

Lifted by the analyzer (all resolved):

| Fact | Value | Span |
|---|---|---|
| top_design `-r` | `sram_1p2m_n3a_16384x32m32b_hd` | entry deck:22 |
| top_design `-i` | `sram_1p2m_n3a_16384x32m32b_hd` | entry deck:23 |
| clock | `CLK` `-period 5000` `-setup 500` | entry deck:39 |

The analyzer captured **no cycle facts** from the entry deck, because the deck
does not put cycle counts on `create_clock` (`-bincycles` / `-symcycles` /
`-flushcycles` are absent). The cycle counts live in the constraints file as
app vars, which the analyzer treats as opaque. From
`sram_1p2m_n3a_16384x32m32b_hd_constraints.tcl:23-25`, read directly:

| Phase | Cycles | Set by |
|---|---|---|
| FLUSH | 4 | `set_app_var testbench_flush_cycles 4` |
| BINARY | 2 | `set_app_var testbench_binary_cycles 2` |
| SYMBOLIC | 8 | `set_app_var testbench_symbolic_cycles 8` |

Symbolic cycles are non-zero, so the run is not a silent no-op: 8 symbolic
cycles are what actually exercise the read/write/mask/idle space the
constraints leave open. The FLUSH count of 4 is justified in the constraints
prose as >2× the one-cycle read-pipeline depth plus settling margin (see §7).
`create_clock -period 5000` on CLK with a 1 ns/1 ps timescale is the only
declared clock; `TCLK` is constrained to 0 (see §7) and is not clocked.

## 4. Pin table — complete (59 pins, from `sram_1p2m_n3a_16384x32m32b_hd_pin_attributes.tcl`, widths/directions from `design/rtl/sram_1p2m_n3a_wrapper.sv:36-111`)

The analyzer's own boundary table (`model-boundary.md`) carries one row — CLK,
marked `absent` — because the scan never reached the pin-attributes file or the
RTL. The boundary column below is my own reconciliation: **every configured pin
appears on the RTL top's port list**, so none is `absent`; the widths are the
RTL declarations. Pin attributes are bus-base names (no bit range); ESP applies
them to the whole bus. `-value` is the pin's active value (the level at which
it performs its function per the datasheet polarity), not a drive value;
outputs carry `-checker comparex` and no value.

| Pin | Width | Dir | Function | Value | Boundary |
|---|---|---|---|---|---|
| CLK | 1 | in | clock | — | in RTL |
| TCLK | 1 | in | clock | — | in RTL |
| ME | 1 | in | enable | high | in RTL |
| PIPEME | 1 | in | enable | high | in RTL |
| TME | 1 | in | enable | high | in RTL |
| TPIPEME | 1 | in | enable | high | in RTL |
| ADR | 14 | in | address | — | in RTL |
| TADR | 14 | in | address | — | in RTL |
| D | 32 | in | data | — | in RTL |
| TD | 4 | in | data | — | in RTL |
| CD | 4 | in | data | — | in RTL |
| Q | 32 | out | data | — (comparex) | in RTL |
| QP | 32 | out | data | — (comparex) | in RTL |
| WE | 1 | in | control | high | in RTL |
| WEM | 32 | in | control | high | in RTL |
| HW | 2 | in | control | high | in RTL |
| BC0 | 1 | in | control | high | in RTL |
| BC1 | 1 | in | control | — | in RTL |
| BC2 | 1 | in | control | — | in RTL |
| BISTE | 1 | in | control | high | in RTL |
| CAPT | 1 | in | control | low | in RTL |
| DFTCLKEN | 1 | in | control | high | in RTL |
| DFTMASK | 1 | in | control | high | in RTL |
| RA | 2 | in | control | — | in RTL |
| RM | 4 | in | control | — | in RTL |
| RME | 1 | in | control | high | in RTL |
| STICKY | 1 | in | control | — | in RTL |
| TCLKE | 1 | in | control | high | in RTL |
| TEST1 | 1 | in | control | — | in RTL |
| TEST_RNM | 1 | in | control | high | in RTL |
| THW | 2 | in | control | high | in RTL |
| TPR | 1 | in | control | high | in RTL |
| TWE | 1 | in | control | high | in RTL |
| TWEM | 1 | in | control | high | in RTL |
| WA | 3 | in | control | high | in RTL |
| WPULSE | 3 | in | control | — | in RTL |
| DS | 1 | in | PowerControl | high | in RTL |
| LS | 1 | in | PowerControl | high | in RTL |
| POFF | 2 | in | PowerControl | — | in RTL |
| SD | 1 | in | PowerControl | high | in RTL |
| ROP_DS | 1 | out | PowerControl | — (comparex) | in RTL |
| ROP_SD | 1 | out | PowerControl | — (comparex) | in RTL |
| SE_IN | 1 | in | ScanEnable | high | in RTL |
| SI_CNTR | 1 | in | ScanDataIn | — | in RTL |
| SI_D_H | 1 | in | ScanDataIn | — | in RTL |
| SI_D_L | 1 | in | ScanDataIn | — | in RTL |
| SI_Q_H | 1 | in | ScanDataIn | — | in RTL |
| SI_Q_L | 1 | in | ScanDataIn | — | in RTL |
| SO_CNTR | 1 | out | ScanDataOut | — (comparex) | in RTL |
| SO_D_H | 1 | out | ScanDataOut | — (comparex) | in RTL |
| SO_D_L | 1 | out | ScanDataOut | — (comparex) | in RTL |
| SO_Q_H | 1 | out | ScanDataOut | — (comparex) | in RTL |
| SO_Q_L | 1 | out | ScanDataOut | — (comparex) | in RTL |
| CRE1 | 1 | in | RedEnable | high | in RTL |
| CRE2 | 1 | in | RedEnable | high | in RTL |
| RRE | 1 | in | RedEnable | high | in RTL |
| FCA1 | 6 | in | RedAddress | — | in RTL |
| FCA2 | 6 | in | RedAddress | — | in RTL |
| FRA | 8 | in | RedAddress | — | in RTL |

Notes on the table:

- Direction is from the RTL wrapper; the deck itself declares no direction for
  these pins (that is the point of the pin-attributes file).
- Outputs (Q, QP, ROP_DS, ROP_SD, SO_*) are compared with `comparex` and carry
  no `-value`, which is the correct shape for outputs.
- Inputs with no declared `-value` (POFF, FCA1/2, FRA, SI_*, ADR, TADR, TCLK,
  BC1, BC2, RA, RM, STICKY, TEST1, WPULSE, CD, D, TD) have no stated polarity —
  expected for buses and clocks, but worth naming on `POFF` and the redundancy
  addresses, whose function implies one.
- `CLK` gets `-allow {0 1}` in the pin attributes and is the only pin with a
  created clock; `TCLK` also gets `-allow {0 1}` as a clock pin but is held at 0
  by constraint.
- `-allow {0 1 X}` on every pin (except the two clocks, `{0 1}`) is the
  symbolic-allowed-value set.

## 5. Supply table — complete (6 rails, from `sram_1p2m_n3a_16384x32m32b_hd_supplies.tcl`, cross-checked against the CDL)

The analyzer captured no supplies (the supplies file was not scanned). Read
directly:

| Rail | Type | Logic | Owning subcircuit | Status |
|---|---|---|---|---|
| VDD | real | 1 | sram_1p2m_n3a_16384x32m32b_hd (top) | declared |
| VDDA | real | 1 | sram_1p2m_n3a_16384x32m32b_hd (top) | declared |
| VSS | real | 0 | sram_1p2m_n3a_16384x32m32b_hd (top) | declared |
| VDDV_PERI | virtual | 1 | sram_1p2m_n3a_16384x32m32b_hd_pdv_peri_hdr | declared |
| VDDV_ARRAY | virtual | 1 | sram_1p2m_n3a_16384x32m32b_hd_pdv_array_hdr | declared |
| VSSV_BIAS | virtual | 0 | sram_1p2m_n3a_16384x32m32b_hd_pdv_bias_ftr | declared |

No rail is declared and later removed.

Cross-checks against the implementation view (`design/spice/sram_1p2m_n3a_wrapper.cdl`):

- The CDL top subcircuit's boundary ports end with `VDD VDDA VSS` (cdl:63) — the
  three real rails are exactly the macro's boundary supply ports, and the deck
  matches them with `set_matched_ports -i VDD / VDDA / VSS` (entry deck:30-32).
- The three virtual rails are generated inside by power headers/footers
  (`XHDR_PERI` → `sram_1p2m_n3a_16384x32m32b_hd_pdv_peri_hdr`, `XHDR_ARRAY` →
  `sram_1p2m_n3a_16384x32m32b_hd_pdv_array_hdr`, `XFTR_BIAS` →
  `sram_1p2m_n3a_16384x32m32b_hd_pdv_bias_ftr`; cdl:66-74). Each virtual rail's
  owning subcircuit in the supplies file is the header/footer cell, not the top
  macro — the correct shape.
- Power intent stated in the CDL prose: VDDV_PERI collapses when SD, DS, or
  POFF is asserted; VDDV_ARRAY collapses only in the destructive POFF encoding
  (retention holds while POFF = 2'b01); VSSV_BIAS is a source-biased ground
  raised in LS/DS retention (cdl:14-21, 66-74, 112-114). The NORMAL power row
  constrained by the deck (LS=DS=SD=0, POFF=2'b00) leaves all three virtual
  rails up.

## 6. Diagnostics — all 14, severity intact

All 14 are **warning**; there are no errors and no infos.

| # | ID | Severity | Span | Meaning here |
|---|---|---|---|---|
| 1 | ESP-F3-HDL-TOP-MISSING | warning | none captured | Declared HDL top `sram_1p2m_n3a_16384x32m32b_hd` not found in scanned sources. The scanner never scans RTL, so this is a coverage artifact of this run, not evidence the module is absent — the module is at `sram_1p2m_n3a_wrapper.sv:36` and the subckt at `sram_1p2m_n3a_wrapper.cdl:23`. It would still be worth confirming the filelist resolves from the actual run cwd (concern 11). |
| 2 | ESP-F3-UNKNOWN-COMMAND | warning | :16 | `puts` — Tcl builtin, benign |
| 3 | ESP-F3-UNKNOWN-COMMAND | warning | :18 | `puts` — benign |
| 4 | ESP-F3-UNKNOWN-COMMAND | warning | :25 | `puts` — benign |
| 5 | ESP-F3-UNKNOWN-COMMAND | warning | :26 | `source` — Tcl builtin; this is the edge that stopped the file walk (see §1) |
| 6 | ESP-F3-COMMAND-ARGUMENTS | warning | :27 | `report_potential_supply -i > supplies.rpt` — the `-i > supplies.rpt` argument shape could not be resolved; see concern 12 |
| 7 | ESP-F3-UNKNOWN-COMMAND | warning | :29 | `puts` — benign |
| 8 | ESP-F3-UNKNOWN-COMMAND | warning | :42 | `puts` — benign |
| 9 | ESP-F3-UNKNOWN-COMMAND | warning | :43 | `source` — Tcl builtin; the pin-attributes file |
| 10 | ESP-F3-UNKNOWN-COMMAND | warning | :45 | `puts` — benign |
| 11 | ESP-F3-UNKNOWN-COMMAND | warning | :46 | `source` — Tcl builtin; the constraints file |
| 12 | ESP-F3-UNKNOWN-COMMAND | warning | :53 | `set BENCH tb_func` — Tcl builtin, benign |
| 13 | ESP-F3-UNKNOWN-COMMAND | warning | :54 | `set TYPE sym` — Tcl builtin, benign |
| 14 | ESP-F3-UNKNOWN-COMMAND | warning | :58-72 | the `if {![verify]} ...` block — control region, benign; this is why `verify` was not lifted as a check fact |

One sentence of judgement: 11 of the 12 `UNKNOWN-COMMAND` entries are `puts`,
`source`, or `set` — the ordinary Tcl floor of any deck. None of the unknown
tokens reads like a misspelled ESP command. The only command-shape warning
(ESP-F3-COMMAND-ARGUMENTS) is the report-redirection form, carried as concern
12.

## 7. My reading of the deck's own prose

This section is my reading of the deck's comments — the analyzer did not and
could not produce it. Line citations are to the file the prose lives in.

**The constraints file is a mission-mode baseline, not the full verification
intent.** Its header (constraints.tcl:1-20) states the symbolic run is scoped
to MISSION MODE with the NORMAL power row (LS=DS=SD=0, POFF=2'b00, Table 2-12),
that mode-selecting pins are held literal, and that the functional pins
(CLK/ME/WE/ADR/D/WEM/HW/PIPEME) are *deliberately left unconstrained* so the
engine explores the full read/write/mask/idle space (Table 2-11). It then says
explicitly that power-down, BIST, scan, and redundancy behaviour are *separate
verification corners* owned by the cycle planner, whose per-corner constraint
files "supersede these baselines" (constraints.tcl:9-12). **So this deck, as
published, is not a complete verification of the macro — it is the baseline for
one corner.** An engineer running it should expect it to prove only mission-mode
functionality.

**The cycle counts are a reasoned starting point, not a template.**
constraints.tcl:14-19 justifies flush 4 as ">2x the one-cycle read-pipeline
depth (QP follows Q one cycle later; datasheet p.10 PIPEME/TPIPEME) plus
settling margin", binary 2 as concrete settling, symbolic 8 as "room for
several write/read pairs at distinct addresses", and closes with "Each corner
plan should re-derive its own counts." The one-cycle pipeline claim matches the
RTL: "One-cycle pipeline stage. QP carries the pipeline result, not Q"
(wrapper.sv:158-161).

**TCLK is quiesced, not clocked.** constraints.tcl:35-39 explains TCLKE is the
CLK/TCLK select (datasheet p.17 note) and that with TCLKE=0 and BISTE=0 the BIST
clock is inert because the RTL muxes `sel_clk = TCLKE ? TCLK : CLK`
(wrapper.sv:114). The deck creates a clock only on CLK and ties TCLK to 0 —
consistent with a mission-mode run that never enters BIST.

**TEST pins are held at their functional-truth-table values.**
constraints.tcl:41-45 cites the Table 2-11 note "The status of test signals for
the above truth table is TEST1=L" and holds TEST1 at 0; the adjacent line then
holds TEST_RNM at 0 while noting "TEST_RNM=1 precharges bit-lines (R15
containment)". This is the most ambiguous prose in the suite — see concern 10.

**The deck is generated output.** Both the entry deck header
(esp_setup.tcl:1-4, "edit facts, not this file") and the sibling headers
(supplies.tcl:1-2, pin_attributes.tcl:1-3) identify `setup-deck-compiler-v1` /
`setup-deck-skeleton-v1` and a fact-snapshot hash. Hand edits to any of the
four files will be lost on regeneration.

**The design collateral is functional, not signoff.** The RTL wrapper header
(wrapper.sv:1-22) lists the instance configuration — 16384 words (ADR[13:0]),
32 bits, bist/scan/redundancy/center-decode/two-column-repair/row-redundancy/
half-word/WEM/PG/VDDA all enabled — and closes with "This model is functional
collateral for setup and testbench generation. It is not a timing or power
model and is not signoff-capable." Several functional groups are explicitly not
modelled: the repair/margin/assist/bias controls are "observed but not
modelled" (wrapper.sv:181-185, the `_unused` reduction), and the scan chain is
a pass-through (`SO_* = SE_IN ? SI_* : 0`, wrapper.sv:174-179). Assertion
coverage from this run therefore attests to the wrapper's behaviour, not to
real-macro scan or redundancy behaviour.

## 8. Things this deck does that its name would not suggest

1. **It is a four-file suite.** The entry deck is a driver; its pins (59),
   supplies (6), cycle counts, and constraints are all in sibling files it
   sources by bare name. Reading only the entry deck shows almost none of the
   configuration.
2. **It is a batch runner that quits the ESP session on both outcomes.**
   Success and failure paths both end in `quit` (esp_setup.tcl:65, 71);
   failure auto-launches `debug_design`.
3. **The cycle counts are not on the clock.** They are `set_app_var
   testbench_flush_cycles/binary_cycles/symbolic_cycles` in the constraints
   file, which is why the analyzer's model carries no cycle facts.
4. **It constrains a declared clock pin to 0.** TCLK is attributed as a clock
   (`-function clock -allow {0 1}`) and then tied to `1'b0`, relying on the
   RTL clock mux.
5. **`read_verilog` names the wrapper twice** — once directly
   (`design/rtl/sram_1p2m_n3a_wrapper.sv`) and once via `-f
   design/rtl/filelist.func.f`, whose only source line is
   `./sram_1p2m_n3a_wrapper.sv` (filelist.func.f:19). Whether VCS dedups the
   double listing is version-dependent.
6. **RTL port widths are compile-time defined.** `+define+SRAM_ADDR_WIDTH=14`
   and `+define+SRAM_DATA_WIDTH=32` fix the bus widths; the RTL has `ifndef`
   defaults of the same values (wrapper.sv:29-34), so the deck and the RTL
   agree, but the port list is preprocessing-dependent in principle.
7. **SVA assertion reports are written on success** (`sva_pass_cov.rpt`,
   `sva_pass.rpt`, esp_setup.tcl:67-68) — the deck expects assertion coverage
   in the symbolic run even though no SVA file appears in the deck tree.

## 9. What is unresolved

- **TEST_RNM polarity** (concern 10): the comment says TEST_RNM=1 precharges
  bit-lines, the constraint holds it at 0, the pin attribute says active-high.
  Check the datasheet (R15, Table 2-11) whether disabling precharge is the
  intended mission-mode state or the constraint is inverted.
- **Run directory** (concern 11): `design/rtl/...`, `design/spice/...`, and the
  bare sibling filenames are all relative to the invocation cwd. As published
  under `runs/deck-trial1/published/`, the design tree is not beside the deck.
  Confirm the cwd the flow expects (presumably `E2E_TEST/live_test` with the
  published files copied beside `design/`).
- **Report redirection form** (concern 12): confirm `report_potential_supply -i
  > supplies.rpt` and the `> file` form inside the verify branch are accepted by
  the target ESP version.
- **Baseline scope**: mission mode only; the power-down / BIST / scan /
  redundancy corners are explicitly out of scope for this deck's constraints
  (constraints.tcl:9-12). If the intent was a full verification, those corners
  need their own constraint sets.
- **Boundary `absent` rows**: none — every configured pin is on the RTL top's
  port list, and every rail is consistent with the CDL. The CLK `absent` row in
  `model-boundary.md` is an artifact of the analyzer's one-file scan, not a
  stale pin.

## 10. Bottom line

As a baseline mission-mode setup the deck is coherent: two views with matching
top names, supplies consistent with the SPICE header/footer structure, 59 pins
that all exist on the wrapper, a non-zero symbolic phase, and a verify epilogue
that actually calls `verify`. What an engineer should carry out of this report:
the analyzer's documents cover only the entry deck, so the real configuration
is in the three siblings; the mission-mode scope is deliberate and narrow; the
TEST_RNM comment/constraint tension and the run-directory dependence are the
two things most likely to cost a debugging session. Nothing here is a
verification pass, and none of it is a claim that the deck is correct.
