# Review — `sram_1p2m_n3a_16384x32m32b_hd` deck-analysis report

Reviewed: `deck-analysis/report.md`, against `model.md`, `diagnostics.md`,
`model-boundary.md`, `model-sources.md`, `model-commands.md`, the entry deck and
its three siblings under `runs/deck-trial1/published/`, and the design views
(`design/rtl/sram_1p2m_n3a_wrapper.sv`,
`design/rtl/filelist.func.f`, `design/spice/sram_1p2m_n3a_wrapper.cdl`).
Every claim was traced to a document line or a source line; nothing was taken on
the report's word. Diagnostics were checked one by one against
`diagnostics.md`. The run ledger (`facts.sqlite3`) was read directly to check the
reader-fact count.

## correct

- **Analyzer receipt (report header, §1).** "1 source, 39 commands, 14
  diagnostics: 0 error, 14 warning, 0 info; no scan bound reached" matches
  `model.md:8-12`, `model-sources.md:9` ("1 row", "file_count not reached"),
  and `diagnostics.md:3-4`. The model digest
  `d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085` in the
  report header matches `model.md:6` exactly.
- **Scope claim (§1).** The claim that the generated documents carry only the
  entry deck's own facts — the CLK clock, the two tops, the house app vars — and
  no pins beyond CLK, no supplies, no constraints is borne out by
  `model.md:16-22` (clock CLK, two tops, no cycle facts) and
  `model-boundary.md:4-14` (one pin row, CLK, `absent`; zero supply rows).
- **Two tops agree (§2 step 4, §3).** `set_top_design -r` and `-i` both name
  `sram_1p2m_n3a_16384x32m32b_hd` at `esp_setup.tcl:22-23`;
  `model-commands.md:21-22` records both as resolved.
- **Clock (§2 step 7, §3).** `create_clock -period 5000 -setup 500 CLK` at
  `esp_setup.tcl:39`; `model-commands.md:34` resolved. The report's statement
  that no `-bincycles/-symcycles/-flushcycles` exist, so the analyzer captured
  no cycle facts, matches `model.md:21-22`.
- **Cycle counts (§3).** FLUSH 4 / BINARY 2 / SYMBOLIC 8 matches
  `constraints.tcl:23-25` (`set_app_var testbench_flush_cycles 4`,
  `testbench_binary_cycles 2`, `testbench_symbolic_cycles 8`). The report reads
  the right lines and does not invent a count.
- **verify / control region (§2 step 10, §6 row 14).** The report's claim that
  `verify` is called (line 58) but was not lifted as a check fact because it sits
  in a control region is supported by `model.md:55` (`TCL-CONTROL-REGION: 1`) and
  `model-commands.md:38` (the `if {![verify]} ...` block spans :58-72).
- **Diagnostics — all 14 reached the report with severity intact.** I
  cross-checked every span in the report's §6 table against `diagnostics.md`:
  HDL-TOP-MISSING (none captured), UNKNOWN-COMMAND at :16, :18, :25, :26, :29,
  :42, :43, :45, :46, :53, :54, :58-72, and COMMAND-ARGUMENTS at :27. All are
  reported as warning, matching `diagnostics.md` exactly; none was dropped or
  softened to info. The "11 of 12 unknown commands are puts/source/set" count
  is arithmetically correct (6 puts + 3 source + 2 set).
- **Pin table (§4) — complete and traceable.** All 59 configured pins are listed
  and every one exists on the RTL top's port list (`wrapper.sv:36-111`); widths
  and directions match the RTL declarations; function, `-value`, and `-checker
  comparex` match `pin_attributes.tcl:5-63` line by line. The no-`-value` input
  list (POFF, FCA1/2, FRA, SI_*, ADR, TADR, TCLK, BC1, BC2, RA, RM, STICKY,
  TEST1, WPULSE, CD, D, TD) is exactly the set of input pins carrying no `-value`
  in the file. `-allow {0 1}` on CLK/TCLK and `-allow {0 1 X}` elsewhere match
  the file. The CLK `absent` row in `model-boundary.md:11` is correctly
  attributed to the one-file scan, not a stale pin.
- **Supply table (§5) — complete and traceable.** All six rails match
  `supplies.tcl:4-9` (VDD/VDDA real logic 1, VSS real logic 0, VDDV_ARRAY /
  VSSV_BIAS / VDDV_PERI virtual with header/footer subcircuits). "No rail is
  declared and later removed" is true — no `set_supply_net -remove` appears.
  The cross-checks resolve: boundary ends `VDD VDDA VSS` at `cdl:63`;
  `set_matched_ports -i VDD/VDDA/VSS` at `esp_setup.tcl:30-32`; the three virtual
  rails are produced by XHDR_PERI / XHDR_ARRAY / XFTR_BIAS at `cdl:66-74` with
  owning subcircuits matching the supplies file. The power-intent prose
  (VDDV_PERI collapses on SD/DS/POFF; VDDV_ARRAY collapses only in the
  destructive POFF encoding with retention at POFF=2'b01; VSSV_BIAS raised in
  LS/DS retention) matches `cdl:14-21`, `cdl:66-74`, and `cdl:112-114` verbatim.
- **Design-view citations (§1, §7, §8) all resolve.** Module
  `sram_1p2m_n3a_16384x32m32b_hd` at `wrapper.sv:36`; subckt at `cdl:23`;
  `sel_clk = TCLKE ? TCLK : CLK` at `wrapper.sv:114`; one-cycle pipeline comment
  at `wrapper.sv:158-161`; scan pass-through (`SO_* = SE_IN ? SI_* : 0`) at
  `wrapper.sv:174-179`; `_unused` reduction at `wrapper.sv:181-185`; `ifndef`
  width defaults at `wrapper.sv:29-34`; functional-not-signoff header at
  `wrapper.sv:1-22`; filelist's only source line `./sram_1p2m_n3a_wrapper.sv`
  at `filelist.func.f:19`. The SVA claim (§8 item 7) holds: the published deck
  tree contains no `.sv`/SVA file beyond the RTL wrapper itself.
- **Reader facts.** The report's "12 (6 intent, 3 design, 3 concern)" matches
  the run ledger directly (`facts.sqlite3`: 6 intent, 3 design, 3 concern, all
  `inferred`, none retracted). Concern numbers 10/11/12 referenced in §6 and §9
  match the logged concern rows (TEST_RNM polarity, run cwd, redirection form).
- **Unresolved regions stayed unresolved.** TEST_RNM polarity, the run-directory
  dependence, and the `> file` redirection forms are kept open in §9, and the
  HDL-TOP-MISSING warning is preserved with the run-cwd caveat rather than
  converted into a clean bill. The report nowhere declares the deck verified or
  approved.

## missing

- No diagnostic was dropped or softened, and no command, pin, width, cycle
  count, supply, or top name is fabricated. Nothing verified as an unresolved
  region is presented as settled. The omissions below are minor and
  non-material:
- **Width defines declared twice, unreconciled.** `+define+SRAM_ADDR_WIDTH=14`
  and `+define+SRAM_DATA_WIDTH=32` appear in the entry deck's `read_verilog`
  (`esp_setup.tcl:17`) *and* again in the filelist (`filelist.func.f:14-15`).
  §8 item 6 discusses the deck-vs-RTL `ifndef` agreement but never notes that the
  deck itself carries the defines in two places that must stay in sync — a small
  drift risk a reader of §8 would reasonably want flagged.
- **`report_clock` not named.** The walkthrough's step 7 names
  `set_simulation_timescale` and `create_clock` but omits `report_clock`
  (`esp_setup.tcl:40`), the one remaining resolved command in that block. Trivial.
- **The report's §1 inventory sentence under-counts the model's contents.** "the
  generated documents carry only ... the CLK clock, the two tops, the house app
  vars" reads as if that were the whole model; the command rows in
  `model-commands.md` additionally carry `read_verilog`/`read_spice`,
  `set_matched_ports`/`match_design_ports`, `set_simulation_timescale`, and the
  testbench epilogue. The intent of the sentence (pins/supplies/constraints are
  absent) is correct; the phrasing slightly over-shrinks what the model holds.

## user-review

- **TEST_RNM polarity (report §9, concern 10).** The constraint holds TEST_RNM at
  `1'b0` (`constraints.tcl:45`), the comment says TEST_RNM=1 precharges bit-lines
  (`constraints.tcl:43`), and the pin attribute says active-high
  (`pin_attributes.tcl:46`). Whether disabling precharge is the intended
  mission-mode state is a datasheet (R15 / Table 2-11) question the deck owner
  must settle; the report correctly leaves it open.
- **Run directory (report §9, concern 11).** All paths (`design/rtl/...`,
  `design/spice/...`, and the bare sibling filenames) are relative to the
  invocation cwd, and as published under `runs/deck-trial1/published/` the
  design tree is not beside the deck. The deck owner must confirm the cwd the
  flow expects before the filelist and sources resolve.
- **Report redirection forms (report §9, concern 12).** `report_potential_supply
  -i > supplies.rpt` (`esp_setup.tcl:27`) and the `> file` forms in the verify
  branch (`:67-68`) depend on the target ESP version accepting shell-style
  redirection. Confirm before relying on the run.
- **Baseline scope (report §9).** The deck is deliberately mission-mode only;
  power-down / BIST / scan / redundancy corners are out of scope for this
  constraints file (`constraints.tcl:9-12`). Whether that is the intended
  coverage is the owner's call — if a full verification was wanted, per-corner
  constraint sets are required.
- **Double-sourced wrapper (report §8 item 5).** The wrapper is named directly
  in `read_verilog` and again via `-f filelist.func.f`; whether VCS dedups the
  double listing is version-dependent. Worth confirming on the actual toolchain.
