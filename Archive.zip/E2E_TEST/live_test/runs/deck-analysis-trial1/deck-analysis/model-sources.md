# Deck sources

- Model digest: d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085
- Rows: 1 (one per reachable source)
- Bounds: file_count not reached

| Relative path | Digest | Role | Parse status | Reached from |
|---|---|---|---|---|
| E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl | 90b9e61a76c6ea9efa587f1ecc3f9de0e263512826096e8f10a214e24f8e0b13 | deck | scanned | (entry) |
