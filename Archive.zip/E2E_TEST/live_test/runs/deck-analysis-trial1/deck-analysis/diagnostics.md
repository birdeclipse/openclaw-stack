# Deck diagnostics

- Model digest: d651a94f6ac95123c1377a18fe6eba5721ee2e4259923ee7f268e0d3a9066085
- Diagnostics: 14 (error 0, warning 14, info 0)

## 1. ESP-F3-HDL-TOP-MISSING (warning)

- Diagnostic ID: diag-440e5f9b0d5c4699
- Message: Declared HDL top was not found
- Source span: none captured

## 2. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-30ff6bbc21e95b01
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:16-16

## 3. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-8876c88ed5f19777
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:18-18

## 4. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-3d07faec1589e694
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:25-25

## 5. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-842354c53d0d3a90
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:26-26

## 6. ESP-F3-COMMAND-ARGUMENTS (warning)

- Diagnostic ID: diag-2262255582622a7f
- Message: Command arguments cannot be resolved
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:27-27

## 7. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-31efb3ff31dfac37
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:29-29

## 8. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-dc25ad8de9118ef1
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:42-42

## 9. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-88251104876a0fe3
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:43-43

## 10. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-95a01f8c10e2e944
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:45-45

## 11. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-83f06a70aa76758a
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:46-46

## 12. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-82ea5afeb05bc52f
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:53-53

## 13. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-007561fbe8aeb299
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:54-54

## 14. ESP-F3-UNKNOWN-COMMAND (warning)

- Diagnostic ID: diag-fbb4c93754e7b694
- Message: Unknown static Tcl command
- Source span: E2E_TEST/live_test/runs/deck-trial1/published/sram_1p2m_n3a_16384x32m32b_hd_esp_setup.tcl:58-72
