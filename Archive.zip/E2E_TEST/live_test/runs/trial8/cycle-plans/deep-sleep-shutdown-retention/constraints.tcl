# ---------------------------------------------------------------------------
# deep-sleep-shutdown-retention — constraints.tcl
# Transliteration of plan.md (corpus digest 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8)
# Corner: verify the deep-sleep/shutdown retention sequence (directive:3)
#
# Cycle counts (from plan.md):
#   BIN = 1  (legal IDLE prelude)
#   SYM = 12 (IDLE->DS entry, DS hold, DS->WAKE_DS, DS exit, 2 guard,
#             IDLE->SD entry, SD hold, SD->WAKE_SD, SD exit, 2 guard)
#   FLUSH = 0 (no pipeline state in flight: Q is never updated under held-low
#              clocks, so the QP pipeline carries nothing; all observable
#              effects are outputs observable immediately)
#
# NOTE on observability (see plan.md Limitations): the wrapper registers
# rop_ds_int/rop_sd_int only on posedge sel_clk or posedge SD or posedge DS
# (sram_1p2m_n3a_wrapper.sv:164-167), and forces q_int<=0 only on posedge
# sel_clk (lines 132-135). With CLK=TCLK=0 held the whole run, the ROP_DS=0 /
# ROP_SD=0 exits and the forced-0 Q/QP/SO are NOT observable in the model.
# This schedule verifies what IS observable: ROP_DS=1 via posedge DS (SYM1),
# ROP_SD=1 via posedge SD (SYM7), and the holds/wakes.
# ---------------------------------------------------------------------------

# --- Testbench cycle counts (app vars) ---
set_app_var testbench_binary_cycles  1
set_app_var testbench_symbolic_cycles 12
set_app_var testbench_flush_cycles   0

# --- Clocks quiescent through the whole run ---
# cycle_fact:50: any rising CLK/TCLK while DS/SD/POFF active is an illegal
# clock event. The powered-down state persists through entry, hold, wake, and
# guard, so CLK and TCLK are held low in every cycle (BIN, SYM).
set_constraint {CLK}  -set {1'b0}
set_constraint {TCLK} -set {1'b0}

# --- BINCYCLE1: legal IDLE prelude ---
# cycle_fact:12 (IDLE: LS=DS=SD=0, POFF=00), cycle_fact:75/79 (entry requires ME=TME=0)
set_constraint {ME}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TME}  -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}   -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF} -cycle {BINCYCLE1} -set {2'b00}

# --- SYMCYCLE1: IDLE->DS entry ---
# cycle_fact:75 (assert DS, ME=TME=0, LS=SD=0, POFF=00), cycle_fact:14 (ROP_DS=1)
set_constraint {ME}   -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}   -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE1} -set {2'b00}
set_constraint {DS}   -cycle {SYMCYCLE1} -set {1'b1}

# --- SYMCYCLE2: DS retention hold ---
# cycle_fact:14 (DS held, ROP_DS=1)
set_constraint {DS}   -cycle {SYMCYCLE2} -set {1'b1}

# --- SYMCYCLE3: DS->WAKE_DS ---
# cycle_fact:76 (deassert DS while LS=SD=0; ROP_DS stays 1 in the model)
set_constraint {DS}   -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE3} -set {1'b0}
set_constraint {SD}   -cycle {SYMCYCLE3} -set {1'b0}

# --- SYMCYCLE4: DS exit cycle ---
# cycle_fact:15 (datasheet DS exit, ROP_DS=0); NOT observable in the model
# under held-low clocks (no posedge sel_clk or posedge DS fires) — ROP_DS
# stays 1. DS is held 0 to keep the powered-down state quiescent.
set_constraint {DS}   -cycle {SYMCYCLE4} -set {1'b0}

# --- SYMCYCLE5-6: DS wake guard (tPGGUARD=2) ---
# cycle_fact:77 (wait ROP_DS=0 then one guard cycle), cycle_fact:92 (retained data)
set_constraint {DS}   -cycle {SYMCYCLE5} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE6} -set {1'b0}

# --- SYMCYCLE7: IDLE->SD entry ---
# cycle_fact:79 (assert SD, ME=TME=0, LS=DS=0, POFF=00), cycle_fact:18 (ROP_SD=1)
set_constraint {ME}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {TME}  -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {LS}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {DS}   -cycle {SYMCYCLE7} -set {1'b0}
set_constraint {POFF} -cycle {SYMCYCLE7} -set {2'b00}
set_constraint {SD}   -cycle {SYMCYCLE7} -set {1'b1}

# --- SYMCYCLE8: SD retention hold ---
# cycle_fact:18 (SD held, ROP_SD=1)
set_constraint {SD}   -cycle {SYMCYCLE8} -set {1'b1}

# --- SYMCYCLE9: SD->WAKE_SD ---
# cycle_fact:80 (deassert SD with all enables low; ROP_SD stays 1 in the model)
set_constraint {SD}   -cycle {SYMCYCLE9} -set {1'b0}

# --- SYMCYCLE10: SD exit cycle ---
# cycle_fact:19 (datasheet SD exit, ROP_SD=0); NOT observable in the model
# under held-low clocks (no posedge sel_clk or posedge SD fires) — ROP_SD
# stays 1. SD is held 0 to keep the powered-down state quiescent.
set_constraint {SD}   -cycle {SYMCYCLE10} -set {1'b0}

# --- SYMCYCLE11-12: SD wake guard (tPGGUARD=2) ---
# cycle_fact:81 (apply tROPSD + tPGGUARD), cycle_fact:94 (data unknown until written)
set_constraint {SD}   -cycle {SYMCYCLE11} -set {1'b0}
set_constraint {SD}   -cycle {SYMCYCLE12} -set {1'b0}
