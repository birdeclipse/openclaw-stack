# Cycle Plan — deep-sleep-shutdown-retention

- corner: deep-sleep-shutdown-retention
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 1 | Establish legal IDLE before any power-mode transition: clocks low, ME=TME=0, LS=SD=DS=0, POFF=00. This is the mode-entry prelude A5 requires — the corner's first transition (IDLE->DS) is only legal from IDLE (`cycle_fact:75`), and IDLE requires LS=DS=SD=0, POFF=00 (`cycle_fact:12`). One cycle suffices because no reset pin exists and no `reset_latency_cycles` scalar is declared; the prelude is pure mode setup, not reset hold. |
| SYM | 12 | Walk the full deep-sleep/shutdown retention sequence cycle by cycle: IDLE->DS entry (assert DS, ROP_DS=1), DS hold, DS->WAKE_DS (deassert DS), DS exit cycle, DS wake guard (tPGGUARD=2), IDLE->SD entry (assert SD, ROP_SD=1), SD hold, SD->WAKE_SD (deassert SD), SD exit cycle, SD wake guard (tPGGUARD=2). Each transition and hold is one cycle; each wake guard is two (`cycle_fact:77`, `cycle_fact:81`). 1+1+1+1+2 + 1+1+1+1+2 = 12. |
| FLUSH | 0 | No pipeline state is in flight: Q is never updated in this schedule (no `posedge sel_clk` fires under the held-low clocks), so the QP pipeline (`pipeline_depth`=1, `fact:ddf-3f2da785`) carries nothing. All observable effects are outputs (ROP_DS, ROP_SD) that reach default comparison immediately at the cycle after their launch. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE prelude | Establish legal IDLE so the first power-mode transition is legal: clocks low, functional enables deasserted, all power-mode pins at their IDLE values. | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:12`, `cycle_fact:75`, `cycle_fact:79`, `pin:CLK`, `pin:TCLK`, `pin:ME`, `pin:TME`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | IDLE->DS entry | Assert DS from legal IDLE: clocks low, ME=TME=0, LS=SD=0, POFF=00. `posedge DS` fires the wrapper's power-mode block, capturing ROP_DS=1. | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `SD=1'b0`, `POFF=2'b00`, `DS=1'b1` | `cycle_fact:75`, `cycle_fact:14`, `cycle_fact:50`, `pin:DS` |
| SYMCYCLE2 | DS retention hold | Hold DS asserted; ROP_DS stays 1 (no edge fires). | `DS=1'b1`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:14`, `cycle_fact:50` |
| SYMCYCLE3 | DS->WAKE_DS | Deassert DS while LS=SD=0 and clocks remain low. The falling edge of DS does not trigger the wrapper's power-mode block, so ROP_DS stays 1 in the model. | `DS=1'b0`, `CLK=1'b0`, `TCLK=1'b0`, `LS=1'b0`, `SD=1'b0` | `cycle_fact:76`, `cycle_fact:50` |
| SYMCYCLE4 | DS exit cycle | Datasheet exit cycle (ROP_DS=0, `cycle_fact:15`); in the wrapper model ROP_DS stays 1 because no `posedge sel_clk` or `posedge DS` fires. Not observable. | `DS=1'b0`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:15`, `cycle_fact:77` |
| SYMCYCLE5-6 | DS wake guard | Hold the powered-down state through the datasheet-required wake guard (tPGGUARD=2 CLK cycles). No observable change in the model: ROP_DS stays 1, Q stays X. | `DS=1'b0`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:77`, `cycle_fact:92` |
| SYMCYCLE7 | IDLE->SD entry | Assert SD from IDLE: clocks low, ME=TME=0, LS=DS=0, POFF=00. `posedge SD` fires the wrapper's power-mode block, capturing ROP_SD=1 and ROP_DS=0 (DS is 0 here). | `CLK=1'b0`, `TCLK=1'b0`, `ME=1'b0`, `TME=1'b0`, `LS=1'b0`, `DS=1'b0`, `POFF=2'b00`, `SD=1'b1` | `cycle_fact:79`, `cycle_fact:18`, `cycle_fact:50`, `pin:SD` |
| SYMCYCLE8 | SD retention hold | Hold SD asserted; ROP_SD stays 1, ROP_DS stays 0 (no edge fires). | `SD=1'b1`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:18`, `cycle_fact:50` |
| SYMCYCLE9 | SD->WAKE_SD | Deassert SD with all enables low. The falling edge of SD does not trigger the wrapper's power-mode block, so ROP_SD stays 1 in the model. | `SD=1'b0`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:80`, `cycle_fact:50` |
| SYMCYCLE10 | SD exit cycle | Datasheet exit cycle (ROP_SD=0, `cycle_fact:19`); in the wrapper model ROP_SD stays 1 because no `posedge sel_clk` or `posedge SD` fires. Not observable. | `SD=1'b0`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:19`, `cycle_fact:81` |
| SYMCYCLE11-12 | SD wake guard | Hold the powered-down state through the datasheet-required wake guard (tPGGUARD=2 CLK cycles). No observable change in the model: ROP_SD stays 1, Q stays X. | `SD=1'b0`, `CLK=1'b0`, `TCLK=1'b0` | `cycle_fact:81`, `cycle_fact:94` |

## Flush phase

none (f=0; no pipeline state is in flight — see Cycle counts).

## Observability

A1 check: `pipeline_depth` = 1 (`fact:ddf-3f2da785`). For each operation launched in SYMCYCLE j, observability `s - j + f` = `12 - j + 0` must be `>= 1`. The last launched operation is IDLE->SD entry at j=7: `12 - 7 + 0 = 5 >= 1`. All earlier launches have larger observability. No operation is launched in SYMCYCLE8-12 (those are holds and guard waits), so the worst case j=s does not arise.

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| IDLE->DS entry | SYMCYCLE1 | SYMCYCLE2 | ROP_DS=1 | `posedge DS` in SYM1 fires the wrapper's power-mode always block (sram_1p2m_n3a_wrapper.sv:164-167), capturing `rop_ds_int <= DS = 1`. No later edge re-drives rop_ds_int until SYM7's posedge SD, so ROP_DS=1 is intact at SYM2. |
| DS retention hold | SYMCYCLE2 | SYMCYCLE3 | ROP_DS stays 1 | DS stays asserted and clocks stay low; no edge fires, so rop_ds_int holds 1. |
| DS->WAKE_DS | SYMCYCLE3 | SYMCYCLE4 | ROP_DS stays 1 (the datasheet ROP_DS=0 exit is NOT observable in this model) | Deasserting DS (1→0) is a falling edge, which does not trigger the wrapper's `posedge sel_clk or posedge SD or posedge DS` block. rop_ds_int holds 1. |
| IDLE->SD entry | SYMCYCLE7 | SYMCYCLE8 | ROP_SD=1 AND ROP_DS=0 | `posedge SD` in SYM7 fires the block, capturing `rop_sd_int <= SD = 1` and `rop_ds_int <= DS = 0`. Both are intact at SYM8 (no later edge). |
| SD retention hold | SYMCYCLE8 | SYMCYCLE9 | ROP_SD stays 1, ROP_DS stays 0 | SD stays asserted, clocks low; no edge fires. |
| SD->WAKE_SD | SYMCYCLE9 | SYMCYCLE10 | ROP_SD stays 1 (the datasheet ROP_SD=0 exit is NOT observable in this model) | Deasserting SD (1→0) is a falling edge, not triggering the block. rop_sd_int holds 1. |

The guard cycles (SYM4-6, SYM10-12) hold the powered-down state through the datasheet-required wake guard (`cycle_fact:77`, `cycle_fact:81`) but produce no observable change in the model: ROP_DS stays 1 through SYM4-6, ROP_SD stays 1 through SYM10-12, and Q stays X throughout. The datasheet's "wait until ROP_DS=0 / ROP_SD=0" precondition for the wake guard (`cycle_fact:77`, `cycle_fact:81`) is never met in the model, because the wrapper cannot register the exit value under held-low clocks.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| CLK | SYM | literal 1'b0 (every cycle) | All clock toggling and clock-edge transitions during the powered-down sequence | Clocks must be quiescent while DS/SD/POFF is active — any rising CLK/TCLK during a powered-down state is an illegal clock event (`cycle_fact:50`). The corner exists to verify the retention sequence, which requires clocks held low through entry, hold, wake, and guard. | `cycle_fact:50`, `cycle_fact:75`, `cycle_fact:76`, `cycle_fact:79`, `cycle_fact:80` |
| TCLK | SYM | literal 1'b0 (every cycle) | All TCLK toggling during the powered-down sequence | Same quiescence requirement as CLK (`cycle_fact:50`); TCLK is the BIST clock and must also stay low during powered-down states. | `cycle_fact:50` |
| DS | SYM | literal (SYM1=1, SYM2=1, SYM3-6=0) | DS transition space outside the entry/hold/wake/guard sequence | The corner is the DS retention sequence itself; DS must follow the entry->hold->wake pattern (`cycle_fact:75`, `cycle_fact:14`, `cycle_fact:76`). Directive-required. | `directive:3`, `cycle_fact:75`, `cycle_fact:14`, `cycle_fact:76` |
| SD | SYM | literal (SYM7=1, SYM8=1, SYM9-12=0) | SD transition space outside the entry/hold/wake/guard sequence | The corner is the shutdown retention sequence; SD must follow the entry->hold->wake pattern (`cycle_fact:79`, `cycle_fact:18`, `cycle_fact:80`). Directive-required. | `directive:3`, `cycle_fact:79`, `cycle_fact:18`, `cycle_fact:80` |
| ME, TME | SYM | literal 1'b0 (entry cycles SYM1, SYM7) | ME/TME transition space in the entry cycles | IDLE->DS and IDLE->SD entry require ME=TME=0 (`cycle_fact:75`, `cycle_fact:79`). In all other cycles ME/TME return to unconstrained. | `cycle_fact:75`, `cycle_fact:79` |
| LS | SYM | literal 1'b0 (entry/wake cycles SYM1, SYM3, SYM7) | LS transition space in the entry/wake cycles | IDLE->DS entry and DS->WAKE_DS require LS=0 (`cycle_fact:75`, `cycle_fact:76`); IDLE->SD entry requires LS=0 (`cycle_fact:79`). Elsewhere unconstrained. | `cycle_fact:75`, `cycle_fact:76`, `cycle_fact:79` |
| POFF | SYM | literal 2'b00 (entry cycles SYM1, SYM7) | POFF transition space in the entry cycles | IDLE->DS and IDLE->SD entry require POFF=00 (`cycle_fact:75`, `cycle_fact:79`). Elsewhere unconstrained. | `cycle_fact:75`, `cycle_fact:79` |

## Assumptions

- **No reset pin and no `reset_latency_cycles` scalar** exist in the corpus, so A5 binds only via the mode-entry prelude, not reset hold. The single BIN cycle establishes legal IDLE (clocks low, ME=TME=0, LS=SD=DS=0, POFF=00) as the prelude the first transition requires (`cycle_fact:12`, `cycle_fact:75`). This is a conservative minimum: one cycle of IDLE setup is sufficient because no reset settle is required.
- **`pipeline_depth` = 1** (`fact:ddf-3f2da785`): QP follows Q with one-cycle latency. This bounds A1; because Q is never updated in this schedule, the pipeline carries nothing and the flush phase is 0.
- **Clocks held low through the entire sym phase** is required by `cycle_fact:50` (no rising CLK/TCLK while DS/SD/POFF active). The plan holds CLK and TCLK low in every sym cycle, including the wake and guard cycles, because the powered-down state persists until the guard completes.
- **BC0/BC1/BC2, ADR, D, WE, WEM, HW, and all other data/address/control pins are left unconstrained** except where a transition row names them. The DS/SD entry rows do not require specific bias values (`cycle_fact:14`, `cycle_fact:18` leave BC0=0/1), so bias pins stay symbolic.
- **The IDLE->SD transition is legal directly from IDLE** (`cycle_fact:79`), and the plan returns to IDLE between the DS wake and the SD entry by holding ME=TME=0 and all power pins at IDLE values in SYMCYCLE7's precondition. This satisfies `cycle_fact:90` (powered states must pass through IDLE between them): the DS sequence completes through WAKE_DS->IDLE (guard cycles SYM5-6) before SD is asserted in SYM7.

## Limitations

- **The ROP_DS=0 and ROP_SD=0 exit transitions are NOT observable in the wrapper model under the legal held-low-clock stimulus.** The wrapper registers `rop_ds_int <= DS; rop_sd_int <= SD` only on `posedge sel_clk or posedge SD or posedge DS` (sram_1p2m_n3a_wrapper.sv:164-167), with `sel_clk = TCLKE ? TCLK : CLK` (line 114). With CLK=TCLK=0 the whole run, no `posedge sel_clk` fires; deasserting DS (SYM3) and SD (SYM9) are falling edges that do not trigger the block. So ROP_DS stays 1 through SYM4-6 (until SYM7's posedge SD captures DS=0) and ROP_SD stays 1 through SYM10-12. The datasheet intends ROP_DS=0 on DS exit (`cycle_fact:15`) and ROP_SD=0 on SD exit (`cycle_fact:19`), but the wrapper cannot produce these under held-low clocks. This is a model-vs-datasheet conflict: the wrapper's ROP_DS/ROP_SD model may itself disagree with the datasheet. The engineer should decide whether the wrapper is the intended model under test or whether the ROP_DS/ROP_SD behavior needs a model fix before this corner can verify the exits.
- **The forced-0 Q/QP/SO claims are NOT observable in the wrapper model under held-low clocks.** The wrapper forces `q_int <= 0` only on `posedge sel_clk` when `powered_down` (sram_1p2m_n3a_wrapper.sv:132-135). With CLK=TCLK=0 the whole run, no `posedge sel_clk` fires, so `q_int` is never forced to 0 and Q stays X (uninitialized array) for the entire schedule. The datasheet intends Q/QP/SO forced 0 on DS/SD entry (`cycle_fact:14`, `cycle_fact:18`), but the wrapper cannot produce this under held-low clocks.
- **Retention-data integrity is not observed.** The plan verifies the mode-transition outputs (ROP_DS/ROP_SD) and the guard-cycle timing, but it does not write then read back a retained word. `cycle_fact:92` states first-read returns previously stored data after DS wake if retention voltage was continuously met; the plan does not exercise a read-after-wake, so a retention-data corruption defect would not be caught by this schedule. This corner does not verify retention-data integrity; the mission-mode read/write corner also holds DS=SD=0 throughout and does not exercise a read-after-wake across a power event, so retention-data integrity is currently unverified by any corner in this run.
- **SD wake data is unknown by design** (`cycle_fact:94`): after SD, data is unknown until written. The plan observes the electrical validity of outputs, not data content.
- **No clock-edge behavior is exercised** during the powered-down states (by design, `cycle_fact:50` forbids it). The plan does not verify the illegal-clock-event response.
- **POFF and LS power modes are not exercised** beyond the IDLE values required for entry. The corner is scoped to DS and SD retention only (`directive:3`).

## Coverage

- catches: a defect that fails to assert ROP_DS=1 on DS entry (posedge DS) or ROP_SD=1 on SD entry (posedge SD); a defect that fails to hold ROP_DS/ROP_SD through the DS/SD hold and wake; a defect that fails to return to IDLE between the DS and SD powered states (`cycle_fact:90`); a defect that allows a clock edge during a powered-down state (would violate the held-low clocks and be exposed as an illegal event).
- misses: the ROP_DS=0/ROP_SD=0 exit transitions (not observable in the wrapper under held-low clocks — see Limitations); the forced-0 Q/QP/SO output convention (not observable in the wrapper under held-low clocks); retention-data corruption across the DS/SD hold (no read-after-wake is performed); SD wake data validity (unknown by design, `cycle_fact:94`); LS and POFF power-mode transitions; illegal-clock-event behavior during powered-down states. These are acceptable because the corner verifies what the wrapper model can actually produce under the legal held-low-clock stimulus, and the unobservable behaviors are reported as limitations/questions rather than asserted.
