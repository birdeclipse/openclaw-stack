# ---------------------------------------------------------------------------
# BIST-mode operation corner — ESP input constraints
# corner: bist-mode-operation
# run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
# corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
#
# Transliteration of plan.md (bist-mode-operation). Cycle counts b=3, s=5, f=3.
# The read-back address relation — full-address equality of the SYMCYCLE5 read
# address to the SYMCYCLE3 write address — is routed to the declaration file
# (testbench_declarations.sv) because it is a 2-cycle history that
# set_constraint cannot express (innopv_ gives only 1-cycle history). The .sv
# captures bist_write_addr <= innont_TADR on the SYMCYCLE3 TCLK posedge and
# assumes innont_TADR == bist_write_addr in SYMCYCLE5, so the read-back reads
# the write's address.
# ---------------------------------------------------------------------------

# --- testbench cycle counts (b=3, s=5, f=3) ---
set_app_var testbench_binary_cycles 3
set_app_var testbench_symbolic_cycles 5
set_app_var testbench_flush_cycles 3

# --- declaration file for the read-back full-address equality relation ---
set_app_var testbench_declaration_file ./testbench_declarations.sv

# --- pins held throughout the run ---
# SE_IN=0: required to enter and stay in BIST, not scan (cycle_fact:88, cycle_fact:58)
set_constraint {SE_IN} -set {1'b0}
# TCLKE=1: selects the BIST clock (cycle_fact:88)
set_constraint {TCLKE} -set {1'b1}

# --- CLK: low in BIN and FLUSH, unconstrained (legal ignored input) in SYM ---
# BIN requires both clocks low (cycle_fact:88); FLUSH keeps a clean exit (cycle_fact:89)
set_constraint {CLK} -set {1'b0} -if {inno_cycle_mode == "BINCYCLE" || inno_cycle_mode == "FLUSHCYCLE"}

# --- TCLK: alternating waveform; rising edges launch the BIST operations ---
set_constraint {TCLK} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TCLK} -cycle {BINCYCLE2} -set {1'b0}
set_constraint {TCLK} -cycle {BINCYCLE3} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {TCLK} -cycle {SYMCYCLE2} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE3} -set {1'b1}
set_constraint {TCLK} -cycle {SYMCYCLE4} -set {1'b0}
set_constraint {TCLK} -cycle {SYMCYCLE5} -set {1'b1}
set_constraint {TCLK} -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {TCLK} -cycle {FLUSHCYCLE2} -set {1'b0}
set_constraint {TCLK} -cycle {FLUSHCYCLE3} -set {1'b0}

# --- BISTE: asserted from BINCYCLE2 through FLUSHCYCLE1, deasserted in FLUSH2-3 ---
set_constraint {BISTE} -set {1'b1} -if {inno_cycle == "BINCYCLE2" || inno_cycle == "BINCYCLE3" || inno_cycle_mode == "SYMCYCLE" || inno_cycle == "FLUSHCYCLE1"}
set_constraint {BISTE} -set {1'b0} -if {inno_cycle == "FLUSHCYCLE2" || inno_cycle == "FLUSHCYCLE3"}

# --- TME: 1 in SYM (BIST operations), 0 in FLUSHCYCLE1 (deassert TME first) ---
set_constraint {TME} -set {1'b1} -if {inno_cycle_mode == "SYMCYCLE"}
set_constraint {TME} -set {1'b0} -if {inno_cycle == "FLUSHCYCLE1"}

# --- TWE: 0 (read) in SYMCYCLE1,5; 1 (write) in SYMCYCLE3 ---
set_constraint {TWE} -set {1'b0} -if {inno_cycle == "SYMCYCLE1" || inno_cycle == "SYMCYCLE5"}
set_constraint {TWE} -set {1'b1} -if {inno_cycle == "SYMCYCLE3"}

# --- THW: full word (2'b11) in the operation cycles ---
set_constraint {THW} -set {2'b11} -if {inno_cycle == "SYMCYCLE1" || inno_cycle == "SYMCYCLE3" || inno_cycle == "SYMCYCLE5"}

# --- TWEM: full write mask ('1) in the write cycle ---
set_constraint {TWEM} -set {'1} -if {inno_cycle == "SYMCYCLE3"}
