# Cycle Plan — bist-mode-operation

- corner: bist-mode-operation
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | IDLE->BIST mode-entry prelude per `cycle_fact:88`: establish TCLKE, assert BISTE, wait one inactive selected-clock cycle. |
| SYM | 5 | BIST read (j=1), low cycle, BIST write (j=3), low cycle, BIST read-back (j=5). Each operation needs a TCLK rising edge; alternating TCLK requires a low cycle between operations. |
| FLUSH | 3 | Execute the clean BIST->IDLE exit per `cycle_fact:89` (deassert TME first, selected clock low, deassert owner, wait one inactive cycle). The read-back is held on Q through the flush because no clock edge re-drives it. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1-3 | BIST entry | IDLE->BIST prelude | `CLK=1'b0`, `TCLK=1'b0`, `SE_IN=1'b0`, `TCLKE=1'b1`; `BISTE=1'b1` from BINCYCLE2 | `cycle_fact:88`, `pin:CLK`, `pin:TCLK`, `pin:SE_IN`, `pin:TCLKE`, `pin:BISTE` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | BIST read | launch BIST read on TCLK rising edge | `TCLK=1'b1`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b1`, `TWE=1'b0`, `THW=2'b11`; `TADR` symbolic | `cycle_fact:25`, `cycle_fact:6`, `pin:TME`, `pin:TWE`, `pin:THW` |
| SYMCYCLE2 | low cycle | TCLK falling edge, no operation | `TCLK=1'b0`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b1` | `cycle_fact:25` |
| SYMCYCLE3 | BIST write | launch BIST write on TCLK rising edge | `TCLK=1'b1`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b1`, `TWE=1'b1`, `THW=2'b11`, `TWEM='1`; `TADR`, `TD` symbolic | `cycle_fact:25`, `cycle_fact:10`, `pin:TWEM` |
| SYMCYCLE4 | low cycle | TCLK falling edge, no operation | `TCLK=1'b0`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b1` | `cycle_fact:25` |
| SYMCYCLE5 | BIST read-back | launch BIST read of the write's address on TCLK rising edge | `TCLK=1'b1`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0`, `TME=1'b1`, `TWE=1'b0`, `THW=2'b11`; `TADR` constrained to equal the SYMCYCLE3 write address via declaration file | `cycle_fact:25`, `cycle_fact:6` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | exit step 1 | deassert TME first, selected clock low; read-back data on Q | `TCLK=1'b0`, `CLK=1'b0`, `TME=1'b0`, `BISTE=1'b1`, `TCLKE=1'b1`, `SE_IN=1'b0` | `cycle_fact:89` |
| FLUSHCYCLE2 | exit step 2 | deassert owner (BISTE) with TME=0 and TCLK low | `TCLK=1'b0`, `CLK=1'b0`, `BISTE=1'b0`, `TCLKE=1'b1`, `SE_IN=1'b0` | `cycle_fact:89`, `cycle_fact:57` |
| FLUSHCYCLE3 | exit step 3 | wait one inactive cycle | `TCLK=1'b0`, `CLK=1'b0`, `BISTE=1'b0`, `TCLKE=1'b1`, `SE_IN=1'b0` | `cycle_fact:89` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| BIST read | SYMCYCLE1 (j=1) | FLUSHCYCLE3 | read data on Q/QP | Q holds read data from SYMCYCLE2, QP from SYMCYCLE3; no later cycle re-drives Q/QP; functional CLK toggle during BIST is a legal ignored input (`cycle_fact:55`) |
| BIST write | SYMCYCLE3 (j=3) | FLUSHCYCLE3 | array[TADR]=TD | verified by read-back j=5 reading the same address; read-back data is held on Q from SYMCYCLE5 through FLUSH (no clock edge re-drives it) |
| BIST read-back | SYMCYCLE5 (j=5) | FLUSHCYCLE3 | read data on Q | the read-back sets `q_int <= mem[TADR]` on the SYMCYCLE5 TCLK posedge; after SYMCYCLE5 no posedge sel_clk fires (TCLK=0 and CLK=0 in all flush cycles, TCLKE=1 so `sel_clk=TCLK=0`), so q_int is never re-driven and the read-back value is held on Q through FLUSH; exit deassertions are clean (TME=0 before BISTE, TCLK low) so the data persists (`cycle_fact:89`, `cycle_fact:57`) |

**A1 derivation** (pipeline_depth=1, `fact:ddf-3f2da785`): for an operation launched in SYMCYCLE j, cycles available to reach comparison are `s - j + f = 5 - j + 3`.

- BIST read j=1: `5 - 1 + 3 = 7 >= 1`. QP data by SYMCYCLE3. OK.
- BIST write j=3: effect verified by read-back j=5, whose data is held on Q from SYMCYCLE5 through FLUSH. `5 - 3 + 3 = 5 >= 1`. OK.
- BIST read-back j=5: `5 - 5 + 3 = 3 >= 1`. Observability is through Q (not QP): the read-back value is held on Q from SYMCYCLE5 through FLUSH because no clock edge re-drives it. Whether ESP's default comparison includes Q is a question the run owner must confirm (see Limitations).

A3 does not bind: this corner shifts no scan chain (`fact:ddf-e73df4c9` describes the scan corner's one-stage chains; no chain is shifted here). A5: no `reset_latency_cycles` scalar is cataloged; the mode-entry prelude (b=3) covers the IDLE->BIST entry per `cycle_fact:88`.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| TCLK | all | literal (alternating waveform) | TCLK waveform space; only the alternating L/H pattern explored | BIST operations require TCLK rising edges; corner requires the operations to execute deterministically | `cycle_fact:25`, `cycle_fact:88` |
| CLK | BIN, FLUSH | literal (1'b0) | CLK toggling in BIN/FLUSH | BIN requires both clocks low; FLUSH keeps a clean exit | `cycle_fact:88`, `cycle_fact:89` |
| SE_IN | all | literal (1'b0) | scan-mode exploration | SE_IN=0 required to enter and stay in BIST, not scan | `cycle_fact:88`, `cycle_fact:58` |
| TCLKE | all | literal (1'b1) | TCLKE toggling (which corrupts per R11) | TCLKE=1 selects the BIST clock; corner requires BIST clock selected | `cycle_fact:88`, `cycle_fact:56` |
| BISTE | BIN2-3, SYM, FLUSH1 | literal (1'b1) | BISTE toggling during operations (corrupts per R12) | BISTE=1 selects BIST mode; deasserted cleanly in exit | `cycle_fact:25`, `cycle_fact:57`, `cycle_fact:89` |
| BISTE | FLUSH2-3 | literal (1'b0) | BISTE held high through exit | clean BIST->IDLE exit deasserts owner | `cycle_fact:89` |
| TME | SYM | literal (1'b1) | TME toggling | TME=1 enables BIST operations | `cycle_fact:25` |
| TME | FLUSH1 | literal (1'b0) | TME held high through exit | exit deasserts TME first | `cycle_fact:89` |
| TWE | SYMCYCLE1,5 | literal (1'b0) | TWE read/write transition space | selects read | `cycle_fact:6` |
| TWE | SYMCYCLE3 | literal (1'b1) | TWE read/write transition space | selects write | `cycle_fact:10` |
| THW | SYMCYCLE1,3,5 | literal (2'b11) | half-word select space | full-word access | `cycle_fact:6`, `cycle_fact:10` |
| TWEM | SYMCYCLE3 | literal ('1) | write-mask space | full write mask | `cycle_fact:10` |
| TADR | SYMCYCLE5 | declaration-file relation (full-address equality to the SYMCYCLE3 write address) | transition space where read-back address differs from write address | read-back must read the write's address to verify the write | `cycle_fact:6` |

## Assumptions

- The BIST read/write operations mirror the functional READ/WRITE semantics (`cycle_fact:6`, `cycle_fact:10`) with the BIST port pins (TME/TWE/THW/TWEM/TD/TADR) on TCLK, per `cycle_fact:25`; no separate BIST truth-table rows are cataloged.
- THW is 2 bits (matching the functional HW=LL/LH/HL/HH semantics); TWEM is all-ones for a full write mask. Widths are not logged in the corpus, so `2'b11` and `'1` are used.
- TPR is left unconstrained during BIST operations; `cycle_fact:53` (R08) describes the functional ME path, not the BIST port.
- The array is uninitialized at start; reads return symbolic/unknown data, which the reference model handles identically.
- Functional-port pins (ME, WE, ADR, D, WEM, HW, DFTMASK, DFTCLKEN, redundancy, power) are left unconstrained during BIST; they are ignored while BISTE=1 (`cycle_fact:25`, `cycle_fact:55`).
- The read-back is observed on Q, not QP. This assumes ESP's default reference-versus-implementation comparison includes Q. If it checks only QP, the read-back (and therefore the write verification) would not reach comparison; the run owner must confirm Q is part of default comparison.

## Limitations

- The address relation is full-address equality of the SYMCYCLE5 read address to the SYMCYCLE3 write address, expressed via the declaration file (the .sv captures `bist_write_addr <= innont_TADR` on the SYMCYCLE3 TCLK posedge and assumes `innont_TADR == bist_write_addr` in SYMCYCLE5). The read-back must read the write's address, so the transition space where they differ is unexplored.
- The BIST write (j=3) is verified only through the read-back (j=5), whose observability is on Q, not QP. If ESP's default comparison checks only QP (the pipeline output), the write verification would not reach comparison. This is a question the run owner must confirm; the plan does not add a TCLK rising edge in the flush phase because `cycle_fact:89` requires the selected clock low during the clean BIST->IDLE exit.
- The array is uninitialized at start. The BIST read in SYMCYCLE1 returns symbolic/unknown data, and the read-back returns the written data only if the write succeeded. A dropped-write defect would make the read-back return X, which ESP's default comparison treats as a legal symbolic outcome — so a dropped-write defect may be indistinguishable from the uninitialized-array X. The write verification is therefore weaker than it appears.
- TCLK is bound to the alternating waveform; other clock waveforms are unexplored.
- Only full-word BIST accesses (THW=2'b11, TWEM='1) are exercised; half-word and masked BIST accesses are not.
- The illegal handoff transitions (TCLKE toggling while a clock is high, R11; BISTE changing while TME=1 or a clock is high, R12) are not exercised; the plan follows the guards to execute the legal sequence.

## Coverage

- catches: BIST-mode ownership handoff errors (BISTE/TCLKE guard violations), BIST read data-path errors, BIST write-then-read-back consistency, clean BIST->IDLE exit, functional-CLK-ignored behavior during BIST.
- misses: half-word/masked BIST accesses, TCLKE-toggling corruption (R11), BISTE-handoff corruption (R12), scan-mode overlap during BIST, and — because the array is uninitialized and the read-back is observed on Q — a dropped-write defect that manifests as X on the read-back. These are intentionally not exercised or are limited by the observability surface: the corner verifies the legal BIST operation sequence, not the illegal transitions, and the write verification's strength depends on Q being part of default comparison.
