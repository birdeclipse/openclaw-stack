// BIST-mode operation corner — declaration-file constraints
// corner: bist-mode-operation
// run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
// corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
//
// Wired from constraints.tcl via:
//   set_app_var testbench_declaration_file ./testbench_declarations.sv

// RULE: bist-readback-same-address
// reason: the BIST read-back in SYMCYCLE5 must read the same address the BIST
//         write wrote in SYMCYCLE3, so the write's effect is observable on Q.
//         This is a 2-cycle history relation — full-address equality of the
//         SYMCYCLE5 read address to the SYMCYCLE3 write address — that
//         set_constraint cannot express: innopv_ gives only 1-cycle history.
//         Built from helper state per the declaration-file guide (Part 2):
//         an always-block capture plus an SVA assume over the captured value.
//         TADR is assumed <= 32 bits (16384-deep array => 14-bit address).
reg [31:0] bist_write_addr;
always @(posedge TCLK)
  if (inno_cycle == "SYMCYCLE3")
    bist_write_addr <= innont_TADR;
bist_readback_same_address: assume property (@(posedge TCLK)
  (inno_cycle == "SYMCYCLE5") |-> (innont_TADR == bist_write_addr));
