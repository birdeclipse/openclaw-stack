# STATUS — trial8

Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
Corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
Ledger: 59 pins, 95 operations, 2 scalars (pipeline_depth=1, scan_chain_length=1)
Directives: mission-mode read/write; scan shift path; BIST-mode operation; deep-sleep/shutdown retention sequence

## Per-corner outcome and review outcome

| corner | plan outcome | review outcome | notes |
|---|---|---|---|
| mission-mode-read-write | plan | correct (missing: none) | 2 user-review items: Q-vs-QP default-comparison question; a write in the last SYM cycle is not verified. No revision required — none invalidated. |
| scan-shift-path | plan | correct (missing: none) | 3 user-review items (DFTMASK=1 out of scope; DFTCLKEN has no effect in the model; shift is observable from BIN2 onward). No revision required. |
| bist-mode-operation | plan | revised after review | 2 invalidating missing findings: (1) prose/Tcl described the read-back relation as TADR[5]==TADR[3] while the .sv implements full-address equality — prose, Tcl header, and .sv comment corrected to full-address equality; (2) the read-back was claimed to reach QP, but no clock edge fires after SYMCYCLE5 so QP never captures it — observability revised to Q, A1 row updated, no TCLK edge added in flush (respects cycle_fact:89). 2 user-review items: write verification strength depends on Q being in default comparison; dropped-write defect may be indistinguishable from uninitialized-array X. |
| deep-sleep-shutdown-retention | plan | revised after review | 2 invalidating missing findings: (1) claimed ROP_DS=0/ROP_SD=0 exits cannot occur in the wrapper under the held-low clocks (wrapper registers rop_ds_int/rop_sd_int only on posedge sel_clk/SD/DS); (2) claimed forced-0 Q/QP/SO is false in the model (q_int forced only on posedge sel_clk). Revised plan now reports the true model trace, marks the exits and forced-0 outputs explicitly NOT observable, and surfaces the model-vs-datasheet conflict as a question. f reduced to 0 (no pipeline state in flight). 1 user-review item: wrapper's ROP_DS/ROP_SD model may itself disagree with the datasheet — needs an engineer decision. |

## Cross-corner summary

See cross-corner-summary.md. The one genuine cross-corner gap: **retention-data
integrity is unverified by any corner.** mission-mode holds DS=SD=0 throughout;
deep-sleep verifies the mode-transition outputs but cannot observe Q under the
legal held-low-clock stimulus (the wrapper only updates q_int on a clock edge,
which cycle_fact:50 forbids while a power mode is active). So no corner
performs a write→retention→read-back word.

## What's left

- **Retention-data integrity** (open): either accept the gap as a limitation
  of the current wrapper model, or (a) correct the wrapper's ROP_DS/ROP_SD and
  q_int power-mode behavior (level-sensitive rather than edge-triggered), then
  re-plan deep-sleep to observe Q and add a write→DS→wake→read-back; or (b) add
  a dedicated retention-data-integrity corner over the corrected model. This is
  the only open item that needs a user decision to close.
- **Default-comparison surface (open question)**: mission-mode and BIST plans
  both assume ESP's default comparison includes Q (not only QP). Confirm this
  before running; if QP-only, the mission-mode flush and the BIST read-back
  lose their primary observability surface.
- **Wrapper ROP_DS/ROP_SD model-vs-datasheet conflict (open question)**:
  the datasheet intends ROP_DS=0/ROP_SD=0 on exit; the wrapper cannot produce
  it under the legal held-low-clock stimulus. Decide whether the wrapper is the
  intended model under test or needs a fix.
- Everything else is complete: every corner has a plan.md (guide template,
  corpus digest in header), constraints.tcl beside it, testbench_declarations.sv
  where routed (bist-mode-operation), and a review.md with all three buckets
  filled. Every review finding that invalidated a plan was revised; none stands
  against a published plan.
