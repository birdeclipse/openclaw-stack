# Corner Survey

Schema: esp.corner-roster.v1
Corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
Ledger facts: 59 pin(s), 95 operation(s), 2 scalar(s)

## Roster

| Corner | Classification | Reason |
| --- | --- | --- |
| calibration | unresolved | no supporting fact |
| clock-gating | unresolved | no supporting fact |
| idle | unresolved | no supporting fact |
| low-power-sequence | directive_named | directive named the corner: Verify the deep-sleep/shutdown retention sequence |
| mission-mode-read-write | directive_named | directive named the corner: Verify mission-mode read and write operations |
| multi-port-contention | absent | structurally impossible: single-port from typed pins ADR, BC0, BC1, BC2, BISTE, CAPT, CD, CLK, CRE1, CRE2, D, DFTCLKEN, DFTMASK, DS, FCA1, FCA2, FRA, HW, LS, ME, PIPEME, POFF, Q, QP, RA, RM, RME, ROP_DS, ROP_SD, RRE, SD, SE_IN, SI_CNTR, SI_D_H, SI_D_L, SI_Q_H, SI_Q_L, SO_CNTR, SO_D_H, SO_D_L, SO_Q_H, SO_Q_L, STICKY, TADR, TCLK, TCLKE, TD, TEST1, TEST_RNM, THW, TME, TPIPEME, TPR, TWE, TWEM, WA, WE, WEM, WPULSE |
| redundancy | candidate | pin-name rule matched CRE1, CRE2, FCA1, FCA2, FRA, RRE |
| scan-dft | directive_named | directive named the corner: Verify the scan shift path; Verify BIST-mode operation |
| bist-mode-operation | fact_supported | function_corner fact 158: Verify BIST-mode operation: with BISTE=1 the BIST port &#40;TME/TWE/TADR/TD/TWEM/THW/TCLK&#41; owns the muxed memory inputs and executes BIST-mode reads and writes, with TCLKE selecting the BIST clock; ownership handoff must follow the one-inactive-cycle guard. |
| deep-sleep-shutdown-retention | fact_supported | function_corner fact 159: Verify the deep-sleep/shutdown retention sequence: legal IDLE-&gt;DS entry with outputs forced 0 and ROP_DS=1, retained array through DS, wake through WAKE_DS &#40;ROP_DS=0 plus guard cycle&#41;, and the destructive IDLE-&gt;SD path with ROP_SD; clocks must be quiescent during powered-down states. |
| scan-shift-path | fact_supported | function_corner fact 157: Verify the scan shift path: with SE_IN asserted, each scan chain &#40;Q_L/Q_H/D_L/D_H/CNTR&#41; shifts its SI input to its SO output across a full chain traversal. |

## Certified selection

- mission-mode-read-write
- low-power-sequence
- scan-dft
- bist-mode-operation
- deep-sleep-shutdown-retention
- scan-shift-path
- redundancy

## Pin inventory

| Pin | Direction |
| --- | --- |
| ADR | input |
| BC0 | input |
| BC1 | input |
| BC2 | input |
| BISTE | input |
| CAPT | input |
| CD | input |
| CLK | input |
| CRE1 | input |
| CRE2 | input |
| D | input |
| DFTCLKEN | input |
| DFTMASK | input |
| DS | input |
| FCA1 | input |
| FCA2 | input |
| FRA | input |
| HW | input |
| LS | input |
| ME | input |
| PIPEME | input |
| POFF | input |
| Q | output |
| QP | output |
| RA | input |
| RM | input |
| RME | input |
| ROP_DS | output |
| ROP_SD | output |
| RRE | input |
| SD | input |
| SE_IN | input |
| SI_CNTR | input |
| SI_D_H | input |
| SI_D_L | input |
| SI_Q_H | input |
| SI_Q_L | input |
| SO_CNTR | output |
| SO_D_H | output |
| SO_D_L | output |
| SO_Q_H | output |
| SO_Q_L | output |
| STICKY | input |
| TADR | input |
| TCLK | input |
| TCLKE | input |
| TD | input |
| TEST1 | input |
| TEST_RNM | input |
| THW | input |
| TME | input |
| TPIPEME | input |
| TPR | input |
| TWE | input |
| TWEM | input |
| WA | input |
| WE | input |
| WEM | input |
| WPULSE | input |

## Evidence catalog

| Ref | Evidence |
| --- | --- |
| cycle_fact:0 | ledger:60: truth_table_row&#40;IDLE, CLK=L, ME=X, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;no change in memory contents&#41;&#41; |
| cycle_fact:1 | ledger:61: truth_table_row&#40;DISABLED, CLK=H, ME=L, TPR=X, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM&#41; |
| cycle_fact:2 | ledger:62: truth_table_row&#40;DISABLED, CLK=H, ME=X, TPR=H, HW=XX, WE=X, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM&#41; |
| cycle_fact:3 | ledger:63: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;both halves disabled, no read&#41;&#41; |
| cycle_fact:4 | ledger:64: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=LH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH-1/QL; NCM &#40;lower half read out, upper half holds&#41;&#41; |
| cycle_fact:5 | ledger:65: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HL, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=QH/QL-1; NCM &#40;upper half read out, lower half holds&#41;&#41; |
| cycle_fact:6 | ledger:66: truth_table_row&#40;READ, CLK=H, ME=H, TPR=L, HW=HH, WE=L, WEM=X, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q; NCM &#40;full word read from addressed location&#41;&#41; |
| cycle_fact:7 | ledger:67: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;both halves disabled, no bits written&#41;&#41; |
| cycle_fact:8 | ledger:68: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=LH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array&#91;L&#93;=Data-in&#91;L&#93; &#40;lower half written, upper half NCM&#41;&#41; |
| cycle_fact:9 | ledger:69: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HL, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array&#91;H&#93;=Data-in&#91;H&#93; &#40;upper half written, lower half NCM&#41;&#41; |
| cycle_fact:10 | ledger:70: truth_table_row&#40;WRITE, CLK=H, ME=H, TPR=L, HW=HH, WE=H, WEM=H, D=Data-in, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; Array=Data-in &#40;full word written&#41;&#41; |
| cycle_fact:11 | ledger:71: truth_table_row&#40;MASK, CLK=H, ME=H, TPR=L, HW=XX, WE=H, WEM=L, D=X, DFTMASK=X, SE_IN=X, DFTCLKEN=L, BISTE=L, Q=Q-1; NCM &#40;masked write, no bits written&#41;&#41; |
| cycle_fact:12 | ledger:72: truth_table_row&#40;NORMAL, ME=0/1, HW=hw_val, LS=0, DS=0, SD=0, POFF=00, BC0=0/1, Q=Q-1, QP=QP-1, SO=SO-1; ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1&#41; |
| cycle_fact:13 | ledger:73: truth_table_row&#40;LIGHT_SLEEP, ME=0/1, HW=XX, LS=1, DS=0, SD=0, POFF=00, BC0=0/1, Q=Q-1, QP=QP-1, SO=SO-1; Xdec power gate, source bias &#40;retained&#41;&#41; |
| cycle_fact:14 | ledger:74: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0-&gt;1, SD=0, POFF=00, BC0=0/1, Q=0, QP=0, SO=0; ROP_DS=1; periphery shutdown, source bias&#41; |
| cycle_fact:15 | ledger:75: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1-&gt;0, SD=0, POFF=00, BC0=0/1, Q=0, QP=X, SO=X; ROP_DS=0 &#40;DS exit&#41;&#41; |
| cycle_fact:16 | ledger:76: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=0-&gt;1, SD=1, POFF=00, BC0=0/1, Q=0, QP=0, SO=0; ROP_DS=1&#41; |
| cycle_fact:17 | ledger:77: truth_table_row&#40;DEEP_SLEEP, ME=X, HW=XX, LS=X, DS=1-&gt;0, SD=1, POFF=00, BC0=0/1, Q=0, QP=0, SO=0; ROP_DS=1&#41; |
| cycle_fact:18 | ledger:78: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0-&gt;1, POFF=00, BC0=X, Q=0, QP=0, SO=0; ROP_SD=1; periphery and array shutdown&#41; |
| cycle_fact:19 | ledger:79: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1-&gt;0, POFF=00, BC0=X, Q=0, QP=X, SO=X; ROP_SD=0 &#40;SD exit&#41;&#41; |
| cycle_fact:20 | ledger:80: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=0-&gt;1, POFF=00, BC0=X, Q=0, QP=0, SO=0; ROP_SD=1&#41; |
| cycle_fact:21 | ledger:81: truth_table_row&#40;SHUTDOWN, ME=X, HW=XX, LS=X, DS=1/0, SD=1-&gt;0, POFF=00, BC0=X, Q=0, QP=0, SO=0; ROP_SD=1&#41; |
| cycle_fact:22 | ledger:82: truth_table_row&#40;STANDARD_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=01, BC0=X, Q=Q-1, QP=X, SO=X; ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1&#41; |
| cycle_fact:23 | ledger:83: truth_table_row&#40;SHUTDOWN_PERIPHERY_OFF, ME=X, HW=XX, LS=X, DS=X, SD=X, POFF=11, BC0=X, Q=Q-1, QP=X, SO=X; ROP_DS=ROP_DS-1, ROP_SD=ROP_SD-1&#41; |
| cycle_fact:24 | ledger:84: truth_table_row&#40;NORMAL, BISTE=L, functional port owns the memory &#40;ME, WE, ADR, D, WEM, CLK active&#41;&#41; |
| cycle_fact:25 | ledger:85: truth_table_row&#40;BIST, BISTE=H, BIST port owns the memory &#40;TME, TWE, TADR, TD, TWEM, TCLK active&#41;&#41; |
| cycle_fact:26 | ledger:86: truth_table_row&#40;REDUNDANCY_COLUMN_NORMAL, CRE=0, FCA=X, no repair element selected&#41; |
| cycle_fact:27 | ledger:87: truth_table_row&#40;REDUNDANCY_COLUMN_REPAIR, CRE=1, FCA=FCA&#91;n&#93;, faulty column replaced by redundant column&#41; |
| cycle_fact:28 | ledger:88: truth_table_row&#40;REDUNDANCY_COLUMN_NORMAL, CRE1=0, CRE2=0, FCA1=X, FCA2=X, no repair element selected&#41; |
| cycle_fact:29 | ledger:89: truth_table_row&#40;REDUNDANCY_COLUMN_LEFT_REPAIR, CRE1=1, CRE2=0, FCA1=FCA1&#91;n&#93;, FCA2=X, faulty column on left side replaced by left redundant column&#41; |
| cycle_fact:30 | ledger:90: truth_table_row&#40;REDUNDANCY_COLUMN_RIGHT_REPAIR, CRE1=0, CRE2=1, FCA1=X, FCA2=FCA2&#91;n&#93;, faulty column on right side replaced by right redundant column&#41; |
| cycle_fact:31 | ledger:91: truth_table_row&#40;REDUNDANCY_COLUMN_BOTH_REPAIR, CRE1=1, CRE2=1, FCA1=FCA1&#91;n&#93;, FCA2=FCA2&#91;n&#93;, faulty column on both sides replaced by respective redundant columns&#41; |
| cycle_fact:32 | ledger:92: truth_table_row&#40;REDUNDANCY_ROW_NORMAL, RRE=0, FRA=X, no repair element selected&#41; |
| cycle_fact:33 | ledger:93: truth_table_row&#40;REDUNDANCY_ROW_REPAIR, RRE=1, FRA=FRA&#91;n&#93;, faulty row replaced by redundant row element&#41; |
| cycle_fact:34 | ledger:94: truth_table_row&#40;BIAS_NORMAL, BC0=0/1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=0, active-mode bias &#40;no source bias applied&#41;&#41; |
| cycle_fact:35 | ledger:95: truth_table_row&#40;BIAS_LS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=0, LS=1, debug mode; array bias removed in Light Sleep&#41; |
| cycle_fact:36 | ledger:96: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=0, SD=0, DS=0, LS=1, Light Sleep with array bias via BC1&#41; |
| cycle_fact:37 | ledger:97: truth_table_row&#40;BIAS_LS, BC0=0, BC1=0, BC2=1, SD=0, DS=0, LS=1, Light Sleep with array bias via BC2&#41; |
| cycle_fact:38 | ledger:98: truth_table_row&#40;BIAS_LS, BC0=0, BC1=1, BC2=1, SD=0, DS=0, LS=1, Light Sleep with array bias via BC1 and BC2&#41; |
| cycle_fact:39 | ledger:99: truth_table_row&#40;BIAS_LS_NO_BIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=0, LS=1, Light Sleep without array bias &#40;BC0 bypasses bias&#41;&#41; |
| cycle_fact:40 | ledger:100: truth_table_row&#40;BIAS_DS_DEBUG, BC0=0, BC1=0, BC2=0, SD=0, DS=1, LS=0, debug mode; array bias removed in Deep Sleep&#41; |
| cycle_fact:41 | ledger:101: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=0, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC1&#41; |
| cycle_fact:42 | ledger:102: truth_table_row&#40;BIAS_DS, BC0=0, BC1=0, BC2=1, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC2&#41; |
| cycle_fact:43 | ledger:103: truth_table_row&#40;BIAS_DS, BC0=0, BC1=1, BC2=1, SD=0, DS=1, LS=0, Deep Sleep with array bias via BC1 and BC2&#41; |
| cycle_fact:44 | ledger:104: truth_table_row&#40;BIAS_DS_NO_BIAS, BC0=1, BC1=0/1, BC2=0/1, SD=0, DS=1, LS=0, Deep Sleep without array bias &#40;BC0 bypasses bias&#41;&#41; |
| cycle_fact:45 | ledger:105: truth_table_row&#40;BIAS_SHUTDOWN, BC0=0/1, BC1=0/1, BC2=0/1, SD=1, DS=0, LS=0, Shutdown without array retention&#41; |
| cycle_fact:46 | ledger:106: truth_table_row&#40;R01_SD_DS, SD=1 and DS=1 &#40;advanced power mode&#41;, Q/QP/SO forced 0; shutdown wins; retention not guaranteed&#41; |
| cycle_fact:47 | ledger:107: truth_table_row&#40;R02_POWER_LS_OVERLAP, SD=1 and LS=1, or DS=1 and LS=1, Q/QP/SO take the deeper-mode value &#40;0 in DS/SD&#41;; deeper mode wins; LS must be deasserted before wake begins&#41; |
| cycle_fact:48 | ledger:108: truth_table_row&#40;R03_POFF10_BC0, POFF=2'b10 while BC0=0 &#40;embedded dual rail&#41;, Q/QP/SO=X; array retained&#41; |
| cycle_fact:49 | ledger:109: truth_table_row&#40;R04_POFF_POWER_OVERLAP, POFF=2'b01 with SD=1, or POFF=2'b11 with DS-only request, Q/QP/SO=X; destructive mode wins&#41; |
| cycle_fact:50 | ledger:110: truth_table_row&#40;R05_CLOCK_WHILE_POWERED_DOWN, any rising CLK/TCLK while DS, SD, or POFF is active, no valid output event; powered outputs retain forced value; illegal clock event&#41; |
| cycle_fact:51 | ledger:111: truth_table_row&#40;R06_HW00_WRITE_NOOP, ME=1, WE=1, HW=00, Q retains Q-1; no bits written&#41; |
| cycle_fact:52 | ledger:112: truth_table_row&#40;R07_HW_PRIORITY, ME=1, WE=1, any selected WEM=1, but its corresponding half is disabled by HW, Q retains Q-1; disabled-half cells retain data&#41; |
| cycle_fact:53 | ledger:113: truth_table_row&#40;R08_TPR_IDLE, TPR=1 while ME=1, Q retains Q-1; no read/write; changes on ADR/D/WE/WEM ignored until TPR setup met&#41; |
| cycle_fact:54 | ledger:114: truth_table_row&#40;R09_TPR_APERTURE, TPR changes inside its CLK setup/hold aperture while ME=1, Q=X for current access; write corrupts current selected WEM bits&#41; |
| cycle_fact:55 | ledger:115: truth_table_row&#40;R10_BISTE_FUNC_CLK, BISTE=1 and functional CLK toggles while TCLKE selects TCLK, BIST result only; functional CLK has no effect &#40;legal ignored input&#41;&#41; |
| cycle_fact:56 | ledger:116: truth_table_row&#40;R11_TCLKE_HIGH, TCLKE toggles while either CLK or TCLK is high, Q/QP/SO=X for one cycle; a runt internal clock may corrupt the current address on a write&#41; |
| cycle_fact:57 | ledger:117: truth_table_row&#40;R12_BISTE_HANDOFF, BISTE changes while ME=1 or TME=1, or while selected clock is high, Q/QP=X until one clean inactive cycle; if WE or TWE was active, selected word/bit mask is corrupted&#41; |
| cycle_fact:58 | ledger:118: truth_table_row&#40;R13_SE_IN_DFTMASK, SE_IN=1 with DFTMASK=1, scan output advances; Q=X; SE_IN scan ownership wins&#41; |
| cycle_fact:59 | ledger:119: truth_table_row&#40;R14_DFTMASK_NO_CLKEN, DFTMASK=1 and DFTCLKEN=0, Q retains Q-1; diagnostic issued&#41; |
| cycle_fact:60 | ledger:120: truth_table_row&#40;R15_TEST_RNM_OVERLAP, TEST_RNM=1 with BISTE=1, SE_IN=1, DFTMASK=1, or TEST1=1, Q=X; array retained; TEST_RNM idle/precharge containment wins below power modes&#41; |
| cycle_fact:61 | ledger:121: truth_table_row&#40;R16_TEST1_INCOMPLETE, TEST1=1 and CLK does not have both a valid rising and falling edge, read Q=X; write completion unknown; current selected word/bit mask corrupted for write&#41; |
| cycle_fact:62 | ledger:122: truth_table_row&#40;R17_RM_TIMING, RME or RM changes with ME=1, or less than tRMSTB before an access, current read Q=X; current selected WEM bits may be corrupted on write&#41; |
| cycle_fact:63 | ledger:123: truth_table_row&#40;R18_ASSIST_DIFFERS, WA, RA, or WPULSE differs from the table-selected value while not in authorized characterization test mode, Q may be X; no broad corruption; current accessed word may be disturbed&#41; |
| cycle_fact:64 | ledger:124: truth_table_row&#40;R19_DUAL_ROW_REPAIR_CONFLICT, RRE1=RRE2=1 and FRA1=FRA2, Q=X on matching address; both repair selections suppressed&#41; |
| cycle_fact:65 | ledger:125: truth_table_row&#40;R20_REPAIR_TIMING, CRE/FCA or RRE/FRA changes while ME=1 or within repair setup/hold aperture, Q=X on possible match; current logical and spare locations both pessimistically corrupted for write&#41; |
| cycle_fact:66 | ledger:126: truth_table_row&#40;R21_ADR_UNIMPLEMENTED, ADR encodes an unimplemented &#40;non-power-of-two logical depth&#41; location, Q=X; writes are ignored&#41; |
| cycle_fact:67 | ledger:127: truth_table_row&#40;R22_CAPT_BISTE0, CAPT=0 while BISTE=0, no effect; comparator state unchanged &#40;legal ignored input&#41;&#41; |
| cycle_fact:68 | ledger:128: truth_table_row&#40;R23_PIPEME_TPIPEME, PIPEME=1 and TPIPEME=1 simultaneously, QP captures from PIPEME when BISTE=0, from TPIPEME when BISTE=1&#41; |
| cycle_fact:69 | ledger:129: truth_table_row&#40;R24_POWER_DURING_SCAN, power mode asserted during scan shift, deep-mode output convention; scan state not guaranteed; array retention follows selected power mode&#41; |
| cycle_fact:70 | ledger:130: truth_table_row&#40;TRANS_IDLE_ACTIVE, IDLE-&gt;ACTIVE: LS=DS=SD=0, POFF inactive, selected enable asserted with setup met, data preserved; normal tCQ behavior&#41; |
| cycle_fact:71 | ledger:131: truth_table_row&#40;TRANS_ACTIVE_IDLE, ACTIVE-&gt;IDLE: deassert ME/TME; complete any TEST1 falling edge; one full inactive clock cycle before ownership/power changes, data preserved; last Q/QP retained&#41; |
| cycle_fact:72 | ledger:132: truth_table_row&#40;TRANS_IDLE_LS, IDLE-&gt;LS: assert LS while DS=SD=0 and POFF inactive; minimum dwell tLSENT, data retained; Q/QP/SO retain prior values&#41; |
| cycle_fact:73 | ledger:133: truth_table_row&#40;TRANS_LS_IDLE, LS-&gt;IDLE: deassert LS; hold ME=TME=0; tLSEXT before next active clock, data retained; prior values retained&#41; |
| cycle_fact:74 | ledger:134: truth_table_row&#40;TRANS_ACTIVE_LS, ACTIVE-&gt;LS &#40;direct&#41;, no direct ACTIVE-&gt;LS transition; must go through IDLE&#41; |
| cycle_fact:75 | ledger:135: truth_table_row&#40;TRANS_IDLE_DS, IDLE-&gt;DS: clocks low; ME=TME=0; LS=SD=0; assert DS; minimum dwell tDSENT, Q/QP/SO forced 0; ROP_DS=1; retained if VDDA remains in retention range&#41; |
| cycle_fact:76 | ledger:136: truth_table_row&#40;TRANS_DS_WAKE_DS, DS-&gt;WAKE_DS: deassert DS while LS=SD=0 and clocks remain low, Q=0, QP/SO=X; ROP_DS=1; retained&#41; |
| cycle_fact:77 | ledger:137: truth_table_row&#40;TRANS_WAKE_DS_IDLE, WAKE_DS-&gt;IDLE: wait until ROP_DS=0, then one guard cycle &#40;tROPDS + tPGGUARD&#41;, outputs become valid after guard; data retained&#41; |
| cycle_fact:78 | ledger:138: truth_table_row&#40;TRANS_DS_SD, DS-&gt;SD: assert SD while clocks remain low; minimum dwell tSDFALL, destroyed/unknown; outputs forced 0; ROP_SD=1&#41; |
| cycle_fact:79 | ledger:139: truth_table_row&#40;TRANS_IDLE_SD, IDLE-&gt;SD: clocks low; ME=TME=0; LS=DS=0; assert SD; minimum dwell tSDENT, Q/QP/SO forced 0; ROP_SD=1; destroyed/unknown upon assertion&#41; |
| cycle_fact:80 | ledger:140: truth_table_row&#40;TRANS_SD_WAKE_SD, SD-&gt;WAKE_SD: restore supplies, then deassert SD; keep all enables low, Q=0, QP/SO=X; ROP_SD=1; unknown; initialization/BIST required&#41; |
| cycle_fact:81 | ledger:141: truth_table_row&#40;TRANS_WAKE_SD_IDLE, WAKE_SD-&gt;IDLE: wait until ROP_SD=0, then apply tPGGUARD &#40;tROPSD + tPGGUARD&#41;, outputs valid electrically, data unknown until written&#41; |
| cycle_fact:82 | ledger:142: truth_table_row&#40;TRANS_IDLE_POFF_RET, IDLE-&gt;POFF_RET: POFF 00-&gt;01; periphery clock stopped; minimum dwell tPOFFENT, Q/QP/SO=X after periphery supply collapse; retained if VDDA valid&#41; |
| cycle_fact:83 | ledger:143: truth_table_row&#40;TRANS_POFF_RET_IDLE, POFF_RET-&gt;IDLE: restore VDD first, wait tVDDSTB, then remove POFF, retained; X until periphery is stable&#41; |
| cycle_fact:84 | ledger:144: truth_table_row&#40;TRANS_IDLE_POFF_SD, IDLE-&gt;POFF_SD: POFF 00-&gt;11 with clocks/enables inactive; minimum dwell tPOFFENT, Q/QP/SO=X; destroyed&#41; |
| cycle_fact:85 | ledger:145: truth_table_row&#40;TRANS_LS_DS, LS-&gt;DS: deassert LS, wait tLSEXT, then assert DS, retained; last Q then forced 0&#41; |
| cycle_fact:86 | ledger:146: truth_table_row&#40;TRANS_DS_LS, DS-&gt;LS: complete DS-&gt;WAKE_DS-&gt;IDLE, then assert LS, retained; per DS wake sequence&#41; |
| cycle_fact:87 | ledger:147: truth_table_row&#40;TRANS_IDLE_SCAN, IDLE-&gt;SCAN: both clocks low; BISTE=0; assert SE_IN; then enable DFT clock, SO follows scan timing; Q not functionally updated; array preserved&#41; |
| cycle_fact:88 | ledger:148: truth_table_row&#40;TRANS_IDLE_BIST, IDLE-&gt;BIST: both clocks low; SE_IN=0; establish TCLKE; assert BISTE; wait one inactive selected-clock cycle, BIST owns all muxed inputs; preserved until BIST writes&#41; |
| cycle_fact:89 | ledger:149: truth_table_row&#40;TRANS_SCAN_BIST_IDLE, SCAN or BIST-&gt;IDLE: deassert DFTCLKEN/TME first; selected clock low; deassert owner; wait one inactive cycle, as modified by test; last test outputs may persist&#41; |
| cycle_fact:90 | ledger:150: truth_table_row&#40;TRANS_POWER_OWNER_REENTRY, any powered/power state to another owner or power state without passing through IDLE, X or deeper-mode clamp; illegal&#41; |
| cycle_fact:91 | ledger:151: truth_table_row&#40;WAKE_LS_ACCESS, wake from LS &#40;post-tLSEXT&#41;, read/write after tLSEXT; first-read returns previously stored data&#41; |
| cycle_fact:92 | ledger:152: truth_table_row&#40;WAKE_DS_ACCESS, wake from DS &#40;after ROP_DS=0 plus guard cycle&#41;, read/write after ROP_DS=0 plus guard; first-read returns previously stored data if retention voltage continuously met&#41; |
| cycle_fact:93 | ledger:153: truth_table_row&#40;WAKE_POFF_RET_ACCESS, wake from retentive POFF &#40;after VDD stable, POFF inactive, guard complete&#41;, read/write after VDD stable, POFF inactive, guard complete; first-read returns previously stored data if VDDA valid&#41; |
| cycle_fact:94 | ledger:154: truth_table_row&#40;WAKE_SD_ACCESS, wake from SD / destructive POFF &#40;write, initialization, or destructive BIST only&#41;, X; reading before initialization is legal electrically but data unknown; first write establishes validity only for written WEM/HW bits&#41; |
| fact:ddf-3f2da785 | The pipeline output &#40;QP&#41; follows the regular output &#40;Q&#41; with a latency of one clock cycle. |
| fact:ddf-e73df4c9 | Each scan chain is modeled as a one-stage pass-through of its input when SE_IN=1, so one logical shift traverses a chain in the model under test. |
| directive:0 | Verify mission-mode read and write operations |
| directive:1 | Verify the scan shift path |
| directive:2 | Verify BIST-mode operation |
| directive:3 | Verify the deep-sleep/shutdown retention sequence |

Every pin in the inventory above is also citable evidence as `pin:<NAME>`.

## Evidence gaps

- No deck model: pin directions come from the logged pin facts only. The corner rules read those same logged directions.
