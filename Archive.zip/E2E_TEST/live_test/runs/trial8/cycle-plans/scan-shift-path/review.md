# Review — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## correct

- **A3 holds.** `scan_chain_length = 1` (`fact:ddf-e73df4c9`: each chain is a one-stage pass-through when SE_IN=1). `f = 1 >= 1`, and SE_IN is driven in every flush cycle — FLUSHCYCLE1 drives `SE_IN=1'b1` (constraints.tcl line 81). Coverage is per cycle, and the single flush cycle is covered. The plan states this explicitly (plan.md lines 18-23).
- **A1 holds.** `pipeline_depth = 0` for the scan path (`fact:ddf-e73df4c9`); the shift launches in SYMCYCLE1 (j=1), `s - j + f = 1 - 1 + 1 = 1 >= 0`. The mission pipeline latency of 1 (`fact:ddf-3f2da785`) applies to QP following Q, not the scan SO_* path, and is correctly excluded. The plan names j and shows the derivation (plan.md lines 25-30).
- **A5 does not bind.** No reset pin exists in the inventory; b=3 is derived from the IDLE->SCAN prelude (`cycle_fact:87`: both clocks low, BISTE=0, assert SE_IN, then enable DFT clock), not from a reset latency. Consistent with guide A5.
- **Selectors are sane.** All cycle selectors are 1-based, in-phase, monotone, non-overlapping; no pin is assigned two values in one cycle. The constraints.tcl is a faithful transliteration of the plan's phase tables (same cycles, same values, same holds) — verified line by line against plan.md BIN/SYM/FLUSH rows.
- **The shift is observable in the model.** The wrapper models scan outputs as `assign SO_* = SE_IN ? SI_* : 1'b0` (sram_1p2m_n3a_wrapper.sv:175-179). With SE_IN=1 held in SYM and FLUSH, SO_* = SI_* (symbolic), so the shift result reaches default comparison intact. The plan's observability row (plan.md line 60) is true in the model.
- **The IDLE->SCAN prelude maps correctly.** BINCYCLE1 (IDLE hold), BINCYCLE2 (assert SE_IN), BINCYCLE3 (enable DFT clock) map the three causal steps of `cycle_fact:87` to three BIN cycles. The plan's BIN rows cite the correct evidence.
- **Citations resolve.** Every ref (cycle_fact:0, 12, 58, 69, 87; fact:ddf-e73df4c9; directive:1; pin:*) is in the survey's Evidence catalog. The corpus digest in the header matches the survey.

## missing

- none

## user-review

- **DFTMASK=0 is held during the shift, excluding the DFTMASK=1 scan behavior.** `cycle_fact:58` states SE_IN=1 with DFTMASK=1 also advances the scan output (with Q=X). The plan holds DFTMASK=0 (plan.md line 68, constraints.tcl line 65), which is not required for the shift (the wrapper's SO_* is independent of DFTMASK) and narrows the corner to the "clean shift". The plan discloses this in Limitations (line 94). Reasonable scoping, but the engineer should confirm the DFTMASK=1 scan path is covered elsewhere or accept it as out of scope.
- **DFTCLKEN=1 has no effect on the scan outputs in the model.** The wrapper's scan outputs are purely SE_IN-gated (sram_1p2m_n3a_wrapper.sv:175-179); DFTCLKEN does not gate them. The plan enables DFTCLKEN per `cycle_fact:87` (the IDLE->SCAN sequence), which is harmless but does not actually enable any clock in the model. The shift works regardless. Not a defect — the observability holds — but the "DFT clock enabled" causal step is not reflected in the model's scan path.
- **The scan shift is combinational, so it is observable from BINCYCLE2 onward** (when SE_IN first asserts), not only from SYMCYCLE1. The plan's launch-cycle claim (SYMCYCLE1) is conservative and correct; no defect.
