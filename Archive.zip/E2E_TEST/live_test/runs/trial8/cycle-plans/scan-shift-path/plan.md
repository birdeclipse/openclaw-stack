# Cycle Plan — scan-shift-path

- corner: scan-shift-path
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 3 | IDLE->SCAN prelude: establish IDLE (clocks low, BISTE=0), assert SE_IN, then enable DFT clock — three distinct causal steps per `cycle_fact:87` |
| SYM | 1 | the scan shift: with SE_IN=1 and DFT clock enabled, each chain shifts its SI to SO; one logical shift traverses a chain (`fact:ddf-e73df4c9`) |
| FLUSH | 1 | A3: f >= scan_chain_length = 1; SE_IN driven in every flush cycle; holds the shift result to default comparison |

## Arithmetic that must hold

**A3 (scan / shift traversal) — binds.** `f >= scan_chain_length`. The scan
chain is a one-stage pass-through of its input when SE_IN=1, so one logical
shift traverses a chain: `scan_chain_length = 1` (`fact:ddf-e73df4c9`).
Therefore `f >= 1`, and `f = 1`. SE_IN is driven in **every** flush cycle —
`FLUSHCYCLE1` drives `SE_IN=1'b1` (per cycle, not per segment; there is one
flush cycle and it is covered).

**A1 (pipeline observability) — binds with depth 0.** The scan shift is a
one-stage pass-through (`fact:ddf-e73df4c9`), so `pipeline_depth = 0` for the
scan path. The shift launches in `SYMCYCLE1` (`j = 1`); cycles available for
its effect to reach comparison are `s - j + f = 1 - 1 + 1 = 1 >= 0`. The
mission pipeline latency of 1 (`fact:ddf-3f2da785`) applies to QP following Q,
not to the scan SO_* path, and is not exercised by this corner.

**A5 (reset / prelude) — does not bind.** No reset pin exists in the pin
inventory (no RSTN or equivalent). `b = 3` is derived from the IDLE->SCAN
prelude (`cycle_fact:87`), not from a reset latency.

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | IDLE hold | establish legal IDLE: both clocks low, BISTE=0, DFT clock disabled, SE_IN deasserted | `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `SE_IN=1'b0`, `DFTCLKEN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:0`, `cycle_fact:87`, `cycle_fact:12` |
| BINCYCLE2 | assert SE_IN | assert SE_IN while clocks low and BISTE=0, per the IDLE->SCAN sequence | `SE_IN=1'b1`, `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `DFTCLKEN=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:87` |
| BINCYCLE3 | enable DFT clock | enable the DFT clock (DFTCLKEN=1) with SE_IN held, entering SCAN state | `DFTCLKEN=1'b1`, `SE_IN=1'b1`, `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:87` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1 | scan shift | with SE_IN=1 and DFT clock enabled, each chain (Q_L/Q_H/D_L/D_H/CNTR) shifts its SI to SO; SI_* left symbolic | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `DFTMASK=1'b0`, `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`; `SI_*` unconstrained | `cycle_fact:87`, `fact:ddf-e73df4c9`, `cycle_fact:58`, `cycle_fact:69` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | hold to comparison | SE_IN held 1 (A3: every flush cycle), DFT clock enabled, DFTMASK quiet; SO_* value from the shift reaches default comparison intact | `SE_IN=1'b1`, `DFTCLKEN=1'b1`, `DFTMASK=1'b0`, `CLK=1'b0`, `TCLK=1'b0`, `BISTE=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `fact:ddf-e73df4c9`, `cycle_fact:69` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| scan shift of chains Q_L/Q_H/D_L/D_H/CNTR | SYMCYCLE1 | FLUSHCYCLE1 | SO_* = SI_* (one-stage pass-through with SE_IN=1) | SE_IN held 1 through FLUSH so SO_* = SI_* still; no power mode asserted (`cycle_fact:69`) to force SO to 0; DFTMASK=0 keeps the shift clean (`cycle_fact:58`) |

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| SE_IN | SYM, FLUSH | literal 1 | SE_IN toggling during the shift (which would stop the shift) | the scan owner; A3 requires SE_IN driven in every flush cycle; the 0->1 transition is explored in BIN | `directive:1`, `cycle_fact:87` |
| DFTCLKEN | SYM, FLUSH | literal 1 | DFTCLKEN toggling | enables the DFT clock per the IDLE->SCAN sequence | `cycle_fact:87` |
| DFTMASK | SYM, FLUSH | literal 0 | DFTMASK=1 scan behavior (legal but Q=X) | "DFTMASK quiet" per the corner; keeps the shift clean | `cycle_fact:58` |
| CLK, TCLK | BIN, SYM, FLUSH | literal 0 | functional clock toggling | legal scan state requires both clocks low | `cycle_fact:87` |
| BISTE | BIN, SYM, FLUSH | literal 0 | BIST mode | scan requires BISTE=0 | `cycle_fact:87` |
| LS, DS, SD, POFF | BIN, SYM, FLUSH | literal 0 / 00 | power modes during scan | NORMAL mode; power modes during scan make scan state not guaranteed | `cycle_fact:12`, `cycle_fact:69` |
| SI_Q_L, SI_Q_H, SI_D_L, SI_D_H, SI_CNTR | SYM, FLUSH | unconstrained | none | the data being shifted; left symbolic for full coverage | `fact:ddf-e73df4c9` |

## Assumptions

- The scan shift is combinational in the model under test: with SE_IN=1, each
  chain's SO follows its SI in the same logical cycle (`fact:ddf-e73df4c9`),
  so no clock edge is required for the shift itself. The clock constraints
  (`CLK=0`, `TCLK=0`) are kept for legal scan-state entry per `cycle_fact:87`
  and are conservative.
- DFTMASK is held at 0 during the shift because the corner describes the shift
  with "DFTMASK quiet". DFTMASK=1 is a legal alternative that still advances
  the scan output (`cycle_fact:58`) but forces Q=X; it is out of scope here and
  recorded under Limitations.
- Power-mode pins (LS/DS/SD/POFF) are held at their NORMAL values
  (`cycle_fact:12`) across the whole schedule because a power mode asserted
  during scan makes scan state not guaranteed (`cycle_fact:69`). This is
  evidence-required, not customary.
- The functional clocks CLK and TCLK are held low throughout; the DFT clock is
  enabled via DFTCLKEN per `cycle_fact:87`.

## Limitations

- DFTMASK=1 during scan (scan output advances, Q=X) is not explored; the corner
  is scoped to the clean shift with DFTMASK quiet (`cycle_fact:58`).
- Power modes asserted during scan are not explored; they make scan state not
  guaranteed (`cycle_fact:69`) and would undermine the corner's observability
  objective.
- BIST mode (BISTE=1) is not explored; scan requires BISTE=0 (`cycle_fact:87`).
- The mission pipeline (QP following Q with latency 1, `fact:ddf-3f2da785`) is
  not exercised; this corner targets the scan SO_* path only.
- The scan->IDLE exit sequence (`cycle_fact:89`) is not exercised; the corner
  verifies the shift path, not the exit.

## Coverage

- catches: a scan chain that fails to pass its SI through to SO when SE_IN=1
  (a broken pass-through, a stuck SO, an SE_IN gating error) would be exposed
  because SO_* is compared against the symbolic SI_* at default comparison.
  A chain that does not shift on the DFT clock, or an SE_IN that does not
  select scan ownership, would surface as an SO_* mismatch. A power-mode or
  DFTMASK interaction that corrupts the shift would surface as a forced or
  X'd SO_*.
- misses: DFTMASK=1 scan behavior, power-mode-during-scan behavior, BIST-mode
  behavior, and the scan->IDLE exit — all out of scope for this corner and
  covered by other roster corners or recorded as limitations above.
