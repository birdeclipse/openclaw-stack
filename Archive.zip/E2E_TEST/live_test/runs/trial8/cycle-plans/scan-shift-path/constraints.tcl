# ---------------------------------------------------------------------------
# scan-shift-path corner constraints
# Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
# Corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
#
# Transliteration of cycle-plans/scan-shift-path/plan.md. Every value and
# condition is a Verilog expression; every pin is a primary input from the
# survey pin inventory. No relation routes to the declaration-file path, so no
# testbench_declarations.sv is emitted.
# ---------------------------------------------------------------------------

# Testbench cycle counts (from the plan's b/s/f derivation).
set_app_var testbench_binary_cycles  3
set_app_var testbench_symbolic_cycles 1
set_app_var testbench_flush_cycles   1

# ---------------------------------------------------------------------------
# BIN phase — IDLE->SCAN prelude (cycle_fact:87)
# ---------------------------------------------------------------------------

# BINCYCLE1: establish legal IDLE — both clocks low, BISTE=0, DFT clock
# disabled, SE_IN deasserted, NORMAL power mode (cycle_fact:0, cycle_fact:12).
set_constraint {CLK}      -cycle {BINCYCLE1} -set {1'b0}
set_constraint {TCLK}     -cycle {BINCYCLE1} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SE_IN}    -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE1} -set {2'b00}

# BINCYCLE2: assert SE_IN while clocks low and BISTE=0 (cycle_fact:87).
set_constraint {SE_IN}    -cycle {BINCYCLE2} -set {1'b1}
set_constraint {CLK}      -cycle {BINCYCLE2} -set {1'b0}
set_constraint {TCLK}     -cycle {BINCYCLE2} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DFTCLKEN} -cycle {BINCYCLE2} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE2} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE2} -set {2'b00}

# BINCYCLE3: enable the DFT clock (DFTCLKEN=1) with SE_IN held, entering SCAN
# state (cycle_fact:87).
set_constraint {DFTCLKEN} -cycle {BINCYCLE3} -set {1'b1}
set_constraint {SE_IN}    -cycle {BINCYCLE3} -set {1'b1}
set_constraint {CLK}      -cycle {BINCYCLE3} -set {1'b0}
set_constraint {TCLK}     -cycle {BINCYCLE3} -set {1'b0}
set_constraint {BISTE}    -cycle {BINCYCLE3} -set {1'b0}
set_constraint {LS}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {DS}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {SD}       -cycle {BINCYCLE3} -set {1'b0}
set_constraint {POFF}     -cycle {BINCYCLE3} -set {2'b00}

# ---------------------------------------------------------------------------
# SYM phase — the scan shift (cycle_fact:87, fact:ddf-e73df4c9)
# SI_* left unconstrained (symbolic): the data being shifted.
# ---------------------------------------------------------------------------

# SYMCYCLE1: with SE_IN=1 and DFT clock enabled, each chain shifts its SI to
# SO; DFTMASK quiet (cycle_fact:58); NORMAL power mode (cycle_fact:69).
set_constraint {SE_IN}    -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {SYMCYCLE1} -set {1'b1}
set_constraint {DFTMASK}  -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {CLK}      -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {TCLK}     -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {BISTE}    -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {SYMCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {SYMCYCLE1} -set {2'b00}

# ---------------------------------------------------------------------------
# FLUSH phase — hold the shift result to default comparison
# A3: SE_IN driven in EVERY flush cycle (fact:ddf-e73df4c9).
# ---------------------------------------------------------------------------

# FLUSHCYCLE1: SE_IN held 1, DFT clock enabled, DFTMASK quiet; SO_* value from
# the shift reaches default comparison intact (fact:ddf-e73df4c9, cycle_fact:69).
set_constraint {SE_IN}    -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {DFTCLKEN} -cycle {FLUSHCYCLE1} -set {1'b1}
set_constraint {DFTMASK}  -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {CLK}      -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {TCLK}     -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {BISTE}    -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {LS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {DS}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {SD}       -cycle {FLUSHCYCLE1} -set {1'b0}
set_constraint {POFF}     -cycle {FLUSHCYCLE1} -set {2'b00}
