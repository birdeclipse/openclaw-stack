# Cross-corner summary — trial8

Corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
Run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
Corners planned: mission-mode-read-write, scan-shift-path, bist-mode-operation, deep-sleep-shutdown-retention

This document names every divergence between the four corner plans, whether
each is deliberate, and the cross-corner findings the interrogator wrote.

## Pins treated differently across corners

| pin | mission-mode-read-write | scan-shift-path | bist-mode-operation | deep-sleep-shutdown-retention | deliberate? |
|---|---|---|---|---|---|
| BISTE | literal 0 (mission mode, `cycle_fact:24`) | literal 0 (scan needs BISTE=0, `cycle_fact:87`) | literal 1 in BIN2-SYM-FLUSH1 (BIST mode, `cycle_fact:88`), 0 in FLUSH2-3 | unconstrained (not part of the DS/SD sequence) | yes — ownership pin, each corner is its own schedule |
| SE_IN | literal 0 (mission mode) | literal 1 (scan owner, `cycle_fact:87`) | literal 0 (BIST requires SE_IN=0, `cycle_fact:88`) | unconstrained | yes — scan/BIST ownership is per-corner |
| CLK | unconstrained (not a mode pin) | literal 0 (`cycle_fact:87` clocks low) | literal 0 in BIN/FLUSH, unconstrained in SYM (legal ignored input while BISTE=1, `cycle_fact:55`) | literal 0 every cycle (`cycle_fact:50` quiescence) | yes — each corner's clock treatment follows its own entry/ownership evidence |
| TCLK | unconstrained | literal 0 | alternating L/H waveform (TCLK drives the BIST operations, `cycle_fact:25`) | literal 0 every cycle (`cycle_fact:50`) | yes — BIST is the only corner that runs on TCLK |
| DS, SD | literal 0 (`cycle_fact:12` NORMAL row) | literal 0 (`cycle_fact:12`) | unconstrained (ignored while BISTE=1) | driven through the DS/SD entry→hold→wake sequence (`cycle_fact:75,76,79,80`) | yes — the deep-sleep corner exists to exercise these; the others must not be in a power mode |
| POFF | literal 00 | literal 00 | unconstrained | literal 00 at the entry cycles only | yes |
| DFTMASK | literal 0 | literal 0 (corner's "DFTMASK quiet") | unconstrained (ignored while BISTE=1) | unconstrained | yes |
| DFTCLKEN | literal 0 | literal 1 (enables DFT clock, `cycle_fact:87`) | unconstrained | unconstrained | yes — only the scan corner enables the DFT clock |

None of these divergences is accidental: each corner constrains exactly the
mode/ownership/power pins its own evidence requires and leaves the rest to the
other corners. The same macro pin is legitimately bound in scan and free in
mission mode — that is the expected shape of a per-corner roster.

## Cycle counts that disagree for the same mechanism, and why

- **pipeline_depth=1** (`fact:ddf-3f2da785`): mission-mode uses it to justify
  f=1 (QP follows Q); BIST uses it for the A1 bound while observing the
  read-back on Q (not QP); deep-sleep uses it to argue that with Q never
  updated the pipeline carries nothing, so f=0. The disagreement is in
  interpretation, not in the scalar: each plan shows its own s-j+f arithmetic.
- **tPGGUARD=2** (datasheet Table 6-2): deep-sleep is the only corner that
  crosses a power-mode wake, and it allocates two guard cycles after both the
  DS wake (SYM5-6) and the SD wake (SYM11-12). No other corner touches a guard.
- **f (flush) differs across all four**: mission f=1, scan f=1, BIST f=3,
  deep-sleep f=0. Each is derived from that corner's observability need
  (pipeline drain / A3 chain hold / clean exit sequence / no pipeline state),
  not from a shared constant.

## Incompatible assumptions

- Mission-mode and scan-shift both hold DS=SD=0 and POFF=00 for the whole run
  (NORMAL row, `cycle_fact:12`); deep-sleep drives DS/SD through their
  transitions. These are different schedules for different corners — no corner
  transitions into another corner's mode, so nothing is reduced between them.
- deep-sleep holds CLK=TCLK=0 the entire run because `cycle_fact:50` forbids a
  rising clock while DS/SD/POFF is active; BIST drives TCLK with rising edges.
  They cannot be reconciled in one schedule, and need not be: they are separate
  runs. A cross-schedule reader should note that a deep-sleep run and a BIST
  run drive TCLK oppositely.

## Interrogator cross-corner finding

- **cross-corner: retention-data integrity is unverified by any corner.**
  mission-mode-read-write holds DS=SD=0 throughout, so it never performs a
  read-after-write across a power event; deep-sleep-shutdown-retention
  verifies the mode-transition outputs (ROP_DS/ROP_SD, entry asserts) but
  deliberately does not write-then-read-back a retained word (and cannot
  observe Q at all, since the wrapper only updates q_int on a clock edge that
  `cycle_fact:50` forbids during powered-down states). So a
  retention-corruption defect — the very thing "retention sequence" most
  naturally promises to check — is not exercised by this run. This is the one
  genuine cross-corner gap. It is **not** a deliberate scope cut so much as a
  consequence of the model under test: under the legal held-low-clock stimulus
  the wrapper cannot register Q at all. Whether that is acceptable is the
  user's call (see STATUS.md). Options if it is not: (a) fix the wrapper's
  ROP_DS/ROP_SD / q_int model to make power-mode outputs level-sensitive, then
  re-plan deep-sleep to observe Q and add a write→DS→wake→read-back word;
  (b) add a dedicated retention-data-integrity corner over the corrected
  model.

## Divergences that were deliberate scoping, not contradictions

- DFTMASK=1 scan behavior is excluded from scan-shift-path (corner scoped to
  the clean shift) and unconstrained elsewhere — deliberate, recorded in that
  plan's Limitations.
- Half-word / masked BIST accesses are not exercised (BIST plan uses
  THW=2'b11, TWEM='1 only) — deliberate full-word scoping.
- The mission-mode plan leaves the margin/assist pins RME/RM/WA/RA/WPULSE
  unconstrained and accepts the R17/R18 X outcomes as legal symbolic outcomes —
  a deliberate full-transition-space choice, not a demotion.
- deep-sleep does not exercise LS or POFF power modes — scoped to DS and SD per
  `directive:3`.

## Bottom line

The four plans are mutually consistent as per-corner schedules. The only
finding that spans corners is the retention-data-integrity gap, which no
corner closes and which traces to the wrapper model's clock-edge-only output
updates conflicting with the datasheet's held-low-clock requirement. Everything
else that differs across corners differs because each corner is scoped to its
own evidence.
