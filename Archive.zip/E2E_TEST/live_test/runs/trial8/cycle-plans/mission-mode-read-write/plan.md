# Cycle Plan — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## Cycle counts

| phase | count | rationale |
|---|---|---|
| BIN | 2 | Establish mission mode: assert the mode-defining control pins (BISTE=0, SE_IN=0, TPR=L, DFTCLKEN=L, DFTMASK=0) and the NORMAL power row (LS=0, DS=0, SD=0, POFF=00) in BINCYCLE1, then hold them one settle cycle in BINCYCLE2 so the first symbolic access sees a stable mission-mode configuration. No `reset_latency_cycles` scalar is declared in the corpus, so A5's reset bound is not triggered; this prelude is mode entry, not reset. |
| SYM | 4 | Explore the mission-mode read/write operation space: ME/WE/HW/WEM/ADR/D left unconstrained so each of the four symbolic cycles is a distinct operation — full-word and half-word reads (`cycle_fact:3-6`), full-word and half-word writes (`cycle_fact:7-10`), masked writes (`cycle_fact:11`), HW=00 write no-op (`cycle_fact:51`), and HW-priority (`cycle_fact:52`) — including the same-address read-after-write subspace. |
| FLUSH | 1 | Propagate the last symbolic operation's effect to QP comparison. `pipeline_depth=1` (`fact:ddf-3f2da785`): QP follows Q with latency one, so one flush cycle carries the final operation's Q value onto QP for default comparison. |

## Binary phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| BINCYCLE1 | mode entry | Assert mission-mode control and NORMAL power row so the functional port owns the memory | `BISTE=1'b0`, `SE_IN=1'b0`, `TPR=1'b0`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00` | `cycle_fact:24`, `cycle_fact:12`, `cycle_fact:3`, `pin:BISTE`, `pin:SE_IN`, `pin:TPR`, `pin:DFTCLKEN`, `pin:DFTMASK`, `pin:LS`, `pin:DS`, `pin:SD`, `pin:POFF` |
| BINCYCLE2 | settle | Hold the mission-mode configuration one full cycle so the first symbolic access sees a stable mode | same pins, same values as BINCYCLE1 | `cycle_fact:24`, `cycle_fact:12` |

## Symbolic phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| SYMCYCLE1-4 | operation space | Explore mission-mode reads and writes: ME/WE/HW/WEM/ADR/D unconstrained so each cycle is a distinct symbolic operation (full/half-word read, full/half-word write, masked write, HW=00 no-op, HW-priority), including same-address read-after-write | mode pins held: `BISTE=1'b0`, `SE_IN=1'b0`, `TPR=1'b0`, `DFTCLKEN=1'b0`, `DFTMASK=1'b0`, `LS=1'b0`, `DS=1'b0`, `SD=1'b0`, `POFF=2'b00`; operation pins `ME`, `WE`, `HW`, `WEM`, `ADR`, `D` unconstrained | `cycle_fact:3`, `cycle_fact:4`, `cycle_fact:5`, `cycle_fact:6`, `cycle_fact:7`, `cycle_fact:8`, `cycle_fact:9`, `cycle_fact:10`, `cycle_fact:11`, `cycle_fact:51`, `cycle_fact:52`, `cycle_fact:24` |

## Flush phase

| cycles | role | intent | pins driven | evidence |
|---|---|---|---|---|
| FLUSHCYCLE1 | pipeline drain | Propagate the last symbolic operation's Q value onto QP for default comparison; QP follows Q with latency one | mode pins held as in SYM; operation pins left at their last-cycle symbolic values | `fact:ddf-3f2da785`, `cycle_fact:68` |

## Observability

| operation | launch cycle | compared by cycle | logical effect | why the value is intact |
|---|---|---|---|---|
| Full-word read (ME=1, WE=0, HW=HH) | SYMCYCLE j (1..4) | cycle j+1 (QP) | Q=Q: full word read out of addressed location (`cycle_fact:6`); QP follows Q with latency one (`fact:ddf-3f2da785`) | QP is registered from Q at the next clock edge; no later cycle re-drives Q before the flush captures it. A1: s-j+f = 4-j+1 >= 1 for all j in 1..4. |
| Half-word read (ME=1, WE=0, HW=LH) | SYMCYCLE j | cycle j+1 (QP) | Q=QH-1/QL: lower half read out, upper half holds (`cycle_fact:4`) | Same pipeline path as full-word read; QP captures Q at next edge. A1: 4-j+1 >= 1. |
| Half-word read (ME=1, WE=0, HW=HL) | SYMCYCLE j | cycle j+1 (QP) | Q=QH/QL-1: upper half read out, lower half holds (`cycle_fact:5`) | Same pipeline path. A1: 4-j+1 >= 1. |
| Full-word write (ME=1, WE=1, HW=HH, WEM=H) | SYMCYCLE j | cycle j+1 (QP) | Array=Data-in: full word written (`cycle_fact:10`); observable via a later same-address read, or the write's Q-1 hold reaches QP | The write's effect is the array contents; a subsequent read at the same ADR (explored symbolically) returns the written data, and that read's Q reaches QP by its own j+1. A1: 4-j+1 >= 1. |
| Half-word write (ME=1, WE=1, HW=LH/HL, WEM=H) | SYMCYCLE j | cycle j+1 (QP) | Array[L]=Data-in[L] or Array[H]=Data-in[H] (`cycle_fact:8`, `cycle_fact:9`) | Same as full-word write; half-word write effect observable via later same-address read. A1: 4-j+1 >= 1. |
| Masked write (ME=1, WE=1, WEM=L) | SYMCYCLE j | cycle j+1 (QP) | NCM: no bits written (`cycle_fact:11`); Q retains Q-1 | The no-op effect (Q=Q-1) propagates to QP at j+1; no later cycle overwrites it before flush. A1: 4-j+1 >= 1. |
| HW=00 write no-op (ME=1, WE=1, HW=00) | SYMCYCLE j | cycle j+1 (QP) | Q retains Q-1; no bits written (`cycle_fact:51`) | Same no-op propagation path. A1: 4-j+1 >= 1. |
| HW-priority (ME=1, WE=1, WEM=1, half disabled by HW) | SYMCYCLE j | cycle j+1 (QP) | Q retains Q-1; disabled-half cells retain data (`cycle_fact:52`) | Same no-op propagation path. A1: 4-j+1 >= 1. |

A1 arithmetic (pipeline_depth=1, `fact:ddf-3f2da785`): for every operation launched in SYMCYCLE j, cycles available to reach comparison are s-j+f = 4-j+1. Worst case j=4 gives 4-4+1 = 1 >= 1. All operations satisfy A1.

## Symbolic treatment

| pin | phase | treatment | coverage given up | justification | evidence |
|---|---|---|---|---|---|
| BISTE | BIN+SYM+FLUSH | literal `1'b0` | BIST-mode ownership handoff and BISTE=1 operation space | Mission mode is defined by BISTE=L: the functional port owns the memory (`cycle_fact:24`). BIST-mode operation is a separate certified corner (`bist-mode-operation`). | `cycle_fact:24`, `cycle_fact:25` |
| SE_IN | BIN+SYM+FLUSH | literal `1'b0` | Scan-shift ownership and SE_IN=1 scan operation | Mission mode requires SE_IN=0; scan shift is a separate certified corner (`scan-shift-path`). | `cycle_fact:24`, `cycle_fact:58` |
| TPR | BIN+SYM+FLUSH | literal `1'b0` | TPR=1 idle and TPR-aperture behavior | Every READ/WRITE row requires TPR=L (`cycle_fact:3-11`); TPR=1 forces idle (`cycle_fact:53`), which is not the read/write operation space this corner explores. | `cycle_fact:3`, `cycle_fact:53` |
| DFTCLKEN | BIN+SYM+FLUSH | literal `1'b0` | DFT clock-enable and scan-clock behavior | Every READ/WRITE row has DFTCLKEN=L (`cycle_fact:3-11`); DFT clocking belongs to the scan corner. | `cycle_fact:3` |
| DFTMASK | BIN+SYM+FLUSH | literal `1'b0` | DFTMASK=1 scan-output advance and diagnostic behavior | Mission mode holds DFTMASK=0; DFTMASK=1 with SE_IN=1 advances scan (`cycle_fact:58`), which is the scan corner's space. | `cycle_fact:58`, `cycle_fact:59` |
| LS | BIN+SYM+FLUSH | literal `1'b0` | Light-sleep entry and bias modes | NORMAL mode requires LS=0 (`cycle_fact:12`); light-sleep is the low-power corner's space. | `cycle_fact:12` |
| DS | BIN+SYM+FLUSH | literal `1'b0` | Deep-sleep entry/exit and retention | NORMAL mode requires DS=0 (`cycle_fact:12`); deep-sleep is the low-power corner's space. | `cycle_fact:12` |
| SD | BIN+SYM+FLUSH | literal `1'b0` | Shutdown entry/exit and destruction | NORMAL mode requires SD=0 (`cycle_fact:12`); shutdown is the low-power corner's space. | `cycle_fact:12` |
| POFF | BIN+SYM+FLUSH | literal `2'b00` | Periphery-off and dual-rail power modes | NORMAL mode requires POFF=00 (`cycle_fact:12`); POFF modes are the low-power corner's space. | `cycle_fact:12` |

Pins left unconstrained (no demotion row, strongest coverage): `ME`, `WE`, `HW`, `WEM`, `ADR`, `D` — the operation space this corner exists to explore. Margin/assist pins `RME`, `RM`, `WA`, `RA`, `WPULSE` are also left unconstrained: `cycle_fact:62` (R17) and `cycle_fact:63` (R18) describe the legal X outcomes when these change with ME=1, and ESP's default comparison treats X as a legal symbolic outcome, so the operation is verified across the full margin/assist transition space rather than only the stable-value subspace.

## Assumptions

- No `reset_latency_cycles` scalar is declared in the corpus, so A5's reset bound is not triggered. The BIN prelude is mode entry (asserting mission-mode control and NORMAL power row), not design reset; `INIT` is credited with no reset or mode work (`guide.md` A5).
- The mode-defining pins (BISTE, SE_IN, TPR, DFTCLKEN, DFTMASK, LS, DS, SD, POFF) are held literal across BIN+SYM+FLUSH to keep the corner inside mission mode. This is a deliberate demotion disclosed in the Symbolic treatment table; the transition classes given up (BIST/scan ownership, power-mode entry) are the territory of the other certified corners.
- `DFTMASK` is set to `1'b0` as part of the mission-mode definition per the run owner's decision aid; with SE_IN=0 held, DFTMASK is otherwise a don't-care for the read/write rows (`cycle_fact:3-11` list DFTMASK=X).
- Margin/assist pins RME/RM/WA/RA/WPULSE are left unconstrained. The X outcomes of `cycle_fact:62` (R17) and `cycle_fact:63` (R18) are legal symbolic outcomes that ESP's default comparison handles; no stable-value hold is imposed, so the operation is verified across the full margin/assist transition space.
- The same-address read-after-write subspace is part of the explored space because ADR is unconstrained across SYM; the engine may revisit an address written earlier in the phase.

## Limitations

- This corner does not verify BIST-mode operation, scan-shift, or low-power/deep-sleep/shutdown sequences; those are separate certified corners and their mode pins are held to mission-mode values here.
- The pipeline is exercised only to depth 1 (`fact:ddf-3f2da785`); QP is compared one cycle after Q. No deeper pipeline behavior is asserted.
- Repair (CRE1/CRE2/FCA1/FCA2/RRE/FRA), BIST, scan, and power-mode pins are not exercised; their interaction with read/write is out of scope for this corner.
- The flush phase is a single cycle; only the last symbolic operation's effect is guaranteed to reach QP comparison. Earlier operations' effects are observable through the same-address read-after-write subspace the engine explores, not through a dedicated per-operation flush.

## Coverage

- catches: defects in the mission-mode read path (full-word and half-word reads returning the wrong half or wrong word, `cycle_fact:3-6`), the write path (full-word and half-word writes corrupting the wrong half, `cycle_fact:7-10`), masked-write and HW=00 no-op behavior (`cycle_fact:11`, `cycle_fact:51`), HW-priority half-disable behavior (`cycle_fact:52`), and the Q-to-QP pipeline registration (`fact:ddf-3f2da785`). Because ME/WE/HW/WEM/ADR/D are unconstrained across four symbolic cycles, the engine explores the full operation and transition space, including same-address read-after-write, and any defect that changes Q or QP in a compared cycle is exposed.
- misses: defects that require leaving mission mode (BIST/scan ownership, power-mode entry) to manifest, and defects in the margin/assist pins' stable-value subspace that only appear when those pins are held (the plan deliberately explores their full transition space instead, accepting the R17/R18 X outcomes as legal). These are acceptable because the mode-transition and stable-value subspaces belong to the other certified corners.
