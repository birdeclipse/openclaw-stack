# Review — mission-mode-read-write

- corner: mission-mode-read-write
- run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
- corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
- outcome: plan

## correct

- **A1 arithmetic holds.** `pipeline_depth=1` (`fact:ddf-3f2da785`); for every operation launched in SYMCYCLE j, `s - j + f = 4 - j + 1 >= 1` for all j in 1..4, worst case j=4 (`4-4+1=1`). The plan names j per row and shows the derivation (plan.md lines 39-48).
- **A5 does not bind as reset.** No reset pin and no `reset_latency_cycles` scalar; the b=2 prelude is mode entry (assert mission-mode control and NORMAL power row), not reset hold. `INIT` is credited with no reset or mode work. Consistent with guide A5.
- **Selectors are sane.** All cycle selectors are 1-based, in-phase, monotone, non-overlapping; no pin is assigned two values in one cycle. The constraints.tcl is a faithful transliteration of the plan's phase tables (same cycles, same values, same holds) — verified line by line against plan.md BIN/SYM/FLUSH rows.
- **The operation space is correctly left unconstrained.** ME/WE/HW/WEM/ADR/D are free across all four symbolic cycles, giving each a distinct symbol per cycle (value space AND transition space) — the strongest coverage for the read/write operation space this corner exists to explore. The plan's symbolic-treatment table correctly leaves these without demotion rows.
- **The mode-pin demotions are disclosed and justified.** BISTE=0 (`cycle_fact:24`), SE_IN=0 (`cycle_fact:24`), TPR=0 (`cycle_fact:3-11`), DFTCLKEN=0 (`cycle_fact:3`), DFTMASK=0, LS/DS/SD=0 and POFF=00 (`cycle_fact:12`) are each held literal across BIN+SYM+FLUSH with a symbolic-treatment row naming the lost scenario class and the corner that owns it. These are phase-wide holds, and each is justified per the mode-defining evidence. Consistent with guide B5/C2.
- **Citations resolve.** Every ref (cycle_fact:3-11, 12, 24, 25, 51, 52, 58, 59, 68; fact:ddf-3f2da785; pin:*) is in the survey's Evidence catalog. The corpus digest in the header matches the survey.
- **The flush phase's QP-capture mechanism is grounded.** The plan cites `cycle_fact:68` (R23: QP captures from PIPEME when BISTE=0) for the flush, which matches the wrapper's `always @(posedge sel_clk) if (BISTE ? TPIPEME : PIPEME) qp_int <= q_int` (sram_1p2m_n3a_wrapper.sv:159-161) with BISTE=0.

## missing

- none

## user-review

- **The "compared by cycle j+1 (QP)" claim is conditional on a clock edge and PIPEME in the flush cycle.** The plan holds CLK unconstrained (correctly — it is not a mode pin), so whether QP captures the last operation's Q in FLUSHCYCLE1 depends on CLK rising and PIPEME being set in that cycle. The engine explores both paths, so the effect is observable on Q regardless (Q holds the value with no clock edge to change it), but the plan's specific "QP by j+1" claim is not guaranteed. The engineer should confirm ESP's default comparison includes Q, not only QP, for the read/write effects to be robustly observed.
- **A write in SYMCYCLE4 (the last symbolic cycle) is not verified.** A write does not change Q (the wrapper's write path updates `mem`, not `q_int`; sram_1p2m_n3a_wrapper.sv:137-146), so the "write's Q-1 hold reaches QP" claim (plan.md line 42) carries only the prior Q value, not evidence of the write. The write's actual effect (array contents) is observable only via a later same-address read, and there is no read after SYMCYCLE4. The plan acknowledges this in Limitations (line 79: "only the last symbolic operation's effect is guaranteed to reach QP comparison"), but the consequence is that a write in the final symbolic cycle is not verified at all. The engineer should accept this as a known coverage gap or add a read-after-write cycle.
- **cross-corner: deep-sleep-shutdown-retention — this corner holds DS=SD=0 throughout, so it does not exercise any read-after-write across a power event; the deep-sleep corner's retention-data-integrity gap (no read-after-wake) is therefore not covered here either. See that corner's user-review.**
