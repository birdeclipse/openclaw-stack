# ---------------------------------------------------------------------------
# Mission-mode read/write corner constraints
# Plan: cycle-plans/mission-mode-read-write/plan.md
# Corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
#
# The mode-defining pins are held literal across the whole run (BIN+SYM+FLUSH)
# to keep the corner inside mission mode: the functional port owns the memory
# (cycle_fact:24) in the NORMAL power row (cycle_fact:12). The operation pins
# ME/WE/HW/WEM/ADR/D are deliberately left UNCONSTRAINED so the engine explores
# the full read/write operation space (cycle_fact:3-11, 51, 52).
# ---------------------------------------------------------------------------

# Testbench cycle counts (b/s/f from the plan)
set_app_var testbench_binary_cycles  2
set_app_var testbench_symbolic_cycles 4
set_app_var testbench_flush_cycles   1

# Declaration-file wiring: ADR no-repeat-prev SVA rule (testbench_declarations.sv)
set_app_var testbench_declaration_file ./testbench_declarations.sv

# Mission-mode control: functional port owns the memory (cycle_fact:24)
set_constraint {BISTE}    -set {1'b0}
set_constraint {SE_IN}    -set {1'b0}
set_constraint {TPR}      -set {1'b0}
set_constraint {DFTCLKEN} -set {1'b0}
set_constraint {DFTMASK}  -set {1'b0}

# NORMAL power row (cycle_fact:12)
set_constraint {LS}   -set {1'b0}
set_constraint {DS}   -set {1'b0}
set_constraint {SD}   -set {1'b0}
set_constraint {POFF} -set {2'b00}

# Hold D at zero except during enabled writes (ME and WE both high)
set_constraint {D} -set {32'h00000000} -if {!(ME && WE)}

# BC0 and BC1 must never both be high in the same cycle (at most one hot)
set_constraint {BC0 BC1} -01hot
