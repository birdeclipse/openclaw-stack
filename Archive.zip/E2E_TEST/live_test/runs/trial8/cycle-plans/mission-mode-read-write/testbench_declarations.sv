// Mission-mode read/write corner — declaration-file constraints
// corner: mission-mode-read-write
// run root: /Users/qiuyuxun/projects/circuit-setup-general/E2E_TEST/live_test/runs/trial8
// corpus digest: 8fd3c72edb30d15340ce08226ca115aba435919833ca00300ffa67a2419eb0d8
//
// Wired from constraints.tcl via:
//   set_app_var testbench_declaration_file ./testbench_declarations.sv

// RULE: adr-no-repeat-prev
// reason: the mission-mode ADR bus is deliberately left unconstrained so the
//         engine explores the full read/write address space, but the address
//         must never repeat the previous cycle's value (user request). This is
//         a 1-cycle lookback relation — current ADR vs innopv_ADR — that
//         set_constraint cannot express: no relation intent compares a target
//         against a lookback value. Concurrent property, clocked on the design
//         clock CLK, SVA over the innont_ADR drive buffer vs the innopv_ADR
//         lookback; both sides are the 14-bit ADR[13:0] bus, so the widths
//         match exactly.
adr_no_repeat_prev: assume property (@(posedge CLK)
  innont_ADR != innopv_ADR);
