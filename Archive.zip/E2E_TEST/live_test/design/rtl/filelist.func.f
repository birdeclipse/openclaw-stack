// VCS filelist for the functional view of
// sram_1p2m_n3a_16384x32m32b_hd (TSMC N3A, 16384 x 32, IT/ST capable).
//
// Instance: bist_enable=TRUE scan_enable=TRUE redundancy_enable=TRUE
//           center_decode=TRUE two_col_repair_elements=TRUE
//           half_word_enable=TRUE wem_enable=TRUE pg_enable=TRUE
//           vdda_enable=TRUE (Embedded Dual Rail)

-sverilog
-timescale=1ns/1ps

+define+FUNCTIONAL
+define+SPEEDSIM
+define+SRAM_ADDR_WIDTH=14
+define+SRAM_DATA_WIDTH=32

+incdir+./include

./sram_1p2m_n3a_wrapper.sv
