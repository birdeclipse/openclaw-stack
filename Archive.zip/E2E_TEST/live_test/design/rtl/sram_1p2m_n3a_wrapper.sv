//======================================================================
// Behavioural wrapper for one instance of the
// Automotive Grade 2 Single Port Ultra High-Density Leakage Control SRAM
// 1.2M Sync Compiler, TSMC N3A FinFET.
//
// Instance configuration (see TSMC_N3A_SRAM_1.2M_Compiler_Spec.md):
//   words                    = 16384        (ADR[13:0])
//   bits                     = 32           (D/Q/WEM[31:0])
//   bist_enable              = TRUE
//   scan_enable              = TRUE
//   redundancy_enable        = TRUE   (column + row repair)
//   center_decode            = TRUE
//   two_col_repair_elements  = TRUE   (CRE1/CRE2, FCA1/FCA2)
//   row_redundancy           = TRUE   (row_repair_element = 1)
//   half_word_enable         = TRUE   (HW[1:0])
//   wem_enable               = TRUE   (SW = 1)
//   pg_enable                = TRUE   (LS/DS/SD, ROP_DS/ROP_SD)
//   vdda_enable              = TRUE   (Embedded Dual Rail, POFF[1:0])
//
// This model is functional collateral for setup and testbench generation.
// It is not a timing or power model and is not signoff-capable.
//======================================================================

`timescale 1ns/1ps

`ifndef SRAM_1P2M_N3A_WRAPPER_SV
`define SRAM_1P2M_N3A_WRAPPER_SV

`ifndef SRAM_ADDR_WIDTH
  `define SRAM_ADDR_WIDTH 14
`endif
`ifndef SRAM_DATA_WIDTH
  `define SRAM_DATA_WIDTH 32
`endif

module sram_1p2m_n3a_16384x32m32b_hd (
  // ---- functional interface ----
  input  wire                          CLK,
  input  wire                          ME,
  input  wire                          WE,
  input  wire [`SRAM_ADDR_WIDTH-1:0]   ADR,
  input  wire [`SRAM_DATA_WIDTH-1:0]   D,
  input  wire [`SRAM_DATA_WIDTH-1:0]   WEM,
  input  wire [1:0]                    HW,
  output wire [`SRAM_DATA_WIDTH-1:0]   Q,

  // ---- read pipeline ----
  input  wire                          PIPEME,
  output wire [`SRAM_DATA_WIDTH-1:0]   QP,

  // ---- BIST interface ----
  input  wire                          TCLK,
  input  wire                          TME,
  input  wire                          TWE,
  input  wire [`SRAM_ADDR_WIDTH-1:0]   TADR,
  input  wire [3:0]                    TD,
  input  wire                          TWEM,
  input  wire [1:0]                    THW,
  input  wire                          BISTE,
  input  wire                          TCLKE,
  input  wire                          TPIPEME,
  input  wire [3:0]                    CD,
  input  wire                          CAPT,
  input  wire                          STICKY,

  // ---- scan / ATPG ----
  input  wire                          SE_IN,
  input  wire                          SI_Q_L,
  input  wire                          SI_Q_H,
  input  wire                          SI_D_L,
  input  wire                          SI_D_H,
  input  wire                          SI_CNTR,
  output wire                          SO_Q_L,
  output wire                          SO_Q_H,
  output wire                          SO_D_L,
  output wire                          SO_D_H,
  output wire                          SO_CNTR,
  input  wire                          DFTCLKEN,
  input  wire                          DFTMASK,

  // ---- redundancy / repair ----
  input  wire                          CRE1,
  input  wire                          CRE2,
  input  wire [5:0]                    FCA1,
  input  wire [5:0]                    FCA2,
  input  wire                          RRE,
  input  wire [7:0]                    FRA,

  // ---- margin and assist ----
  input  wire                          RME,
  input  wire [3:0]                    RM,
  input  wire [1:0]                    RA,
  input  wire [2:0]                    WA,
  input  wire [2:0]                    WPULSE,

  // ---- test ----
  input  wire                          TEST1,
  input  wire                          TEST_RNM,

  // ---- power management ----
  input  wire                          LS,
  input  wire                          DS,
  input  wire                          SD,
  input  wire [1:0]                    POFF,
  input  wire                          TPR,
  input  wire                          BC0,
  input  wire                          BC1,
  input  wire                          BC2,
  output wire                          ROP_DS,
  output wire                          ROP_SD
);

  // Muxed ownership: BISTE selects the BIST port, TCLKE selects its clock.
  wire                        sel_clk  = TCLKE ? TCLK : CLK;
  wire                        sel_me   = BISTE ? TME  : ME;
  wire                        sel_we   = BISTE ? TWE  : WE;
  wire [`SRAM_ADDR_WIDTH-1:0] sel_adr  = BISTE ? TADR : ADR;
  wire [1:0]                  sel_hw   = BISTE ? THW  : HW;
  wire [`SRAM_DATA_WIDTH-1:0] sel_d    = BISTE ? {8{TD}} : D;
  wire [`SRAM_DATA_WIDTH-1:0] sel_wem  = BISTE ? {`SRAM_DATA_WIDTH{TWEM}} : WEM;

  reg [`SRAM_DATA_WIDTH-1:0] mem [0:(1<<`SRAM_ADDR_WIDTH)-1];
  reg [`SRAM_DATA_WIDTH-1:0] q_int;
  reg [`SRAM_DATA_WIDTH-1:0] qp_int;
  reg                        rop_ds_int;
  reg                        rop_sd_int;

  wire powered_down = SD | DS | POFF[0] | POFF[1];
  wire lower_en     = sel_hw[0];
  wire upper_en     = sel_hw[1];

  always @(posedge sel_clk) begin
    if (powered_down) begin
      q_int <= {`SRAM_DATA_WIDTH{1'b0}};
    end
    else if (sel_me && !TPR) begin
      if (sel_we) begin
        if (lower_en) begin
          for (int i = 0; i < `SRAM_DATA_WIDTH/2; i++)
            if (sel_wem[i]) mem[sel_adr][i] <= sel_d[i];
        end
        if (upper_en) begin
          for (int i = `SRAM_DATA_WIDTH/2; i < `SRAM_DATA_WIDTH; i++)
            if (sel_wem[i]) mem[sel_adr][i] <= sel_d[i];
        end
      end
      else begin
        q_int <= mem[sel_adr];
      end
    end
  end

  // Synchronous write-through: DFTMASK=1 with DFTCLKEN=1 passes D to the output.
  always @(posedge sel_clk) begin
    if (DFTMASK && DFTCLKEN) q_int <= sel_d;
  end

  // One-cycle pipeline stage. QP carries the pipeline result, not Q.
  always @(posedge sel_clk) begin
    if (BISTE ? TPIPEME : PIPEME) qp_int <= q_int;
  end

  // Power-mode ready outputs. Low means the macro is ready for operation.
  always @(posedge sel_clk or posedge SD or posedge DS) begin
    rop_ds_int <= DS;
    rop_sd_int <= SD;
  end

  assign Q       = q_int;
  assign QP      = qp_int;
  assign ROP_DS  = rop_ds_int;
  assign ROP_SD  = rop_sd_int;

  // Scan chain outputs are modelled as pass-through of their inputs.
  assign SO_Q_L   = SE_IN ? SI_Q_L  : 1'b0;
  assign SO_Q_H   = SE_IN ? SI_Q_H  : 1'b0;
  assign SO_D_L   = SE_IN ? SI_D_L  : 1'b0;
  assign SO_D_H   = SE_IN ? SI_D_H  : 1'b0;
  assign SO_CNTR  = SE_IN ? SI_CNTR : 1'b0;

  // Repair, margin, assist, and bias controls are observed but not modelled.
  wire _unused = &{CRE1, CRE2, FCA1, FCA2, RRE, FRA,
                   RME, RM, RA, WA, WPULSE,
                   TEST1, TEST_RNM, LS, BC0, BC1, BC2,
                   CD, CAPT, STICKY, 1'b0};

endmodule

`endif
