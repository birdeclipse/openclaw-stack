# Reading an ESP setup deck and the analyzer's documents

This is the vocabulary the five generated documents are written in, plus the
domain reasoning that turns a table cell into a finding. Read it before you
interpret a supply, a cycle count, a port group, or a pin attribute.

`circuit-setup-deck`'s `documents/guide.md` is the companion for *building* a
deck — the ESP command order, the real-versus-virtual supply distinction, the
pin-polarity (`-value`) reasoning. When you need to know whether a deck did
something the right way round, that is where the rule lives. This file is about
reading.

## 1. What the analyzer is, and what it refuses to be

`analyze_deck` is a **non-evaluating** scanner. It never runs the deck, never
expands a variable, never resolves a `[...]` substitution, and never
preprocesses HDL. That is not a limitation to work around — it is the trust
boundary between arbitrary customer content and everything downstream.

The consequence you will meet constantly: **an unresolved thing is reported as
unresolved, and that report is a fact about the deck.**

- `source $::env(SITE_TCL)` becomes `AA-SRC-DYNAMIC`, not a followed edge. The
  deck's behaviour depends on an environment variable — say that in the report.
- A `read_verilog` argument built from a variable becomes `RV-DYNAMIC-ARGUMENT`.
  Which files the deck actually compiles is not determined by the deck alone.
- A module whose ports depend on a `` `ifdef `` becomes
  `HDL-PREPROCESSING-DEPENDENT`. The port list in the document is partial by
  construction.

**Do not report the scanner's coverage as a property of the deck.** "The
analyzer could not resolve four commands" is about us. "Four of this deck's
commands take paths from the environment, so what it loads is not knowable from
the files" is about the deck, and it is the same four commands.

## 2. `model.md` — the overview, section by section

Its length does not grow with the deck. Every section is always present; an
empty one says so, because a missing heading and an empty one look the same to a
reader.

| Section | What it carries |
|---|---|
| header | entry deck, builder and parser identity + version, **model digest** |
| `## Inventory` | source, command, diagnostic and coverage counts |
| `## Verification setup` | the lifted setup facts (see §3) |
| `## Cycle plan facts` | the lifted cycle facts (see §4) |
| `## HDL structure` | selected top, its ports with declared widths, scanner findings |
| `## Coverage and unresolved` | every coverage category with its count, **zeros included** |
| `## Bounds` | which scan bounds the walk reached |
| `## Detail documents` | row counts for the two long documents |

The **model digest** is the content identity of the whole canonical model. Two
analyses with the same digest saw the same deck bytes. Quote it in the report
when the deck tree is one a reviewer might have to reproduce.

`## Coverage and unresolved` printing zeros is deliberate: it distinguishes
"checked and found none" from "not checked". A zero row is not a finding.

`## Bounds` naming a reached bound **is** a finding — the scan stopped early, so
every count below it is a floor, not a total.

## 3. Verification-setup facts

Lifted only from catalog commands whose arguments fully resolved. The `kind` is
what the command means, not what it is called:

| kind | Lifted from |
|---|---|
| `top_design` | `set_top_design` |
| `mode` | `set_verify_mode` |
| `testbench` | `set_testbench`, `set_active_testbench` |
| `clock` | `create_clock` |
| `supply` | `set_supply_net` |
| `constraint` | `set_constraint` |
| `check` | `check_design`, `verify`, `analyze_spice` |

`set_top_design -r` is the **reference** view (usually Verilog); `-i` is the
**implementation** view (usually SPICE). A deck that declares only one of them
verifies one thing against nothing. A deck that declares two different names is
a finding worth the report's opening paragraph.

A deck with no `check` fact configures a testbench and never asks ESP to verify
it. That is almost always either an include fragment rather than an entry deck,
or a real defect. Check which before calling it either.

## 4. Cycle-plan facts, and why the axis matters

| kind | Lifted from |
|---|---|
| `cycle_count` | `create_clock -bincycles` / `-symcycles` / `-flushcycles` |
| `cycle_phase` | `create_clock -phase`, `set_power_sequence -cycles`/`-powerup`/`-powerdn` |
| `cycle_assignment` | `set_constraint <pin> -set <value> -cycle <label>` |
| `cycle_check` | `set_constraint <pin> -cycle <label>` with no `-set` |
| `cycle_style` | `set_constraint ... -style ...` |
| `check_event` | `set_constraint ... -check_num ...` |

**The axis is cycles, never time.** `-check_num` is a within-cycle check index,
not a cycle index; reading it as a cycle number is the single most common
misreading of an ESP deck.

The three phases are distinct and a report has to keep them apart:

- **FLUSH** cycles initialize the design to a known state. An input's `value`
  in a pin attribute is its **active value** — the level at which the pin
  performs its function, per the datasheet's polarity — not the value driven
  during FLUSH.
- **BINARY** cycles drive concrete `0`/`1` vectors.
- **SYMBOLIC** cycles drive symbolic values, and are what actually proves
  something. `testbench_symbolic_cycles` set to zero, or absent while the deck
  declares symbolic constraints, means the deck will run and prove nothing.

`ESP-F3-CYCLE-INCOMPLETE` means a lifted cycle fact carried a label with no pin,
or a pin with no label. The constraint is scoped to something the deck did not
finish naming.

## 5. `model-boundary.md` — the two tables that carry the report

### Pins: `| Pin | Boundary | Function | Group | Constraint | Timing |`

The **Boundary** column is the point of the table. It reconciles what the deck
*configures* against what the design's HDL top actually *exports*:

- a width and direction — the deck and the design agree;
- **`absent`** — the deck configures a pin the design does not have. Either the
  deck is stale, the wrong top was selected, or the port list is
  preprocessing-dependent and the scanner could not see it. All three are
  findings, and they need different follow-ups, so say which you think it is and
  why.
- **`out of range: <declaration>`** — the bus exists, the index does not. A
  `DIN[8]` constraint on a `[7:0]` bus. This is a separate label from `absent` on
  purpose: an off-by-one on a real bus is a different bug from a missing pin.

Read the header line first: it gives the pin count, the off-boundary count, and
the out-of-range count, so you know how much of the table is a defect before you
read a row.

**Function** is the ESP pin function — `clock`, `chipen`, `write`, `address`,
`data`, `bypass`, `ScanEnable`, `ScanDataIn`, `ScanDataOut`, `RedAddress`,
`RedEnable`, `PowerControl`, and so on. A data output has no `value`: it is
compared with `comparex`, not driven. An input with no `value` has no declared
polarity — legitimate for a clock or a data bus, but worth naming on a pin
whose function implies one.

**Group** is the port group. Pins in one group are constrained together; a pin
missing from every group is constrained individually or not at all.

**Constraint** and **Timing** say what the deck did to the pin. A constraint
that a later line removes shows up here — an over-constrained input is the
standard way to make a deck pass while proving nothing, and a *removed*
constraint is the standard way to be surprised by what it proved.

### Supplies: `| Rail | Type | Logic | Subcircuit | Status |`

- **Type** `real` — the rail crosses the macro boundary. `virtual` — it is
  generated inside by a power header or footer, and its owning subcircuit is that
  cell, not the top macro.
- **Logic** `1` is supply-like, `0` is ground-like.
- **Status** `declared`, or **removed with the line that removed it**. A rail
  declared and later removed is the second thing a reader most needs to see: the
  power intent the deck states in its first half is not the power intent it runs
  with.

A `virtual` rail whose subcircuit is the top macro is either a mislabelled real
rail or a missing header cell. A `real` rail that is not a boundary port of the
SPICE top is one or the other too.

## 6. `diagnostics.md` — the deterministic findings

Sorted deterministically, each with a stable diagnostic ID, a severity, a
message, and a source span. **Every entry must reach the report with its
severity intact.** Dropping or softening one is the defect the reviewer looks
for first.

Source-graph findings (prefix `AA-`) are about the file graph:

| Code | Meaning |
|---|---|
| `AA-SRC-MISSING` | a declared `source` target does not exist |
| `AA-SRC-CYCLE` | two files source each other |
| `AA-SRC-DYNAMIC` | the source path is computed, so the walk stopped |
| `AA-SRC-OUTSIDE-ROOT` | a declared source points outside the workspace |
| `AA-SRC-DEPTH-EXCEEDED` | the `source` chain is deeper than the scan bound |
| `AA-TCL-UNBALANCED` | braces or brackets do not balance in a scanned region |

Model findings (prefix `ESP-F3-`) are about the deck's content:

| Code | Meaning | Usual follow-up |
|---|---|---|
| `ESP-F3-UNKNOWN-COMMAND` | not in the reviewed catalog | often benign: `source`, `proc`, `set` and every Tcl builtin land here. A *misspelled* ESP command lands here too, and that one matters |
| `ESP-F3-COMMAND-ARGUMENTS` | arguments do not fit the catalog spec | a real defect: the command will fail or do something else |
| `ESP-F3-TOP-MISSING` | no resolved top-design declaration | check for a dynamic `set_top_design`, then report it |
| `ESP-F3-HDL-TOP-AMBIGUOUS` | no unique HDL top declaration | several modules and nothing selects one |
| `ESP-F3-HDL-TOP-MISSING` | the declared top was not found in the RTL | stale filelist, or the top is in a file the deck does not read |
| `ESP-F3-HDL-PORTS-INCOMPLETE` | the port list is partial | preprocessing, escaped identifiers, or a complex port type — the pin table is a floor |
| `ESP-F3-SUPPLY-CONFLICT` | one rail declared with both logic values | one of the two lines is wrong; the deck's power intent is undefined |
| `ESP-F3-CLOCK-CONFLICT` | one clock declared with two periods | the later one wins at run time; say which |
| `ESP-F3-CYCLE-INCOMPLETE` | a cycle fact lacks a pin or a label | see §4 |
| `ESP-F3-SOURCE-SYMLINK` | a source resolves out of the workspace through a link | a finding: report it, do not chase it |
| `ESP-F3-SOURCE-IDENTITY-MISMATCH` | a source's bytes did not match its recorded digest | something wrote the tree mid-scan |
| `ESP-F3-READ-VERILOG-OPTION` | a `read_verilog` option was given without its argument | a real defect |
| `ESP-F3-COMMAND-LIMIT`, `ESP-F3-SOURCE-BOUND`, `ESP-F3-TRUNCATED` | a scan bound stopped the walk | every count below it is a floor, not a total |
| `ESP-F3-FLOW-*` | a catalog flow-order rule was violated | see below |

The flow rules come from the reviewed catalog, and the code is
`ESP-F3-<rule_id>`. Each says one command group must not precede another **within
one file**, and each is skipped when either command sits inside a control region
the scanner could not evaluate:

| Code | Rule | Severity |
|---|---|---|
| `ESP-F3-FLOW-PROC-READ` | process model must not precede `read_spice` | error |
| `ESP-F3-FLOW-SUPPLY-READ` | `read_spice` must not precede supply declarations | error |
| `ESP-F3-FLOW-DOMAIN-INSPECTOR` | power domain must not precede inspector rules | error |
| `ESP-F3-FLOW-TUNE-WRITE` | SPICE tuning must not precede testbench write | error |
| `ESP-F3-FLOW-CHECK-VERIFY` | `check_design` must not precede `verify` | error |
| `ESP-F3-FLOW-DEBUG-VERIFY` | `verify` must not precede debug commands | error |
| `ESP-F3-FLOW-TB-VERIFY` | testbench config must not precede `verify` | warning |

A flow violation is the one class where the `error` severity really means error:
the command runs against state that does not exist yet.

**`ESP-F3-UNKNOWN-COMMAND` deserves one sentence of judgement, not a count.**
Six of them in a deck that uses `source`, `set` and `proc` is nothing. One of
them on a token that reads like `set_testbanch_pin_attributes` is the finding of
the day.

## 7. `model-sources.md` and `model-commands.md`

`model-sources.md`: `| Relative path | Digest | Role | Parse status | Reached from |`

- **Role** `deck` (the entry), `source-deck` (reached by `source`), `filelist`
  (reached by `-f`), `rtl` (named as HDL).
- **Parse status** `scanned` (Tcl we read) or `opaque` (declared but not
  interpreted as Tcl — RTL, SPICE, a filelist).
- **Reached from** is the reachability parent, so this table is the file graph.
  A source with no path to the entry deck is not in it.

`model-commands.md` carries one row per scanned command with its resolution
state: `resolved`, `unknown` (not in the catalog), `dynamic` (a word the scanner
would have had to evaluate), `opaque` (in the catalog, but its argument shape did
not resolve).

Open either one **only for a specific question**. They are one row per source and
one row per command; a deck with 88 commands spends real turns on a read you did
not need.

## 8. Reading the deck's own prose

A third of a typical deck is comments, and most sit directly above the command
they explain. That prose is the only place three things live:

- **intent** — why a constraint is there, what the author was working around, what
  they intended to come back to;
- **stated-but-not-encoded design properties** — "read latency is 3 cycles" when
  nothing declares it, a datasheet reference, a revision note;
- **your own concerns** — the thing that looks wrong in a way no rule caught.

These are what the three `analysis_log_*` tools exist for, and they are the only
content in the report that the analyzer could not have produced. Everything else
in the report is your reading of a table; this is your reading of the deck.

Two failure modes to avoid, in order of frequency:

1. **Transcribing.** Logging "the deck calls `create_clock -period 10`" as an
   intent fact. That is a document row. It is already extracted, and it burns a
   turn the report needs.
2. **Inventing.** Logging an intent fact for a deck with no comments, because the
   report has an Intent heading. An empty heading that says "this deck carries no
   explanatory prose" is a real finding. A fabricated one is the failure the
   citation gate exists to catch, and it will catch the citation, not the
   fabrication — so catch the fabrication yourself.
