# ESP setup-deck domain knowledge

Generic ESP setup knowledge. It describes how ESP setup decks work, not what any
particular design contains. Treat every design-specific value as something you
must observe in the opened sources.

## What a setup deck is

An ESP setup deck is a Tcl program that tells ESP which two views of a design to
compare, how the design is powered, what each top-level pin means, and how the
symbolic testbench should drive it. ESP then builds a testbench and runs a formal
equivalence/verification pass across the reference and implementation views.

Two views, always:

- the **reference** side, read with `read_verilog -r`, is the RTL or behavioural
  model;
- the **implementation** side, read with `read_spice -i`, is the
  transistor-level netlist.

`set_top_design -r <name>` and `set_top_design -i <name>` name the top cell on
each side. The two names normally match, and a mismatch is a real finding rather
than something to paper over.

## Canonical command order

Order is part of correctness. The load-bearing rules:

1. The process/technology model comes first. `set_process -i -technology_file
   <file>.edm` (and `set_device_model`) MUST appear before any `read_spice`,
   because the netlist is parsed against the device models. When no technology
   file is supplied, ESP falls back to its built-in process models; that is a
   legitimate default worth reporting, not an error.
2. Design reads next: `read_verilog -r`, then `read_spice -i`.
3. `set_top_design` after the reads.
4. Supply nets before anything that reasons about power.
   `report_potential_supply -i` is the standard way to dump what ESP believes
   the supplies are, so a human can cross-check the declarations.
5. Port matching after both views and the supplies exist: `match_design_ports`,
   then `report_matched_ports` and `report_unmatched_ports`. Unmatched ports are
   the single most common cause of a deck that loads but cannot verify. A real
   supply rail is a port on the SPICE side only — functional RTL has no supply
   ports — so each one is declared implementation-only with
   `set_matched_ports -i <net>` before `match_design_ports`; the compiled deck
   already emits those lines from the real supply facts.
6. Timescale and clock: `set_simulation_timescale`, then `create_clock`.
7. Pin attributes before the testbench is written.
8. Constraints and cycle counts last, immediately before `write_testbench`.

## Supplies: real versus virtual

`set_supply_net -i -logic <0|1> -type <real|virtual> <net> -design <subcircuit>`

- A **real** supply is a rail that arrives at the macro boundary from outside:
  the periphery rail, the array rail, ground. It appears in the top-level
  subcircuit port list.
- A **virtual** supply is generated inside the macro by a local power switch or
  header device — a gated rail, a source-biased ground, a retention rail. It
  does not cross the macro boundary. You recognise one by finding the header or
  footer device that drives it, typically gated by a sleep, shutdown, or
  periphery-off control pin.
- `-logic 0` declares a ground-like net, `-logic 1` a supply-like net. Get this
  from the net's role in the netlist, not from its name.
- `-design <subcircuit>` names the subcircuit that owns the net. For a virtual
  rail this is usually the power-header cell, not the top macro, and naming the
  wrong owner silently mis-scopes the declaration.

Reasoning method: read the top-level `.SUBCKT` port list for candidate real
rails, then walk the instantiated cells and MOS device lines looking for
switches whose source or drain produces a rail that never reaches the boundary.
Those are the virtual rails.

## Pin attributes

`set_testbench_pin_attributes <pin> -function <function> -value <high|low>
-allow {<values>}` for inputs, and `-checker comparex` for outputs.

`-function` assigns the pin's role. Common function vocabulary:

`clock`, `enable`, `address`, `data`, `control`, `bypass`, `ScanEnable`,
`ScanDataIn`, `ScanDataOut`, `RedAddress`, `RedEnable`, `PowerControl`.

The function drives how ESP's symbolic testbench treats the pin, so assigning
`control` to something that is really an enable, or `data` to an address bus,
produces a testbench that exercises the wrong behaviour.

`-allow {0 1 X}` declares which symbolic values the pin may take. Omitting a
legal value over-constrains the search; adding an illegal one invites
unreachable states.

`-checker comparex` is the standard output checker: it compares the two views
while tolerating `X` where the model legitimately produces unknowns. Outputs
take a checker, not a driven value.

## Pin polarity: `-value`

`-value high|low` on an **input** declares the pin's **active value**: the
level at which the pin performs its `-function`, as the datasheet states it.
An active-high reset resets the design when high, so it takes `-value high`;
an active-low chip enable takes `-value low`. ESP interprets the pin's
function through this polarity, so getting it backwards makes the testbench
treat assertion as deassertion for everything the function drives.

It is **not** the value driven during the flush cycles, and not a permanent
constraint — a pin you need held gets a `set_constraint`, not a `-value`.

Deriving it is reading, never reasoning:

- the datasheet's polarity statement is the evidence: "active low" → `low`,
  "active high" → `high`;
- derive it from the stated polarity, never from the pin's name — a `PD`
  pin is as likely power-down as pull-down;
- log a value only where a source states a polarity. A pin whose function
  has none stated (a clock, a data or address bus) keeps the field empty,
  and the deck emits no `-value` for it.

## Cycle counts

Three app vars size the symbolic run:

- `testbench_flush_cycles` — cycles ESP spends flushing the design into a
  defined starting state before symbolic stimulus begins. Long enough to
  cover the deepest reset, wake, or mode-entry sequence.
- `testbench_binary_cycles` — cycles driven with concrete binary values.
- `testbench_symbolic_cycles` — cycles driven with symbolic values, where the
  actual proof work happens.

These are verification-plan decisions. They are never invented from a template,
and a deck that omits them uses ESP's own defaults. They live in **your**
`<macro>_constraints.tcl`: the compiler is forbidden from emitting them.

## Constraints

`set_constraint` narrows the symbolic input space:

- `-set {1'b0}` ties a scalar pin;
- `-set {<width>'d0}` ties a vector;
- `-set {<pin>[a:b]}` makes one bus track another, for mirrored or shared buses;
- `-symbolic_static` keeps a pin symbolic but constant across the run, which is
  how you model a strap or a mode pin whose value is unknown but fixed.

Leave genuinely unconstrained inputs unconstrained. Over-constraining is the
most common way to make a deck pass while proving nothing.
