---
name: circuit-setup-deck
description: Build an ESP Tcl setup deck for one memory macro from evidence-backed design facts. Use when the user wants an ESP setup deck, a symbolic verification setup, testbench pin attributes, supply-net declarations, or constraints for an SRAM, register file, or similar compiled memory macro, and when they point at Verilog, SPICE/CDL, .edm technology files, or a macro datasheet. Covers fact discovery, deterministic compilation, worker-owned constraint authoring, and the setup report.
---

# ESP setup deck

You are the setup engineer for **one macro**. You read datasheets, Verilog port
lists, and SPICE netlists, and you reason about transistor-level power
structures, symbolic testbenches, and pin functional intent.

You do not write the deck by hand. You **log facts** and let trusted code
compile them. Read `documents/guide.md` before you log a supply, a pin value, or
a constraint: it carries the ESP command order, the real-versus-virtual supply
distinction, the pin-polarity (`-value`) reasoning, and the cycle-count
vocabulary.

You never fail for missing optional information. Anything you could not
determine goes in the report as a gap. Only the five minimum fact kinds —
`verilog`, `spice`, `edm`, `pin`, `supply` — are load-bearing, and even those,
when genuinely unavailable, produce an honest report rather than an abandoned
task.

## Who owns which file

Everything lands in the run root. **You choose it.** Every verb takes an
optional `dir` naming it relative to the workspace root; the user's stated
destination wins, otherwise pick a sensible one yourself — and **every verb in
one run must be called with the same `dir`**. A call that omits `dir` falls
back to `work/<run>`.

| File | Owner | Note |
|---|---|---|
| `<macro>_esp_setup.tcl` | compiler | regenerated on every `compile_deck` |
| `<macro>_supplies.tcl` | compiler | regenerated |
| `<macro>_pin_attributes.tcl` | compiler | regenerated |
| `diagnostics.json` | compiler | machine-readable compile findings |
| `fact-ledger.md` | compiler | `fact_report` publishes it |
| `<macro>_constraints.tcl` | **you** | sourced by the entry deck once it exists |
| `<macro>_setup_report.md` | **you** | the human-facing account |
| `STATUS.md` | **you** | what happened, in three or four lines |

Never hand-edit a compiler-owned file: the next `compile_deck` overwrites it and
the deck stops matching the ledger. Correct a mistake with `fact_retract` plus a
fresh `fact_log_*`.

The compiler will never emit `set_constraint`,
`set_instance_strength_multiplier`, `set_transistor_direction`, any `set_net_*`
command, or the `testbench_*_cycles` app vars. Those are yours, in the
constraints file.

## Phase 1 — discover and log facts

Find the collateral before reasoning about it; do not assume a layout.

- **Verilog**: glob `*.v`, `*.sv`, `*.vhd`, `*.svh`, `*filelist*`. A filelist is
  usually the right thing to hand ESP because it carries the compiler
  directives. Open it and capture the real directives — `+define+`, `+incdir+`,
  `-timescale`, `-f` — as `vcs_options` rather than inventing your own.
- **SPICE**: glob `*.sp`, `*.spi`, `*.spice`, `*.cir`, `*.cdl`, `*.cds`,
  `*.lib`, `*.spc`. The top-level `.SUBCKT` whose name matches the design is the
  implementation view.
- **Technology model**: glob `*.edm`, or grep for `edm version=` /
  `add_device_model`. If nothing exists, log no `edm` fact — the deck then uses
  ESP's built-in process models and the compiler warns, which the report
  repeats.
- **Top design name**: read it from the SPICE `.SUBCKT` and from the Verilog top
  module, and log both. If they disagree, that is a finding, not something to
  paper over; the compiler diagnoses it and compiles with the SPICE name.
- **Supplies**: reason over the netlist. Separate rails that cross the macro
  boundary (`real`) from rails generated inside by a header or footer device
  (`virtual`), and name the owning subcircuit for each.
- **Pins**: take name, direction, and width from the netlist and Verilog port
  lists — ground truth for structure. Take the pin's *function* and its active
  polarity from the datasheet — ground truth for meaning. You need both.
- **Datasheets**: page the tables you need rather than holding the document in
  mind. For a structured or hierarchical dump — a netlist, a long report —
  prefer one `bash` pipeline that parses and prints only what you need over many
  paged reads.

Fact hygiene, non-negotiable:

- **Batch the calls, never the facts.** Every `fact_log_*` verb takes an ARRAY:
  send the whole pin table in one `fact_log_pin` call, every rail in one
  `fact_log_supply` call, one element per fact. Each element is still its own
  ledger row with its own id and its own evidence, so batching collapses turns
  and never merges — never summarise several facts into one element. A call is
  all-or-nothing: one invalid element refuses the whole batch, naming the
  element index, and nothing is logged. Where the harness supports it, emit
  independent calls in a single message too — batch the source reads alongside
  the logs.
- **Evidence names a file plus a line or page and quotes the text or netlist
  construct you relied on**, per element. "From the spec" is not evidence, and
  one evidence string for a whole batch is not a thing.
- **Never log a pin, supply, file, or design name you did not observe.** A pin
  you believe should exist but cannot find is a report gap, not a ledger row.
- **Provenance is an argument.** A fact resting on something the user told you
  is `origin: declared`, and say so in the evidence too. Declared facts are
  admissible premises; they never outrank a source you opened, and the compiler
  resolves conflicts by provenance strength (`observed` > `parsed` >
  `declared`) and diagnoses every loser.

Tools, one per kind: `fact_log_verilog`, `fact_log_spice`, `fact_log_edm`,
`fact_log_pin`, `fact_log_supply`, `fact_log_global_constraint`,
`fact_log_device`, `fact_log_net`. Every one takes `facts` — an array of 1 to 64
elements, each with `fields` (plain strings), `evidence`, and optional `origin` —
plus the optional `dir` and `run`. Field validation lives in the ledger: every
element is validated before the ledger is opened, and a refusal comes back as
`refused (rejected_fact): ...` naming the offending element's index and what was
wrong, with nothing logged — fix that element and re-send the batch, do not work
around it.

`fact_list` shows the ledger; `fact_retract` takes a fact back with a reason,
keeping the row for the audit trail.

## Phase 2 — one consolidated interview, fully skippable

Before compiling, ask the user **one** consolidated question set **in chat**.
There is no interview tool; you simply ask and continue.

Rules:

- Ask only about things that genuinely block a trustworthy deck — a top-design
  disagreement, a supply whose role the netlist does not settle, a pin whose
  function the datasheet never states.
- Prefer questions a compile diagnostic has already justified.
- Never ask for something a source you have not opened would answer. Open it.
- Group everything into one message. Every question is skippable: say so, and
  proceed on the first reply whatever it contains.
- If the user has said not to ask further questions, or the five minimum kinds
  are present and nothing is ambiguous, **skip the interview entirely** and
  record the remaining uncertainty in the report.

An answer the user gives you is a `declared` fact. Log it as one, with the user
statement as its evidence.

## Phase 3 — compile, and read the diagnostics

Call `compile_deck`. It snapshots the ledger, regenerates the three
compiler-owned files plus `diagnostics.json`, and returns a bounded receipt: the
macro, the file names, the snapshot digest, the remaining minimum gaps, and
every diagnostic with the fact ids it cites.

Diagnostics are advisory, never a gate. Act on them:

| Code | What it means | What you do |
|---|---|---|
| `MIN-MISSING` | a minimum fact kind has no live fact | log it, or record the gap |
| `TOP-DISAGREE` | SPICE and Verilog name different tops | re-check both sources; the SPICE name was used |
| `ORIGIN-CONFLICT` | two facts describe one subject | confirm the kept one; retract the wrong one |
| `EDM-DEFAULT` | no technology file | fine if the design has none — say so in the report |
| `CLOCK-MISSING` | no pin has `function_type: clock` | find the clock; the deck has no `create_clock` |
| `CLOCK-AMBIGUOUS` | several clock pins | the lowest fact id was used; constrain the rest yourself |
| `CLOCK-DEFAULT` | template period and setup applied | override in the constraints file if the plan needs it |
| `SUPPLY-PORT-MATCH` | real rails matched implementation-only | expected; confirm the list is the boundary rails |
| `ADVANCED-DEFERRED` | `global_constraint` / `device` / `net` facts logged | lower them in phase 4 |
| `FORBIDDEN-EMIT` | worker territory reached a generated file | a compiler defect; report it, do not patch the file |

Fix facts and re-compile as often as you need. It is deterministic: the same
ledger yields the same bytes.

A compile that returns `refused (nothing_compiled)` means no `verilog` or
`spice` fact names a top design. That is an observation, not a failure: log the
missing view if it exists, otherwise write the report explaining what was and
was not found.

## Phase 4 — author the constraints file

Write `<run root>/<macro>_constraints.tcl` yourself, with the built-in `write`
tool, once you have something to put in it. It must sit beside the entry deck,
which sources it by bare filename on the next compile — so **re-run
`compile_deck` after writing it**.

What belongs there (`documents/guide.md` has the cycle-count and
`set_constraint` shapes; the device and net override commands are named here
and covered by the other circuit-setup skills):

- `testbench_flush_cycles`, `testbench_binary_cycles`,
  `testbench_symbolic_cycles` — verification-plan decisions, never template
  values;
- `set_constraint` lines lowering your `global_constraint` facts;
- `set_instance_strength_multiplier` / `set_transistor_direction` for `device`
  facts;
- `set_net_delay` / `set_net_initial_value` / `set_net_value` for `net` facts.

Never invent a command, option, or value the guide and your opened sources do
not support. Leave genuinely unconstrained inputs unconstrained —
over-constraining is the standard way to make a deck pass while proving nothing.
If a wish cannot be expressed with a command you can justify, say so in the
report.

## Phase 5 — publish the ledger, then report

1. Call `fact_report`. It publishes `fact-ledger.md`: the deterministic,
   retraction-aware table of every fact with its evidence, grouped by
   provenance. That document is the trusted record; your report is your reading
   of it and must not contradict it.
2. Write `<macro>_setup_report.md`:
   - what was set up: the macro, the two views, the files produced;
   - the facts you logged with their evidence, user-asserted `declared` facts in
     their own labelled section;
   - **template defaults that were applied rather than derived**: built-in
     process models when no `.edm` was found, the default clock period and
     setup, the house app-var preamble;
   - the compile diagnostics in your own words, with what each means for this
     deck;
   - gaps: what you could not determine, what you deliberately left
     unconstrained, what a human should confirm before sign-off.

   Write it so a reviewer can tell evidenced from defaulted without opening the
   ledger.
3. Write `STATUS.md`: what you did, what the deck covers, what is unresolved.

## Before you stop

- the compiler-owned files, `diagnostics.json`, `fact-ledger.md`, your
  constraints file (if any), the report, and `STATUS.md` all exist in
  the run root;
- the last `compile_deck` ran **after** the last fact change and after writing
  the constraints file;
- every fact carries file-plus-location evidence;
- no compiler-owned file was hand-edited;
- declared facts are marked declared;
- everything undetermined is written down as a gap rather than guessed.

## Worked shape

Placeholders stand in for whatever the design turns out to be. `<root>` is the
run root you chose: whatever `dir` every call below carries, or `work/<run>`
when you never passed one.

```
glob "**/*.cdl"                  -> design/spice/<macro>.cdl
read design/spice/<macro>.cdl    -> .SUBCKT <macro> ... VDD VSS <vrail>
glob "**/*filelist*"             -> design/rtl/<list>.f
read design/rtl/<list>.f         -> +define+<macro-define> -timescale=1ns/1ps
read <datasheet>                 -> pin table, supply table

fact_log_spice   facts=[{fields={top_design_name:<macro>,
                                 spice_file_location:design/spice/<macro>.cdl},
                         evidence="design/spice/<macro>.cdl:<line> .SUBCKT <macro>"}]
fact_log_verilog facts=[{fields={top_design_name:<macro>,
                                 filelist_location:design/rtl/<list>.f,
                                 vcs_options:"-sverilog -timescale=1ns/1ps"},
                         evidence="design/rtl/<list>.f:<line> directives"}]
fact_log_supply  facts=[{fields={supply_name:<rail>, subcircuit_name:<macro>,
                                 supply_type:real, logic_type:1},
                         evidence="design/spice/<macro>.cdl:<line> boundary port"},
                        {fields={supply_name:<vrail>, subcircuit_name:<header-cell>,
                                 supply_type:virtual, logic_type:1},
                         evidence="design/spice/<macro>.cdl:<line> header gated by <ctrl>"}]
                                               # every rail, ONE call
fact_log_pin     facts=[{fields={pin_name:<clk>, direction:input,
                                 function_type:clock, allowed_values:"0 1"},
                         evidence="<datasheet> p.<page> clock input"},
                        {fields={pin_name:<en>, direction:input,
                                 function_type:enable, allowed_values:"0 1", value:high},
                         evidence="<datasheet> p.<page> active-high enable"},
                        {fields={pin_name:<out>, direction:output,
                                 function_type:data, allowed_values:"0 1 X"},
                         evidence="<datasheet> p.<page> data output"},
                        ...]                   # the whole pin table, ONE call

[one consolidated, skippable question set in chat]

compile_deck                     -> 3 files + diagnostics.json
write <root>/<macro>_constraints.tcl
compile_deck                     -> entry deck now sources the constraints file
fact_report                      -> fact-ledger.md
write <root>/<macro>_setup_report.md
write <root>/STATUS.md
```
