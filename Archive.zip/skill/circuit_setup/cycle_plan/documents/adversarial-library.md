# Adversarial review library

The seven review families, in strict severity order, with what each one
attacks and what discharges it.

## Nothing ran before you read this

**No deterministic code screened the plan you're about to review.** There's
no checker, no schema, and no oracle behind `plan.md`: it's markdown the
planner authored against `documents/guide.md` (MIGRATION.md §13.11 records
why). The consequence for you is direct — **the mechanical questions are
yours too.**

So before the judgment work, do the arithmetic the guide requires, because
nobody else did:

- **A1** — for every operation, is the comparison cycle at least the
  launch cycle plus `pipeline_depth`? Compute `s - j + f` from the plan's
  own counts and its declared launch cycle; a plan that left `j` implicit
  asserted the worst case whether it meant to or not.
- **A3** — is the flush or shift phase at least one full chain traversal,
  and is shift-enable driven in **every** cycle of it? Coverage is per
  cycle, not per segment.
- **A5** — is the binary phase at least `reset_latency_cycles` of hold
  plus settle, and is `INIT` credited with nothing evidence does not
  guarantee?
- **Unbound scalars** — where one of those numbers was never stated, did
  the plan ask or escalate, or did it quietly pick a plausible value? The
  second one is the silent-green failure, and it is family A's most
  valuable finding.
- **Selectors** — 1-based, every end inside its phase count, segments in
  monotone `(phase, start)` order, no unstated overlap on one pin
  (last-write-wins), and never two values for one pin in one cycle.
- **Authorability** — inputs only, every pin in the survey's inventory
  spelled as the inventory spells it, every value justified by a cited
  operation row, every phase-wide hold justified per cycle, and every
  relation direct lowering cannot express faithfully routed to the
  declaration file rather than approximated.
- **Citations** — every ref resolves in the survey's Evidence catalog, and
  every load-bearing claim carries one. An uncited count, value, launch
  cycle, legality claim, reduction, or corner justification is a finding
  on its own.
- **Coverage** — a pin bound in every cycle of the symbolic phase is a
  demotion whether the plan called it one or not, and it needs a
  symbolic-treatment row with its lost scenario class.

Only then the part no checker could ever have done:

- whether the plan's *causal story* is the one the corner needs — the
  reachable prelude, the right launch operation, an effect that genuinely
  propagates;
- whether a justification is *true*, not merely present;
- whether a relation in the evidence was expressed, bound, routed,
  recorded, or ignored — and whether that choice was the right one;
- whether the corner still explores what it exists to explore;
- families B (beyond B3), C, and E, which are judgment throughout.

Both halves are the review. An arithmetic slip you decline to check
because it feels mechanical is an arithmetic slip that ships.

## Review doctrine

Treat the candidate plan as an unproven claim. Try to falsify it with
authoritative design evidence, exact candidate semantics, the guide's
arithmetic worked yourself, and formal-verification reasoning. A concern
becomes a challenge only when it is material and grounded.

Review in this strict failure-severity order:

1. A — sequence sufficiency and silent under-cycling;
2. B — over-constraint, unreachable operations, and false passes;
3. D — corner completeness across the run's roster;
4. E — explicit specification legality;
5. C — symbolic reduction and evidence-backed capacity concerns;
6. F — faithful ESP or declaration-file lowering; and
7. G — coverage you derive yourself, and capacity fallback.

Exhaust applicable higher-severity questions before lower-severity ones. Do
not invent findings to populate a family. Combine questions that share one
root cause, required correction, and discharge argument. Keep them
separate when repairing one would not discharge the other.

Every family below attacks what the candidate CONSTRAINED, never what it
left free. An unconstrained pin receives a distinct symbol in every `sym`
cycle, which is the strongest formal coverage available for the served
corner: it costs nothing, needs no justification, and no reduction row. A
free pin is challengeable on exactly two grounds, neither of them
coverage — it leaves an explicitly forbidden combination reachable
(family E), or it makes a requested operation unreachable or its
observation nondeterministic (family A). "This pin looks unhandled", "this
value is customary", and "the state space looks large" are not defects.

Each instantiated challenge identifies:

- its archetype;
- a question-shaped statement of the candidate claim under attack;
- the concrete concern and why it is material;
- authoritative evidence refs when design behavior is involved;
- exact candidate refs showing the defect or omission;
- affected refs;
- required discharge evidence; and
- the smallest acceptable correction.

Candidate-only grounding is allowed for intrinsic defects such as
inconsistent counts or overlapping last-write-wins constraints. Otherwise,
a suspicion without authoritative evidence and a candidate locus is
omitted. Missing facts become evidence requests, not fabricated defects.

## Family A — sequence sufficiency

### A1 — pipeline observability

Trigger: the candidate launches an operation whose effect crosses a
declared logical pipeline depth.

Attack: reconstruct launch cycle `j`, remaining symbolic cycles, flush
cycles, and the plan's propagation claim. Ask whether the effect reaches
default comparison before the plan ends. Compute `s - j + f` against the
declared `pipeline_depth` yourself; the plan's own arithmetic is a claim,
not a result.

Discharge: a cycle-by-cycle logical propagation trace names the launch
cycle, each required progression step, and the comparison-reached-by
cycle.

### A2 — pattern or protocol length

Trigger: authoritative evidence defines an ordered sequence of `L`
logical steps.

Attack: map every required step to consecutive candidate cycles. Look for
omitted, reordered, overlapping, or prematurely terminated steps.

Discharge: a complete step-to-cycle map covers the evidence-defined
sequence.

### A3 — special-mode flush

Trigger: authoritative evidence declares a scan-chain or other serial
depth and the served corner exercises it.

Attack: verify enough flush cycles remain and required enable/mode
conditions stay active across the whole drain. Count the flush cycles
against the declared chain length yourself, and check the enable cycle by
cycle rather than segment by segment.

Discharge: declared depth is covered and the relevant control state is
held through every required flush cycle.

### A4 — minimum logical dwell

Trigger: authoritative evidence requires `K` complete logical cycles in a
state.

Attack: count only candidate cycles that actually satisfy the state's
defining relations. Do not infer a dwell requirement from customary
circuit practice.

Discharge: a state-to-cycle map demonstrates at least `K` qualifying
cycles.

### A5 — concrete prelude sufficiency

Trigger: the candidate relies on reset, power-up, mode entry, or pipeline
initialization before symbolic activity.

Attack: do not credit `INIT` unless evidence guarantees the behavior.
Verify that BIN contains every required concrete step and logical wait,
and that its count reaches `reset_latency_cycles` of hold plus settle.

Discharge: every BINCYCLE has a grounded role and the complete prelude
reaches the required state before the first dependent operation.

## Family B — over-constraint and false pass

Treat ordered constraints as a substitution program. For each relevant
cycle, apply selectors, guards, and last-write-wins ordering; then examine
the reachable input image.

### B1 — forced-pin exclusion

Trigger: a forced pin value conflicts with a value required by a claimed
operation or transition, or a forced pin value excludes a spec row that
is documented as a legal no-op, an ignored input, or a resolved priority
rather than a prohibition.

Attack: ask which named cycle still admits the required assignment after
all active substitutions. For a legal-row exclusion, first confirm the
row is genuinely legal and not a mislabeled prohibition, then ask which
named cycle the excluded legal combination would have populated absent
the added constraint.

Discharge: a satisfying assignment remains reachable in a named cycle, or
the forcing constraint is narrowed or removed. Excluding a documented
legal combination is never discharged by relabeling it a reduction — a
legal row has no scenario class to disclose away.

### B2 — guard collapse

Trigger: one constraint assigns a pin that appears in its own or another
required guard relation.

Attack: evaluate whether the required input combination survives for any
symbol assignment after substitution.

Discharge: a compact truth-table or image argument shows the required
combination remains reachable, or the guard/assignment is corrected.

### B3 — shadowing and command order

Trigger: multiple rules write the same target over overlapping cycles.

Attack: find the overlaps yourself — walk every constraint's pin and
cycle range against every other. Determine which rule wins and whether
that priority matches the cited design relation.

Discharge: rules are non-overlapping, intentionally ordered with
evidence, or merged into one unambiguous constraint.

### B4 — mutation-style defect detectability

Trigger: the candidate claims to exercise an operation or state
transition.

Attack: hypothesize a concrete logical defect such as dropped write,
stuck decode, lost retention state, or released scan enable. Trace
whether its effect reaches default comparison before the plan ends. Do
not request output values, checker numbers, masks, or a new output plan.

Discharge: the named mutation changes a targeted effect that reaches
default comparison in a named cycle.

### B5 — symbolic demotion audit

Trigger: a pin is bound in every SYM cycle, or the candidate declares a
symbolic reduction. Bindings compose by last-write-wins across segments.
A pin bound in every `sym` cycle derives `binary` when every
last-write-wins binding is a literal `set_value`, and `symbol_reused`
when every cycle is bound but at least one binding is a symbolic
reference (`innopv_*`) or `symbolic_static`. Coverage is value coverage,
not a single segment span.

Attack: derive the classification yourself — nothing derived it for you.
Verify every demotion you find has a matching disclosure row with
authoritative or user support, states the exact lost scenario class, and
preserves the served corner. Reason on the coverage lattice, not mere
constraint presence: unconstrained gives a distinct symbol per `sym`
cycle (value space AND transition space); `symbolic_static` keeps the
value space but loses within-phase transitions; a literal loses both. A
pin correlated to the served functional corner is the pin whose spaces
the corner exists to explore. For a concretized CONTROL pin, and for each
cycle the constraint covers, ask which named operation in the cited
directive or evidence requires the pin's value in THAT cycle — or whether
the binding merely encodes one arbitrary sequence and destroys the
exploration the corner exists to perform. Coverage is value coverage, not
a single segment span, so read the segments and compose them.

Discharge: every reduction you derived has a supported necessity, exact
lost coverage statement, and corner-sufficiency argument. A control-pin
demotion discharges only with a cited user directive or authoritative
evidence that covers the cycles the constraint spans. A directive naming
a value for one operation discharges that value only in the cycle or
cycles that operation occupies; a phase-wide hold justified by a
single-operation directive is not discharged. Omitting a mandatory
disclosure row is not a discharge.

## Family C — symbolic capacity and reduction tradeoffs

Capacity is evidence-driven. A large-looking state space alone is not a
plan defect. Capacity reduction is optional and trigger-gated: a data bus
or write mask wider than 32 bits; a declared `pipeline_depth` of 2 or
more; a multi-port instance; or a `sym` phase longer than roughly 8
cycles.

### C1 — supported capacity risk

Trigger: an authoritative capacity limit, user directive, or known
failed-run fact applies, or at least one structural capacity trigger
fires: a data bus or write mask wider than 32 bits; a declared
`pipeline_depth` of 2 or more; a multi-port instance; or a `sym` phase
longer than roughly 8 cycles.

Attack: identify the supported risk and whether the candidate has a
viable reduction or partition fallback. Require a capacity reduction only
when a trigger fires and such evidence or direction justifies it. Without
that, record only a non-blocking risk in the compact review summary. Do
not require a reduction from apparent design size alone.

Discharge: the candidate fits the supported limit, records an accepted
risk, or names a grounded fallback.

### C2 — reduction tradeoff

Trigger: data, mask, address, or control symbolism is demoted or
reused — including a pin bound in every `sym` cycle that the
value-coverage oracle marks `binary` or `symbol_reused`. A
capacity-motivated demotion is in play only under the same four triggers
as C1.

Attack: verify the exact lost scenario class and whether it is outside
the served corner. Audit the preferred reduction order: data, masks,
address, then target-sequence controls. For a control-pin demotion, ask
whether a user directive or authoritative evidence required the pin's
value in each cycle the constraint covers. A single-operation directive
does not license a phase-wide hold. Never treat dropping a mandatory
symbolic-treatment row as the repair.

Discharge: the loss is explicit, evidence-backed, and compatible with the
corner's required behavior. A control-pin demotion also cites the
directive or evidence that required the pin's value in each cycle the
constraint spans. Citation of a single-operation directive does not
discharge a phase-wide hold.

### C3 — aliasing

Trigger: symbols are reused across addresses, ports, cycles, or controls
where distinctness can expose a defect.

Attack: test whether forced equality can hide decode, collision, or
ordering failures.

Discharge: distinctness is preserved where required, or evidence shows
the alias is intentional and harmless for this corner.

## Family D — corner completeness

You review every corner of the run in one pass, so roster completeness is
yours to read off the survey's roster and the set of plans that exist.

### D1 — family roster

Trigger: always, once, across the whole run.

Attack: compare the survey's certified selection against the plans that
exist. Verify every corner on the selection has a plan, an `unresolved`,
or an `infeasible`, and that every detected design feature has a plan or
a grounded exclusion reason.

Discharge: all roster cells are explicit and every selected corner is
resolved.

### D2 — required cross-mode interaction

Trigger: the served corner is inherently interaction-shaped or carried
context names a required prior operation.

Attack: map the complete round trip, such as write -> power event -> wake
-> read-back, and identify any missing link.

Discharge: one named plan trace covers every interaction step and reaches
default comparison.

### D3 — state-transition coverage

Trigger: authoritative evidence declares state or mode edges required by
the served corner.

Attack: map each required edge to candidate cycles and list grounded
gaps. Do not broaden a directed corner into unrelated modes.

Discharge: every in-scope edge has a cycle mapping or grounded exclusion.

## Family E — explicit specification legality

### E1 — missing explicit exclusion

Trigger: authoritative evidence explicitly forbids an input combination.

Attack: locate the constraint excluding it or the candidate's documented
soft-policy deviation. Do not infer prohibitions from customary SRAM or
standard-cell practice.

Discharge: the region is excluded with evidence, or the deliberate
deviation explains why it does not undermine the requested
equivalence/model-checking objective and names expected verification
noise or capacity cost.

### E2 — meaningful exploration of a forbidden or undefined region

Trigger: an explicit forbidden region is deliberately left symbolic, or
the candidate makes a soundness claim that depends on behavior there.

Attack: distinguish explicit prohibition from merely undefined behavior
and test whether the stated deviation rationale is sufficient.

Discharge: the region is constrained, or its symbolic exploration is
accepted with a grounded reason. Undefined-but-not-forbidden input space
is not a defect.

### E3 — prohibition discharged by pinning instead of expressing

Trigger: authoritative evidence forbids an input combination, and the
candidate satisfies it by pinning every operand the rule names to a
constant instead of authoring a conditional constraint.

Attack: for each pinned operand, ask whether the corner's mode-defining
evidence required that constant, or whether the planner merely nailed
down both sides of the rule so it could never fire. Once one operand is
bound by genuine mode-defining evidence the rule is already dead; a
second binding on the remaining operand purchases nothing but coverage
loss.

Discharge: every bound operand is evidence-defined for the served corner
and carries its own symbolic-treatment row naming the excluded scenario
class. An operand made irrelevant by another operand's binding carries no
constraint of its own.

### E4 — relational surface never authored

Trigger: authoritative evidence contains a runtime-relation or
illegal-condition table naming an in-scope pin, and the candidate
contains zero `condition` constraints and zero `declaration_file` routes.

Attack: this is a signal, not itself a defect — a corner whose
mode-defining evidence fixes every pin the table's rows name can
legitimately produce an all-`set_value` plan. Use the signal to audit the
table row by row: did each row land on an express, bind-and-disclose,
route, limit, or no-action outcome, or was every row discharged by
uniformly pinning its operands?

Discharge: every relation-table row maps to a defensible outcome for this
corner, or the absence of conditional/declaration-file constraints is
independently justified by evidence that fixes every relation-table
operand in scope.

## Family F — lowering fidelity

### F1 — expressibility and declaration-file route

Trigger: a rule claims `set_constraint` lowering.

Attack: check the pin's direction in the survey's inventory yourself.
Verify a direct rule targets a primary input and is exactly expressible
through its value, condition, and cycle selector. When the semantics need
concurrent state, multi-cycle history, or a richer relation, reject
one-cycle `innopv_*` approximations and verify the declaration-file
declarations, initialization/state updates, application logic, invocation
hooks, and ordering against direct constraints. Also reject a rule that
approximates a timing-aperture or analog-window relation — a setup/hold
window, a continuous-time margin, or another sub-cycle relation — with a
cycle-level constraint, direct or declaration-file; no cycle boundary can
express a sub-cycle aperture faithfully.

Discharge: direct lowering is faithful or a complete declaration-file
sketch faithfully implements the evidence-defined relation. For a
timing-aperture or analog-window relation, discharge requires a
`limitations` entry naming it and no constraint that claims to enforce
it.

### F2 — logical clock constraint

Trigger: a primary clock is constrained with user or evidence support.

Attack: verify the logical gating/selection relation and confirm enough
clock events remain for the claimed witness. A normally unconstrained
clock is not a missing-plan defect.

Discharge: the clock relation is evidence-backed and the target sequence
remains executable.

### F3 — whole-plan surface conformance

Trigger: always for a successful plan.

Attack: walk the whole plan and verify every executable rule has exactly
one faithful route: direct primary-input `set_constraint` semantics or a
referenced declaration-file requirement. Confirm no route modifies output
checking.

Discharge: the complete plan conforms to the allowed lowering surfaces
with no orphan, duplicated, or output-check rule.

## Family G — derived coverage and capacity fallback

### G1 — derived coverage oracle

Trigger: always for a successful plan.

Attack: derive the value coverage yourself, pin by pin and phase by
phase — nothing derived it for you, and the plan's own symbolic-treatment
table is the claim under attack rather than the answer. A pin is `binary`
when a literal `set_value` binds every cycle of the phase,
`symbol_reused` when every cycle is bound but at least one binding is a
symbolic reference (`innopv_*`) or `symbolic_static`, and `symbolic` if
it is left free in at least one `sym` cycle. Bindings compose by
last-write-wins across segments; coverage is value coverage, not a single
segment span. Verify every `binary` or `symbol_reused` cell you derive in
the symbolic phase has a matching disclosure row and a B5/C2
justification.

Discharge: the plan's reductions agree with the coverage you derived and
all of them are justified. A pin bound in every `sym` cycle with no
disclosure row is an unjustified binary demotion — a G1 defect, not a
suggested repair.

### G2 — evidence-backed capacity fallback

Trigger: only when an authoritative capacity risk applies or a structural
capacity trigger fires: a data bus or write mask wider than 32 bits; a
declared `pipeline_depth` of 2 or more; a multi-port instance; or a `sym`
phase longer than roughly 8 cycles.

Attack: verify the precommitted fallback is concrete and follows the
preferred reduction order. Do not require a fallback for speculative size
alone.

Discharge: a named partition or reduction step is available if the
supported capacity failure occurs.

## Non-plan outcomes

For `outcome: unresolved`, review whether every requested fact is
genuinely soundness-critical, absent or conflicting, and precise enough
for the user to supply. Plan-only archetypes may be not applicable.

For `outcome: infeasible`, review the claimed contradiction against ESP
semantics, the exact user request, and authoritative evidence. Challenge
a false non-plan outcome when the supplied evidence already supports a
sound plan.

## Long-tail extension

A specialized design — complex redundancy, calibration, ECC, ROM,
dual-rail power — may need review archetypes and discharge criteria this
library does not carry. Derive them from the design's own evidence and
name them in the review with the same grounding rule.

They participate in the same contract and override nothing: not ESP
semantics, not the authority precedence, not the grounding rule, and not
the guide's arithmetic. None of those will stop a plan on their own — you
are what stops it — so a domain argument that a rule does not apply here
has to be made in the review and grounded, never assumed.
