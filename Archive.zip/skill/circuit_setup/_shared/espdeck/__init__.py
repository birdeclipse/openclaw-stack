"""Deterministic core of the ``circuit-setup-deck`` skill.

A 1:1 port of the legacy ESP setup-deck deterministic modules
(``esp_agent.design_facts.{facts,ledger,report}`` and
``esp_agent.setup_deck.{compiler,emit}``), stdlib-only, with two seams replaced:

* ``canonical_json_bytes`` is vendored into :mod:`espdeck.canonical` instead of
  being imported from ``esp_agent.orchestration.contracts``;
* the ``scratch_work_item_dir`` Workspace-State-Root seam is replaced by the
  ``<workdir>/work/<run>/`` convention (:func:`espdeck.ledger.run_dir`).

Nothing here imports ``esp_agent``. :mod:`espdeck.cli` is the single entry point
the opencode tool wrappers spawn; the modules keep their legacy shape so oracle
review stays a file-by-file diff.

Submodules are imported explicitly (``from espdeck.compiler import ...``); this
file deliberately imports none of them, so spawning the CLI costs one module.
"""
