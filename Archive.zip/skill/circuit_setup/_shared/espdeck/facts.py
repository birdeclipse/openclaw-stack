"""Design Fact model shared by ``setup.deck``, ``setup.author``, and
``setup.analyze`` (ADR 0038, ADR 0041).

A Design Fact is one evidence-backed statement about the design, logged through
a flat string tool. ``origin`` carries provenance strength: ``parsed`` facts cite
a source file or document span, ``declared`` facts rest on a user assertion,
``observed`` facts come from the live ESP toolchain, and ``inferred`` facts are
a reader's judgement about a deck. ``observed`` is reserved in V1: nothing
produces it yet, but it stores and validates so the future ESP integration needs
no migration.

``inferred`` is set by the ``setup.analyze`` executors and is never a
model-facing argument, so no tool exposes ``origin`` (ADR 0041 amendment).

Validation returns bounded error strings rather than raising: an over-cap or
malformed log is a Worker observation error, never a Task failure.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from hashlib import sha256
from types import MappingProxyType
from typing import Final, Literal

from .canonical import canonical_json_bytes

FactKind = Literal[
    "verilog",
    "spice",
    "edm",
    "pin",
    "supply",
    "global_constraint",
    "device",
    "net",
    # setup.analyze reader facts. Never minimum kinds: their absence is not a gap.
    "intent",
    "design",
    "concern",
    # cycle.plan's corner roster (ADR 0043). "function_corner", never "corner":
    # in silicon a corner is a PVT process corner, and a model with
    # semiconductor priors reads it that way. Never a minimum kind -- a design
    # with no functional corners is not an incomplete design.
    "function_corner",
    # cycle.plan's fact-ledger intake (ADR 0043 amendment). ``operation`` is one
    # truth-table row -- the behaviour the plan has to schedule cycles for --
    # and ``plan_scalar`` is one of the three cycle-arithmetic numbers only the
    # user can supply. Neither is a minimum kind: a deck compiles without
    # either, and cycle.plan refuses on its own terms when they are missing.
    "operation",
    "plan_scalar",
]
FactOrigin = Literal["parsed", "declared", "observed", "inferred"]

#: Declaration order. Also the stable order of ``minimum_gaps`` output.
FIELD_SPECS: Final[Mapping[str, tuple[str, ...]]] = MappingProxyType(
    {
        "verilog": (
            "top_design_name",
            "filelist_location",
            "verilog_file_location",
            "vcs_options",
        ),
        "spice": ("top_design_name", "spice_file_location"),
        "edm": ("top_design_name", "edm_file_location"),
        "pin": ("pin_name", "direction", "function_type", "allowed_values", "value"),
        "supply": ("supply_name", "subcircuit_name", "supply_type", "logic_type"),
        "global_constraint": ("pin_name", "facts"),
        "device": ("device_name", "subcircuit_name", "facts"),
        "net": ("net_name", "subcircuit_name", "facts"),
        "intent": ("subject", "statement"),
        "design": ("subject", "statement"),
        "concern": ("subject", "statement"),
        # ``corner_name`` becomes a directory under ``cycle-plans/``, so it must
        # additionally be one safe path segment. That check is the LOGGING TOOL's
        # job, not this function's: ``normalize_fact`` validates fact shape and
        # knows nothing about paths, and cycle.plan re-checks at the walk before
        # any mkdir (``_split_slugs``). Two checks, two reasons, neither
        # redundant -- the tool rejects a bad name at the source, the walk
        # refuses to build a directory from one that reached the ledger anyway.
        "function_corner": ("corner_name", "statement"),
        # cycle.plan's evidence corpus is assembled FROM the ledger, so these
        # two kinds are its intake vocabulary. ``operation`` is one truth-table
        # row read out of a datasheet: ``pin_conditions`` is the row's input
        # side ("CEN=L, GWEN=H") and ``output_effect`` its output side
        # ("Q = mem[A]"), which a row may legitimately leave blank -- a mode
        # entry has conditions and no observable output.
        "operation": ("operation_name", "pin_conditions", "output_effect"),
        # ``plan_scalar`` is a Declared Design Fact in ledger clothing: cycle
        # arithmetic (A1/A3/A5) needs a pipeline depth, a scan chain length or
        # a reset latency, and no spec table states them. ``name`` is closed
        # (``VALID_PLAN_SCALAR_NAMES``) and ``value`` is a non-negative integer
        # in canonical decimal form, both checked in ``normalize_fact``:
        # cycle.plan re-derives the same three names when it mints its
        # ``DeclaredDesignFactV1`` records, and a name it cannot map would
        # otherwise reach that seam as an unloggable corpus.
        "plan_scalar": ("name", "value", "statement"),
    }
)

#: The five basic fact kinds. Their absence is the only content-shaped shortfall
#: that suppresses deck compilation, and even then the Task still finishes.
MINIMUM_KINDS: Final[frozenset[str]] = frozenset({"verilog", "spice", "edm", "pin", "supply"})

#: An absent EDM is satisfied by ESP's built-in process models plus a report
#: warning, so it is reported as a gap but never makes a published deck
#: "incomplete". Only the load-bearing kinds below can do that.
DEFAULTABLE_MINIMUM_KINDS: Final[frozenset[str]] = frozenset({"edm"})
BLOCKING_MINIMUM_KINDS: Final[frozenset[str]] = MINIMUM_KINDS - DEFAULTABLE_MINIMUM_KINDS

# Row-count caps used to live here: ``PER_KIND_CAPS`` (verilog/spice/edm 8,
# pin 256, supply 64, global_constraint/device/net 128,
# intent/design/concern 64) and ``MAX_LIVE_FACTS`` 512. Both are deleted.
#
# Neither had a producer, and both were enforced at the WRITE seam: the ledger
# refused the 257th pin of a real 300-pin design. ADR 0042's rule is that a
# bound derives from a real producer -- a deadline, a context window, an OS
# limit, a domain contract -- and that "a capped walk yields a prefix instead of
# nothing". A row count's only producer is whatever RENDERS the rows, so the
# bound belongs to the renderer, which can truncate and say so. Those bounds now
# live beside their renderers: ``MAX_ROSTER_PINS`` / ``MAX_ROSTER_BLOCK_BYTES``
# (authoring/runtime/prompts.py), ``_DEFAULT_PROJECTION_CAP``
# (authoring/facts_view.py), ``MAX_LISTED_FACTS``
# (setup_analysis/runtime/deck_analysis_tools.py), ``_FACT_LIST_MAX_CHARS``
# (setup_deck/runtime/deck_tools.py), and ``REQUEST_EXTRACT_MAX_CHARS``
# (authoring/runtime/constraint_author.py, reused by setup_deck_loop's extract).
# ``setup_deck/compiler.py`` emits to a file and is deliberately unbounded.
#
# The caps were also a latent Work Item park: a refusal carries no
# ``RefusalReason``, so five in a row tripped the progress guard's all-error
# streak. ``verilog``/``spice``/``edm`` capped at 8 made that reachable.
#
# Content bounds below stay: their producer is the transport that carries them.
MAX_FIELD_CHARS: Final[int] = 1024
MAX_EVIDENCE_CHARS: Final[int] = 4096
MAX_MESSAGE_CHARS: Final[int] = 512

VALID_ORIGINS: Final[frozenset[str]] = frozenset({"parsed", "declared", "observed", "inferred"})
VALID_DIRECTIONS: Final[frozenset[str]] = frozenset({"input", "output", "inout"})
VALID_PIN_VALUES: Final[frozenset[str]] = frozenset({"high", "low", ""})
VALID_SUPPLY_TYPES: Final[frozenset[str]] = frozenset({"real", "virtual"})

#: The closed ``plan_scalar.name`` vocabulary. It is exactly cycle.plan's
#: ``DeclaredDesignFactV1.kind`` literal: these three numbers are what A1
#: (pipeline depth), A3 (scan chain length) and A5 (reset latency) need, and a
#: fourth name would reach that model as an unconstructible fact.
VALID_PLAN_SCALAR_NAMES: Final[frozenset[str]] = frozenset(
    {"pipeline_depth", "scan_chain_length", "reset_latency_cycles"}
)

#: Fields that may legitimately normalize to the empty string.
#: ``pin.function_type`` stays required here. setup.author's lean ``log_pin_fact``
#: opts into an empty function_type through ``extra_optional_fields``.
_OPTIONAL_FIELDS: Final[Mapping[str, frozenset[str]]] = MappingProxyType(
    {
        "verilog": frozenset({"filelist_location", "verilog_file_location", "vcs_options"}),
        "pin": frozenset({"value", "allowed_values"}),
        "supply": frozenset({"subcircuit_name"}),
        "device": frozenset({"subcircuit_name"}),
        "net": frozenset({"subcircuit_name"}),
        "operation": frozenset({"output_effect"}),
    }
)

_LOGIC_ALIASES: Final[Mapping[str, str]] = MappingProxyType(
    {
        "0": "0",
        "1": "1",
        "logic0": "0",
        "logic1": "1",
        "low": "0",
        "high": "1",
        "gnd": "0",
        "vdd": "1",
    }
)


@dataclass(frozen=True, slots=True)
class FactRecord:
    """One immutable ledger row. ``fields`` holds exactly this kind's keys."""

    fact_id: int
    kind: str
    origin: str
    fields: Mapping[str, str]
    evidence: str
    retracted: bool = False
    retract_reason: str = ""


@dataclass(frozen=True, slots=True)
class FactSnapshot:
    """Live facts plus the digest that keys compiler byte-stability."""

    facts: tuple[FactRecord, ...]
    digest: str


def _bounded(message: str) -> str:
    if len(message) <= MAX_MESSAGE_CHARS:
        return message
    return message[: MAX_MESSAGE_CHARS - 1] + "…"


def normalize_fact(
    kind: str,
    fields: Mapping[str, object],
    evidence: str,
    origin: str,
    *,
    extra_optional_fields: frozenset[str] = frozenset(),
) -> tuple[dict[str, str], str] | str:
    """Validate one fact. Return ``(clean_fields, clean_origin)`` or an error string.

    Never raises. Callers surface the string to the Worker as a tool error.
    ``extra_optional_fields`` is a writer-path overlay: the shared pin
    ``function_type`` requirement stays in force unless a caller such as
    setup.author's lean ``log_pin_fact`` opts in.
    """

    spec = FIELD_SPECS.get(kind)
    if spec is None:
        valid = ", ".join(sorted(FIELD_SPECS))
        return _bounded(f"unknown fact kind {kind!r}; valid kinds are {valid}")

    clean_origin = str(origin).strip().lower()
    if clean_origin not in VALID_ORIGINS:
        valid = ", ".join(sorted(VALID_ORIGINS))
        return _bounded(f"unknown origin {origin!r}; valid origins are {valid}")

    clean_evidence = evidence.strip()
    if not clean_evidence:
        return _bounded("evidence is required: name the source file and line or page")
    if len(clean_evidence) > MAX_EVIDENCE_CHARS:
        return _bounded(f"evidence exceeds {MAX_EVIDENCE_CHARS} characters")

    provided = dict(fields)
    unknown = sorted(set(provided) - set(spec))
    if unknown:
        expected = ", ".join(spec)
        return _bounded(f"unknown field(s) {', '.join(unknown)}; {kind} takes {expected}")

    optional = _OPTIONAL_FIELDS.get(kind, frozenset()) | extra_optional_fields
    clean: dict[str, str] = {}
    for name in spec:
        raw = provided.get(name, "")
        value = "" if raw is None else str(raw).strip()
        if len(value) > MAX_FIELD_CHARS:
            return _bounded(f"field {name} exceeds {MAX_FIELD_CHARS} characters")
        if not value and name not in optional:
            return _bounded(f"field {name} is required for a {kind} fact")
        clean[name] = value

    if kind == "verilog" and not clean["filelist_location"] and not clean["verilog_file_location"]:
        return _bounded(
            "a verilog fact needs filelist_location or verilog_file_location; both were empty"
        )

    if kind == "pin":
        direction = clean["direction"].lower()
        if direction not in VALID_DIRECTIONS:
            valid = ", ".join(sorted(VALID_DIRECTIONS))
            return _bounded(f"pin direction {clean['direction']!r} must be one of {valid}")
        clean["direction"] = direction
        value = clean["value"].lower()
        if value not in VALID_PIN_VALUES:
            return _bounded(f"pin value {clean['value']!r} must be high, low, or empty")
        clean["value"] = value

    if kind == "supply":
        supply_type = clean["supply_type"].lower()
        if supply_type not in VALID_SUPPLY_TYPES:
            valid = ", ".join(sorted(VALID_SUPPLY_TYPES))
            return _bounded(f"supply type {clean['supply_type']!r} must be one of {valid}")
        clean["supply_type"] = supply_type
        logic = _LOGIC_ALIASES.get(clean["logic_type"].lower())
        if logic is None:
            return _bounded(f"supply logic_type {clean['logic_type']!r} must resolve to 0 or 1")
        clean["logic_type"] = logic

    if kind == "plan_scalar":
        scalar_name = clean["name"].lower()
        if scalar_name not in VALID_PLAN_SCALAR_NAMES:
            valid = ", ".join(sorted(VALID_PLAN_SCALAR_NAMES))
            return _bounded(f"plan_scalar name {clean['name']!r} must be one of {valid}")
        clean["name"] = scalar_name
        # Stored canonically as ``str(int(...))`` so two logs of the same number
        # ("2" and "02") produce one snapshot digest rather than two.
        # ``isdecimal`` and not ``isdigit``: the latter admits "²", which then
        # raises inside ``int`` -- and a signed form is rejected outright
        # because a cycle count is never negative.
        digits = clean["value"]
        if not digits.isdecimal():
            return _bounded(
                f"plan_scalar value {clean['value']!r} must be a non-negative whole number"
            )
        clean["value"] = str(int(digits))

    return clean, clean_origin


def snapshot_digest(facts: Sequence[FactRecord]) -> str:
    """Digest live facts in ascending id. The compiler's byte-stability key."""

    payload = [
        {
            "fact_id": record.fact_id,
            "kind": record.kind,
            "origin": record.origin,
            "fields": dict(record.fields),
            "evidence": record.evidence,
        }
        for record in sorted(
            (item for item in facts if not item.retracted),
            key=lambda item: item.fact_id,
        )
    ]
    return sha256(canonical_json_bytes(payload)).hexdigest()


def minimum_gaps(snapshot: FactSnapshot) -> tuple[str, ...]:
    """Minimum basic kinds with no live fact, in FIELD_SPECS declaration order."""

    present = {record.kind for record in snapshot.facts}
    return tuple(kind for kind in FIELD_SPECS if kind in MINIMUM_KINDS and kind not in present)


def blocking_minimum_gaps(snapshot: FactSnapshot) -> tuple[str, ...]:
    """Missing minimum kinds that genuinely prevent a trustworthy deck.

    A published deck is only "incomplete" when one of these is absent. An absent
    EDM resolves to ESP's built-in process models plus a warning, so it is a
    reportable gap rather than an incompleteness.
    """

    present = {record.kind for record in snapshot.facts}
    return tuple(
        kind for kind in FIELD_SPECS if kind in BLOCKING_MINIMUM_KINDS and kind not in present
    )


def facts_of_kind(snapshot: FactSnapshot, kind: str) -> tuple[FactRecord, ...]:
    """Live facts of ``kind``, ascending fact id."""

    return tuple(
        sorted((item for item in snapshot.facts if item.kind == kind), key=lambda i: i.fact_id)
    )


__all__ = [
    "FIELD_SPECS",
    "MAX_EVIDENCE_CHARS",
    "MAX_FIELD_CHARS",
    "BLOCKING_MINIMUM_KINDS",
    "DEFAULTABLE_MINIMUM_KINDS",
    "MINIMUM_KINDS",
    "VALID_DIRECTIONS",
    "VALID_ORIGINS",
    "VALID_PIN_VALUES",
    "VALID_PLAN_SCALAR_NAMES",
    "VALID_SUPPLY_TYPES",
    "FactKind",
    "FactOrigin",
    "FactRecord",
    "FactSnapshot",
    "blocking_minimum_gaps",
    "facts_of_kind",
    "minimum_gaps",
    "normalize_fact",
    "snapshot_digest",
]
