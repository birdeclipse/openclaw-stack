"""Canonical serialization vendored into the ``espdeck`` package.

Byte-for-byte the legacy ``canonical_json_bytes`` (three identical copies lived
in ``orchestration/contracts.py``, ``setup_analysis/_canonical.py`` and
``cycle_planning/_canonical.py``). Fact digests are
``sha256(canonical_json_bytes(...))``, so this function IS the digest contract:
any change here invalidates every recorded snapshot digest.
"""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Any


def canonical_json_bytes(value: Any) -> bytes:
    """Return one deterministic JSON representation for JSON-compatible data."""

    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def content_digest(data: bytes) -> str:
    """Return the SHA-256 hexadecimal digest for exact content bytes."""

    return sha256(data).hexdigest()


__all__ = ["canonical_json_bytes", "content_digest"]
