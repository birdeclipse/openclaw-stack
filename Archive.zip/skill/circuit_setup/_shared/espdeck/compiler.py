"""Deterministic Design Fact Ledger to ESP Tcl deck compiler (ADR 0038).

For an identical snapshot, compiler version, and skeleton revision this emits
byte-identical files. Emission order derives from stable sorts, never from fact
insertion order, so the digest is the only byte-stability key a caller needs.

Ownership split, normative:

* The compiler owns the three base files end to end and regenerates them on
  every compile.
* The compiler owns the **static versioned skeleton** — the house app-var
  preamble, the timescale default, the port-match reports, the default clock,
  and the ``write_testbench``/``verify`` epilogue. Those are tool-behaviour house
  standards no datasheet would ever evidence, so they are template content
  rather than facts. This intentionally reverses the legacy "no boilerplate app
  vars" invariant (ADR 0038).
* The Worker owns ``<macro>_constraints.tcl``. The compiler NEVER emits
  ``set_constraint``, cycle-count app vars, ``set_instance_strength_multiplier``,
  ``set_transistor_direction``, or any ``set_net_*`` command; it only sources the
  worker-owned file when it already exists.

``compile_deck`` never raises and never writes to disk. It returns bytes.

Every ``facts_of_kind`` call below is deliberately **unbounded**. These facts
reach a Tcl file, not a prompt and not an observation, so there is no context
window to protect and no truncation to report: a deck for a design with 900 pins
has 900 pin lines, and a ceiling here would silently emit a deck that does not
describe the design. That is the opposite of the render-side bounds the prompt
and observation seams carry. Do not add one.
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from hashlib import sha256
from types import MappingProxyType
from typing import Final, Literal

from .emit import CATALOG, banner, comment, emit_command, option_names, quote_tcl
from .facts import FactRecord, FactSnapshot, facts_of_kind, minimum_gaps

SKELETON_VERSION: Final[str] = "setup-deck-skeleton-v1"
COMPILER_VERSION: Final[str] = "setup-deck-compiler-v1"

#: Clock period and setup are template defaults on purpose: clock period is not
#: a significant factor in ESP's verification flow (ADR 0038). An explicit wish
#: is lowered by the Worker into the constraints file.
DEFAULT_CLOCK_PERIOD: Final[int] = 5000
DEFAULT_CLOCK_SETUP: Final[int] = 500

DEFAULT_TESTBENCH_NAME: Final[str] = "tb_func"
DEFAULT_TESTBENCH_TYPE: Final[str] = "sym"

#: House app-var preamble. Versioned with SKELETON_VERSION.
_APP_VAR_PREAMBLE: Final[tuple[tuple[str, str], ...]] = (
    ("waveform_format", "fsdb"),
    ("verify_rcdelay_unit", "fs"),
    ("verify_delay_round_multiple", "100"),
    ("verify_stop_on_randomize", "true"),
    ("verify_randomize_variables", "sysmem"),
    ("netlist_supply_by_connection", "off"),
    ("parser_verilog", "latest"),
    ("coverage", "true"),
)

_DEFAULT_VCS_OPTIONS: Final[tuple[str, ...]] = ("-sverilog", "-timescale=1ns/1ps")

#: Commands the compiler must never emit. Worker-owned territory.
FORBIDDEN_COMMANDS: Final[frozenset[str]] = frozenset(
    {
        "set_constraint",
        "set_instance_strength_multiplier",
        "set_transistor_direction",
        "set_net_delay",
        "set_net_initial_value",
        "set_net_value",
    }
)
FORBIDDEN_APP_VARS: Final[frozenset[str]] = frozenset(
    {
        "testbench_binary_cycles",
        "testbench_symbolic_cycles",
        "testbench_flush_cycles",
    }
)

_ADVANCED_KINDS: Final[tuple[str, ...]] = ("global_constraint", "device", "net")
_CLOCK_FUNCTION: Final[str] = "clock"

DiagnosticSeverity = Literal["error", "warning", "info"]


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """One advisory compile finding. Never a gate."""

    severity: str
    code: str
    message: str
    fact_ids: tuple[int, ...] = ()


@dataclass(frozen=True, slots=True)
class CompileResult:
    """Candidate bytes plus provenance. ``macro`` is None when unresolvable."""

    macro: str | None
    files: Mapping[str, bytes]
    diagnostics: tuple[Diagnostic, ...]
    manifest: Mapping[str, str]


def deck_file_names(macro: str) -> tuple[str, str, str]:
    """Return (entry, supplies, pin attributes) file names for ``macro``."""

    return (
        f"{macro}_esp_setup.tcl",
        f"{macro}_supplies.tcl",
        f"{macro}_pin_attributes.tcl",
    )


def constraints_file_name(macro: str) -> str:
    """The worker-owned constraints file name."""

    return f"{macro}_constraints.tcl"


def report_file_name(macro: str) -> str:
    """The worker-owned setup report name."""

    return f"{macro}_setup_report.md"


def _origin_rank(origin: str) -> int:
    """Provenance strength: observed beats parsed beats declared."""

    return {"observed": 2, "parsed": 1, "declared": 0}.get(origin, 0)


def _subject(record: FactRecord) -> str:
    """Conflict-detection subject key for one fact."""

    fields = record.fields
    if record.kind == "pin":
        return fields.get("pin_name", "")
    if record.kind == "supply":
        return f"{fields.get('subcircuit_name', '')}::{fields.get('supply_name', '')}"
    return "top_design_name"


def _resolve_conflicts(
    records: Sequence[FactRecord],
    diagnostics: list[Diagnostic],
) -> tuple[FactRecord, ...]:
    """Keep the strongest-provenance fact per subject, diagnosing the losers."""

    winners: dict[str, FactRecord] = {}
    losers: dict[str, list[FactRecord]] = {}
    for record in sorted(records, key=lambda item: item.fact_id):
        key = _subject(record)
        held = winners.get(key)
        if held is None:
            winners[key] = record
            continue
        if _origin_rank(record.origin) > _origin_rank(held.origin):
            winners[key] = record
            losers.setdefault(key, []).append(held)
        else:
            losers.setdefault(key, []).append(record)

    for key, dropped in sorted(losers.items()):
        kept = winners[key]
        for record in dropped:
            if record.origin == kept.origin:
                continue
            diagnostics.append(
                Diagnostic(
                    severity="warning",
                    code="ORIGIN-CONFLICT",
                    message=(
                        f"{kept.kind} subject {key or '(top)'}: kept the {kept.origin} fact "
                        f"{kept.fact_id} and ignored the {record.origin} fact {record.fact_id}"
                    ),
                    fact_ids=(kept.fact_id, record.fact_id),
                )
            )
    return tuple(sorted(winners.values(), key=lambda item: item.fact_id))


def _top_name(record: FactRecord) -> str:
    return record.fields.get("top_design_name", "")


def _resolve_macro(
    snapshot: FactSnapshot,
    diagnostics: list[Diagnostic],
) -> str | None:
    """Prefer the SPICE top-design name; diagnose disagreement with Verilog."""

    spice = facts_of_kind(snapshot, "spice")
    verilog = facts_of_kind(snapshot, "verilog")
    spice_name = _top_name(spice[0]) if spice else ""
    verilog_name = _top_name(verilog[0]) if verilog else ""

    if spice_name and verilog_name and spice_name != verilog_name:
        diagnostics.append(
            Diagnostic(
                severity="error",
                code="TOP-DISAGREE",
                message=(
                    f"spice fact {spice[0].fact_id} names top design {spice_name!r} but "
                    f"verilog fact {verilog[0].fact_id} names {verilog_name!r}; "
                    "compiling with the spice name"
                ),
                fact_ids=(spice[0].fact_id, verilog[0].fact_id),
            )
        )
    resolved = spice_name or verilog_name
    return resolved or None


def _check_catalog(
    name: str,
    options: Sequence[tuple[str, str]],
    diagnostics: list[Diagnostic],
    seen: set[str],
) -> None:
    """Advisory catalog legality check, reported once per command name."""

    if name in seen:
        return
    seen.add(name)
    if not CATALOG.is_known_command(name):
        diagnostics.append(
            Diagnostic(
                severity="warning",
                code="CATALOG-UNKNOWN",
                message=f"command {name} is not in the pinned ESP command catalog",
            )
        )
        return
    unknown = CATALOG.unknown_options(name, option_names(options))
    if unknown:
        diagnostics.append(
            Diagnostic(
                severity="warning",
                code="CATALOG-UNKNOWN",
                message=f"command {name} has option(s) not in the catalog: {', '.join(unknown)}",
            )
        )


def _fold_verilog_read(
    verilog_facts: Sequence[FactRecord],
) -> tuple[str, tuple[tuple[str, str], ...]]:
    """Fold every verilog fact into one ``read_verilog -r -vcs`` argument string."""

    tokens: list[str] = []
    seen: set[str] = set()

    def push(token: str) -> None:
        if token and token not in seen:
            seen.add(token)
            tokens.append(token)

    for record in verilog_facts:
        for raw in record.fields.get("vcs_options", "").split():
            push(raw)
    for default in _DEFAULT_VCS_OPTIONS:
        push(default)
    for record in verilog_facts:
        loose = record.fields.get("verilog_file_location", "")
        if loose:
            push(loose)
    # One ``-f`` per filelist. The flag itself is never deduplicated: a second
    # bare path would be read as a loose source instead of a filelist.
    emitted_filelists: set[str] = set()
    for record in verilog_facts:
        filelist = record.fields.get("filelist_location", "")
        if filelist and filelist not in emitted_filelists:
            emitted_filelists.add(filelist)
            tokens.append("-f")
            tokens.append(filelist)
    return " ".join(tokens), ()


def _supply_only_ports(
    macro: str, snapshot: FactSnapshot
) -> tuple[tuple[str, tuple[int, ...]], ...]:
    """Real top-boundary supply names with no pin fact of the same name.

    A real rail appears in the top-level SPICE port list, but functional RTL
    carries no supply ports, so the implementation-side port would stay
    unmatched after ``match_design_ports``. Each one is declared
    implementation-only with ``set_matched_ports -i <net>`` before the match
    runs. Virtual rails never reach the boundary and rails owned by an inner
    subcircuit are not top-level ports, so neither participates.
    """

    pin_names = {record.fields.get("pin_name", "") for record in facts_of_kind(snapshot, "pin")}
    by_name: dict[str, list[int]] = {}
    for record in facts_of_kind(snapshot, "supply"):
        if record.fields.get("supply_type", "") != "real":
            continue
        owner = record.fields.get("subcircuit_name", "")
        if owner and owner != macro:
            continue
        name = record.fields.get("supply_name", "")
        if not name or name in pin_names:
            continue
        by_name.setdefault(name, []).append(record.fact_id)
    return tuple((name, tuple(sorted(ids))) for name, ids in sorted(by_name.items()))


def _emit_supplies(macro: str, supply_facts: Sequence[FactRecord]) -> tuple[str, list[str]]:
    """Render the supplies fragment and collect emitted command names."""

    lines: list[str] = [
        comment(f"{macro} supply nets"),
        comment(f"generated by {COMPILER_VERSION} / {SKELETON_VERSION}"),
        "",
    ]
    ordered = sorted(
        supply_facts,
        key=lambda item: (
            item.fields.get("subcircuit_name", "") or macro,
            item.fields.get("supply_type", ""),
            item.fields.get("supply_name", ""),
        ),
    )
    for record in ordered:
        design = record.fields.get("subcircuit_name", "") or macro
        lines.append(
            emit_command(
                "set_supply_net",
                flags=("-i",),
                options=(
                    ("-logic", record.fields.get("logic_type", "0")),
                    ("-type", record.fields.get("supply_type", "real")),
                ),
                positionals=(record.fields.get("supply_name", ""),),
            )
            + " "
            + emit_command("", options=(("-design", design),)).strip()
        )
    return "\n".join(lines) + "\n", ["set_supply_net"] if ordered else []


def _allow_list(raw: str) -> str:
    tokens = [token.strip().upper() for token in raw.replace(",", " ").split() if token.strip()]
    return " ".join(tokens)


def _emit_pin_attributes(macro: str, pin_facts: Sequence[FactRecord]) -> tuple[str, list[str]]:
    """Render the pin-attributes fragment and collect emitted command names."""

    lines: list[str] = [
        comment(f"{macro} testbench pin attributes"),
        comment(f"generated by {COMPILER_VERSION} / {SKELETON_VERSION}"),
        comment("inputs carry their active value (-value); outputs are compared with comparex"),
        "",
    ]
    ordered = sorted(
        pin_facts,
        key=lambda item: (
            item.fields.get("function_type", ""),
            item.fields.get("pin_name", ""),
        ),
    )
    for record in ordered:
        fields = record.fields
        options: list[tuple[str, str]] = [("-function", fields.get("function_type", ""))]
        flags: list[str] = []
        if fields.get("direction") == "output":
            options.append(("-checker", "comparex"))
        elif fields.get("value"):
            options.append(("-value", fields["value"]))
        allow = _allow_list(fields.get("allowed_values", ""))
        if allow:
            options.append(("-allow", "{" + allow + "}"))
        lines.append(
            emit_command(
                "set_testbench_pin_attributes",
                flags=tuple(flags),
                positionals=(fields.get("pin_name", ""),),
            )
            + " "
            + " ".join(f"{option} {value}" for option, value in options)
        )
    return "\n".join(lines) + "\n", ["set_testbench_pin_attributes"] if ordered else []


def _emit_entry(
    macro: str,
    snapshot: FactSnapshot,
    *,
    constraints_file_present: bool,
    diagnostics: list[Diagnostic],
) -> tuple[str, list[tuple[str, tuple[tuple[str, str], ...]]]]:
    """Render the entry deck. Returns text plus (command, options) pairs emitted."""

    emitted: list[tuple[str, tuple[tuple[str, str], ...]]] = []
    supplies_name, pin_name = deck_file_names(macro)[1], deck_file_names(macro)[2]
    lines: list[str] = [
        comment(f"{macro} ESP setup deck"),
        comment(f"compiler {COMPILER_VERSION}, skeleton {SKELETON_VERSION}"),
        comment(f"fact snapshot {snapshot.digest}"),
        comment("generated from the Design Fact Ledger; edit facts, not this file"),
        "",
        comment("--- house application variables (template default) ---"),
    ]
    for name, value in _APP_VAR_PREAMBLE:
        lines.append(f"set_app_var {name} {value}")
    lines.append("")

    edm_facts = _resolve_conflicts(facts_of_kind(snapshot, "edm"), diagnostics)
    verilog_facts = facts_of_kind(snapshot, "verilog")
    spice_facts = facts_of_kind(snapshot, "spice")

    # FLOW-PROC-READ: the technology file must precede every read_spice.
    if edm_facts:
        lines.append(comment("--- process / technology model ---"))
        for record in edm_facts:
            options = (("-technology_file", record.fields.get("edm_file_location", "")),)
            lines.append(emit_command("set_process", flags=("-i",), options=options))
            emitted.append(("set_process", options))
        lines.append("")
    else:
        diagnostics.append(
            Diagnostic(
                severity="warning",
                code="EDM-DEFAULT",
                message=(
                    "no edm fact was logged; the deck omits set_process and ESP built-in "
                    "process models will be used"
                ),
            )
        )

    lines.append(banner("READ REFERENCE DESIGN"))
    if verilog_facts:
        folded, _ = _fold_verilog_read(verilog_facts)
        lines.append(f'read_verilog -r -vcs "{folded}"')
        emitted.append(("read_verilog", (("-vcs", folded),)))
    lines.append(banner("READ IMPLEMENTATION DESIGN"))
    for record in spice_facts:
        location = record.fields.get("spice_file_location", "")
        lines.append(emit_command("read_spice", flags=("-i",), positionals=(location,)))
        emitted.append(("read_spice", ()))
    lines.append("")

    lines.append(comment("--- top design ---"))
    lines.append(emit_command("set_top_design", flags=("-r",), positionals=(macro,)))
    lines.append(emit_command("set_top_design", flags=("-i",), positionals=(macro,)))
    emitted.append(("set_top_design", ()))
    lines.append("")

    lines.append(banner("SET SUPPLY NETS"))
    lines.append(f"source -echo -verbose {supplies_name}")
    lines.append("report_potential_supply -i > supplies.rpt")
    emitted.append(("report_potential_supply", ()))
    lines.append("")

    lines.append(banner("MATCH DESIGN PORTS"))
    supply_only = _supply_only_ports(macro, snapshot)
    for name, _fact_ids in supply_only:
        options = (("-i", name),)
        lines.append(emit_command("set_matched_ports", options=options))
        emitted.append(("set_matched_ports", options))
    if supply_only:
        diagnostics.append(
            Diagnostic(
                severity="info",
                code="SUPPLY-PORT-MATCH",
                message=(
                    "real supply port(s) with no RTL counterpart are matched "
                    "implementation-only via set_matched_ports -i: "
                    + ", ".join(name for name, _ in supply_only)
                ),
                fact_ids=tuple(fact_id for _, fact_ids in supply_only for fact_id in fact_ids),
            )
        )
    lines.append("match_design_ports")
    lines.append("report_matched_ports")
    lines.append("report_unmatched_ports")
    emitted.extend(
        [("match_design_ports", ()), ("report_matched_ports", ()), ("report_unmatched_ports", ())]
    )
    lines.append("")

    lines.append(comment("--- timescale and clock (template defaults) ---"))
    lines.append("set_simulation_timescale 1 ns 1 ps")
    emitted.append(("set_simulation_timescale", ()))

    clock_pins = [
        record
        for record in facts_of_kind(snapshot, "pin")
        if record.fields.get("function_type", "").lower() == _CLOCK_FUNCTION
    ]
    if not clock_pins:
        diagnostics.append(
            Diagnostic(
                severity="warning",
                code="CLOCK-MISSING",
                message="no pin fact has function_type clock; the deck omits create_clock",
            )
        )
    else:
        if len(clock_pins) > 1:
            diagnostics.append(
                Diagnostic(
                    severity="warning",
                    code="CLOCK-AMBIGUOUS",
                    message=("more than one clock pin fact was logged; using the lowest fact id"),
                    fact_ids=tuple(record.fact_id for record in clock_pins),
                )
            )
        chosen = clock_pins[0]
        options = (
            ("-period", str(DEFAULT_CLOCK_PERIOD)),
            ("-setup", str(DEFAULT_CLOCK_SETUP)),
        )
        lines.append(
            emit_command(
                "create_clock",
                options=options,
                positionals=(chosen.fields.get("pin_name", ""),),
            )
        )
        lines.append("report_clock")
        emitted.append(("create_clock", options))
        emitted.append(("report_clock", ()))
        diagnostics.append(
            Diagnostic(
                severity="info",
                code="CLOCK-DEFAULT",
                message=(
                    f"create_clock uses the template default period {DEFAULT_CLOCK_PERIOD} and "
                    f"setup {DEFAULT_CLOCK_SETUP}; override in the constraints file if needed"
                ),
                fact_ids=(chosen.fact_id,),
            )
        )
    lines.append("")

    lines.append(banner("SOURCE TESTBENCH PIN ATTRIBUTES"))
    lines.append(f"source -echo -verbose {pin_name}")
    lines.append("")

    if constraints_file_present:
        lines.append(banner("SOURCE WORKER-OWNED CONSTRAINTS"))
        lines.append(f"source -echo -verbose {constraints_file_name(macro)}")
        lines.append("")

    lines.append("report_process -i")
    emitted.append(("report_process", ()))
    lines.append("")

    lines.append(comment("--- testbench and verification epilogue (template default) ---"))
    lines.append("set_app_var testbench_style symbolic")
    lines.append(emit_command("current_design", flags=("-i",), positionals=(macro,)))
    lines.append(f"set BENCH {DEFAULT_TESTBENCH_NAME}")
    lines.append(f"set TYPE {DEFAULT_TESTBENCH_TYPE}")
    lines.append('write_testbench -replace "$BENCH"')
    lines.append('set_active_testbench "$BENCH.$TYPE"')
    emitted.extend([("current_design", ()), ("write_testbench", ()), ("set_active_testbench", ())])
    lines.append("")
    lines.extend(
        [
            "if {![verify]} {",
            "  if { ![info exists debug_cmd]} {",
            '    set debug_cmd "debug_design "',
            "  }",
            "  eval $debug_cmd",
            "  report_log",
            "  report_status",
            "  quit",
            "} else {",
            "  report_assertion_coverage > sva_pass_cov.rpt",
            "  report_assertion > sva_pass.rpt",
            "  report_log",
            "  report_status",
            "  quit",
            "}",
        ]
    )
    emitted.append(("verify", ()))
    return "\n".join(lines) + "\n", emitted


def _assert_no_forbidden(text: str) -> tuple[str, ...]:
    """Return forbidden command or app-var names found in emitted bytes."""

    found: list[str] = []
    for name in sorted(FORBIDDEN_COMMANDS):
        for line in text.splitlines():
            stripped = line.strip()
            if stripped.startswith(name):
                found.append(name)
                break
    for name in sorted(FORBIDDEN_APP_VARS):
        if f"set_app_var {name}" in text:
            found.append(name)
    return tuple(found)


def compile_deck(
    snapshot: FactSnapshot,
    *,
    constraints_file_present: bool = False,
) -> CompileResult:
    """Compile one ledger snapshot into candidate deck bytes. Never raises."""

    diagnostics: list[Diagnostic] = []

    gaps = minimum_gaps(snapshot)
    if gaps:
        diagnostics.append(
            Diagnostic(
                severity="error" if {"verilog", "spice"} & set(gaps) else "warning",
                code="MIN-MISSING",
                message=f"minimum basic fact kind(s) missing: {', '.join(gaps)}",
            )
        )

    advanced_ids = tuple(
        record.fact_id for kind in _ADVANCED_KINDS for record in facts_of_kind(snapshot, kind)
    )
    if advanced_ids:
        diagnostics.append(
            Diagnostic(
                severity="info",
                code="ADVANCED-DEFERRED",
                message=(
                    "advanced facts are worker-owned; lower them into the constraints file: "
                    + ", ".join(str(item) for item in sorted(advanced_ids))
                ),
                fact_ids=tuple(sorted(advanced_ids)),
            )
        )

    macro = _resolve_macro(snapshot, diagnostics)
    if macro is None:
        diagnostics.append(
            Diagnostic(
                severity="error",
                code="MIN-MISSING",
                message="no verilog or spice fact names a top design; nothing was compiled",
            )
        )
        manifest = {
            "snapshot_digest": snapshot.digest,
            "compiler_version": COMPILER_VERSION,
            "skeleton_version": SKELETON_VERSION,
        }
        return CompileResult(
            macro=None,
            files=MappingProxyType({}),
            diagnostics=tuple(diagnostics),
            manifest=MappingProxyType(manifest),
        )

    entry_name, supplies_name, pin_name = deck_file_names(macro)

    supply_facts = _resolve_conflicts(facts_of_kind(snapshot, "supply"), diagnostics)
    pin_facts = _resolve_conflicts(facts_of_kind(snapshot, "pin"), diagnostics)

    entry_text, emitted = _emit_entry(
        macro,
        snapshot,
        constraints_file_present=constraints_file_present,
        diagnostics=diagnostics,
    )
    supplies_text, supply_commands = _emit_supplies(macro, supply_facts)
    pin_text, pin_commands = _emit_pin_attributes(macro, pin_facts)

    seen: set[str] = set()
    for name, options in emitted:
        _check_catalog(name, options, diagnostics, seen)
    for name in supply_commands:
        _check_catalog(
            name,
            (("-logic", "0"), ("-type", "real"), ("-design", macro)),
            diagnostics,
            seen,
        )
    for name in pin_commands:
        _check_catalog(name, (("-function", "clock"),), diagnostics, seen)

    files: dict[str, bytes] = {
        entry_name: entry_text.encode("utf-8"),
        supplies_name: supplies_text.encode("utf-8"),
        pin_name: pin_text.encode("utf-8"),
    }

    for filename, payload in files.items():
        leaked = _assert_no_forbidden(payload.decode("utf-8"))
        if leaked:
            diagnostics.append(
                Diagnostic(
                    severity="error",
                    code="FORBIDDEN-EMIT",
                    message=(
                        f"{filename} contains worker-owned command(s) {', '.join(leaked)}; "
                        "this is a compiler defect"
                    ),
                )
            )

    manifest: dict[str, str] = {
        "snapshot_digest": snapshot.digest,
        "compiler_version": COMPILER_VERSION,
        "skeleton_version": SKELETON_VERSION,
    }
    for filename in sorted(files):
        manifest[f"sha256:{filename}"] = sha256(files[filename]).hexdigest()

    return CompileResult(
        macro=macro,
        files=MappingProxyType(files),
        diagnostics=tuple(diagnostics),
        manifest=MappingProxyType(manifest),
    )


__all__ = [
    "COMPILER_VERSION",
    "DEFAULT_CLOCK_PERIOD",
    "DEFAULT_CLOCK_SETUP",
    "FORBIDDEN_APP_VARS",
    "FORBIDDEN_COMMANDS",
    "SKELETON_VERSION",
    "CompileResult",
    "Diagnostic",
    "DiagnosticSeverity",
    "compile_deck",
    "constraints_file_name",
    "deck_file_names",
    "report_file_name",
    "quote_tcl",
]
