"""Deterministic human-readable projection of one Trusted Design Fact Ledger.

Every ``fact_log_*`` tool writes into the same ledger, and the only other
human-facing view of it is model-authored prose -- ``<macro>_setup_report.md``.
Prose can disagree with the rows it describes, and a live legacy run produced
exactly that: a rejected ``log_edm_fact`` reached the journal and no
deliverable. This renderer is the trusted-code answer: what a reviewer reads IS
the table, projected by a pure function of the rows.

It is a **file**, not a prompt projection:

* **Unbounded.** The bound-belongs-to-the-renderer rule
  (``facts.py`` above ``MAX_FIELD_CHARS``) also says a renderer emitting to a
  file has no window to protect -- ``setup_deck/compiler.py`` is unbounded for
  the same reason. A ledger with 900 pins has 900 pin rows here. Do not add a
  cap: a truncated audit document is worse than a long one.
* **Retraction-aware.** It reads every row, not the live snapshot. ``retract``
  deliberately keeps the row and the reason, and a fact the agent took back --
  with why -- is the most audit-relevant line in the table.

Pure: rows in, text out. Nothing here touches the filesystem except
:func:`publish_fact_report`, which is the one best-effort write seam.
"""

from __future__ import annotations

import logging
from collections.abc import Sequence
from pathlib import Path
from typing import Final

from .facts import (
    FIELD_SPECS,
    FactRecord,
    FactSnapshot,
    minimum_gaps,
    snapshot_digest,
)
from .ledger import FactLedger

__all__ = [
    "FACT_REPORT_NAME",
    "publish_fact_report",
    "render_fact_report",
]

_LOGGER = logging.getLogger(__name__)

#: Published beside each Module's ``STATUS.md``. Deliberately NOT ``facts.md``:
#: ``cycle.plan`` already publishes a planner-authored ``cycle-plans/facts.md``
#: (its reading of the spec), and on a case-insensitive filesystem -- APFS by
#: default -- ``FACTS.md`` would silently overwrite it. The two documents are
#: also genuinely different: that one is the spec digest, this one is the ledger.
FACT_REPORT_NAME: Final[str] = "fact-ledger.md"

#: Origin sections, in reading order. Provenance is the first question a
#: reviewer asks of a fact, and separating parsed from user-asserted declared
#: material is what ``setup.deck``'s report cue has always asked a model to do
#: by hand. Unknown origins render after these, sorted: ``origin`` is
#: unconstrained TEXT in the schema on purpose, so a new provenance class must
#: appear rather than vanish.
_ORIGIN_TITLES: Final[tuple[tuple[str, str], ...]] = (
    ("parsed", "Parsed"),
    ("declared", "Declared by the user"),
    ("observed", "Observed from the toolchain"),
    ("inferred", "Inferred by the reader"),
)


def render_fact_report(
    records: Sequence[FactRecord],
    *,
    session_id: str,
    work_item_id: str,
) -> str:
    """Render every ledger row -- live and retracted -- as one plain document.

    Byte-stable for a given set of rows: sections follow ``_ORIGIN_TITLES`` then
    ``FIELD_SPECS`` declaration order, and rows follow ascending ``fact_id``.

    Scoped to one ledger. A Module that READS another Work Item's facts rather
    than logging its own -- ``cycle.plan`` resolves ``setup.deck``'s pin roster
    that way -- reports the ledger it owns, and the ledger it read reports
    itself under its own Work Item. Restating borrowed rows here would put the
    same 67 pins in two documents that can then disagree.
    """

    live = tuple(record for record in records if not record.retracted)
    retracted = tuple(record for record in records if record.retracted)
    digest = snapshot_digest(live)
    gaps = minimum_gaps(FactSnapshot(facts=live, digest=digest))

    lines = [
        "# Design Fact Ledger",
        "",
        f"session: {_inline(session_id)}",
        f"work item: {_inline(work_item_id)}",
        f"snapshot digest: {digest}",
        f"live facts: {len(live)}",
        f"retracted facts: {len(retracted)}",
    ]
    if gaps:
        lines.append("missing minimum fact kinds: " + ", ".join(gaps))

    lines.extend(("", "## Live facts", ""))
    if live:
        for origin, title in _origin_order(live):
            matched = tuple(record for record in live if record.origin == origin)
            if not matched:
                continue
            lines.extend((f"### {title}", ""))
            lines.extend(_kind_blocks(matched))
    else:
        lines.extend(("(none)", ""))

    lines.extend(("## Retracted facts", ""))
    if retracted:
        for record in retracted:
            lines.append(_format_retracted(record))
            lines.append("")
    else:
        lines.extend(("(none)", ""))

    return "\n".join(lines).rstrip() + "\n"


def publish_fact_report(publish_root: Path, ledger: FactLedger) -> bool:
    """Write ``fact-ledger.md`` under ``publish_root``. Never raises.

    Called from each Module's terminal path beside its ``STATUS.md`` write, so
    the document exists on success, cancellation, a progress-guard park and a
    failure alike -- the runs where a reviewer most wants to know what the agent
    had actually established. A ledger that cannot be read or a directory that
    cannot be written is a missing document, never a failed Work Item.

    Identity comes off the ledger rather than from the caller: the header must
    name the ledger these rows were read from, and a caller that can pass the
    ids separately is a caller that can pass mismatched ones. The legacy Work
    Item id is the ``run`` id here -- ``work/<run>/`` is the unit of work -- and
    ``session_id`` is the opencode session that owns the run.
    """

    try:
        records = ledger.list()
        text = render_fact_report(
            records,
            session_id=ledger.session_id,
            work_item_id=ledger.run,
        )
        publish_root.mkdir(parents=True, exist_ok=True)
        _ = (publish_root / FACT_REPORT_NAME).write_text(text, encoding="utf-8")
    except Exception:
        _LOGGER.debug("%s could not be published", FACT_REPORT_NAME, exc_info=True)
        return False
    return True


def _origin_order(records: Sequence[FactRecord]) -> tuple[tuple[str, str], ...]:
    known = frozenset(origin for origin, _title in _ORIGIN_TITLES)
    extra = sorted({record.origin for record in records if record.origin not in known})
    return (*_ORIGIN_TITLES, *((origin, origin) for origin in extra))


def _kind_blocks(records: Sequence[FactRecord]) -> list[str]:
    kinds = [kind for kind in FIELD_SPECS if any(item.kind == kind for item in records)]
    extra = sorted({item.kind for item in records if item.kind not in FIELD_SPECS})
    lines: list[str] = []
    for kind in (*kinds, *extra):
        lines.extend((f"#### {kind}", ""))
        for record in sorted(
            (item for item in records if item.kind == kind),
            key=lambda item: item.fact_id,
        ):
            lines.append(_format_record(record))
            lines.append("")
    return lines


def _format_record(record: FactRecord) -> str:
    lines = [f"- fact {record.fact_id}"]
    lines.extend(_field_lines(record))
    return "\n".join(lines)


def _format_retracted(record: FactRecord) -> str:
    """Retracted rows are flat: kind and origin move onto the bullet.

    They are grouped by nothing because there is rarely more than a handful, and
    a reader wants them in the order they were taken back.
    """

    lines = [f"- fact {record.fact_id} ({_inline(record.origin)}, {_inline(record.kind)})"]
    reason = _inline(record.retract_reason)
    lines.append(f"  reason: {reason if reason else '(none given)'}")
    lines.extend(_field_lines(record))
    return "\n".join(lines)


def _field_lines(record: FactRecord) -> list[str]:
    """One indented line per populated field, in the kind's declaration order.

    An empty field is dropped rather than rendered blank: ``normalize_fact``
    stores every key a kind declares, so keeping them would pad a pin row with
    four empty lines for the optional fields nobody filled.
    """

    spec = FIELD_SPECS.get(record.kind, tuple(record.fields))
    lines: list[str] = []
    for key in spec:
        value = _inline(str(record.fields.get(key, "")))
        if value:
            lines.append(f"  {key}: {value}")
    evidence = _inline(record.evidence)
    if evidence:
        lines.append(f"  evidence: {evidence}")
    return lines


def _inline(text: str) -> str:
    """Fold every line terminator to a space so a value cannot end its line.

    ``normalize_fact`` only strips the ends of a field, so an interior newline in
    a model-authored ``statement`` survives into the ledger. Every value here
    sits mid-line behind a bullet or an indent, and column 0 is where ``#`` and
    ``-`` acquire their meaning -- a value that cannot reach column 0 cannot
    forge a heading or a section. That is the whole threat, and it is the same
    reasoning as ``setup_analysis/report/documents.py``'s ``_inline``: nothing
    further is escaped, because a deck analysis turns on ``[5:0]`` and
    ``WDATA[7]`` and entity-encoding them would hide the content to defend
    against a rendering that never happens.
    """

    folded = text.replace("\r\n", " ").replace("\n", " ").replace("\r", " ")
    folded = folded.replace("\u2028", " ").replace("\u2029", " ")
    return " ".join(folded.split())
