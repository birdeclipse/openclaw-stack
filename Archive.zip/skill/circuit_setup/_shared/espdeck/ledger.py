"""Trusted Design Fact Ledger for the ``circuit-setup-deck`` skill.

One SQLite store per run at ``<workdir>/work/<run>/facts.sqlite3``. The legacy
``scratch_work_item_dir(session_id, work_item_id)`` seam under the Workspace
State Root is replaced by that convention; nothing else about the store changed.
Only this package writes it: the model reaches it through the ``fact_*`` and
``compile_deck`` tools, and agent permissions deny editing ``work/**``.

A caller may name that root explicitly instead. :func:`run_dir` takes an
optional ``dir`` relative to the workdir, and ``<workdir>/<dir>`` is then the
root verbatim -- the ``<run>`` segment is NOT appended. ``work/<run>`` stays the
default when no ``dir`` is given, and every segment of a supplied one is
validated as one safe path segment confined under the workdir, so a run root is
a choice and never an escape.

Append-and-retract: a retracted row is kept with its reason so a correction
leaves an auditable trail. ``snapshot()`` exposes live rows only.

Recording is unbounded. ``log`` refuses malformed input and nothing else -- no
row-count ceiling, per kind or in total. Bounding a row count is the job of
whatever renders those rows into a prompt or an observation, because only the
renderer can truncate and report the truncation; see the note above
``MAX_FIELD_CHARS`` in ``facts.py``.
"""

from __future__ import annotations

import json
import re
import sqlite3
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from pathlib import Path
from types import MappingProxyType
from typing import Final

from .canonical import canonical_json_bytes
from .facts import (
    FactRecord,
    FactSnapshot,
    normalize_fact,
    snapshot_digest,
)

LEDGER_FILENAME: Final[str] = "facts.sqlite3"
SCHEMA_VERSION: Final[str] = "1"
_DEFAULT_RUN: Final[str] = "default"
_WORK_DIRNAME: Final[str] = "work"
_MAX_REASON_CHARS: Final[int] = 512

#: Segments one supplied ``dir`` may carry. A run root is a place to put a run,
#: not a tree to walk; the bound is here for the same reason every other
#: model-supplied value has one.
_MAX_DIR_SEGMENTS: Final[int] = 8

#: One safe path segment: no separators, no ``..``, no leading dot. It validates
#: a run id and every segment of a supplied ``dir``, because they are the same
#: question asked about the same kind of value.
_SEGMENT_RE: Final[re.Pattern[str]] = re.compile(r"[A-Za-z0-9][A-Za-z0-9._-]{0,63}")

# ``origin`` is plain TEXT with NO CHECK constraint on purpose: the reserved
# ``observed`` provenance class (live ESP toolchain facts) must store without a
# schema migration when the future integration ADR lands.
_SCHEMA: Final[tuple[str, ...]] = (
    """
    CREATE TABLE IF NOT EXISTS facts (
        fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
        kind TEXT NOT NULL,
        origin TEXT NOT NULL,
        fields_json TEXT NOT NULL,
        evidence TEXT NOT NULL,
        retracted INTEGER NOT NULL DEFAULT 0,
        retract_reason TEXT NOT NULL DEFAULT ''
    )
    """,
    """
    CREATE TABLE IF NOT EXISTS meta (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    )
    """,
)


class FactLedgerSchemaError(RuntimeError):
    """The on-disk ledger schema version is not one this build understands."""


@dataclass(frozen=True, slots=True)
class FactDraft:
    """One row of a batch :meth:`FactLedger.log_many` call, before validation."""

    fields: Mapping[str, object]
    evidence: str
    origin: str = "parsed"


@dataclass(frozen=True, slots=True)
class FactLogResult:
    """Bounded ledger outcome. Mirrors ``DocumentLoopToolResult`` discipline."""

    is_error: bool
    message: str
    fact_id: int | None = None
    records: tuple[FactRecord, ...] = field(default=())
    #: Which batch row refused, when one did. The ledger does not know what the
    #: wire called the array, so the caller spells ``facts[3]`` / ``rows[3]``.
    rejected_index: int | None = None


def run_dir(workdir: Path, run: str, override: str | None = None) -> Path:
    """Return this run's whole state and publish root.

    ``<workdir>/<override>`` when ``override`` names one, verbatim -- the run id
    is NOT appended, because the caller has named the root it wants. Otherwise
    ``<workdir>/work/<run>``, the default convention.

    Segment validation lives here -- one implementation, because this path is
    the only boundary that keeps one run's Design Facts out of another's, and
    keeps a model-supplied run id or ``dir`` from escaping the workdir. Every
    CLI re-checks at its argument seam so a bad value reads as a bounded refusal
    rather than an exception: two checks, two reasons, neither redundant.

    An empty, absent or whitespace-only ``override`` means "not given" and takes
    the default: the tool wrappers send an omitted string argument as ``""``.
    """

    base = Path(workdir)
    declared = (override or "").strip()
    if declared:
        return _confined_root(base, declared)
    segment = (run or "").strip() or _DEFAULT_RUN
    if not _SEGMENT_RE.fullmatch(segment):
        raise ValueError(
            f"run id {segment!r} must match {_SEGMENT_RE.pattern} (one safe path segment)"
        )
    return base / _WORK_DIRNAME / segment


def _confined_root(workdir: Path, declared: str) -> Path:
    """Resolve a supplied ``dir`` under ``workdir``, or say why it cannot be.

    Two checks, because they answer different questions: every segment must be
    a safe segment, which is what makes traversal unrepresentable; and the
    result must still resolve inside the workdir, which is what a symlink in an
    otherwise blameless path can break.
    """

    segments = [part for part in declared.replace("\\", "/").split("/") if part]
    if declared.startswith("/") or Path(declared).is_absolute() or not segments:
        raise ValueError(f"dir {declared!r} must be a relative path under the workdir")
    if len(segments) > _MAX_DIR_SEGMENTS:
        raise ValueError(
            f"dir {declared!r} carries {len(segments)} segments; "
            f"a run root takes at most {_MAX_DIR_SEGMENTS}"
        )
    for part in segments:
        if not _SEGMENT_RE.fullmatch(part):
            raise ValueError(
                f"dir segment {part!r} must match {_SEGMENT_RE.pattern} "
                "(one safe path segment: letters, digits, dot, dash and underscore, "
                "starting with a letter or digit)"
            )
    root = workdir.joinpath(*segments)
    anchor = workdir.resolve()
    if anchor not in root.resolve().parents:
        raise ValueError(f"dir {declared!r} resolves outside the workdir")
    return root


def fact_ledger_path(root: Path) -> Path:
    """Return ``<run root>/facts.sqlite3``."""

    return Path(root) / LEDGER_FILENAME


def _record_from_row(row: sqlite3.Row) -> FactRecord:
    fields = json.loads(row["fields_json"])
    return FactRecord(
        fact_id=int(row["fact_id"]),
        kind=str(row["kind"]),
        origin=str(row["origin"]),
        fields=MappingProxyType(dict(fields)),
        evidence=str(row["evidence"]),
        retracted=bool(row["retracted"]),
        retract_reason=str(row["retract_reason"]),
    )


class FactLedger:
    """Append-and-retract Design Fact store. Trusted code is the only writer."""

    def __init__(
        self,
        workdir: Path,
        run: str,
        *,
        session_id: str = "",
        root: Path | None = None,
    ) -> None:
        self._workdir = Path(workdir)
        self._run = (run or "").strip() or _DEFAULT_RUN
        self._session_id = session_id.strip() or self._run
        # The caller resolves the root at its argument seam -- that is where a
        # bad ``dir`` becomes a refusal rather than an exception -- and hands it
        # over, so the two can never disagree about where this run lives.
        self._root = Path(root) if root is not None else run_dir(self._workdir, self._run)
        self._path = fact_ledger_path(self._root)
        self._path.parent.mkdir(parents=True, exist_ok=True)
        self._connection = sqlite3.connect(self._path, check_same_thread=False)
        self._connection.row_factory = sqlite3.Row
        self._connection.execute("PRAGMA journal_mode=WAL")
        self._connection.execute("PRAGMA synchronous=NORMAL")
        for statement in _SCHEMA:
            self._connection.execute(statement)
        self._enforce_schema_version()
        self._connection.commit()

    @property
    def path(self) -> Path:
        return self._path

    @property
    def root(self) -> Path:
        """This run's state and publish root; the ledger file's own parent."""

        return self._root

    @property
    def workdir(self) -> Path:
        return self._workdir

    @property
    def run(self) -> str:
        return self._run

    @property
    def session_id(self) -> str:
        """The opencode session this run belongs to; defaults to the run id."""

        return self._session_id

    def _enforce_schema_version(self) -> None:
        row = self._connection.execute(
            "SELECT value FROM meta WHERE key = 'schema_version'"
        ).fetchone()
        if row is None:
            self._connection.execute(
                "INSERT INTO meta (key, value) VALUES ('schema_version', ?)",
                (SCHEMA_VERSION,),
            )
            return
        found = str(row["value"])
        if found != SCHEMA_VERSION:
            raise FactLedgerSchemaError(
                f"fact ledger schema version {found} is not supported (expected {SCHEMA_VERSION})"
            )

    def log_many(
        self,
        kind: str,
        drafts: Sequence[FactDraft],
        *,
        extra_optional_fields: frozenset[str] = frozenset(),
    ) -> FactLogResult:
        """Append every draft, or nothing at all. Never raises.

        All-or-nothing by construction: EVERY draft is normalized before the
        first INSERT, so a batch whose fourth row is malformed leaves the store
        exactly as it was, and ``rejected_index`` names that row.

        A batch is a **call-count** economy and nothing else. Each draft is
        still its own ledger row with its own ``fact_id``, its own origin and
        its own evidence, so every fact stays individually citable and
        retractable; the rows go in as one transaction, so the ids are
        contiguous and ascending in draft order.
        """

        if not drafts:
            return FactLogResult(is_error=True, message="no facts to log")
        prepared: list[tuple[dict[str, str], str, str]] = []
        for index, draft in enumerate(drafts):
            normalized = normalize_fact(
                kind,
                draft.fields,
                draft.evidence,
                draft.origin,
                extra_optional_fields=extra_optional_fields,
            )
            if isinstance(normalized, str):
                return FactLogResult(is_error=True, message=normalized, rejected_index=index)
            clean_fields, clean_origin = normalized
            prepared.append((clean_fields, clean_origin, draft.evidence.strip()))
        # No count check beyond the caller's own batch bound. Row-count caps were
        # deleted with ``PER_KIND_CAPS`` / ``MAX_LIVE_FACTS``: recording is
        # unbounded and the render seams truncate-and-report instead (see
        # ``facts.py`` above ``MAX_FIELD_CHARS`` for the rationale and the list
        # of bounds that replaced them). The old ``cap = PER_KIND_CAPS[kind]``
        # was also an unguarded ``KeyError`` for an unknown kind, so a new fact
        # kind no longer has to register in a cap table to be loggable.

        fact_ids: list[int] = []
        for clean_fields, clean_origin, clean_evidence in prepared:
            cursor = self._connection.execute(
                "INSERT INTO facts (kind, origin, fields_json, evidence) VALUES (?, ?, ?, ?)",
                (
                    kind,
                    clean_origin,
                    canonical_json_bytes(clean_fields).decode("utf-8"),
                    clean_evidence,
                ),
            )
            fact_ids.append(int(cursor.lastrowid or 0))
        self._connection.commit()
        placeholders = ", ".join("?" for _ in fact_ids)
        rows = self._connection.execute(
            f"SELECT * FROM facts WHERE fact_id IN ({placeholders}) ORDER BY fact_id",
            tuple(fact_ids),
        ).fetchall()
        return FactLogResult(
            is_error=False,
            message="ok",
            fact_id=fact_ids[0],
            records=tuple(_record_from_row(row) for row in rows),
        )

    def log(
        self,
        kind: str,
        fields: Mapping[str, object],
        evidence: str,
        *,
        origin: str = "parsed",
        extra_optional_fields: frozenset[str] = frozenset(),
    ) -> FactLogResult:
        """Append one fact -- the one-row case of :meth:`log_many`."""

        return self.log_many(
            kind,
            (FactDraft(fields=fields, evidence=evidence, origin=origin),),
            extra_optional_fields=extra_optional_fields,
        )

    def retract(self, fact_id: int, reason: str) -> FactLogResult:
        """Mark one fact retracted, keeping the row and the reason."""

        try:
            target = int(fact_id)
        except (TypeError, ValueError):
            return FactLogResult(is_error=True, message="fact_id must be an integer")
        row = self._connection.execute(
            "SELECT * FROM facts WHERE fact_id = ?", (target,)
        ).fetchone()
        if row is None:
            return FactLogResult(is_error=True, message=f"no fact with id {target}")
        if bool(row["retracted"]):
            return FactLogResult(is_error=True, message=f"fact {target} is already retracted")
        clean_reason = (reason or "").strip()[:_MAX_REASON_CHARS]
        self._connection.execute(
            "UPDATE facts SET retracted = 1, retract_reason = ? WHERE fact_id = ?",
            (clean_reason, target),
        )
        self._connection.commit()
        updated = self._connection.execute(
            "SELECT * FROM facts WHERE fact_id = ?", (target,)
        ).fetchone()
        return FactLogResult(
            is_error=False,
            message="ok",
            fact_id=target,
            records=(_record_from_row(updated),),
        )

    def list(self, kind: str | None = None) -> tuple[FactRecord, ...]:
        """Every row including retracted ones, ascending fact id."""

        if kind is None:
            rows = self._connection.execute("SELECT * FROM facts ORDER BY fact_id").fetchall()
        else:
            rows = self._connection.execute(
                "SELECT * FROM facts WHERE kind = ? ORDER BY fact_id", (kind,)
            ).fetchall()
        return tuple(_record_from_row(row) for row in rows)

    def snapshot(self) -> FactSnapshot:
        """Live rows only, ascending fact id, with the byte-stability digest."""

        rows = self._connection.execute(
            "SELECT * FROM facts WHERE retracted = 0 ORDER BY fact_id"
        ).fetchall()
        records = tuple(_record_from_row(row) for row in rows)
        return FactSnapshot(facts=records, digest=snapshot_digest(records))

    def close(self) -> None:
        """Idempotent close."""

        try:
            self._connection.close()
        except sqlite3.Error:
            pass


__all__ = [
    "LEDGER_FILENAME",
    "SCHEMA_VERSION",
    "FactDraft",
    "FactLedger",
    "FactLedgerSchemaError",
    "FactLogResult",
    "fact_ledger_path",
    "run_dir",
]
