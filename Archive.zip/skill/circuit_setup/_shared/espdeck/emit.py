"""Canonical ESP Tcl emission for the ``setup.deck`` compiler (ADR 0038).

Pure text helpers. Nothing here reads the ledger, touches disk, or decides
policy: given values it renders exact bytes, so the compiler above it stays a
straight-line mapping from a fact snapshot to a deck.

Command names and options are checked against the pinned ESP command catalog.
A catalog miss is advisory: the line is still emitted and the compiler raises a
diagnostic, because the catalog is evidence about ESP, not authority over it.
"""

from __future__ import annotations

import json
import re
from collections.abc import Iterable, Sequence
from functools import lru_cache
from pathlib import Path
from typing import Any, Final

#: The pinned catalog is one reviewed asset shared by both deterministic cores:
#: ``espdeck`` reads it for emit legality and ``espanalysis`` loads it
#: fail-closed for command classification. It therefore lives in
#: ``_shared/data/`` -- a sibling of both packages -- rather than inside either
#: one, so there is exactly one copy to review and one provenance sidecar. The
#: JSON and its ``.provenance.json`` are byte-identical copies of the reviewed
#: legacy ``setup_analysis/data/`` asset.
_CATALOG_RESOURCE: Final[str] = "esp_command_catalog_v1.json"
_CATALOG_PATH: Final[Path] = Path(__file__).resolve().parent.parent / "data" / _CATALOG_RESOURCE

#: Bare identifiers, paths, and simple numbers need no quoting.
_BARE: Final[re.Pattern[str]] = re.compile(r"^[A-Za-z0-9_./:+=\-\[\]]+$")


def quote_tcl(value: str) -> str:
    """Brace-quote a value unless it is a bare token that cannot re-tokenize."""

    if value == "":
        return "{}"
    if _BARE.match(value) is not None:
        return value
    if "{" in value or "}" in value:
        escaped = value.replace("\\", "\\\\").replace('"', '\\"')
        return f'"{escaped}"'
    return "{" + value + "}"


def emit_command(
    name: str,
    *,
    flags: Sequence[str] = (),
    options: Sequence[tuple[str, str]] = (),
    positionals: Sequence[str] = (),
) -> str:
    """Render one command: flags, then options, then positionals, single-spaced."""

    parts: list[str] = [name]
    parts.extend(flags)
    for option, value in options:
        parts.append(option)
        parts.append(quote_tcl(value))
    parts.extend(quote_tcl(item) for item in positionals)
    return " ".join(parts)


def comment(text: str) -> str:
    """Render a ``#`` comment line."""

    return f"# {text}" if text else "#"


def banner(text: str) -> str:
    """Render the house ``puts "INFO: ..."`` progress line."""

    return f'puts "INFO: {text}"'


def option_names(options: Iterable[tuple[str, str]]) -> tuple[str, ...]:
    """Project option names for a catalog legality check."""

    return tuple(option for option, _ in options)


@lru_cache(maxsize=1)
def _catalog_payload() -> dict[str, Any]:
    raw = _CATALOG_PATH.read_bytes()
    payload = json.loads(raw.decode("utf-8"))
    return payload if isinstance(payload, dict) else {}


@lru_cache(maxsize=1)
def _command_options() -> dict[str, frozenset[str]]:
    """Map command name to its known option/flag names from ``commands``."""

    commands = _catalog_payload().get("commands")
    if not isinstance(commands, dict):
        return {}
    table: dict[str, frozenset[str]] = {}
    for command, spec in commands.items():
        if not isinstance(command, str) or not isinstance(spec, dict):
            continue
        entries = spec.get("options")
        if not isinstance(entries, list):
            continue
        names: set[str] = set()
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            option_name = entry.get("name")
            if isinstance(option_name, str) and option_name.startswith("-"):
                names.add(option_name)
        table[command] = frozenset(names)
    return table


@lru_cache(maxsize=1)
def _known_commands() -> frozenset[str]:
    """Every command name the catalog knows, from ``commands`` and ``command_groups``."""

    payload = _catalog_payload()
    names: set[str] = set()
    for section in ("commands", "command_groups"):
        entry = payload.get(section)
        if isinstance(entry, dict):
            names.update(key for key in entry if isinstance(key, str))
    return frozenset(names)


class CommandCatalog:
    """Read-only view of the pinned ESP command catalog."""

    def is_known_command(self, name: str) -> bool:
        known = _known_commands()
        # An empty or unreadable catalog must not turn every line into a
        # diagnostic, so treat "no catalog" as "no opinion".
        return not known or name in known

    def unknown_options(self, name: str, options: Sequence[str]) -> tuple[str, ...]:
        table = _command_options()
        known = table.get(name)
        if known is None or not known:
            return ()
        return tuple(option for option in options if option not in known)


CATALOG: Final[CommandCatalog] = CommandCatalog()


__all__ = [
    "CATALOG",
    "CommandCatalog",
    "banner",
    "comment",
    "emit_command",
    "option_names",
    "quote_tcl",
]
