#!/usr/bin/env python3
"""JSON-on-stdin entry point for the ``espdeck`` deterministic core.

    python3 espdeck/cli.py <verb>   <<< '{"run": "ab12cd34", "workdir": "/repo"}'

Verbs: ``log`` | ``list`` | ``retract`` | ``snapshot`` | ``report`` | ``compile``.

``log`` takes an ARRAY of facts -- ``facts: [{fields, evidence, origin}]`` under
one ``kind`` -- and is all-or-nothing: every row is validated before any row is
stored, so a batch with one bad row stores nothing and the refusal names the
offending index. Each row is still its own ledger fact with its own id, origin
and evidence; batching saves tool calls, never ledger rows.

One JSON object on stdout, mirroring the legacy ``ConfinedToolResult``::

    {"ok": bool, "message": str, "data": object|null, "refusal": str|null}

**Exit 0 for domain refusals.** A rejected fact, an absent ledger, or a compile
that cannot name a top design is an observation the model must read and act on,
never a tool crash (ADR 0038, MIGRATION.md section 9.4). A non-zero exit means a
harness defect -- unknown verb, unparseable stdin, an unreadable packaged asset
-- and the TS wrapper surfaces that as a tool error.

The whole run lives in one directory, the run root: ``facts.sqlite3`` beside
the compiled deck files and ``diagnostics.json``. Every verb takes an optional
``dir`` naming that root relative to the workdir; when ``dir`` is omitted the
root falls back to ``<workdir>/work/<run>``, with the run id NOT appended to a
supplied ``dir``. The model's own ``<macro>_constraints.tcl``,
``<macro>_setup_report.md`` and ``STATUS.md`` are written by the built-in
``write`` tool -- this CLI never emits them; the constraints file must sit in
the run root because the entry deck sources it by bare filename.

Every result is bounded: ``compile`` and ``report`` return paths and counts, not
file content. The written files are on disk for the model to read.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Final

_PACKAGE_PARENT: Final[str] = str(Path(__file__).resolve().parent.parent)
if _PACKAGE_PARENT not in sys.path:
    # This module is spawned by path (`python3 .../espdeck/cli.py`), so it has no
    # package context of its own; absolute imports of its own package are the
    # one form that works both as a script and under `python3 -m espdeck.cli`.
    sys.path.insert(0, _PACKAGE_PARENT)

from espdeck.canonical import canonical_json_bytes  # noqa: E402
from espdeck.compiler import (  # noqa: E402
    COMPILER_VERSION,
    SKELETON_VERSION,
    CompileResult,
    compile_deck,
    constraints_file_name,
    report_file_name,
)
from espdeck.facts import (  # noqa: E402
    FIELD_SPECS,
    blocking_minimum_gaps,
    facts_of_kind,
    minimum_gaps,
)
from espdeck.ledger import (  # noqa: E402
    FactDraft,
    FactLedger,
    FactLedgerSchemaError,
    FactLogResult,
    fact_ledger_path,
    run_dir,
)
from espdeck.report import (  # noqa: E402
    FACT_REPORT_NAME,
    publish_fact_report,
)

VERBS: Final[tuple[str, ...]] = (
    "log",
    "list",
    "retract",
    "snapshot",
    "report",
    "compile",
)

#: Domain refusal codes. Closed set: the wrapper and the SKILL.md workflow read
#: these, so a new one is a contract change rather than a message tweak.
REFUSALS: Final[tuple[str, ...]] = (
    "invalid_args",  # a malformed or out-of-range argument value
    "rejected_fact",  # FIELD_SPECS validation refused the fact
    "no_ledger",  # a read verb ran before any fact was logged
    "no_fact",  # retract named a fact the ledger does not hold
    "ledger_schema",  # the on-disk schema version is not this build's
    "nothing_compiled",  # no verilog or spice fact names a top design
    "publish_failed",  # the run root could not be written
)

DIAGNOSTICS_NAME: Final[str] = "diagnostics.json"
DIAGNOSTICS_SCHEMA: Final[str] = "espdeck.diagnostics.v1"

#: Characters one ``list`` message carries. Ported from the legacy
#: ``_FACT_LIST_MAX_CHARS``: the producer is the model's observation ceiling,
#: and a capped read yields a prefix AND says so.
_FACT_LIST_MAX_CHARS: Final[int] = 8192
_MESSAGE_MAX_CHARS: Final[int] = 8192

#: sqlite binds a Python ``int`` as a signed 64-bit INTEGER and raises
#: ``OverflowError`` outside that range -- before any row is read, so the
#: ledger's own "no fact with id" result would never be reached. A 32-digit
#: fact_id is a schema-valid tool call, so it has to read as a bounded refusal.
_MAX_SQLITE_INTEGER: Final[int] = 2**63 - 1

#: Rows one ``log`` call carries. The ledger itself is unbounded (see
#: ``espdeck.ledger``); this is the *transport's* bound, which is what keeps one
#: malformed call from being an unbounded validation loop.
_MAX_LOGGED_FACTS: Final[int] = 64


@dataclass(frozen=True, slots=True)
class Result:
    """The wire result. ``refusal`` is the authoritative classification."""

    ok: bool
    message: str
    data: dict[str, Any] | None = None
    refusal: str | None = None

    def to_json(self) -> str:
        payload = {
            "ok": self.ok,
            "message": self.message[:_MESSAGE_MAX_CHARS],
            "data": self.data,
            "refusal": self.refusal,
        }
        return json.dumps(payload, ensure_ascii=False)


def _refuse(code: str, message: str) -> Result:
    return Result(ok=False, message=message, refusal=code)


class HarnessDefect(Exception):
    """Malformed invocation. Exits non-zero; never a domain observation."""


# ---- argument seam ----------------------------------------------------


def _workdir(arguments: dict[str, Any]) -> Path:
    raw = str(arguments.get("workdir", "") or "").strip()
    return Path(raw).expanduser() if raw else Path.cwd()


def _relative(path: Path, base: Path) -> str:
    """Name ``path`` relative to the run's workdir when it sits inside it.

    Receipts name ``work/<run>/...`` rather than an absolute path:
    that is the spelling the model needs for its own ``write`` calls, and the
    spelling an agent ``edit`` permission pattern is written against.
    """

    try:
        return str(path.relative_to(base))
    except ValueError:
        return str(path)


def _as_int(value: object) -> int | None:
    text = str(value or "").strip()
    if not text:
        return None
    try:
        parsed = int(text)
    except ValueError:
        return None
    if not -_MAX_SQLITE_INTEGER - 1 <= parsed <= _MAX_SQLITE_INTEGER:
        return None
    return parsed


def _open_ledger(arguments: dict[str, Any], *, create: bool) -> FactLedger | Result:
    """Open the run's ledger, or return the refusal that explains why not."""

    workdir = _workdir(arguments)
    run = str(arguments.get("run", "") or "")
    session = str(arguments.get("session", "") or "")
    if not workdir.is_dir():
        return _refuse("invalid_args", f"workdir {workdir} is not a directory")
    try:
        # ``run_dir`` owns run-id AND ``dir`` segment validation -- one
        # implementation, shared with espcycle and espanalysis, because the three
        # CLIs write one ledger and must never disagree about where it is.
        root = run_dir(workdir, run, str(arguments.get("dir", "") or ""))
    except ValueError as error:
        return _refuse("invalid_args", str(error))
    path = fact_ledger_path(root)
    if not create and not path.is_file():
        return _refuse(
            "no_ledger",
            f"no fact ledger at {path}; log a fact before reading or compiling",
        )
    try:
        return FactLedger(workdir, run, session_id=session, root=root)
    except FactLedgerSchemaError as error:
        return _refuse("ledger_schema", str(error))
    except OSError as error:
        return _refuse("invalid_args", f"could not open {path}: {type(error).__name__}")


# ---- verbs ------------------------------------------------------------


def _verb_log(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    """Append one batch of ``kind`` facts, or none of them.

    All-or-nothing, and the refusal names the row by index: a twelve-fact batch
    with one bad row is one fix away rather than a bisect. Every row is still
    its own ledger fact with its own id, origin and evidence, so a batched call
    and twelve single calls produce the identical ledger.
    """

    kind = str(arguments.get("kind", "") or "").strip()
    if kind not in FIELD_SPECS:
        valid = ", ".join(sorted(FIELD_SPECS))
        return _refuse("invalid_args", f"unknown fact kind {kind!r}; valid kinds are {valid}")
    drafts = _drafts(arguments)
    if isinstance(drafts, Result):
        return drafts
    result = ledger.log_many(kind, drafts)
    if result.is_error:
        return _refuse("rejected_fact", _indexed(result))
    fact_ids = [record.fact_id for record in result.records]
    live = len(facts_of_kind(ledger.snapshot(), kind))
    return Result(
        ok=True,
        message=(
            f"logged {len(fact_ids)} {kind} fact(s) ({live} live {kind} fact(s)); "
            f"fact ids: {', '.join(str(item) for item in fact_ids)}"
        ),
        data={"fact_ids": fact_ids, "kind": kind, "count": len(fact_ids)},
    )


def _drafts(arguments: dict[str, Any]) -> tuple[FactDraft, ...] | Result:
    """Read the ``facts`` array, or return the refusal that explains why not."""

    raw = arguments.get("facts")
    if not isinstance(raw, list) or not raw:
        return _refuse(
            "invalid_args",
            "facts must be a non-empty array of {fields, evidence, origin} objects",
        )
    if len(raw) > _MAX_LOGGED_FACTS:
        return _refuse(
            "invalid_args",
            f"facts carries {len(raw)} rows; one log call takes at most {_MAX_LOGGED_FACTS}",
        )
    drafts: list[FactDraft] = []
    for index, entry in enumerate(raw):
        if not isinstance(entry, dict):
            return _refuse(
                "invalid_args",
                f"facts[{index}]: each row must be an object with fields, evidence and origin",
            )
        fields = entry.get("fields", {})
        if not isinstance(fields, dict):
            return _refuse(
                "invalid_args",
                f"facts[{index}]: fields must be an object of name to string",
            )
        drafts.append(
            FactDraft(
                fields=fields,
                evidence=str(entry.get("evidence", "") or ""),
                origin=str(entry.get("origin", "") or "parsed"),
            )
        )
    return tuple(drafts)


def _indexed(result: FactLogResult) -> str:
    """Name the refused row by its argument path, so the model fixes that row."""

    if result.rejected_index is None:
        return result.message
    return f"facts[{result.rejected_index}]: {result.message}"


def _verb_list(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    kind_filter = str(arguments.get("kind_filter", "") or "").strip() or None
    records = ledger.list(kind_filter)
    if not records:
        return Result(ok=True, message="ledger is empty", data={"count": 0, "shown": 0})
    lines = [
        f"{item.fact_id} {item.kind} [{item.origin}]"
        + (" RETRACTED" if item.retracted else "")
        + ": "
        + ", ".join(f"{key}={value}" for key, value in item.fields.items() if value)
        for item in records
    ]
    body = "\n".join(lines)
    shown = len(lines)
    if len(body) > _FACT_LIST_MAX_CHARS:
        body = body[:_FACT_LIST_MAX_CHARS]
        shown = body.count("\n") + 1 if body else 0
        body += f"\n[truncated: showing {shown} of {len(records)} fact(s)]"
    return Result(ok=True, message=body, data={"count": len(records), "shown": shown})


def _verb_retract(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    fact_id = _as_int(arguments.get("fact_id"))
    if fact_id is None:
        return _refuse("invalid_args", "retract needs a decimal fact_id")
    reason = str(arguments.get("reason", "") or "")
    if not reason.strip():
        return _refuse("invalid_args", "retract needs a reason")
    result = ledger.retract(fact_id, reason)
    if result.is_error:
        return _refuse("no_fact", result.message)
    return Result(
        ok=True,
        message=f"retracted fact {fact_id}",
        data={"fact_id": fact_id},
    )


def _verb_snapshot(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    del arguments
    snapshot = ledger.snapshot()
    counts: dict[str, int] = {}
    for record in snapshot.facts:
        counts[record.kind] = counts.get(record.kind, 0) + 1
    gaps = minimum_gaps(snapshot)
    blocking = blocking_minimum_gaps(snapshot)
    lines = [
        f"snapshot digest {snapshot.digest}",
        f"live facts: {len(snapshot.facts)}",
        "by kind: " + (", ".join(f"{kind}={counts[kind]}" for kind in sorted(counts)) or "(none)"),
    ]
    if gaps:
        lines.append("missing minimum fact kinds: " + ", ".join(gaps))
    return Result(
        ok=True,
        message="\n".join(lines),
        data={
            "snapshot_digest": snapshot.digest,
            "live_facts": len(snapshot.facts),
            "kinds": counts,
            "minimum_gaps": list(gaps),
            "blocking_minimum_gaps": list(blocking),
        },
    )


def _verb_report(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    publish_root = ledger.root
    if not publish_fact_report(publish_root, ledger):
        return _refuse("publish_failed", f"could not publish {FACT_REPORT_NAME} to {publish_root}")
    records = ledger.list()
    live = sum(1 for record in records if not record.retracted)
    path = publish_root / FACT_REPORT_NAME
    shown = _relative(path, ledger.workdir)
    return Result(
        ok=True,
        message=(
            f"published {FACT_REPORT_NAME} ({shown}): "
            f"{live} live fact(s), {len(records) - live} retracted"
        ),
        data={
            "path": shown,
            "bytes": path.stat().st_size,
            "live_facts": live,
            "retracted_facts": len(records) - live,
        },
    )


def _diagnostics_lines(result: CompileResult) -> list[str]:
    return [
        f"[{item.severity}] {item.code}: {item.message}"
        + (f" (facts {', '.join(str(i) for i in item.fact_ids)})" if item.fact_ids else "")
        for item in result.diagnostics
    ]


def diagnostics_payload(
    result: CompileResult,
    *,
    snapshot_digest: str,
    minimum_gaps_found: tuple[str, ...],
    blocking_gaps_found: tuple[str, ...],
) -> dict[str, Any]:
    """The published ``diagnostics.json`` body. Byte-stable for a snapshot."""

    return {
        "schema": DIAGNOSTICS_SCHEMA,
        "compiler_version": COMPILER_VERSION,
        "skeleton_version": SKELETON_VERSION,
        "snapshot_digest": snapshot_digest,
        "macro": result.macro,
        "files": sorted(result.files),
        "manifest": dict(result.manifest),
        "minimum_gaps": list(minimum_gaps_found),
        "blocking_minimum_gaps": list(blocking_gaps_found),
        "diagnostics": [
            {
                "severity": item.severity,
                "code": item.code,
                "message": item.message,
                "fact_ids": list(item.fact_ids),
            }
            for item in result.diagnostics
        ],
    }


def _verb_compile(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    del arguments
    snapshot = ledger.snapshot()
    gaps = minimum_gaps(snapshot)
    blocking = blocking_minimum_gaps(snapshot)
    publish_root = ledger.root

    probe = compile_deck(snapshot)
    if probe.macro is None:
        return Result(
            ok=False,
            message=(
                "nothing was compiled: no verilog or spice fact names a top design.\n"
                + "\n".join(_diagnostics_lines(probe))
            ),
            data={
                "compiled": False,
                "minimum_gaps": list(gaps),
                "blocking_minimum_gaps": list(blocking),
                "diagnostics": diagnostics_payload(
                    probe,
                    snapshot_digest=snapshot.digest,
                    minimum_gaps_found=gaps,
                    blocking_gaps_found=blocking,
                )["diagnostics"],
            },
            refusal="nothing_compiled",
        )

    macro = probe.macro
    constraints_present = (publish_root / constraints_file_name(macro)).is_file()
    result = compile_deck(snapshot, constraints_file_present=constraints_present)

    payload = diagnostics_payload(
        result,
        snapshot_digest=snapshot.digest,
        minimum_gaps_found=gaps,
        blocking_gaps_found=blocking,
    )
    try:
        publish_root.mkdir(parents=True, exist_ok=True)
        for filename, content in result.files.items():
            _ = (publish_root / filename).write_bytes(content)
        _ = (publish_root / DIAGNOSTICS_NAME).write_bytes(canonical_json_bytes(payload) + b"\n")
    except OSError as error:
        return _refuse(
            "publish_failed",
            f"could not write the deck bundle to {publish_root}: {type(error).__name__}",
        )

    shown_root = _relative(publish_root, ledger.workdir)
    lines = [
        f"compiled {macro} into {shown_root}/",
        "files: " + ", ".join(sorted(result.files)) + f", {DIAGNOSTICS_NAME}",
    ]
    if constraints_present:
        lines.append(f"the entry deck sources {constraints_file_name(macro)} (yours)")
    else:
        lines.append(
            f"write {shown_root}/{constraints_file_name(macro)} to add cycle counts, "
            "constraints, or device and net overrides; the next compile will source it"
        )
    if gaps:
        lines.append("minimum fact kinds still missing: " + ", ".join(gaps))
    lines.append(f"report to write: {report_file_name(macro)}")
    diagnostics = _diagnostics_lines(result)
    if diagnostics:
        lines.append("diagnostics:")
        lines.extend(f"  {item}" for item in diagnostics)
    return Result(
        ok=True,
        message="\n".join(lines),
        data={
            "compiled": True,
            "macro": macro,
            "run_root": shown_root,
            "files": sorted(result.files),
            "diagnostics_file": DIAGNOSTICS_NAME,
            "snapshot_digest": snapshot.digest,
            "manifest": dict(result.manifest),
            "constraints_file": constraints_file_name(macro),
            "constraints_file_present": constraints_present,
            "report_file": report_file_name(macro),
            "minimum_gaps": list(gaps),
            "blocking_minimum_gaps": list(blocking),
            "diagnostics": payload["diagnostics"],
        },
    )


_HANDLERS: Final[dict[str, Any]] = {
    "log": (_verb_log, True),
    "list": (_verb_list, False),
    "retract": (_verb_retract, False),
    "snapshot": (_verb_snapshot, False),
    "report": (_verb_report, False),
    "compile": (_verb_compile, False),
}


def run(verb: str, arguments: dict[str, Any]) -> Result:
    """Dispatch one verb. Raises :class:`HarnessDefect` for a bad invocation."""

    entry = _HANDLERS.get(verb)
    if entry is None:
        raise HarnessDefect(f"unknown verb {verb!r}; expected one of {', '.join(VERBS)}")
    handler, creates = entry
    opened = _open_ledger(arguments, create=creates)
    if isinstance(opened, Result):
        return opened
    try:
        return handler(opened, arguments)
    finally:
        opened.close()


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print(
            f"usage: cli.py <{'|'.join(VERBS)}>  (JSON arguments on stdin)",
            file=sys.stderr,
        )
        return 2
    raw = sys.stdin.read()
    text = raw.strip()
    if not text:
        arguments: dict[str, Any] = {}
    else:
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as error:
            print(f"stdin is not JSON: {error}", file=sys.stderr)
            return 2
        if not isinstance(parsed, dict):
            print("stdin JSON must be an object", file=sys.stderr)
            return 2
        arguments = parsed
    try:
        result = run(argv[0], arguments)
    except HarnessDefect as error:
        print(Result(ok=False, message=str(error), refusal=None).to_json())
        print(str(error), file=sys.stderr)
        return 2
    print(result.to_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
