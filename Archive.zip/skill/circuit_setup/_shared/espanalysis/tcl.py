"""Deterministic, non-evaluating scanner for the static Tcl subset used by ESP."""

from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Literal

from .models import (
    CoverageRecord,
    DeckDiagnostic,
    ScannedCommand,
    ScannedWord,
    SourceRef,
    SourceSpan,
    word_substitutes,
)

_CONTROL_COMMANDS = frozenset({"proc", "if", "foreach", "while", "for", "eval"})


@dataclass(frozen=True, slots=True)
class TclScanResult:
    """Scanner output plus all physical segments needed to reconstruct input bytes."""

    commands: tuple[ScannedCommand, ...]
    coverage: tuple[CoverageRecord, ...]
    diagnostics: tuple[DeckDiagnostic, ...]
    segments: tuple[SourceSpan, ...]
    command_limit_reached: bool = False

    def reconstruct(self, source_bytes: bytes, /) -> bytes:
        """Reconstruct the exact input from the ordered physical segment spans."""
        return b"".join(source_bytes[span.start_byte : span.end_byte] for span in self.segments)


def scan_tcl(
    source_ref: SourceRef,
    source_bytes: bytes,
    /,
    *,
    max_commands: int = 1_024,
) -> TclScanResult:
    """Scan top-level Tcl commands without evaluating Tcl or altering source bytes.

    Bracket nesting is intentionally a local safety guard: it is not a nested Tcl
    parser and never prevents an otherwise ordinary command flush.
    """
    path = source_ref.relative_path
    commands: list[ScannedCommand] = []
    coverage: list[CoverageRecord] = []
    diagnostics: list[DeckDiagnostic] = []
    segments: list[SourceSpan] = []
    start = 0
    brace_depth = 0
    in_quote = False
    bracket_depth = 0
    comment = False
    limit_reached = False
    index = 0
    # R6 (docs/known-issues.md, 2026-08-23): this loop used to call
    # ``_escaped(source_bytes, index)`` for every byte, and ``_escaped``
    # re-walks the entire backslash run preceding ``index`` -- O(n^2) on a long
    # run, a synchronous multi-minute stall inside async ``consume_tcl`` on a
    # 128 KiB backslash file. ``escaped`` is now a running parity with the same
    # meaning -- whether the byte at ``index`` sits after an odd-length
    # backslash run -- and ``next_escaped`` carries that parity forward one
    # byte at a time.
    #
    # The same review found ``_span`` recounting newlines from byte 0 for
    # every flushed segment -- a second O(n^2). ``line`` is the 1-based line
    # number of the byte at ``index`` (bumped as the loop passes each newline)
    # and ``start_line`` is the line number at ``start``, handed down through
    # ``_flush`` so ``_span`` only ever counts newlines inside the span it is
    # building.
    next_escaped = False
    line = 1
    start_line = 1

    while index < len(source_bytes):
        byte = source_bytes[index]
        escaped = next_escaped
        # Per-byte bookkeeping happens once, before dispatch: every branch
        # below advances ``index`` by exactly one -- this loop never jumps --
        # so both invariants hold on every ``continue`` path. If a future
        # branch ever jumps ``index`` (say, consuming a quoted word inline),
        # the jump lands immediately after a closing quote/brace -- a
        # non-backslash byte -- so the parity restarts at False from that
        # boundary, and ``line`` must advance by a ``count(b"\n", ...)`` over
        # just the jumped slice; never recompute either from byte 0.
        next_escaped = not next_escaped if byte == ord("\\") else False
        if byte == ord("\n"):
            line += 1

        if comment:
            # A backslash-newline continues a *comment* in Tcl, so the comment text
            # runs past it and the next physical line is still comment bytes. Without
            # this check ``# note \<LF>set_constraint x -set 1`` flushed the comment at
            # the continuation newline and then scanned the commented-out line as a
            # real top-level command. Every other newline in this loop already
            # honours continuations (see the ordinary-newline branch below).
            if byte == ord("\n") and not _continues_at_newline(source_bytes, index):
                comment = False
                _flush(
                    start,
                    index + 1,
                    start_line,
                    False,
                    source_ref,
                    source_bytes,
                    commands,
                    coverage,
                    diagnostics,
                    segments,
                    bracket_depth,
                    max_commands,
                )
                if len(commands) >= max_commands and index + 1 < len(source_bytes):
                    limit_reached = True
                    break
                start = index + 1
                start_line = line
                bracket_depth = 0
            index += 1
            continue

        if brace_depth:
            if byte == ord("{") and not escaped:
                brace_depth += 1
            elif byte == ord("}") and not escaped:
                brace_depth -= 1
            index += 1
            continue

        if in_quote:
            if byte == ord('"') and not escaped:
                in_quote = False
            elif byte == ord("[") and not escaped:
                bracket_depth += 1
            elif byte == ord("]") and not escaped and bracket_depth:
                bracket_depth -= 1
            index += 1
            continue

        if byte == ord("#") and _at_command_start(source_bytes, start, index):
            comment = True
            index += 1
            continue
        if byte == ord("{") and not escaped and _at_word_boundary(source_bytes, index):
            brace_depth = 1
            index += 1
            continue
        if byte == ord('"') and not escaped and _at_word_boundary(source_bytes, index):
            in_quote = True
            index += 1
            continue
        if byte == ord("[") and not escaped:
            bracket_depth += 1
        elif byte == ord("]") and not escaped and bracket_depth:
            bracket_depth -= 1

        if byte == ord(";"):
            _flush(
                start,
                index + 1,
                start_line,
                False,
                source_ref,
                source_bytes,
                commands,
                coverage,
                diagnostics,
                segments,
                bracket_depth,
                max_commands,
            )
            if len(commands) >= max_commands and index + 1 < len(source_bytes):
                limit_reached = True
                break
            start = index + 1
            start_line = line
            bracket_depth = 0
        elif byte == ord("\n") and not _continues_at_newline(source_bytes, index):
            _flush(
                start,
                index + 1,
                start_line,
                False,
                source_ref,
                source_bytes,
                commands,
                coverage,
                diagnostics,
                segments,
                bracket_depth,
                max_commands,
            )
            if len(commands) >= max_commands and index + 1 < len(source_bytes):
                limit_reached = True
                break
            start = index + 1
            start_line = line
            bracket_depth = 0
        index += 1

    if limit_reached:
        limit_span = _span(path, start, len(source_bytes), source_bytes, start_line)
        segments.append(limit_span)
        coverage.append(
            CoverageRecord(
                category="BOUNDS-LIMIT-REACHED",
                span=limit_span,
                source_ref=source_ref,
                detail=f"Descriptor bound reached: command_count={max_commands}",
            )
        )
        diagnostics.append(
            _diagnostic(
                "ESP-F3-COMMAND-LIMIT",
                "warning",
                "Top-level command limit reached",
                limit_span,
                source_ref,
                coverage_impact=True,
            )
        )
    elif start < len(source_bytes):
        unsafe = brace_depth > 0 or in_quote
        _flush(
            start,
            len(source_bytes),
            start_line,
            unsafe,
            source_ref,
            source_bytes,
            commands,
            coverage,
            diagnostics,
            segments,
            bracket_depth,
            max_commands,
        )
    elif not segments and source_bytes:
        segments.append(_span(path, 0, len(source_bytes), source_bytes, 1))

    return TclScanResult(
        commands=tuple(commands),
        coverage=tuple(coverage),
        diagnostics=tuple(diagnostics),
        segments=tuple(segments),
        command_limit_reached=limit_reached,
    )


def _flush(
    start: int,
    end: int,
    start_line: int,
    unbalanced: bool,
    source_ref: SourceRef,
    source_bytes: bytes,
    commands: list[ScannedCommand],
    coverage: list[CoverageRecord],
    diagnostics: list[DeckDiagnostic],
    segments: list[SourceSpan],
    bracket_depth: int,
    max_commands: int,
) -> None:
    if end <= start:
        return
    span = _span(source_ref.relative_path, start, end, source_bytes, start_line)
    segments.append(span)
    words = _words(source_ref.relative_path, source_bytes, start, end, start_line)
    if not words or len(commands) >= max_commands:
        return
    anchor_safe = not unbalanced and bracket_depth == 0
    command = ScannedCommand(
        occurrence_id=_occurrence_id(source_ref.relative_path, len(commands)),
        name=words[0].text,
        words=tuple(words),
        span=span,
        anchor_safe=anchor_safe,
    )
    commands.append(command)

    if unbalanced:
        coverage.append(
            CoverageRecord(
                category="TCL-UNBALANCED",
                span=span,
                source_ref=source_ref,
                detail="EOF leaves a brace or quoted word open",
            )
        )
        diagnostics.append(
            _diagnostic(
                "AA-TCL-UNBALANCED",
                "warning",
                "EOF leaves a brace or quoted word open",
                span,
                source_ref,
                coverage_impact=True,
            )
        )
    if bracket_depth:
        coverage.append(
            CoverageRecord(
                category="TCL-BRACKET-GUARD",
                span=span,
                source_ref=source_ref,
                detail="Bracket substitution is open at command flush",
            )
        )
    if command.name in _CONTROL_COMMANDS:
        coverage.append(
            CoverageRecord(
                category="TCL-CONTROL-REGION",
                span=span,
                source_ref=source_ref,
                detail="Execution-dependent Tcl control region",
            )
        )
    if any(word.dynamic for word in command.words):
        coverage.append(
            CoverageRecord(
                category="TCL-DYNAMIC",
                span=span,
                source_ref=source_ref,
                detail="Command contains dynamic Tcl syntax",
            )
        )


def _words(path: str, data: bytes, start: int, end: int, start_line: int) -> list[ScannedWord]:
    words: list[ScannedWord] = []
    index = start
    # R6: word spans used to recount newlines from byte 0 for every word.
    # ``line`` is the line number at ``counted``; both advance together over
    # just the bytes between consecutive word starts (word bodies and skipped
    # separators included), so line accounting per command slice is O(slice)
    # rather than O(words * bytes-before-slice).
    line = start_line
    counted = start
    while index < end:
        while index < end:
            if data[index] in b" \t\r\n;":
                index += 1
                continue
            if _line_continuation(data, index):
                index = _skip_continuation(data, index, end)
                continue
            break
        if index >= end:
            break
        if data[index] == ord("#") and not words and _at_command_start(data, start, index):
            index = _end_of_comment(data, index, end)
            continue
        word_start = index
        line += data.count(b"\n", counted, word_start)
        counted = word_start
        form: Literal["bare", "braced", "quoted"] = "bare"
        if data[index] == ord("{") and _at_word_boundary(data, index):
            form = "braced"
            index, text_start, text_end = _consume_braced(data, index, end)
        elif data[index] == ord('"') and _at_word_boundary(data, index):
            form = "quoted"
            index, text_start, text_end = _consume_quoted(data, index, end)
        else:
            index = _consume_bare(data, index, end)
            text_start, text_end = word_start, index
        raw_text = data[text_start:text_end]
        text = raw_text.decode("utf-8", errors="replace")
        word_span = _span(path, word_start, index, data, line)
        words.append(
            ScannedWord(
                text=text,
                span=word_span,
                form=form,
                dynamic=word_substitutes(form, text),
            )
        )
    return words


def _consume_bare(data: bytes, start: int, end: int) -> int:
    # R6: the old loop asked ``_line_continuation``/``_escaped`` about every
    # byte, and ``_escaped`` re-walks the entire preceding backslash run --
    # O(n^2) on a long run, reached from the EOF flush of a backslash-only
    # file. ``escaped`` is the same parity kept incrementally. Starting it at
    # False is sound because every path into ``_words`` places a bare word's
    # first byte immediately after a non-backslash byte: the start of the
    # command slice (which begins after an unescaped ';' or newline, or at
    # byte 0), a skipped separator, the newline of a line continuation, or the
    # closing '}' / '"' of the previous word -- so the backslash run preceding
    # ``start`` is always empty.
    escaped = False
    index = start
    while index < end:
        byte = data[index]
        if byte == ord("\\"):
            if not escaped and _continuation_follows(data, index):
                break
            escaped = not escaped
        elif byte in b" \t\r\n;" and not escaped:
            break
        else:
            escaped = False
        index += 1
    return index


def _end_of_comment(data: bytes, index: int, end: int) -> int:
    """Return the index just past the comment starting at ``index``.

    A backslash-newline continues a comment in Tcl, so comment text runs to the
    first newline that is *not* a continuation. Stopping at the first newline
    instead let a commented-out command on a continued line be split into words,
    which promoted it to a real command in ``_flush``.
    """
    while index < end:
        newline = data.find(b"\n", index, end)
        if newline < 0:
            break
        if not _continues_at_newline(data, newline):
            return newline + 1
        index = newline + 1
    return end


def _line_continuation(data: bytes, index: int) -> bool:
    """Return whether a line continuation starts at ``index``.

    A continuation is an unescaped ``\\`` immediately before an LF -- reached
    directly or through a CRLF pair -- or a trailing ``\\`` with no line left to
    continue. Tcl folds the sequence away, so for word-splitting it reads as
    whitespace rather than as word bytes. A ``\\\\`` pair is a literal backslash
    and is deliberately excluded, and so is ``\\`` before a lone CR: Tcl's rule is
    backslash-*newline*, and backslash-CR falls under "backslash followed by any
    other character", which keeps ``puts a\\<CR>b`` as a single word.

    The following byte is probed against ``len(data)`` rather than against the
    caller's command end, because a continuation is a property of the byte stream
    and not of the slice being split. Every ``_flush`` in ``scan_tcl`` ends a
    command slice on a ``;``/newline terminator or at ``len(data)``, so the
    trailing-``\\`` branch is reachable only at true EOF -- where the byte is
    folded away rather than kept as word text, which is the recorded contract of
    ``test_frag_noeol_trailing_backslash_emits_no_word`` (corpus evidence
    t4_hostile_core/input/frag_noeol.tcl, whose last byte is ``\\``). Reading the
    command end here would extend that EOF reasoning to any future flush that
    stopped mid-line.
    """
    if data[index] != ord("\\") or _escaped(data, index):
        return False
    return _continuation_follows(data, index)


def _continuation_follows(data: bytes, index: int) -> bool:
    """Return whether the ``\\`` at ``index`` is followed by a newline or EOF.

    The escape-state-free tail of ``_line_continuation``, split out for R6 so
    ``_consume_bare`` can keep the backslash parity incrementally instead of
    re-walking the run through ``_escaped`` for every byte of it.
    """
    following = index + 1
    if following >= len(data):
        return True
    if data[following] == ord("\n"):
        return True
    return data[following] == ord("\r") and data[following + 1 : following + 2] == b"\n"


def _skip_continuation(data: bytes, index: int, end: int) -> int:
    """Return the index just past the continuation starting at ``index``."""
    return index + 1 if index + 1 >= end else index + 2


def _consume_braced(data: bytes, start: int, end: int) -> tuple[int, int, int]:
    depth = 1
    index = start + 1
    text_start = index
    while index < end:
        if data[index] == ord("{") and not _escaped(data, index):
            depth += 1
        elif data[index] == ord("}") and not _escaped(data, index):
            depth -= 1
            if depth == 0:
                return index + 1, text_start, index
        index += 1
    return end, text_start, end


def _consume_quoted(data: bytes, start: int, end: int) -> tuple[int, int, int]:
    index = start + 1
    text_start = index
    while index < end:
        if data[index] == ord('"') and not _escaped(data, index):
            return index + 1, text_start, index
        index += 1
    return end, text_start, end


def _escaped(data: bytes, index: int) -> bool:
    # Walks the whole backslash run preceding ``index``. Callers must only ask
    # about bytes whose preceding runs are disjoint -- quote/brace/newline/
    # separator positions -- which keeps the total walk O(n) per scan. R6
    # removed the two per-byte call sites (the scan_tcl main loop and
    # _consume_bare) that made this quadratic on long backslash runs.
    run = 0
    index -= 1
    while index >= 0 and data[index] == ord("\\"):
        run += 1
        index -= 1
    return run % 2 == 1


def _continues_at_newline(data: bytes, newline_index: int) -> bool:
    index = newline_index - 1
    if index >= 0 and data[index] == ord("\r"):
        index -= 1
    run = 0
    while index >= 0 and data[index] == ord("\\"):
        run += 1
        index -= 1
    return run % 2 == 1


def _at_command_start(data: bytes, start: int, index: int) -> bool:
    while start < index:
        if data[start] not in b" \t\r\n":
            return False
        start += 1
    return True


def _at_word_boundary(data: bytes, index: int) -> bool:
    if index == 0:
        return True
    previous = data[index - 1]
    if previous not in b" \t\r\n;":
        return False
    # An escaped separator is word text rather than a separator -- ``a\ {b`` is one
    # word whose brace is literal -- so it vetoes the boundary. The newline of a
    # line continuation is the one exception: the continuation backslash escapes
    # its own newline, yet the pair folds away as whitespace (see
    # _line_continuation). Without the exception a brace or quote in column 0
    # after an LF continuation was not seen as a word start, so
    # ``set_constraint x \<LF>{a b}`` split into bare ``{a`` and ``b}``, and a
    # ``foreach`` body opened at column 0 was scanned as three further top-level
    # commands plus one named ``}``. Keyed on a real continuation, not on any
    # escaped CR/LF, so that ``\`` before a lone CR stays literal word text.
    if previous == ord("\n") and _continues_at_newline(data, index - 1):
        return True
    return not _escaped(data, index - 1)


def _span(path: str, start: int, end: int, data: bytes, start_line: int) -> SourceSpan:
    # R6: this used to derive ``start_line`` from ``data.count(b"\n", 0,
    # start)`` -- a from-byte-0 rescan for every span, quadratic across a
    # scan's flushed segments and words. Callers now carry the line number
    # incrementally, and the only count left is over the span's own bytes;
    # spans built during one scan are disjoint, so the total counting work is
    # O(n). ``max(start, end - 1)`` keeps the old inclusive-end convention: a
    # span ending just past a newline ends ON that newline's line.
    end_line = start_line + data.count(b"\n", start, max(start, end - 1))
    return SourceSpan(
        relative_path=path,
        start_byte=start,
        end_byte=end,
        start_line=start_line,
        end_line=end_line,
    )


def _occurrence_id(path: str, ordinal: int) -> str:
    return f"tcl-{sha256(f'{path}:{ordinal}'.encode()).hexdigest()[:16]}"


def _diagnostic(
    code: str,
    severity: Literal["error", "warning", "info"],
    message: str,
    span: SourceSpan,
    source_ref: SourceRef,
    *,
    coverage_impact: bool,
) -> DeckDiagnostic:
    identity = f"{code}:{span.relative_path}:{span.start_byte}:{span.end_byte}"
    return DeckDiagnostic(
        diagnostic_id=f"diag-{sha256(identity.encode()).hexdigest()[:16]}",
        code=code,
        severity=severity,
        message=message,
        span=span,
        source_ref=source_ref,
        remediation_class=None,
        coverage_impact=coverage_impact,
    )


__all__ = ["TclScanResult", "scan_tcl"]
