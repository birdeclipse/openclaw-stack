"""Fact-only schemas for deterministic setup-deck analysis output."""

from __future__ import annotations

import re
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from .canonical import canonical_json_bytes

BUILDER_IDENTITY = "esp.setup-model-builder"
PARSER_IDENTITY = "esp.setup-static-parser"

_SHA256_HEX_PATTERN = r"^[0-9a-f]{64}$"
_WINDOWS_ABSOLUTE_PATH = re.compile(r"^[A-Za-z]:[\\/]")
_LEGACY_DIAGNOSTIC_CODES = frozenset(
    {
        "AA-SRC-MISSING",
        "AA-SRC-OUTSIDE-ROOT",
        "AA-SRC-DYNAMIC",
        "AA-SRC-CYCLE",
        "AA-SRC-DEPTH-EXCEEDED",
        "AA-TCL-UNBALANCED",
    }
)

CoverageCategory = Literal[
    "TCL-DYNAMIC",
    "TCL-CONTROL-REGION",
    "TCL-UNBALANCED",
    "TCL-BRACKET-GUARD",
    "RV-DYNAMIC-ARGUMENT",
    "RV-EMBEDDED-OPTION-VECTOR",
    "FILELIST-UNSUPPORTED-FORM",
    "FILELIST-CYCLE",
    "FILELIST-DEPTH",
    "SOURCE-MISSING",
    "SOURCE-ROOT-ESCAPE",
    "SOURCE-SYMLINK",
    "HDL-PREPROCESSING-DEPENDENT",
    "HDL-ESCAPED-IDENTIFIER",
    "HDL-COMPLEX-PORT-TYPE",
    "HDL-NONANSI-PARTIAL",
    "HDL-TOP-AMBIGUOUS",
    "HDL-TOP-INFERRED-SOLE-CANDIDATE",
    "HDL-TOP-DECLARED-MISSING",
    "BOUNDS-LIMIT-REACHED",
    "CATALOG-NO-OPTION-SPEC",
    "CATALOG-ARGUMENT-UNRESOLVED",
    "DEFERRED-SPICE",
    "DEFERRED-SEMANTIC-HDL",
    "DEFERRED-CONTAINED-TCL",
]


class _SetupModel(BaseModel):
    """Strict immutable base for every public setup-analysis schema."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True, populate_by_name=True)

    def to_canonical_bytes(self) -> bytes:
        """Return this document's stable canonical JSON representation."""
        return canonical_json_bytes(self.model_dump(mode="json", by_alias=True))


class _RelativePathModel(_SetupModel):
    """Require root-relative, portable POSIX paths at model boundaries."""

    @field_validator("relative_path", check_fields=False)
    @classmethod
    def _validate_relative_path(cls, value: str) -> str:
        if not value or value.startswith("/") or _WINDOWS_ABSOLUTE_PATH.match(value):
            msg = "relative_path must be a non-empty root-relative POSIX path"
            raise ValueError(msg)
        if "\\" in value or any(part in {"", ".", ".."} for part in value.split("/")):
            msg = "relative_path must be a normalized root-relative POSIX path"
            raise ValueError(msg)
        return value


class SourceRef(_RelativePathModel):
    """Content identity for one confined source file."""

    relative_path: str
    content_digest: str = Field(pattern=_SHA256_HEX_PATTERN)


class SourceSpan(_RelativePathModel):
    """Exact byte and inclusive line span inside one root-relative source file."""

    relative_path: str
    start_byte: int = Field(ge=0)
    end_byte: int = Field(ge=0)
    start_line: int = Field(ge=1)
    end_line: int = Field(ge=1)

    @model_validator(mode="after")
    def _validate_range(self) -> Self:
        if self.end_byte < self.start_byte:
            msg = "end_byte must not precede start_byte"
            raise ValueError(msg)
        if self.end_line < self.start_line:
            msg = "end_line must not precede start_line"
            raise ValueError(msg)
        return self


def word_substitutes(form: str, text: str) -> bool:
    """Return whether Tcl would substitute this word's text.

    Brace quoting suppresses substitution outright, so a braced word is never
    dynamic however many ``$`` or bracket bytes it carries. Bare and quoted
    words both substitute. The one definition is shared by the scanner
    (``tcl.py``) and by :class:`ScannedWord`'s validator so the flag and its
    check can never drift apart.
    """
    return form != "braced" and any(marker in text for marker in ("$", "[", "]"))


class ScannedWord(_SetupModel):
    """One scanned Tcl word with exact provenance and lexical form."""

    text: str
    span: SourceSpan
    form: Literal["bare", "braced", "quoted"]
    dynamic: bool

    @model_validator(mode="after")
    def _validate_dynamic_marker(self) -> Self:
        if self.dynamic != word_substitutes(self.form, self.text):
            msg = "dynamic must match Tcl substitution markers in text"
            raise ValueError(msg)
        return self


class ScannedCommand(_SetupModel):
    """One deterministic static Tcl command occurrence."""

    occurrence_id: str = Field(min_length=1, max_length=256)
    name: str = Field(min_length=1, max_length=256)
    words: tuple[ScannedWord, ...]
    span: SourceSpan
    anchor_safe: bool


class CoverageRecord(_SetupModel):
    """A named unsupported or otherwise unexplained analysis region."""

    category: CoverageCategory
    span: SourceSpan | None
    source_ref: SourceRef | None
    detail: str = Field(min_length=1, max_length=512)


class DeckDiagnostic(_SetupModel):
    """A deterministic, bounded diagnostic bound to source/model facts."""

    diagnostic_id: str = Field(min_length=1, max_length=256)
    code: str = Field(min_length=1, max_length=128)
    severity: Literal["error", "warning", "info"]
    message: str = Field(min_length=1, max_length=512)
    span: SourceSpan | None
    source_ref: SourceRef | None
    remediation_class: str | None = Field(default=None, max_length=128)
    coverage_impact: bool

    @field_validator("code")
    @classmethod
    def _validate_code_vocabulary(cls, value: str) -> str:
        if value not in _LEGACY_DIAGNOSTIC_CODES and not value.startswith("ESP-F3-"):
            msg = "diagnostic code must be a preserved alias or an ESP-F3 versioned code"
            raise ValueError(msg)
        return value


class SourceRecordV1(_SetupModel):
    """One consumed source's factual identity, role, edge, and parse result."""

    source_ref: SourceRef
    role: str = Field(min_length=1, max_length=128)
    parse_status: str = Field(min_length=1, max_length=128)
    reachability_parent: SourceRef | None


class NormalizedCommandV1(_SetupModel):
    """One ordered normalized command with its factual resolution state."""

    command: ScannedCommand
    options: tuple[ScannedWord, ...]
    flow_order: int = Field(ge=0)
    resolution_state: Literal["resolved", "unknown", "dynamic", "opaque"]


class VerificationSetupFactV1(_SetupModel):
    """One literal verification-setup fact lifted from a supported command."""

    kind: str = Field(min_length=1, max_length=128)
    values: tuple[str, ...]
    command_occurrence_id: str = Field(min_length=1, max_length=256)
    span: SourceSpan


class CyclePlanFactV1(_SetupModel):
    """One literal cycle-plan fact lifted from a supported command."""

    kind: str = Field(min_length=1, max_length=128)
    values: tuple[str, ...]
    command_occurrence_id: str = Field(min_length=1, max_length=256)
    span: SourceSpan


class HdlPortV1(_SetupModel):
    """One trustworthy, statically visible selected-top port."""

    name: str = Field(min_length=1, max_length=256)
    direction: Literal["input", "output", "inout"]
    width_text: str | None = Field(default=None, max_length=256)
    span: SourceSpan


class HdlScannerFindingV1(_SetupModel):
    """A factual scanner finding, without diagnostic severity or advice."""

    code: str = Field(min_length=1, max_length=128)
    detail: str = Field(min_length=1, max_length=512)
    span: SourceSpan | None
    source_ref: SourceRef | None


class HdlStructureV1(_SetupModel):
    """Selected top declaration, trustworthy ports, and scanner-local facts."""

    selected_top: str | None = Field(default=None, max_length=256)
    selected_top_span: SourceSpan | None = None
    ports: tuple[HdlPortV1, ...]
    scanner_findings: tuple[HdlScannerFindingV1, ...]


class SetupDeckModelV1(_SetupModel):
    """The deterministic, fact-only setup-deck model Artifact."""

    schema_identity: Literal["esp.setup-deck-model.v1"] = Field(
        default="esp.setup-deck-model.v1",
        serialization_alias="schema",
        validation_alias="schema",
    )
    sources: tuple[SourceRecordV1, ...]
    commands: tuple[NormalizedCommandV1, ...]
    verification_setup: tuple[VerificationSetupFactV1, ...]
    cycle_plan: tuple[CyclePlanFactV1, ...]
    hdl_structure: HdlStructureV1 | None
    coverage: tuple[CoverageRecord, ...]


class DeckDiagnosticsV1(_SetupModel):
    """Bounded typed diagnostic Evidence for one exact model digest."""

    schema_identity: Literal["esp.deck-diagnostics.v1"] = Field(
        default="esp.deck-diagnostics.v1",
        serialization_alias="schema",
        validation_alias="schema",
    )
    model_digest: str = Field(pattern=_SHA256_HEX_PATTERN)
    diagnostics: tuple[DeckDiagnostic, ...]


class BoundReachedV1(_SetupModel):
    """One declared descriptor bound and the factual observed value."""

    name: str = Field(min_length=1, max_length=128)
    limit: int = Field(ge=0)
    observed: int = Field(ge=0)


class SetupModelIntegrityV1(_SetupModel):
    """Integrity Evidence binding sources, versions, limits, and validation facts."""

    schema_identity: Literal["esp.setup-model-integrity.v1"] = Field(
        default="esp.setup-model-integrity.v1",
        serialization_alias="schema",
        validation_alias="schema",
    )
    model_digest: str = Field(pattern=_SHA256_HEX_PATTERN)
    captured_sources: tuple[SourceRef, ...]
    builder_identity: str = Field(min_length=1, max_length=128)
    builder_version: str = Field(min_length=1, max_length=128)
    parser_identity: str = Field(min_length=1, max_length=128)
    parser_version: str = Field(min_length=1, max_length=128)
    bounds_reached: tuple[BoundReachedV1, ...]
    validation_results: tuple[str, ...]

    @model_validator(mode="after")
    def _validate_source_set(self) -> Self:
        paths = tuple(source.relative_path for source in self.captured_sources)
        if paths != tuple(sorted(paths)) or len(paths) != len(set(paths)):
            msg = "captured_sources must be uniquely ordered by relative_path"
            raise ValueError(msg)
        return self
