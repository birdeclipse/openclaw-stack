#!/usr/bin/env python3
# /// script
# requires-python = ">=3.12"
# dependencies = ["pydantic>=2,<3"]
# ///
"""JSON-on-stdin entry point for the ``espanalysis`` deterministic core.

    uv run espanalysis/cli.py <verb>  <<< '{"workdir": "/repo", "run": "ab12cd34"}'

Verbs: ``analyze`` | ``log_fact`` | ``facts``.

One JSON object on stdout, the same wire result :mod:`espdeck.cli` returns::

    {"ok": bool, "message": str, "data": object|null, "refusal": str|null}

**Exit 0 for domain refusals.** A deck that cannot be found, a source that
changed under the walk, a build that failed closed, a fact whose evidence cites
nothing that resolves -- all of these are observations the analyst must read and
adapt to, never a tool crash (ADR 0038, MIGRATION.md section 12.4). A non-zero
exit means a harness defect -- unknown verb, unparseable stdin, an unreadable
packaged catalog -- and the TS wrapper surfaces that as a tool error.

``analyze`` writes the five deterministic documents to
``<workdir>/work/<run>/deck-analysis/`` and returns a bounded
pointer-and-counts receipt. **The receipt is not the model**: the analyst reads
the documents with the built-in ``read`` tool. Reader facts live in the run's
own ledger at ``<workdir>/work/<run>/facts.sqlite3``, written through
:mod:`espdeck.ledger` -- one ledger implementation, shared with the setup-deck
skill, because a fact ``cycle.plan`` later consumes must be the same row
whichever skill logged it.

Every verb takes an optional ``dir`` naming the run root relative to the workdir
instead of the ``work/<run>`` default: ``<workdir>/<dir>/deck-analysis/`` and
``<workdir>/<dir>/facts.sqlite3``, with the run id NOT appended. It resolves
through the same ``espdeck.ledger.run_dir`` the other two CLIs use -- three CLIs
writing one ledger must never disagree about where it is -- so a run analyzed
under a chosen root is the run the deck and cycle-plan skills see there too.

The PEP 723 header above is how ``pydantic`` is provisioned: ``uv run`` reads it
and builds the environment. A system or venv install satisfies the import too,
so plain ``python3`` works wherever pydantic is already present; the TS wrapper
tries ``uv run`` first and falls back to ``python3``.

Three seams from the legacy toolbox are deliberately absent, because what
produced them is gone:

* **the confined toolbox.** ``read``/``write``/``glob``/``grep``/``bash`` are
  opencode built-ins now. This CLI keeps the two file capabilities that are
  *its own*: the bounded source reader (:mod:`espanalysis.reader`) and the
  document publisher below.
* **the role gate.** ``analyze_deck`` and the ``log_*`` tools refused the
  reviewer role in-process. That is now an agent definition: the reviewer's
  ``agents/circuit-deck-reviewer.md`` does not list these tools at all, which
  is a stronger boundary than a runtime refusal.
* **the policy seam.** ``_POLICY_UNAVAILABLE`` had exactly one producer, the
  kernel's write-admission policy. A publication that fails now fails as
  ``build_failed``, which is what the legacy code did for every non-policy
  cause.
"""

from __future__ import annotations

import asyncio
import json
import re
import sys
from collections import Counter
from dataclasses import dataclass
from pathlib import Path, PurePosixPath
from typing import Any, Final

_PACKAGE_PARENT: Final[str] = str(Path(__file__).resolve().parent.parent)
if _PACKAGE_PARENT not in sys.path:
    # This module is spawned by path (`python3 .../espanalysis/cli.py`), so it
    # has no package context of its own; absolute imports of its own package are
    # the one form that works both as a script and under
    # `python3 -m espanalysis.cli`. The same insert makes `espdeck` importable:
    # both packages sit under this one `_shared` root, which is also what lets
    # `espcycle` later do `from espanalysis.models import ...`.
    sys.path.insert(0, _PACKAGE_PARENT)

from espdeck.facts import facts_of_kind  # noqa: E402
from espdeck.ledger import (  # noqa: E402
    FactLedger,
    FactLedgerSchemaError,
    fact_ledger_path,
    run_dir,
)

from espanalysis.builder import (  # noqa: E402
    BuildFailure,
    BuildOutcome,
    build_setup_deck_model,
)
from espanalysis.reader import SourceError, WorkRootSourceReader  # noqa: E402
from espanalysis.report.documents import (  # noqa: E402
    BOUNDARY_DOCUMENT_NAME,
    COMMANDS_DOCUMENT_NAME,
    DIAGNOSTICS_DOCUMENT_NAME,
    OVERVIEW_DOCUMENT_NAME,
    SOURCES_DOCUMENT_NAME,
    render_boundary_document,
    render_commands_document,
    render_diagnostics_document,
    render_overview_document,
    render_sources_document,
)

VERBS: Final[tuple[str, ...]] = ("analyze", "log_fact", "facts")

#: Domain refusal codes. Closed set: the wrapper and the SKILL.md workflow read
#: these, so a new one is a contract change rather than a message tweak. The
#: seven source reasons are the legacy ``_SOURCE_FAILURE_REASONS`` verbatim
#: minus ``stale_claim``, which was a claim-level fault with no analog here.
REFUSALS: Final[tuple[str, ...]] = (
    "invalid_args",  # a malformed or out-of-range argument value
    "build_failed",  # the deterministic build or the publication failed closed
    "not_found",  # the entry deck or a source is absent
    "outside_root",  # a source path escapes the workdir
    "symlink_denied",  # a source resolves outside the workdir through a link
    "protected_path",  # a source path is protected
    "budget_exhausted",  # a source-read budget stopped the walk
    "mutated",  # a source changed digest while the deck was being read
    "unreadable",  # a source could not be read
    "fact_refused",  # the citation gate or the ledger refused the fact
    "no_ledger",  # a read verb ran before any fact was logged
    "ledger_schema",  # the on-disk schema version is not this build's
)

#: Where the five generated documents and the two model-authored ones live,
#: under the run root rather than the workdir root: one run's analysis must not
#: overwrite another's, and ``espdeck`` already owns ``work/<run>/`` as the
#: whole state-and-publish root.
PUBLISHED_DIRECTORY: Final[str] = "deck-analysis"
#: Authored by the analyst agent, read but never rewritten by the reviewer.
REPORT_DOCUMENT_NAME: Final[str] = "report.md"
#: The one published file the reviewer agent owns.
REVIEW_DOCUMENT_NAME: Final[str] = "review.md"

_MESSAGE_MAX_CHARS: Final[int] = 8192

#: Ported from ``deck_analysis_tools._DECK_MAX_CHARS``. 4096 is Linux
#: ``PATH_MAX`` -- the same OS limit every other path bound holds to. This is a
#: *resource* bound and nothing else: the location question belongs to
#: :mod:`espanalysis.reader`, which resolves and refuses on its own terms, so
#: the argument is passed through verbatim. ``builder._read_entry`` asserts the
#: consumed ``relative_path`` equals what was asked for, which makes the
#: declared string the source-graph identity the captured digests hang off.
#: Normalizing it here would also resolve a symlinked deck, turning
#: ``symlink_denied`` into a successful build -- a source-integrity property,
#: not a confinement one.
_DECK_MAX_CHARS: Final[int] = 4096

_SEVERITIES: Final[tuple[str, ...]] = ("error", "warning", "info")

#: Each generated document with the receipt field that points at it, in the
#: order they are written. A failed write stops the run here, so the order is
#: also the order in which a partial tree fills up.
_DOCUMENTS: Final[tuple[tuple[str, str, Any], ...]] = (
    (OVERVIEW_DOCUMENT_NAME, "overview_path", render_overview_document),
    (DIAGNOSTICS_DOCUMENT_NAME, "diagnostics_path", render_diagnostics_document),
    (SOURCES_DOCUMENT_NAME, "sources_path", render_sources_document),
    (COMMANDS_DOCUMENT_NAME, "commands_path", render_commands_document),
    (BOUNDARY_DOCUMENT_NAME, "boundary_path", render_boundary_document),
)

#: Ledger kinds this CLI serves. The kind arrives as an argument but the TS
#: wrapper pins one per export, so the model never chooses it (D3); this list is
#: what makes a wrapper bug a bounded refusal instead of a cross-skill write.
_READER_KINDS: Final[tuple[str, ...]] = ("intent", "design", "concern")

#: Set by this CLI on every reader fact, never by the caller (D5). No verb reads
#: an ``origin`` argument, so there is no path by which a model can claim its
#: inference was parsed from a source.
_READER_ORIGIN: Final[str] = "inferred"

#: Rows one ``facts`` list observation carries. Ported from
#: ``deck_analysis_tools.MAX_LISTED_FACTS``: a capped list yields rows plus an
#: honest ``elided`` count and the caller can narrow with ``kind_filter``.
MAX_LISTED_FACTS: Final[int] = 512

#: A `path:line` citation, shaped so the path part must carry a `/` or a
#: dot-extension: `\w` alone matched bare digits, so the `3:2` in "the ratio is
#: 3:2" and the `10:30` in "captured at 10:30" entered the match set as paths.
#:
#: Cost: **quadratic in the evidence length, not linear.** Neither alternative
#: nests an ambiguous quantifier, so matching is polynomial rather than
#: exponential -- there is no ReDoS here -- but near-miss input made of
#: repeated dotted fragments forces maximal backtracking, measured at a clean
#: x3.9 per doubling: 12 ms at 1 KiB, 184 ms at 4 KiB, 0.73 s at 8 KiB.
#:
#: What bounds this call is therefore NOT the shape of the pattern, it is
#: ``_MAX_FACT_EVIDENCE`` = 4096, declared as the Zod ``max(4096)`` on the
#: ``evidence`` argument in ``tool/analysis.ts`` and re-checked below because a
#: CLI is callable without the wrapper. That caps the worst case near 180 ms.
#: **Raising that cap requires re-measuring this scan**; 64 KiB would cost
#: roughly 45 s per call.
_CITATION: Final[re.Pattern[str]] = re.compile(
    r"((?:[\w.\-\[\]]{1,255}/)+[\w.\-\[\]]{1,255}|[\w\-\[\]]{1,255}(?:\.[\w\-\[\]]{1,32})+)"
    r":(\d{1,9})"
)

#: How many non-resolving citations a refusal names. The evidence field is
#: capped at 4096 characters, which admits roughly 1300 citations; a refusal is
#: an instruction to the model, not a transcript.
_MAX_REPORTED_CITATION_FAILURES: Final[int] = 3
_MAX_FACT_EVIDENCE: Final[int] = 4096

#: sqlite binds a Python ``int`` as a signed 64-bit INTEGER and raises
#: ``OverflowError`` outside that range -- before any row is read, so the
#: ledger's own "no fact with id" result would never be reached.
_MAX_SQLITE_INTEGER: Final[int] = 2**63 - 1

_BUILD_FAILED: Final[str] = "build_failed"

#: The ``SourceError`` codes the analyst is told by name. Ported from
#: ``deck_analysis_tools._SOURCE_FAILURE_REASONS``; every other cause falls
#: through to ``build_failed``.
_SOURCE_FAILURE_REASONS: Final[frozenset[str]] = frozenset(
    {
        "not_found",
        "outside_root",
        "symlink_denied",
        "protected_path",
        "budget_exhausted",
        "mutated",
        "unreadable",
    }
)

#: One safe sentence per reason. None names a host path, and none echoes the
#: model-supplied deck argument back at the model.
_REASON_DETAIL: Final[dict[str, str]] = {
    "not_found": "the named path does not exist under the work root",
    "outside_root": "the named path escapes the work root",
    "symlink_denied": "a source resolves outside the work root through a link",
    "protected_path": "the named path is protected",
    "budget_exhausted": "a source-read budget stopped the walk",
    "mutated": "a source changed digest while the deck was being read",
    "unreadable": "a source could not be read",
    _BUILD_FAILED: "the deterministic build failed closed",
}


@dataclass(frozen=True, slots=True)
class Result:
    """The wire result. ``refusal`` is the authoritative classification."""

    ok: bool
    message: str
    data: dict[str, Any] | None = None
    refusal: str | None = None

    def to_json(self) -> str:
        payload = {
            "ok": self.ok,
            "message": self.message[:_MESSAGE_MAX_CHARS],
            "data": self.data,
            "refusal": self.refusal,
        }
        return json.dumps(payload, ensure_ascii=False)


def _refuse(code: str, message: str) -> Result:
    return Result(ok=False, message=message, refusal=code)


class HarnessDefect(Exception):
    """Malformed invocation. Exits non-zero; never a domain observation."""


# ---- argument seam ----------------------------------------------------


@dataclass(frozen=True, slots=True)
class RunContext:
    """The workdir and run root every verb resolves before doing anything."""

    workdir: Path
    run: str
    root: Path

    @property
    def published(self) -> Path:
        return self.root / PUBLISHED_DIRECTORY

    @property
    def ledger_path(self) -> Path:
        return fact_ledger_path(self.root)


def _context(arguments: dict[str, Any]) -> RunContext | Result:
    """Resolve the run, or return the refusal that explains why not."""

    raw = str(arguments.get("workdir", "") or "").strip()
    declared = Path(raw).expanduser() if raw else Path.cwd()
    if not declared.is_dir():
        return _refuse("invalid_args", f"workdir {declared} is not a directory")
    # Resolved once, here, and every derived path is built from the resolved
    # form. The reader resolves its root too, so deriving the run root from the
    # DECLARED path instead would make `_relative` fail wherever the two differ
    # -- a macOS `/var` -> `/private/var` symlink is enough -- and every receipt
    # would carry an absolute host path instead of `work/<run>/...`.
    workdir = declared.resolve()
    run = str(arguments.get("run", "") or "")
    try:
        # `run_dir` owns run-id AND `dir` segment validation -- one
        # implementation, because this path is what keeps one run's documents out
        # of another's, and it is shared with `espdeck` and `espcycle` so the
        # three CLIs can never disagree about where the run root is. Checking it
        # here too is what turns a bad value into a bounded refusal instead of a
        # traceback: two checks, two reasons, neither redundant.
        root = run_dir(workdir, run, str(arguments.get("dir", "") or ""))
    except ValueError as error:
        return _refuse("invalid_args", str(error))
    return RunContext(workdir=workdir, run=run, root=root)


def _reader(context: RunContext) -> WorkRootSourceReader:
    """One reader per invocation, with the run's ledger protected.

    The ledger is the one file under the workdir whose bytes must never become
    deck evidence or a resolving citation: it is reached only through
    ``log_fact``, which pins ``origin``. Legacy protected it in the confined
    toolbox that served both source reads and citation probes; this is that
    protection, at the one seam that now serves both.
    """

    return WorkRootSourceReader(
        context.workdir,
        protected=frozenset({context.ledger_path}),
    )


def _open_ledger(context: RunContext, *, create: bool) -> FactLedger | Result:
    """Open the run's ledger, or return the refusal that explains why not."""

    path = context.ledger_path
    if not create and not path.is_file():
        return _refuse(
            "no_ledger",
            f"no fact ledger at {path}; log a fact before reading it",
        )
    try:
        return FactLedger(context.workdir, context.run, root=context.root)
    except FactLedgerSchemaError as error:
        return _refuse("ledger_schema", str(error))
    except OSError as error:
        return _refuse("invalid_args", f"could not open {path}: {type(error).__name__}")


def _relative(path: Path, base: Path) -> str:
    """Name ``path`` relative to the workdir when it sits inside it.

    Receipts name ``work/<run>/deck-analysis/...`` rather than an absolute path:
    that is the spelling the model needs for its own ``read`` and ``write``
    calls, and the spelling an agent ``edit`` permission pattern is written
    against.
    """

    try:
        return path.relative_to(base).as_posix()
    except ValueError:
        return str(path)


# ---- analyze ----------------------------------------------------------


def _verb_analyze(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Build the model from deck bytes, publish five documents, return a receipt."""

    deck = arguments.get("deck")
    if not isinstance(deck, str) or not deck or len(deck) > _DECK_MAX_CHARS:
        return _refuse(
            _BUILD_FAILED,
            f"deck must be a path of 1 to {_DECK_MAX_CHARS} characters",
        )
    try:
        outcome = asyncio.run(
            build_setup_deck_model(entry_deck=deck, reader=_reader(context))
        )
    except BuildFailure as error:
        return _build_refused(error)
    return _published_or_refused(context, deck, outcome)


def _build_failure_reason(error: BuildFailure) -> str:
    """Name the first source-port fault in the cause chain, or the catch-all."""

    current: BaseException | None = error
    while current is not None:
        if isinstance(current, SourceError):
            return current.code if current.code in _SOURCE_FAILURE_REASONS else _BUILD_FAILED
        current = current.__cause__
    return _BUILD_FAILED


def _build_refused(error: BuildFailure) -> Result:
    reason = _build_failure_reason(error)
    return _refuse(reason, _REASON_DETAIL[reason])


def _published_or_refused(
    context: RunContext, deck: str, outcome: BuildOutcome
) -> Result:
    """Keep publication inside the analyzer's failure boundary.

    ADR 0038: analyzer failure is an error observation, never a crash. A
    renderer or a write that raises is still analyzer failure, so the boundary
    here has to be broad. The message names the reason and the exception class;
    never ``str(error)``, which can carry an absolute host path.
    """

    try:
        return _publish(context, deck, outcome)
    except Exception as error:  # noqa: BLE001
        return _refuse(
            _BUILD_FAILED,
            f"{_REASON_DETAIL[_BUILD_FAILED]} ({type(error).__name__} while publishing)",
        )


def _publish(context: RunContext, deck: str, outcome: BuildOutcome) -> Result:
    """Write all five documents, regenerating every one of them every call.

    A failed write is reported where it happened and nothing is rolled back: a
    partial tree plus a named failure is more use to the analyst than an empty
    directory and the same message.
    """

    published = context.published
    published.mkdir(parents=True, exist_ok=True)
    written: list[str] = []
    for name, _field, render in _DOCUMENTS:
        target = published / name
        relative = _relative(target, context.workdir)
        try:
            target.write_text(render(outcome), encoding="utf-8")
        except OSError as error:
            landed = ", ".join(written) if written else "none"
            return _refuse(
                _BUILD_FAILED,
                f"{relative} was not written ({type(error).__name__}); "
                f"documents left in place: {landed}",
            )
        written.append(relative)
    receipt = _receipt(context, deck, outcome)
    return Result(
        ok=True,
        message=(
            f"analyzed {deck}: {receipt['source_count']} source(s), "
            f"{receipt['command_count']} command(s); five documents in "
            f"{_relative(published, context.workdir)}"
        ),
        data=receipt,
    )


def _receipt(context: RunContext, deck: str, outcome: BuildOutcome) -> dict[str, Any]:
    """Return the bounded pointer-and-counts receipt, never the model itself."""

    severities = Counter(
        diagnostic.severity for diagnostic in outcome.diagnostics.diagnostics
    )
    receipt: dict[str, Any] = {
        field: _relative(context.published / name, context.workdir)
        for name, field, _render in _DOCUMENTS
    }
    receipt["entry_deck"] = deck
    receipt["source_count"] = len(outcome.model.sources)
    receipt["command_count"] = len(outcome.model.commands)
    receipt["diagnostic_counts"] = {
        severity: severities[severity] for severity in _SEVERITIES
    }
    receipt["bounds_reached"] = [bound.name for bound in outcome.integrity.bounds_reached]
    return receipt


# ---- log_fact ---------------------------------------------------------


def _authored_paths(context: RunContext) -> frozenset[PurePosixPath]:
    """The published documents a model in this run wrote.

    A fact citing one of these is circular attribution: the model asserts a
    claim, writes it to a file, then offers the file as the support for the
    claim, and trusted code signs off. The five documents ``analyze`` generates
    are deliberately absent -- those are trusted-code output over deck bytes,
    which is exactly what a reader fact should be attributed to.

    Matched as whole relative paths, never by basename: a deck that ships its
    own file called ``report.md`` is citable deck evidence, and telling the
    model that file "is a document this run authored" would be false and
    unactionable. Three spellings per document -- bare, ``deck-analysis/``, and
    the full ``work/<run>/deck-analysis/`` -- because a citation may be written
    any of those ways and the refusal has to be about the file, not the spelling.
    """

    published = _relative(context.published, context.workdir)
    return frozenset(
        PurePosixPath(candidate)
        for name in (REPORT_DOCUMENT_NAME, REVIEW_DOCUMENT_NAME)
        for candidate in (name, f"{PUBLISHED_DIRECTORY}/{name}", f"{published}/{name}")
    )


def _verb_log_fact(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Store one reader fact, or refuse it with a bounded error observation.

    Never raises and never fails the caller (D8): a rejected fact is an
    observation the model can correct and retry. ``origin`` is set here, not by
    the caller -- no verb exposes it (D5).
    """

    kind = str(arguments.get("kind", "") or "").strip()
    if kind not in _READER_KINDS:
        return _refuse(
            "invalid_args",
            f"kind must be one of {', '.join(_READER_KINDS)}",
        )
    subject = arguments.get("subject")
    statement = arguments.get("statement")
    evidence = arguments.get("evidence")
    for name, value in (
        ("subject", subject),
        ("statement", statement),
        ("evidence", evidence),
    ):
        if not isinstance(value, str) or not value.strip():
            return _refuse("fact_refused", f"{name} must be a non-empty string")
    assert isinstance(subject, str) and isinstance(statement, str)
    assert isinstance(evidence, str)
    if len(evidence) > _MAX_FACT_EVIDENCE:
        return _refuse(
            "fact_refused",
            f"evidence must be at most {_MAX_FACT_EVIDENCE} characters",
        )

    attribution = _verified_evidence(context, evidence)
    if attribution is not None:
        return _refuse("fact_refused", attribution)

    opened = _open_ledger(context, create=True)
    if isinstance(opened, Result):
        return opened
    try:
        try:
            result = opened.log(
                kind,
                {"subject": subject, "statement": statement},
                evidence,
                origin=_READER_ORIGIN,
            )
        except Exception as error:  # noqa: BLE001
            return _refuse(
                "fact_refused",
                f"the ledger refused the fact ({type(error).__name__})",
            )
        if result.is_error:
            return _refuse("fact_refused", result.message)
        return Result(
            ok=True,
            message=f"logged {kind} fact {result.fact_id} (inferred)",
            data={"fact_id": result.fact_id, "kind": kind},
        )
    finally:
        opened.close()


def _verified_evidence(context: RunContext, evidence: str) -> str | None:
    """Verify attribution, never validity (D6).

    The contract is *at least one* resolving citation -- what the no-match
    message below promises and what the tool description in ``tool/analysis.ts``
    tells the model. Implementing it as *all* refuses well-attributed facts
    whenever a prose colon reads as a citation: ``"cfg/a.tcl:3 shows the ratio
    is 3:2"`` would be refused for citing ``3``. Naming a non-path as a path
    leaves the model no way to see what blocked it, so that refusal is
    unactionable as well as wrong. Failures are still reported, as advisory
    detail on the refusal that happens when *no* citation resolves.
    """

    citations = _CITATION.findall(evidence)
    if not citations:
        return "evidence must name at least one `path:line` under the work root"
    authored = _authored_paths(context)
    reader = _reader(context)
    failures: list[str] = []
    for path_text, line_text in citations:
        failure = _citation_failure(reader, authored, path_text, line_text)
        if failure is None:
            return None
        if failure not in failures:
            failures.append(failure)
    reported = ", ".join(failures[:_MAX_REPORTED_CITATION_FAILURES])
    return f"no `path:line` in this evidence resolves: {reported}"


def _citation_failure(
    reader: WorkRootSourceReader,
    authored: frozenset[PurePosixPath],
    path_text: str,
    line_text: str,
) -> str | None:
    """Return why one citation does not resolve, or ``None`` when it does.

    Three checks: the path is not a document a model in this run authored, it is
    readable inside the workdir, and the line exists. Whether the reader's
    reading of that line is correct is not checkable and is deliberately not
    checked.
    """

    if PurePosixPath(path_text) in authored:
        return f"{path_text} is a document this run authored, not evidence"
    try:
        total = reader.line_count(path_text)
    except (SourceError, OSError):
        # Fail closed: an unreadable path is a citation that does not resolve,
        # never one that is waved through.
        return f"{path_text} is not readable under the work root"
    line = int(line_text)
    if line < 1 or line > total:
        return f"{path_text}:{line} is past the end of that file"
    return None


# ---- facts ------------------------------------------------------------


def _verb_facts(context: RunContext, arguments: dict[str, Any]) -> Result:
    """List or retract logged reader facts."""

    operation = str(arguments.get("op", "") or "").strip()
    if operation not in ("list", "retract"):
        return _refuse("invalid_args", "op must be `list` or `retract`")
    kind_filter = str(arguments.get("kind_filter", "") or "").strip()
    # The reader roster used to be enforced by omission -- the default `kinds`
    # tuple below -- so any caller-supplied filter reached `facts_of_kind`
    # unchecked. Harmless while this ledger held reader facts only, and exactly
    # the boundary that does not survive the shared one it now writes to.
    if kind_filter and kind_filter not in _READER_KINDS:
        return _refuse(
            "fact_refused",
            f"kind_filter must be one of {', '.join(_READER_KINDS)}",
        )
    opened = _open_ledger(context, create=False)
    if isinstance(opened, Result):
        return opened
    try:
        if operation == "list":
            return _facts_listed(opened, kind_filter)
        return _fact_retracted(opened, arguments)
    finally:
        opened.close()


def _facts_listed(ledger: FactLedger, kind_filter: str) -> Result:
    try:
        snapshot = ledger.snapshot()
    except Exception as error:  # noqa: BLE001
        return _refuse(
            "fact_refused",
            f"the ledger could not be read ({type(error).__name__})",
        )
    kinds = (kind_filter,) if kind_filter else _READER_KINDS
    available = [
        {
            "fact_id": record.fact_id,
            "kind": kind,
            "subject": record.fields.get("subject", ""),
        }
        for kind in kinds
        for record in facts_of_kind(snapshot, kind)
    ]
    listed = available[:MAX_LISTED_FACTS]
    elided = len(available) - len(listed)
    lines = [f"{row['fact_id']} {row['kind']}: {row['subject']}" for row in listed]
    if elided:
        lines.append(f"[{elided} more fact(s) not shown; narrow with kind_filter]")
    return Result(
        ok=True,
        message="\n".join(lines) if lines else "no reader facts logged yet",
        data={"facts": listed, "elided": elided},
    )


def _fact_retracted(ledger: FactLedger, arguments: dict[str, Any]) -> Result:
    fact_id = arguments.get("fact_id") or ""
    reason = arguments.get("reason") or "retracted by the reader"
    if not fact_id:
        return _refuse("fact_refused", "retract needs the fact_id to retract")
    try:
        target = int(str(fact_id))
    except ValueError:
        return _refuse("fact_refused", "fact_id must be an integer")
    # `FactLedger.retract` binds this straight into a sqlite query, which raises
    # `OverflowError` outside the signed 64-bit range before the ledger's own
    # "no fact with id" result is reached. A 32-digit id is a schema-valid tool
    # call, so an unbounded parse turns a fumbled id into a crash -- the one
    # thing D8 forbids.
    if not 0 < target <= _MAX_SQLITE_INTEGER:
        return _refuse(
            "fact_refused",
            f"fact_id must be an integer from 1 to {_MAX_SQLITE_INTEGER}",
        )
    try:
        result = ledger.retract(target, str(reason))
    except Exception as error:  # noqa: BLE001
        return _refuse(
            "fact_refused",
            f"the ledger refused the retraction ({type(error).__name__})",
        )
    if result.is_error:
        return _refuse("fact_refused", result.message)
    return Result(
        ok=True,
        message=f"retracted fact {target}",
        data={"retracted": target},
    )


_HANDLERS: Final[dict[str, Any]] = {
    "analyze": _verb_analyze,
    "log_fact": _verb_log_fact,
    "facts": _verb_facts,
}


def run(verb: str, arguments: dict[str, Any]) -> Result:
    """Dispatch one verb. Raises :class:`HarnessDefect` for a bad invocation."""

    handler = _HANDLERS.get(verb)
    if handler is None:
        raise HarnessDefect(f"unknown verb {verb!r}; expected one of {', '.join(VERBS)}")
    context = _context(arguments)
    if isinstance(context, Result):
        return context
    return handler(context, arguments)


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print(
            f"usage: cli.py <{'|'.join(VERBS)}>  (JSON arguments on stdin)",
            file=sys.stderr,
        )
        return 2
    raw = sys.stdin.read()
    text = raw.strip()
    if not text:
        arguments: dict[str, Any] = {}
    else:
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as error:
            print(f"stdin is not JSON: {error}", file=sys.stderr)
            return 2
        if not isinstance(parsed, dict):
            print("stdin JSON must be an object", file=sys.stderr)
            return 2
        arguments = parsed
    try:
        result = run(argv[0], arguments)
    except HarnessDefect as error:
        print(Result(ok=False, message=str(error), refusal=None).to_json())
        print(str(error), file=sys.stderr)
        return 2
    print(result.to_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
