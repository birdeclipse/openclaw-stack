"""Fail-closed loader for the reviewed ESP command catalog asset."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from pathlib import Path
from types import MappingProxyType
from typing import cast

CATALOG_SCHEMA = "esp.command-catalog.v1"
#: One reviewed copy, in ``_shared/data/`` beside this package rather than
#: inside it: ``espdeck.emit`` loads the same asset for emit legality.
_CATALOG_PATH = Path(__file__).resolve().parent.parent / "data" / "esp_command_catalog_v1.json"

type FrozenJson = (
    None | bool | int | float | str | tuple[FrozenJson, ...] | Mapping[str, FrozenJson]
)


class CatalogLoadError(RuntimeError):
    """Raised when the packaged catalog is absent, malformed, or unreviewed."""


def _freeze_json(value: object) -> FrozenJson:
    if value is None or isinstance(value, (bool, int, float, str)):
        return value
    if isinstance(value, list):
        return tuple(_freeze_json(item) for item in value)
    if isinstance(value, dict) and all(isinstance(key, str) for key in value):
        return MappingProxyType({key: _freeze_json(item) for key, item in value.items()})
    msg = "catalog JSON contains an unsupported value"
    raise CatalogLoadError(msg)


def _require_mapping(value: object, field_name: str) -> dict[str, object]:
    if not isinstance(value, dict) or not all(isinstance(key, str) for key in value):
        msg = f"catalog {field_name} must be an object with string keys"
        raise CatalogLoadError(msg)
    return value


def _validate_option_spec(command: str, spec: object) -> None:
    if spec is None:
        return
    spec_mapping = _require_mapping(spec, f"commands.{command}")
    if set(spec_mapping) != {"options", "takes_positional"}:
        msg = f"catalog commands.{command} has an invalid option-spec shape"
        raise CatalogLoadError(msg)
    if not isinstance(spec_mapping["takes_positional"], bool) or not isinstance(
        spec_mapping["options"], list
    ):
        msg = f"catalog commands.{command} has invalid option-spec values"
        raise CatalogLoadError(msg)
    for option in spec_mapping["options"]:
        option_mapping = _require_mapping(option, f"commands.{command}.options")
        if set(option_mapping) != {"kind", "name", "required"}:
            msg = f"catalog commands.{command} has an invalid option entry"
            raise CatalogLoadError(msg)
        if (
            option_mapping["kind"] not in {"positional", "option", "flag"}
            or not isinstance(option_mapping["name"], str)
            or not option_mapping["name"]
            or not isinstance(option_mapping["required"], bool)
        ):
            msg = f"catalog commands.{command} has invalid option entry values"
            raise CatalogLoadError(msg)


@dataclass(frozen=True, slots=True)
class CommandLookup:
    """One catalog query; unknown commands are explicit ordinary results."""

    name: str
    known: bool
    option_spec: Mapping[str, FrozenJson] | None
    flow_group: str | None


@dataclass(frozen=True, slots=True)
class CommandCatalog:
    """Immutable, validated projection of one packaged catalog asset."""

    commands: Mapping[str, Mapping[str, FrozenJson] | None]
    command_groups: Mapping[str, str]
    flow_constraints: tuple[Mapping[str, FrozenJson], ...]
    common_misspellings: Mapping[str, str]

    @property
    def command_count(self) -> int:
        return len(self.commands)

    @property
    def unspecified_command_count(self) -> int:
        return sum(spec is None for spec in self.commands.values())

    @property
    def specified_command_count(self) -> int:
        return self.command_count - self.unspecified_command_count

    @property
    def command_group_count(self) -> int:
        return len(self.command_groups)

    @property
    def flow_group_count(self) -> int:
        return len(frozenset(self.command_groups.values()))

    def lookup(self, command: str) -> CommandLookup:
        """Return the exact catalog answer, including explicit unknown commands."""
        option_spec = self.commands.get(command)
        flow_group = self.command_groups.get(command)
        return CommandLookup(
            name=command,
            known=command in self.commands or flow_group is not None,
            option_spec=option_spec,
            flow_group=flow_group,
        )

    def option_spec(self, command: str) -> Mapping[str, FrozenJson] | None:
        """Return the exact immutable option spec, or ``None`` when absent/unknown."""
        return self.lookup(command).option_spec

    def flow_group(self, command: str) -> str | None:
        """Return the exact flow group, or ``None`` when ungrouped/unknown."""
        return self.lookup(command).flow_group


def _load_catalog(asset_path: Path) -> CommandCatalog:
    try:
        raw = json.loads(asset_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError) as error:
        msg = f"unable to load command catalog asset: {asset_path.name}"
        raise CatalogLoadError(msg) from error

    root = _require_mapping(raw, "root")
    if (
        set(root)
        != {
            "schema",
            "commands",
            "command_groups",
            "flow_constraints",
            "common_misspellings",
        }
        or root["schema"] != CATALOG_SCHEMA
    ):
        msg = "command catalog has an unrecognized schema"
        raise CatalogLoadError(msg)

    commands = _require_mapping(root["commands"], "commands")
    command_groups = _require_mapping(root["command_groups"], "command_groups")
    misspellings = _require_mapping(root["common_misspellings"], "common_misspellings")
    constraints = root["flow_constraints"]
    if not isinstance(constraints, list):
        msg = "catalog flow_constraints must be an array"
        raise CatalogLoadError(msg)

    for command, spec in commands.items():
        _validate_option_spec(command, spec)
    if not all(isinstance(group, str) and group for group in command_groups.values()):
        msg = "catalog command_groups must map commands to non-empty groups"
        raise CatalogLoadError(msg)
    if not all(isinstance(value, str) and value for value in misspellings.values()):
        msg = "catalog common_misspellings must map to non-empty strings"
        raise CatalogLoadError(msg)
    for constraint in constraints:
        constraint_mapping = _require_mapping(constraint, "flow_constraints")
        if set(constraint_mapping) != {
            "after_group",
            "before_group",
            "message",
            "rule_id",
            "severity",
        } or not all(isinstance(value, str) and value for value in constraint_mapping.values()):
            msg = "catalog flow_constraints contain an invalid entry"
            raise CatalogLoadError(msg)

    unspecified_count = sum(spec is None for spec in commands.values())
    inventory_counts = (len(commands), unspecified_count, len(command_groups))
    #: 114, not 116: ``set_testbench_pin_attributes`` and ``set_portgroup`` gained
    #: reviewed option specs so the pin inventory can tell a positional target
    #: from an option value (`docs/plans/analyze-module-v2.md` §3a.1).
    if inventory_counts != (205, 114, 65):
        msg = "catalog command inventory does not match the reviewed v1 asset"
        raise CatalogLoadError(msg)
    if (len(set(command_groups.values())), len(constraints), len(misspellings)) != (20, 7, 10):
        msg = "catalog flow inventory does not match the reviewed v1 asset"
        raise CatalogLoadError(msg)

    frozen_commands = _freeze_json(commands)
    frozen_groups = _freeze_json(command_groups)
    frozen_constraints = _freeze_json(constraints)
    frozen_misspellings = _freeze_json(misspellings)
    if not (
        isinstance(frozen_commands, Mapping)
        and isinstance(frozen_groups, Mapping)
        and isinstance(frozen_constraints, tuple)
        and isinstance(frozen_misspellings, Mapping)
    ):
        msg = "catalog freeze produced an invalid projection"
        raise CatalogLoadError(msg)

    return CommandCatalog(
        commands=cast(Mapping[str, Mapping[str, FrozenJson] | None], frozen_commands),
        command_groups=cast(Mapping[str, str], frozen_groups),
        flow_constraints=cast(tuple[Mapping[str, FrozenJson], ...], frozen_constraints),
        common_misspellings=cast(Mapping[str, str], frozen_misspellings),
    )


@cache
def load_command_catalog(asset_path: Path | None = None) -> CommandCatalog:
    """Load and cache the immutable reviewed catalog, failing closed on every defect."""
    return _load_catalog(_CATALOG_PATH if asset_path is None else asset_path)
