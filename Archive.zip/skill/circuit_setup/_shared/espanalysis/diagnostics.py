"""Pure deterministic diagnostics over static setup-analysis results."""

from __future__ import annotations

from collections import defaultdict
from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from hashlib import sha256
from typing import Literal, cast

from .catalog import CommandCatalog, load_command_catalog
from .models import (
    CoverageRecord,
    CyclePlanFactV1,
    DeckDiagnostic,
    NormalizedCommandV1,
    SourceRef,
    SourceSpan,
    VerificationSetupFactV1,
)


@dataclass(frozen=True, slots=True)
class _Candidate:
    code: str
    severity: Literal["error", "warning", "info"]
    message: str
    span: SourceSpan | None
    source_ref: SourceRef | None
    remediation_class: str | None
    coverage_impact: bool


def analyze_diagnostics(
    *,
    commands: Sequence[NormalizedCommandV1],
    coverage: Sequence[CoverageRecord],
    verification_setup: Sequence[VerificationSetupFactV1],
    cycle_plan: Sequence[CyclePlanFactV1],
    prior_diagnostics: Sequence[DeckDiagnostic] = (),
    catalog: CommandCatalog | None = None,
) -> tuple[DeckDiagnostic, ...]:
    """Return deterministic new and scanner-provided diagnostics without I/O.

    Scanner and locator diagnostics are accepted verbatim so preserved legacy
    aliases retain their original meanings. This function only derives new,
    model-level rules from immutable scanner and lifter outputs.
    """
    active_catalog = load_command_catalog() if catalog is None else catalog
    candidates: list[_Candidate] = []
    _unknown_commands(commands, candidates)
    _argument_failures(commands, coverage, candidates)
    _missing_setup_identity(verification_setup, commands, candidates)
    _inconsistent_facts(verification_setup, candidates)
    _incomplete_cycle_facts(cycle_plan, candidates)
    _coverage_findings(coverage, candidates)
    _flow_findings(commands, coverage, active_catalog, candidates)
    generated = _materialize(candidates)
    return tuple(sorted((*prior_diagnostics, *generated), key=_diagnostic_order))


def _unknown_commands(
    commands: Sequence[NormalizedCommandV1], candidates: list[_Candidate]
) -> None:
    for normalized in commands:
        if normalized.resolution_state == "unknown":
            candidates.append(
                _candidate(
                    "ESP-F3-UNKNOWN-COMMAND",
                    "warning",
                    "Unknown static Tcl command",
                    normalized.command.span,
                    coverage_impact=True,
                )
            )


def _argument_failures(
    commands: Sequence[NormalizedCommandV1],
    coverage: Sequence[CoverageRecord],
    candidates: list[_Candidate],
) -> None:
    for normalized in commands:
        if normalized.resolution_state != "opaque":
            continue
        if not _has_coverage(
            normalized.command.span,
            "CATALOG-ARGUMENT-UNRESOLVED",
            coverage,
        ):
            continue
        candidates.append(
            _candidate(
                "ESP-F3-COMMAND-ARGUMENTS",
                "warning",
                "Command arguments cannot be resolved",
                normalized.command.span,
                coverage_impact=True,
            )
        )


def _missing_setup_identity(
    facts: Sequence[VerificationSetupFactV1],
    commands: Sequence[NormalizedCommandV1],
    candidates: list[_Candidate],
) -> None:
    if not commands or any(fact.kind == "top_design" for fact in facts):
        return
    span = commands[0].command.span
    candidates.append(
        _candidate(
            "ESP-F3-TOP-MISSING",
            "warning",
            "No resolved top design declaration",
            span,
            coverage_impact=True,
        )
    )


def _inconsistent_facts(
    facts: Sequence[VerificationSetupFactV1], candidates: list[_Candidate]
) -> None:
    _conflicting_supplies(facts, candidates)
    _conflicting_clocks(facts, candidates)


def _conflicting_supplies(
    facts: Sequence[VerificationSetupFactV1], candidates: list[_Candidate]
) -> None:
    by_net: dict[str, tuple[str, VerificationSetupFactV1]] = {}
    for fact in facts:
        if fact.kind != "supply" or not fact.values:
            continue
        net = fact.values[-1]
        logic = _option_value(fact.values, "-logic")
        if logic is None:
            continue
        existing = by_net.get(net)
        if existing is None:
            by_net[net] = (logic, fact)
        elif existing[0] != logic:
            candidates.append(
                _candidate(
                    "ESP-F3-SUPPLY-CONFLICT",
                    "warning",
                    "Supply has conflicting logic values",
                    fact.span,
                    coverage_impact=False,
                )
            )


def _conflicting_clocks(
    facts: Sequence[VerificationSetupFactV1], candidates: list[_Candidate]
) -> None:
    by_clock: dict[str, tuple[str | None, VerificationSetupFactV1]] = {}
    for fact in facts:
        if fact.kind != "clock" or not fact.values:
            continue
        clock = fact.values[-1]
        period = _option_value(fact.values, "-period")
        existing = by_clock.get(clock)
        if existing is None:
            by_clock[clock] = (period, fact)
        elif period is not None and existing[0] is not None and period != existing[0]:
            candidates.append(
                _candidate(
                    "ESP-F3-CLOCK-CONFLICT",
                    "warning",
                    "Clock has conflicting periods",
                    fact.span,
                    coverage_impact=False,
                )
            )


def _incomplete_cycle_facts(facts: Sequence[CyclePlanFactV1], candidates: list[_Candidate]) -> None:
    for fact in facts:
        if fact.kind in {"cycle_assignment", "cycle_check"} and len(fact.values) < 2:
            candidates.append(
                _candidate(
                    "ESP-F3-CYCLE-INCOMPLETE",
                    "warning",
                    "Cycle fact lacks a pin or label",
                    fact.span,
                    coverage_impact=True,
                )
            )


def _coverage_findings(coverage: Sequence[CoverageRecord], candidates: list[_Candidate]) -> None:
    for record in coverage:
        if record.category == "BOUNDS-LIMIT-REACHED":
            candidates.append(
                _candidate(
                    "ESP-F3-TRUNCATED",
                    "warning",
                    "Static analysis reached a declared bound",
                    record.span,
                    source_ref=record.source_ref,
                    coverage_impact=True,
                )
            )
        elif record.category == "HDL-TOP-AMBIGUOUS":
            candidates.append(
                _candidate(
                    "ESP-F3-HDL-TOP-AMBIGUOUS",
                    "warning",
                    "No unique HDL top declaration",
                    record.span,
                    source_ref=record.source_ref,
                    coverage_impact=True,
                )
            )
        elif record.category == "HDL-TOP-DECLARED-MISSING":
            candidates.append(
                _candidate(
                    "ESP-F3-HDL-TOP-MISSING",
                    "warning",
                    "Declared HDL top was not found",
                    record.span,
                    source_ref=record.source_ref,
                    coverage_impact=True,
                )
            )
        elif record.category in {
            "HDL-PREPROCESSING-DEPENDENT",
            "HDL-ESCAPED-IDENTIFIER",
            "HDL-COMPLEX-PORT-TYPE",
            "HDL-NONANSI-PARTIAL",
        }:
            candidates.append(
                _candidate(
                    "ESP-F3-HDL-PORTS-INCOMPLETE",
                    "warning",
                    "HDL top ports are incomplete",
                    record.span,
                    source_ref=record.source_ref,
                    coverage_impact=True,
                )
            )


def _flow_findings(
    commands: Sequence[NormalizedCommandV1],
    coverage: Sequence[CoverageRecord],
    catalog: CommandCatalog,
    candidates: list[_Candidate],
) -> None:
    commands_by_path: dict[str, list[NormalizedCommandV1]] = defaultdict(list)
    for command in commands:
        commands_by_path[command.command.span.relative_path].append(command)

    for path in sorted(commands_by_path):
        path_commands = sorted(
            commands_by_path[path],
            key=lambda command: (command.command.span.start_byte, command.flow_order),
        )
        for constraint in catalog.flow_constraints:
            before_group = _string_field(constraint, "before_group")
            after_group = _string_field(constraint, "after_group")
            rule_id = _string_field(constraint, "rule_id")
            severity = _string_field(constraint, "severity")
            if before_group is None or after_group is None or rule_id is None or severity is None:
                continue
            after = _first_group(path_commands, after_group, catalog)
            before = _first_group(path_commands, before_group, catalog)
            if (
                after is None
                or before is None
                or after.command.span.start_byte >= before.command.span.start_byte
            ):
                continue
            if _is_execution_dependent(after.command.span, coverage) or _is_execution_dependent(
                before.command.span, coverage
            ):
                continue
            candidates.append(
                _candidate(
                    f"ESP-F3-{rule_id}",
                    cast(Literal["error", "warning", "info"], severity),
                    "Static flow order conflicts with catalog rule",
                    before.command.span,
                    coverage_impact=False,
                )
            )


def _first_group(
    commands: Sequence[NormalizedCommandV1], group: str, catalog: CommandCatalog
) -> NormalizedCommandV1 | None:
    for command in commands:
        if (
            command.resolution_state == "resolved"
            and catalog.flow_group(command.command.name) == group
        ):
            return command
    return None


def _is_execution_dependent(span: SourceSpan, coverage: Sequence[CoverageRecord]) -> bool:
    for record in coverage:
        region = record.span
        if (
            record.category in {"TCL-CONTROL-REGION", "TCL-DYNAMIC"}
            and region is not None
            and region.relative_path == span.relative_path
            and region.start_byte <= span.start_byte
            and span.end_byte <= region.end_byte
        ):
            return True
    return False


def _has_coverage(
    span: SourceSpan,
    category: str,
    coverage: Sequence[CoverageRecord],
) -> bool:
    return any(record.category == category and record.span == span for record in coverage)


def _candidate(
    code: str,
    severity: Literal["error", "warning", "info"],
    message: str,
    span: SourceSpan | None,
    *,
    source_ref: SourceRef | None = None,
    coverage_impact: bool,
) -> _Candidate:
    return _Candidate(code, severity, message, span, source_ref, None, coverage_impact)


def _materialize(candidates: Sequence[_Candidate]) -> tuple[DeckDiagnostic, ...]:
    sorted_candidates = sorted(candidates, key=_candidate_order)
    ordinals: dict[tuple[str, int, str], int] = defaultdict(int)
    diagnostics: list[DeckDiagnostic] = []
    for candidate in sorted_candidates:
        path, start, _, _, _ = _candidate_order(candidate)
        key = (path, start, candidate.code)
        ordinal = ordinals[key]
        ordinals[key] += 1
        identity = f"{candidate.code}:{path}:{_span_text(candidate.span)}:{ordinal}"
        diagnostics.append(
            DeckDiagnostic(
                diagnostic_id=f"diag-{sha256(identity.encode()).hexdigest()[:16]}",
                code=candidate.code,
                severity=candidate.severity,
                message=candidate.message,
                span=candidate.span,
                source_ref=candidate.source_ref,
                remediation_class=candidate.remediation_class,
                coverage_impact=candidate.coverage_impact,
            )
        )
    return tuple(diagnostics)


def _candidate_order(candidate: _Candidate) -> tuple[str, int, str, int, str]:
    if candidate.span is None:
        return "", -1, candidate.code, -1, candidate.message
    return (
        candidate.span.relative_path,
        candidate.span.start_byte,
        candidate.code,
        candidate.span.end_byte,
        candidate.message,
    )


def _diagnostic_order(diagnostic: DeckDiagnostic) -> tuple[str, int, str, str]:
    if diagnostic.span is None:
        return "", -1, diagnostic.code, diagnostic.diagnostic_id
    return (
        diagnostic.span.relative_path,
        diagnostic.span.start_byte,
        diagnostic.code,
        diagnostic.diagnostic_id,
    )


def _option_value(values: Sequence[str], option_name: str) -> str | None:
    for index, value in enumerate(values[:-1]):
        if value == option_name:
            return values[index + 1]
    return None


def _string_field(mapping: Mapping[str, object], key: str) -> str | None:
    value = mapping.get(key)
    return value if isinstance(value, str) else None


def _span_text(span: SourceSpan | None) -> str:
    if span is None:
        return "none"
    return f"{span.relative_path}:{span.start_byte}:{span.end_byte}"


__all__ = ["analyze_diagnostics"]
