"""Bounded, syntax-only HDL top-port scanning.

Selection rule: ``selected_top`` is a literal deck fact when it is non-``None``.
It selects exactly one module whose declared name equals that string byte-for-byte;
there is no case folding, aliasing, hierarchy resolution, or fallback.  A declared
name that is absent is reported as missing and no candidate is substituted.  With
no declared top, a sole scanned candidate may be returned only with
``selection_provenance == "sole_candidate"`` and explicit inference coverage.
Zero or multiple candidates are ambiguous and yield no ports.

This is a small stateful lexer and header parser, not a regex over HDL text.  It
recognizes only the module-header forms pinned by the F0 scanner spike.  It does
not preprocess, elaborate parameters, resolve widths, parse connectivity, or
invoke an Agent.
"""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from typing import Literal, Protocol, cast

from .models import CoverageCategory, CoverageRecord, SourceRef, SourceSpan

HdlResultClass = Literal["trustworthy-complete", "trustworthy-partial-with-coverage", "must-defer"]
HdlSelectionProvenance = Literal["declared", "sole_candidate"]
PortDirection = Literal["input", "output", "inout"]


class HdlSourceRead(Protocol):
    """The portion of a trusted source-port response used by this scanner."""

    @property
    def data(self) -> bytes: ...


class HdlSourceReader(Protocol):
    """Injected source reader; this domain package never opens files itself."""

    async def read(self, relative_path: str, /) -> HdlSourceRead: ...


@dataclass(frozen=True, slots=True)
class HdlScanBounds:
    """Finite port-scan ceilings recommended by the F0 scanner spike."""

    max_files: int = 64
    max_total_bytes: int = 512 * 1024
    max_file_bytes: int = 128 * 1024

    def __post_init__(self) -> None:
        if min(self.max_files, self.max_total_bytes, self.max_file_bytes) < 1:
            raise ValueError("HDL scan bounds must be positive")


_DEFAULT_BOUNDS = HdlScanBounds()


@dataclass(frozen=True, slots=True)
class HdlPort:
    """One statically visible top-level port declaration."""

    name: str
    direction: PortDirection
    declared_width_text: str | None
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class HdlScanResult:
    """Scanner-local result, mapped into the model Artifact by the builder."""

    result_class: HdlResultClass
    selected_module: str | None
    selection_provenance: HdlSelectionProvenance | None
    ports: tuple[HdlPort, ...]
    coverage: tuple[CoverageRecord, ...]


@dataclass(frozen=True, slots=True)
class _Token:
    text: str
    start: int
    end: int
    kind: Literal["identifier", "escaped", "macro", "punctuation", "other"]


@dataclass(frozen=True, slots=True)
class _ModuleHeader:
    name: str
    source_ref: SourceRef
    data: bytes
    tokens: tuple[_Token, ...]
    module_start: int
    ports_open: int
    ports_close: int
    semicolon: int
    complex_parameterization: bool

    @property
    def span(self) -> SourceSpan:
        return _span(self.source_ref.relative_path, self.data, self.module_start, self.semicolon)


async def scan_top_ports(
    *,
    sources: Sequence[SourceRef],
    selected_top: str | None,
    reader: HdlSourceReader,
    bounds: HdlScanBounds = _DEFAULT_BOUNDS,
) -> HdlScanResult:
    """Scan declared HDL sources for one selected module's trustworthy ports.

    ``sources`` must be root-relative explicit RTL sources. Reader failures
    deliberately propagate: confinement, mutation, and read failures belong to
    the trusted reader/source-graph boundary and cannot become partial HDL facts.
    """
    headers, limit_coverage = await _scan_headers(sources, reader, bounds)
    candidates = tuple(
        sorted(headers, key=lambda item: (item.source_ref.relative_path, item.module_start))
    )

    if selected_top is not None:
        matches = tuple(header for header in candidates if header.name == selected_top)
        if len(matches) == 1:
            result = _scan_selected_header(matches[0])
            return HdlScanResult(
                result_class=result.result_class,
                selected_module=selected_top,
                selection_provenance="declared",
                ports=result.ports,
                coverage=tuple((*limit_coverage, *result.coverage)),
            )
        if len(matches) == 0 and not limit_coverage:
            return _deferred(
                coverage=_coverage(
                    "HDL-TOP-DECLARED-MISSING",
                    None,
                    None,
                    "declared top module was not found in scanned sources",
                )
            )
        return _deferred(
            coverage=tuple(
                (
                    *limit_coverage,
                    _top_ambiguous_coverage(None, None, "declared top cannot be resolved"),
                )
            )
        )

    if len(candidates) == 1 and not limit_coverage:
        result = _scan_selected_header(candidates[0])
        return HdlScanResult(
            result_class=result.result_class,
            selected_module=candidates[0].name,
            selection_provenance="sole_candidate",
            ports=result.ports,
            coverage=tuple(
                (
                    _coverage(
                        "HDL-TOP-INFERRED-SOLE-CANDIDATE",
                        candidates[0].span,
                        candidates[0].source_ref,
                        "top was inferred from the sole scanned candidate",
                    ),
                    *result.coverage,
                )
            ),
        )

    return _deferred(
        coverage=tuple(
            (
                *limit_coverage,
                _top_ambiguous_coverage(None, None, "no unique top candidate is available"),
            )
        )
    )


@dataclass(frozen=True, slots=True)
class _HeaderScan:
    result_class: HdlResultClass
    ports: tuple[HdlPort, ...]
    coverage: tuple[CoverageRecord, ...]


async def _scan_headers(
    sources: Sequence[SourceRef], reader: HdlSourceReader, bounds: HdlScanBounds
) -> tuple[tuple[_ModuleHeader, ...], tuple[CoverageRecord, ...]]:
    headers: list[_ModuleHeader] = []
    coverage: list[CoverageRecord] = []
    total_bytes = 0
    seen_paths: set[str] = set()

    for source_ref in sources:
        if source_ref.relative_path in seen_paths:
            continue
        seen_paths.add(source_ref.relative_path)
        if len(seen_paths) > bounds.max_files:
            coverage.append(
                _coverage(
                    "BOUNDS-LIMIT-REACHED",
                    None,
                    source_ref,
                    f"HDL file-count limit reached: {bounds.max_files}",
                )
            )
            break
        source = await reader.read(source_ref.relative_path)
        data = source.data
        if len(data) > bounds.max_file_bytes:
            coverage.append(
                _coverage(
                    "BOUNDS-LIMIT-REACHED",
                    None,
                    source_ref,
                    f"HDL per-file byte limit reached: {bounds.max_file_bytes}",
                )
            )
            break
        if total_bytes + len(data) > bounds.max_total_bytes:
            coverage.append(
                _coverage(
                    "BOUNDS-LIMIT-REACHED",
                    None,
                    source_ref,
                    f"HDL aggregate byte limit reached: {bounds.max_total_bytes}",
                )
            )
            break
        total_bytes += len(data)
        headers.extend(_module_headers(source_ref, data))

    return tuple(headers), tuple(coverage)


def _module_headers(source_ref: SourceRef, data: bytes) -> tuple[_ModuleHeader, ...]:
    tokens = _lex(data)
    headers: list[_ModuleHeader] = []
    index = 0
    while index < len(tokens):
        token = tokens[index]
        if token.text != "module":
            index += 1
            continue
        header, next_index = _try_module_header(source_ref, data, tokens, index)
        if header is not None:
            headers.append(header)
        index = max(next_index, index + 1)
    return tuple(headers)


def _try_module_header(
    source_ref: SourceRef, data: bytes, tokens: tuple[_Token, ...], start: int
) -> tuple[_ModuleHeader | None, int]:
    name_index = start + 1
    if name_index >= len(tokens) or tokens[name_index].kind not in {"identifier", "escaped"}:
        return None, name_index
    name = tokens[name_index]
    index = name_index + 1
    parameterized = False
    if index < len(tokens) and tokens[index].text == "#":
        parameterized = True
        parameter_close = _matching_paren(tokens, index + 1)
        if parameter_close is None:
            return None, index + 1
        index = parameter_close + 1
    if index >= len(tokens) or tokens[index].text != "(":
        return None, index
    ports_open = index
    ports_close = _matching_paren(tokens, ports_open)
    if ports_close is None:
        return None, ports_open + 1
    semicolon_index = ports_close + 1
    if semicolon_index >= len(tokens) or tokens[semicolon_index].text != ";":
        return None, semicolon_index
    return (
        _ModuleHeader(
            name=name.text,
            source_ref=source_ref,
            data=data,
            tokens=tokens,
            module_start=tokens[start].start,
            ports_open=ports_open,
            ports_close=ports_close,
            semicolon=tokens[semicolon_index].end,
            complex_parameterization=parameterized,
        ),
        semicolon_index + 1,
    )


def _scan_selected_header(header: _ModuleHeader) -> _HeaderScan:
    header_tokens = header.tokens[header.ports_open : header.ports_close + 1]
    if header.complex_parameterization:
        return _must_defer_header(
            header, "HDL-COMPLEX-PORT-TYPE", "module parameterization requires elaboration"
        )
    if any(token.kind == "macro" for token in header_tokens):
        return _must_defer_header(
            header, "HDL-PREPROCESSING-DEPENDENT", "module header depends on preprocessing"
        )
    if any(token.kind == "escaped" for token in header_tokens):
        return _must_defer_header(
            header, "HDL-ESCAPED-IDENTIFIER", "module header contains an escaped identifier"
        )

    segments = _comma_segments(header.tokens, header.ports_open + 1, header.ports_close)
    if all(_is_bare_identifier_segment(segment) for segment in segments):
        return _scan_nonansi(header, segments)
    return _scan_ansi(header, segments)


def _scan_ansi(header: _ModuleHeader, segments: tuple[tuple[_Token, ...], ...]) -> _HeaderScan:
    ports: list[HdlPort] = []
    for segment in segments:
        parsed = _parse_ansi_port(header, segment)
        if parsed is None:
            return _must_defer_header(
                header,
                "HDL-COMPLEX-PORT-TYPE",
                "module header has an unsupported ANSI port declaration",
            )
        ports.append(parsed)
    return _HeaderScan("trustworthy-complete", tuple(ports), ())


def _scan_nonansi(header: _ModuleHeader, segments: tuple[tuple[_Token, ...], ...]) -> _HeaderScan:
    names = tuple(segment[0].text for segment in segments)
    declarations = _nonansi_declarations(header)
    if declarations is None:
        return _must_defer_header(
            header, "HDL-COMPLEX-PORT-TYPE", "module body has an unsupported port declaration"
        )

    declared_by_name = {port.name: port for port in declarations}
    visible_ports = tuple(declared_by_name[name] for name in names if name in declared_by_name)
    missing_names = tuple(name for name in names if name not in declared_by_name)
    if missing_names:
        return _HeaderScan(
            "trustworthy-partial-with-coverage",
            visible_ports,
            (
                _coverage(
                    "HDL-NONANSI-PARTIAL",
                    header.span,
                    header.source_ref,
                    "non-ANSI header names lack visible direction declarations",
                ),
            ),
        )
    return _HeaderScan("trustworthy-complete", visible_ports, ())


def _nonansi_declarations(header: _ModuleHeader) -> tuple[HdlPort, ...] | None:
    index = header.ports_close + 2
    ports: list[HdlPort] = []
    while index < len(header.tokens):
        token = header.tokens[index]
        if token.text == "endmodule":
            return tuple(ports)
        if token.text not in {"input", "output", "inout"}:
            return tuple(ports)
        semicolon = _find_statement_end(header.tokens, index)
        if semicolon is None:
            return None
        statement = header.tokens[index:semicolon]
        parsed = _parse_nonansi_statement(header, statement)
        if parsed is None:
            return None
        ports.extend(parsed)
        index = semicolon + 1
    return tuple(ports)


def _parse_ansi_port(header: _ModuleHeader, segment: tuple[_Token, ...]) -> HdlPort | None:
    if not segment or segment[0].text not in {"input", "output", "inout"}:
        return None
    direction = segment[0].text
    return _parse_port_declaration(header, direction, segment[1:])


def _parse_nonansi_statement(
    header: _ModuleHeader, statement: tuple[_Token, ...]
) -> tuple[HdlPort, ...] | None:
    if not statement or statement[0].text not in {"input", "output", "inout"}:
        return None
    direction = statement[0].text
    parts = _split_tokens_on_comma(statement[1:])
    parsed: list[HdlPort] = []
    shared_prefix: tuple[_Token, ...] | None = None
    for part in parts:
        if not part:
            return None
        if shared_prefix is None:
            prefix, name = _declaration_prefix_and_name(part)
            if name is None:
                return None
            shared_prefix = prefix
            port = _parse_port_declaration(header, direction, part)
        else:
            if len(part) != 1 or part[0].kind != "identifier":
                return None
            port = _port_from_name(header, direction, shared_prefix, part[0])
        if port is None:
            return None
        parsed.append(port)
    return tuple(parsed)


def _parse_port_declaration(
    header: _ModuleHeader, direction: str, declaration: tuple[_Token, ...]
) -> HdlPort | None:
    prefix, name = _declaration_prefix_and_name(declaration)
    if name is None:
        return None
    return _port_from_name(header, direction, prefix, name)


def _declaration_prefix_and_name(
    declaration: tuple[_Token, ...],
) -> tuple[tuple[_Token, ...], _Token | None]:
    if not declaration:
        return (), None
    if any(token.kind in {"macro", "escaped"} for token in declaration):
        return (), None
    if any(
        token.text in {"interface", "modport", "ref", "var", "typedef", "#"}
        for token in declaration
    ):
        return (), None
    name = declaration[-1]
    if name.kind != "identifier":
        return (), None
    prefix = declaration[:-1]
    openings = tuple(index for index, token in enumerate(prefix) if token.text == "[")
    if len(openings) > 1:
        return (), None
    if openings:
        opening = openings[0]
        close = _matching_bracket(prefix, opening)
        if close is None or close != len(prefix) - 1:
            return (), None
        qualifier_tokens = prefix[:opening]
    else:
        if any(token.text in {"]", "{", "}", "(", ")"} for token in prefix):
            return (), None
        qualifier_tokens = prefix
    if any(token.text not in {"wire", "reg", "logic", "signed"} for token in qualifier_tokens):
        return (), None
    return prefix, name


def _port_from_name(
    header: _ModuleHeader, direction: str, prefix: tuple[_Token, ...], name: _Token
) -> HdlPort | None:
    if direction not in {"input", "output", "inout"}:
        return None
    width = _width_text(header.data, prefix)
    if any(token.text == "[" for token in prefix) and width is None:
        return None
    return HdlPort(
        name=name.text,
        direction=cast(PortDirection, direction),
        declared_width_text=width,
        span=_span(header.source_ref.relative_path, header.data, name.start, name.end),
    )


def _width_text(data: bytes, prefix: tuple[_Token, ...]) -> str | None:
    for index, token in enumerate(prefix):
        if token.text == "[":
            close = _matching_bracket(prefix, index)
            if close is None:
                return None
            return data[token.start : prefix[close].end].decode("utf-8", "replace")
    return None


def _is_bare_identifier_segment(segment: tuple[_Token, ...]) -> bool:
    return len(segment) == 1 and segment[0].kind == "identifier"


def _comma_segments(
    tokens: tuple[_Token, ...], start: int, end: int
) -> tuple[tuple[_Token, ...], ...]:
    return _split_tokens_on_comma(tokens[start:end])


def _split_tokens_on_comma(tokens: tuple[_Token, ...]) -> tuple[tuple[_Token, ...], ...]:
    parts: list[tuple[_Token, ...]] = []
    part_start = 0
    bracket_depth = 0
    for index, token in enumerate(tokens):
        if token.text == "[":
            bracket_depth += 1
        elif token.text == "]":
            bracket_depth -= 1
        elif token.text == "," and bracket_depth == 0:
            parts.append(tokens[part_start:index])
            part_start = index + 1
    parts.append(tokens[part_start:])
    return tuple(parts)


def _matching_paren(tokens: tuple[_Token, ...], opening: int) -> int | None:
    if opening >= len(tokens) or tokens[opening].text != "(":
        return None
    depth = 0
    for index in range(opening, len(tokens)):
        if tokens[index].text == "(":
            depth += 1
        elif tokens[index].text == ")":
            depth -= 1
            if depth == 0:
                return index
    return None


def _matching_bracket(tokens: tuple[_Token, ...], opening: int) -> int | None:
    if opening >= len(tokens) or tokens[opening].text != "[":
        return None
    depth = 0
    for index in range(opening, len(tokens)):
        if tokens[index].text == "[":
            depth += 1
        elif tokens[index].text == "]":
            depth -= 1
            if depth == 0:
                return index
    return None


def _find_statement_end(tokens: tuple[_Token, ...], start: int) -> int | None:
    for index in range(start, len(tokens)):
        if tokens[index].text == ";":
            return index
        if tokens[index].text == "endmodule":
            return None
    return None


def _must_defer_header(header: _ModuleHeader, category: str, detail: str) -> _HeaderScan:
    return _HeaderScan(
        "must-defer", (), (_coverage(category, header.span, header.source_ref, detail),)
    )


def _deferred(*, coverage: CoverageRecord | tuple[CoverageRecord, ...]) -> HdlScanResult:
    records = (coverage,) if isinstance(coverage, CoverageRecord) else coverage
    return HdlScanResult("must-defer", None, None, (), records)


def _top_ambiguous_coverage(
    span: SourceSpan | None, source_ref: SourceRef | None, detail: str
) -> CoverageRecord:
    return _coverage("HDL-TOP-AMBIGUOUS", span, source_ref, detail)


def _coverage(
    category: str, span: SourceSpan | None, source_ref: SourceRef | None, detail: str
) -> CoverageRecord:
    return CoverageRecord(
        category=cast(CoverageCategory, category),
        span=span,
        source_ref=source_ref,
        detail=detail,
    )


def _span(relative_path: str, data: bytes, start: int, end: int) -> SourceSpan:
    start_line = data.count(b"\n", 0, start) + 1
    end_line = data.count(b"\n", 0, max(start, end - 1)) + 1
    return SourceSpan(
        relative_path=relative_path,
        start_byte=start,
        end_byte=end,
        start_line=start_line,
        end_line=end_line,
    )


def _lex(data: bytes) -> tuple[_Token, ...]:
    tokens: list[_Token] = []
    index = 0
    while index < len(data):
        byte = data[index]
        if byte in b" \t\r\n\f\v":
            index += 1
            continue
        if data[index : index + 2] == b"//":
            newline = data.find(b"\n", index + 2)
            index = len(data) if newline == -1 else newline + 1
            continue
        if data[index : index + 2] == b"/*":
            close = data.find(b"*/", index + 2)
            index = len(data) if close == -1 else close + 2
            continue
        start = index
        if byte == ord("\\"):
            index += 1
            while index < len(data) and data[index] not in b" \t\r\n\f\v":
                index += 1
            tokens.append(
                _Token(data[start:index].decode("utf-8", "replace"), start, index, "escaped")
            )
            continue
        if byte == ord("`"):
            index += 1
            while index < len(data) and _is_identifier_byte(data[index]):
                index += 1
            tokens.append(
                _Token(data[start:index].decode("ascii", "replace"), start, index, "macro")
            )
            continue
        if _is_identifier_start(byte):
            index += 1
            while index < len(data) and _is_identifier_byte(data[index]):
                index += 1
            tokens.append(
                _Token(data[start:index].decode("ascii", "replace"), start, index, "identifier")
            )
            continue
        index += 1
        text = chr(byte)
        kind: Literal["punctuation", "other"] = "punctuation" if text in "()[];," else "other"
        tokens.append(_Token(text, start, index, kind))
    return tuple(tokens)


def _is_identifier_start(byte: int) -> bool:
    return (
        byte == ord("_")
        or byte == ord("$")
        or ord("a") <= byte <= ord("z")
        or ord("A") <= byte <= ord("Z")
    )


def _is_identifier_byte(byte: int) -> bool:
    return _is_identifier_start(byte) or ord("0") <= byte <= ord("9")


__all__ = [
    "HdlPort",
    "HdlResultClass",
    "HdlScanBounds",
    "HdlScanResult",
    "HdlSelectionProvenance",
    "HdlSourceRead",
    "HdlSourceReader",
    "PortDirection",
    "scan_top_ports",
]
