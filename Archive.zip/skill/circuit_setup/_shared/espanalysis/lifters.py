"""Deterministic literal fact lifting for static setup-deck commands."""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass
from typing import Literal, cast

from .catalog import CommandCatalog, load_command_catalog
from .models import (
    CoverageCategory,
    CoverageRecord,
    CyclePlanFactV1,
    NormalizedCommandV1,
    ScannedCommand,
    ScannedWord,
    VerificationSetupFactV1,
)


@dataclass(frozen=True, slots=True)
class LiftResult:
    """Normalized command occurrences and facts safely lifted from them."""

    normalized_commands: tuple[NormalizedCommandV1, ...]
    verification_setup: tuple[VerificationSetupFactV1, ...]
    cycle_plan: tuple[CyclePlanFactV1, ...]
    coverage: tuple[CoverageRecord, ...]


@dataclass(frozen=True, slots=True)
class _ResolvedArguments:
    """One catalog-validated literal command argument vector."""

    option_values: tuple[tuple[str, str | None], ...]
    positional_values: tuple[str, ...]

    def value(self, name: str) -> str | None:
        for option_name, option_value in self.option_values:
            if option_name == name:
                return option_value
        return None


def lift_commands(
    commands: Sequence[ScannedCommand],
    /,
    *,
    catalog: CommandCatalog | None = None,
) -> LiftResult:
    """Normalize command occurrences and lift only fully literal catalog facts.

    A catalog-declared option shape is an atomic resolution unit: a dynamic word,
    unknown option, missing option value, or missing required positional prevents
    every fact from that command from being emitted. Known commands without a
    reviewed option shape remain opaque occurrences rather than guessed facts.
    """
    active_catalog = load_command_catalog() if catalog is None else catalog
    normalized: list[NormalizedCommandV1] = []
    verification_setup: list[VerificationSetupFactV1] = []
    cycle_plan: list[CyclePlanFactV1] = []
    coverage: list[CoverageRecord] = []

    for flow_order, command in enumerate(commands):
        lookup = active_catalog.lookup(command.name)
        state, arguments = _resolution(command, lookup.option_spec, lookup.known)
        normalized.append(
            NormalizedCommandV1(
                command=command,
                options=command.words[1:],
                flow_order=flow_order,
                resolution_state=state,
            )
        )
        if state == "dynamic":
            coverage.append(_coverage(command, "TCL-DYNAMIC", "Dynamic command cannot be lifted"))
            continue
        if state != "resolved" or arguments is None:
            if lookup.known and lookup.option_spec is None:
                coverage.append(
                    _coverage(
                        command,
                        "CATALOG-NO-OPTION-SPEC",
                        f"Catalog has no option spec for {command.name}",
                    )
                )
            elif state == "opaque":
                coverage.append(
                    _coverage(
                        command,
                        "CATALOG-ARGUMENT-UNRESOLVED",
                        "Catalog argument shape cannot be resolved",
                    )
                )
            continue
        _lift_verification(command, verification_setup)
        if command.name == "read_spice":
            coverage.append(
                _coverage(
                    command,
                    "DEFERRED-SPICE",
                    "Declared SPICE source is not statically interpreted",
                )
            )
        _lift_cycle(command, arguments, cycle_plan)

    return LiftResult(
        normalized_commands=tuple(normalized),
        verification_setup=tuple(verification_setup),
        cycle_plan=tuple(cycle_plan),
        coverage=tuple(coverage),
    )


def _resolution(
    command: ScannedCommand,
    option_spec: Mapping[str, object] | None,
    known: bool,
) -> tuple[Literal["resolved", "unknown", "dynamic", "opaque"], _ResolvedArguments | None]:
    if any(word.dynamic for word in command.words):
        return "dynamic", None
    if not known:
        return "unknown", None
    if option_spec is None:
        return "opaque", None
    parsed = _parse_arguments(command.words[1:], option_spec)
    return ("resolved", parsed) if parsed is not None else ("opaque", None)


def _parse_arguments(
    words: tuple[ScannedWord, ...], option_spec: Mapping[str, object]
) -> _ResolvedArguments | None:
    raw_options = option_spec.get("options")
    takes_positional = option_spec.get("takes_positional")
    if not isinstance(raw_options, tuple) or not isinstance(takes_positional, bool):
        return None

    typed_options = cast(tuple[object, ...], raw_options)
    option_kinds: dict[str, str] = {}
    required_positionals: list[str] = []
    for raw_option in typed_options:
        if not isinstance(raw_option, Mapping):
            return None
        option_mapping = cast(Mapping[str, object], raw_option)
        name = option_mapping.get("name")
        kind = option_mapping.get("kind")
        required = option_mapping.get("required")
        if not isinstance(name, str) or not isinstance(kind, str) or not isinstance(required, bool):
            return None
        if kind in {"option", "flag"}:
            option_kinds[name] = kind
        elif kind == "positional" and required:
            required_positionals.append(name)
        elif kind != "positional":
            return None

    option_values: list[tuple[str, str | None]] = []
    positional_values: list[str] = []
    index = 0
    while index < len(words):
        word = words[index]
        token = word.text
        if token.startswith("-"):
            kind = option_kinds.get(token)
            if kind is None:
                return None
            if kind == "flag":
                option_values.append((token, None))
                index += 1
                continue
            if index + 1 >= len(words) or words[index + 1].dynamic:
                return None
            option_values.append((token, words[index + 1].text))
            index += 2
            continue
        if not takes_positional:
            return None
        positional_values.append(token)
        index += 1

    if len(positional_values) < len(required_positionals):
        return None
    return _ResolvedArguments(tuple(option_values), tuple(positional_values))


def _lift_verification(
    command: ScannedCommand,
    facts: list[VerificationSetupFactV1],
) -> None:
    kind = {
        "set_top_design": "top_design",
        "set_verify_mode": "mode",
        "set_testbench": "testbench",
        "set_active_testbench": "testbench",
        "create_clock": "clock",
        "set_supply_net": "supply",
        "set_constraint": "constraint",
        "check_design": "check",
        "verify": "check",
        "analyze_spice": "check",
    }.get(command.name)
    if kind is None:
        return
    facts.append(
        VerificationSetupFactV1(
            kind=kind,
            values=tuple(word.text for word in command.words[1:]),
            command_occurrence_id=command.occurrence_id,
            span=command.span,
        )
    )


def _lift_cycle(
    command: ScannedCommand,
    arguments: _ResolvedArguments,
    facts: list[CyclePlanFactV1],
) -> None:
    if command.name == "create_clock":
        for option_name in ("-phase", "-bincycles", "-symcycles", "-flushcycles"):
            value = arguments.value(option_name)
            if value is not None:
                kind = "cycle_phase" if option_name == "-phase" else "cycle_count"
                facts.append(_cycle_fact(kind, command, (option_name, value)))
        return
    if command.name == "set_power_sequence":
        for option_name in ("-cycles", "-powerup", "-powerdn"):
            value = arguments.value(option_name)
            if value is not None:
                facts.append(_cycle_fact("cycle_phase", command, (option_name, value)))
        return
    if command.name != "set_constraint":
        return

    cycle = arguments.value("-cycle")
    assignment = arguments.value("-set")
    if cycle is not None:
        kind = "cycle_assignment" if assignment is not None else "cycle_check"
        facts.append(_cycle_fact(kind, command, (*arguments.positional_values, cycle)))
    style = arguments.value("-style")
    if style is not None:
        facts.append(_cycle_fact("cycle_style", command, (*arguments.positional_values, style)))
    check_num = arguments.value("-check_num")
    if check_num is not None:
        facts.append(_cycle_fact("check_event", command, (*arguments.positional_values, check_num)))


def _cycle_fact(kind: str, command: ScannedCommand, values: tuple[str, ...]) -> CyclePlanFactV1:
    return CyclePlanFactV1(
        kind=kind,
        values=values,
        command_occurrence_id=command.occurrence_id,
        span=command.span,
    )


def _coverage(command: ScannedCommand, category: str, detail: str) -> CoverageRecord:
    return CoverageRecord(
        category=cast(CoverageCategory, category),
        span=command.span,
        source_ref=None,
        detail=detail,
    )


__all__ = ["LiftResult", "lift_commands"]
