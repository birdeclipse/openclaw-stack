"""Spec-driven split of one command's words into target, options, and flags.

`docs/plans/analyze-module-v2.md` §3 requires a fact line to present its values
"as the reviewed option spec recovered them: the target distinguished from its
options, and each option paired with its value". This module is that recovery,
and it is the only place that judgement lives: the overview renderer, the two
inventories (§3a), and ``STATUS.md``'s pin count all read it.

Position is deliberately not used. ``set_testbench_pin_attributes`` documents its
positional ``tbpin`` **last** (``espcommand.txt:21993-22017``) while every deck in
the corpus writes it first, so a positional-by-index rule would mislabel either
the documentation or the reality. The spec's ``kind`` is the only stable signal.

Pure by construction: the catalog is packaged data reached through the existing
accessor, so rendering stays a function of the fact (§3 property 4).
"""

from __future__ import annotations

from collections.abc import Mapping, Sequence
from dataclasses import dataclass

from ..catalog import CommandCatalog, FrozenJson

#: A leading ``-`` on a word the spec does not name. Never a target: a
#: misspelled option is not a pin, and neither is a negative number.
_OPTION_PREFIX = "-"


@dataclass(frozen=True, slots=True)
class OptionView:
    """One command's words, split by what the reviewed spec says they are."""

    #: Positional targets, in source order. Empty when the spec takes none.
    targets: tuple[str, ...] = ()
    #: ``(-name, value)`` pairs, in source order.
    options: tuple[tuple[str, str], ...] = ()
    #: Valueless options, in source order.
    flags: tuple[str, ...] = ()
    #: Every word, unsplit, when the command has no reviewed option spec.
    #: Callers render this exactly as they always have (§3 property 2).
    unspecified: tuple[str, ...] = ()

    @property
    def has_spec(self) -> bool:
        return not self.unspecified


def option_view(
    command: str,
    words: Sequence[str],
    catalog: CommandCatalog,
) -> OptionView:
    """Split ``words`` using ``command``'s reviewed option spec.

    With no spec the words are returned untouched in ``unspecified``: the flat
    rendering is this module's documented fallback, not an error. 114 of the
    catalog's 205 commands are still unspecified.
    """
    spec = catalog.option_spec(command)
    if spec is None:
        return OptionView(unspecified=tuple(words))

    valued, valueless = _option_names(spec)
    # Every option name the spec declares. A word in this set is never a value:
    # consuming it would eat the option itself and push its real value into
    # `targets` as a phantom pin, which `configured_pins` then reports as a
    # fabricated `absent` row (inventories.py:88-92).
    named = valued | valueless
    targets: list[str] = []
    options: list[tuple[str, str]] = []
    flags: list[str] = []
    index = 0
    while index < len(words):
        word = words[index]
        following = words[index + 1] if index + 1 < len(words) else None
        if word in valued and following is not None and following not in named:
            options.append((word, following))
            index += 2
            continue
        if word.startswith(_OPTION_PREFIX):
            # An undeclared option followed by a bare number is a value-taking
            # option the reviewed spec has not catalogued yet. Pairing them is
            # what keeps the number out of `targets`: `set_input_delay -min -0.5
            # clk` classified `-0.5` as a flag, and treating it as a positional
            # instead would hand `configured_pins` a pin named `-0.5`.
            if word not in valueless and following is not None and _is_number(following):
                options.append((word, following))
                index += 2
                continue
            # A declared flag, a misspelled option, or a valued option whose
            # value is missing. Every word is preserved and no target invented.
            flags.append(word)
            index += 1
            continue
        targets.append(word)
        index += 1
    return OptionView(targets=tuple(targets), options=tuple(options), flags=tuple(flags))


def _is_number(word: str) -> bool:
    """Whether ``word`` is a numeric literal, and so a value rather than a name.

    A digit is required as well as a successful ``float`` so that ``-inf`` and
    ``-nan`` stay name-shaped. ``-1hot`` and ``-01cold`` carry digits but fail
    ``float``, so the declared ``set_constraint`` flags are unaffected.
    """
    if not any(character.isdigit() for character in word):
        return False
    try:
        _ = float(word)
    except ValueError:
        return False
    return True


def _option_names(spec: Mapping[str, FrozenJson]) -> tuple[frozenset[str], frozenset[str]]:
    """Return the value-taking and valueless option names from one spec."""
    entries = spec.get("options")
    if not isinstance(entries, Sequence):
        return frozenset(), frozenset()
    valued: set[str] = set()
    valueless: set[str] = set()
    for entry in entries:
        if not isinstance(entry, Mapping):
            continue
        name = entry.get("name")
        kind = entry.get("kind")
        if not isinstance(name, str) or not isinstance(kind, str):
            continue
        if kind == "option":
            valued.add(name)
        elif kind == "flag":
            valueless.add(name)
    return frozenset(valued), frozenset(valueless)


__all__ = ["OptionView", "option_view"]
