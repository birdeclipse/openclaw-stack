"""Trusted rendering of setup-analysis documents.

ADR 0038 retired the untrusted report draft and its renderer along with the
schema-gated report Worker. What remains is ``documents.py``, which the deck
analysis document loop imports directly.
"""
