"""The two deck inventories: pins against the HDL boundary, and supplies.

`docs/plans/analyze-module-v2.md` §3a. Both tables describe **the deck**, which
is why they replaced the coverage sections revision 0019 removed: once
``esp_shell`` runs a deck, "how much our parser resolved" is a fact about this
scanner and tells a reader nothing about the design.

Rows are the **union** of what the deck configures and what the boundary
provides, never the intersection (decision D24). Dropping either side hides
exactly the mismatch the table exists to show: a pin the deck drives that the
RTL does not have.

Every function here is pure — a function of the model plus packaged catalog
data (§3 property 4) — and stable byte-for-byte across calls (property 5).
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass

from ..catalog import CommandCatalog, load_command_catalog
from ..models import HdlPortV1, NormalizedCommandV1, SetupDeckModelV1
from .option_view import OptionView, option_view

#: Commands whose positional target names a testbench pin. ``set_portgroup`` is
#: deliberately absent: its positionals are group names, not pins.
#:
#: ``create_clock`` and ``set_input_delay`` are included because a clock or a
#: delay on a pin the RTL does not export is the same defect class as a pin
#: attribute on one. In ``t5_sram_full`` this is the only thing that surfaces
#: ``refclk`` (``cfg/tb_config.tcl:15``), which no ``set_testbench_pin_attributes``
#: call mentions.
_PIN_TARGET_COMMANDS: frozenset[str] = frozenset(
    {
        "set_testbench_pin_attributes",
        "create_clock",
        "set_input_delay",
        "set_constraint",
    }
)

_PIN_ATTRIBUTES = "set_testbench_pin_attributes"
_PORTGROUP = "set_portgroup"
_SUPPLY = "set_supply_net"
_SUPPLY_REMOVED = "remove_supply_net"
_CONSTRAINT = "set_constraint"
_CONSTRAINT_REMOVED = "remove_constraint"

#: Rendered when the boundary has no port of this name.
ABSENT = "absent"

#: Rendered when the boundary has a port of this name but not this bit. A
#: separate label from ``ABSENT`` on purpose: the bus exists, the index does
#: not, so a reader looking for a missing pin and a reader looking for a bad
#: index are not shown the same word.
OUT_OF_RANGE = "out of range"

#: Fills a detail cell for a command that carries no options and no flags. It
#: replaces an ``or "set"`` fallback that asserted a setting the deck never
#: made; a marker must assert nothing.
_NO_OPTIONS = "(no options)"


@dataclass(frozen=True, slots=True)
class PinRow:
    """One pin, from the deck or the boundary or both."""

    name: str
    boundary: str
    function: tuple[str, ...] = ()
    group: tuple[str, ...] = ()
    constraint: tuple[str, ...] = ()
    timing: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class SupplyRow:
    """One supply rail and whether it is still declared."""

    rail: str
    supply_type: str
    logic: str
    subcircuit: str
    status: str


def configured_pins(
    model: SetupDeckModelV1, catalog: CommandCatalog | None = None
) -> frozenset[str]:
    """Every pin name the deck names as a target.

    Read through the reviewed option spec, never by position:
    ``set_testbench_pin_attributes`` documents its ``tbpin`` positional last
    (``espcommand.txt:21993-22017``) while every corpus deck writes it first.
    """
    resolved = catalog or load_command_catalog()
    names: set[str] = set()
    for command in model.commands:
        if command.command.name not in _PIN_TARGET_COMMANDS:
            continue
        for target in _targets(command, resolved):
            names.update(_split_targets(target))
    return frozenset(names)


def boundary_pins(model: SetupDeckModelV1) -> frozenset[str]:
    """Every port the HDL top exports."""
    structure = model.hdl_structure
    if structure is None:
        return frozenset()
    return frozenset(port.name for port in structure.ports)


def off_boundary_pins(
    model: SetupDeckModelV1, catalog: CommandCatalog | None = None
) -> frozenset[str]:
    """Every configured pin the boundary does not provide at all.

    The set form of the ``absent`` column, and the only correct way to count it.
    ``configured_pins(model) - boundary_pins(model)`` compares ``addr[0]`` to
    ``addr`` by exact string, so it reported four off-boundary pins for
    ``t6_intent_full`` (``cfg/symbols.tcl:36-39``) that the RTL does export.
    """
    resolved = catalog or load_command_catalog()
    structure = model.hdl_structure
    ports = {port.name: port for port in (structure.ports if structure else ())}
    return frozenset(
        pin for pin in configured_pins(model, resolved) if _resolve_port(pin, ports) is None
    )


def out_of_range_pins(
    model: SetupDeckModelV1, catalog: CommandCatalog | None = None
) -> frozenset[str]:
    """Pins that index a real port outside its declared width.

    A sibling of :func:`off_boundary_pins` rather than part of it, so
    ``pins off boundary`` keeps meaning "no such port" exactly. Both read the
    rows the table renders, which is what stops a counter drifting from the
    table it summarises.
    """
    return frozenset(
        row.name for row in pin_inventory(model, catalog) if row.boundary.startswith(OUT_OF_RANGE)
    )


def pin_inventory(
    model: SetupDeckModelV1, catalog: CommandCatalog | None = None
) -> tuple[PinRow, ...]:
    """One row per pin known from any source, boundary-first then deck-only.

    A configured pin with no port renders ``absent`` rather than being dropped.
    A bit-select is keyed on its raw target and resolved against the bus it
    selects from, so ``addr[0]`` is its own row carrying ``addr``'s declaration.
    A withdrawn constraint keeps its cell and gains a marker: deleting the
    content would let a reader believe an inactive constraint is active.
    """
    resolved = catalog or load_command_catalog()
    structure = model.hdl_structure
    ports = {port.name: port for port in (structure.ports if structure else ())}
    configured = configured_pins(model, resolved)

    functions: dict[str, list[str]] = {}
    groups: dict[str, list[str]] = {}
    constraints: dict[str, list[str]] = {}
    timing: dict[str, list[str]] = {}

    for command in model.commands:
        name = command.command.name
        view = option_view(name, [word.text for word in command.options], resolved)
        options = dict(view.options)
        if name == _PIN_ATTRIBUTES:
            for target in _each_target(view.targets):
                functions.setdefault(target, []).extend(
                    f"{option} {value}"
                    for option, value in view.options
                    if option in ("-function", "-value", "-shift_length", "-direction")
                )
                if "-portgroup" in options:
                    groups.setdefault(target, []).append(options["-portgroup"])
        elif name == _PORTGROUP:
            continue
        elif name in (_CONSTRAINT, _CONSTRAINT_REMOVED):
            marker = "removed: " if name == _CONSTRAINT_REMOVED else ""
            detail = _detail(view) or _NO_OPTIONS
            for target in _each_target(view.targets):
                constraints.setdefault(target, []).append(f"{marker}{detail} ({_where(command)})")
        elif name in ("create_clock", "set_input_delay"):
            detail = _detail(view)
            entry = f"{name} {detail}" if detail else name
            for target in _each_target(view.targets):
                timing.setdefault(target, []).append(entry)

    rows: list[PinRow] = []
    for pin in sorted(ports) + sorted(configured - set(ports)):
        rows.append(
            PinRow(
                name=pin,
                boundary=_boundary_text(pin, ports),
                function=tuple(functions.get(pin, ())),
                group=tuple(groups.get(pin, ())),
                constraint=tuple(constraints.get(pin, ())),
                timing=tuple(timing.get(pin, ())),
            )
        )
    return tuple(rows)


def supply_inventory(
    model: SetupDeckModelV1, catalog: CommandCatalog | None = None
) -> tuple[SupplyRow, ...]:
    """One row per declared rail, with the line that removed it when removed.

    Needs no catalog work of its own; it needs §1, so the braced
    ``{vbias\\[[0-3]\\]}`` rail at ``t5_sram_full/input/cfg/supplies.tcl:17``
    stops being discarded as dynamic. Before §1 that row does not exist, which
    makes this table §1's most legible acceptance test.
    """
    resolved = catalog or load_command_catalog()
    removals: dict[tuple[str, str], str] = {}
    by_rail: dict[str, tuple[str, str]] = {}
    for command in model.commands:
        if command.command.name != _SUPPLY_REMOVED:
            continue
        view = option_view(command.command.name, [w.text for w in command.options], resolved)
        design = dict(view.options).get("-design", "")
        where = _where(command)
        for target in view.targets:
            removals[(target, design)] = where
            by_rail[target] = (design, where)

    rows: list[SupplyRow] = []
    for command in model.commands:
        if command.command.name != _SUPPLY:
            continue
        view = option_view(command.command.name, [w.text for w in command.options], resolved)
        options = dict(view.options)
        design = options.get("-design", "")
        for rail in view.targets:
            rows.append(
                SupplyRow(
                    rail=rail,
                    supply_type=options.get("-type", "real"),
                    logic=options.get("-logic", ""),
                    subcircuit=design,
                    status=_supply_status(rail, design, removals, by_rail),
                )
            )
    return tuple(rows)


def _targets(command: NormalizedCommandV1, catalog: CommandCatalog) -> tuple[str, ...]:
    return option_view(
        command.command.name,
        [word.text for word in command.options],
        catalog,
    ).targets


def _each_target(targets: tuple[str, ...]) -> tuple[str, ...]:
    """Flatten braced multi-target words: ``{raddr renable}`` names two pins."""
    return tuple(part for target in targets for part in _split_targets(target))


def _split_targets(target: str) -> tuple[str, ...]:
    return tuple(part for part in target.split() if part)


def _detail(view: OptionView) -> str:
    """One detail cell's arguments: option/value pairs first, then flags.

    Flags used to be dropped here, and the ``or "set"`` fallback that then
    filled the empty cell asserted the opposite of the flag it had just
    discarded: ``set_constraint dout -ignore``
    (``t5_sram_full/input/cfg/constraints.tcl:23``) rendered ``set``.
    ``-ignore``, ``-1hot``, ``-1cold``, ``-01hot``, ``-01cold`` and
    ``-symbolic_static`` are every flag the reviewed ``set_constraint`` spec
    declares, so the inversion covered all of them.
    """
    return " ".join([f"{option} {value}" for option, value in view.options] + list(view.flags))


def _supply_status(
    rail: str,
    design: str,
    removals: Mapping[tuple[str, str], str],
    by_rail: Mapping[str, tuple[str, str]],
) -> str:
    """``declared``, or ``removed`` naming the line that withdrew the rail.

    Keying only on ``(rail, design)`` left a withdrawn rail rendering
    ``declared`` whenever ``-design`` appeared on one of the two commands and
    not the other -- the same failure the constraint column guards against by
    keeping a removed cell instead of deleting it. When either side omits the
    subcircuit the rail name is the only key both sides share, so the match is
    made on it and the disagreement is rendered rather than hidden. Two
    *different* named subcircuits stay ``declared``: those are two instances,
    and a removal in one does not withdraw the rail in the other.
    """
    exact = removals.get((rail, design))
    if exact is not None:
        return f"removed ({exact})"
    near = by_rail.get(rail)
    if near is None:
        return "declared"
    removed_design, where = near
    if design and removed_design:
        return "declared"
    side = "declaration" if design else "removal"
    return f"removed ({where}; -design {design or removed_design} on the {side} only)"


def _boundary_text(pin: str, ports: Mapping[str, HdlPortV1]) -> str:
    """The boundary cell: the port's declaration, or why the row has none."""
    port = _resolve_port(pin, ports)
    if port is None:
        return ABSENT
    declaration = f"{port.direction} {port.width_text or '1'}"
    index = _bit_index(pin)
    declared = _declared_range(port.width_text)
    if index is not None and declared is not None and not declared[0] <= index <= declared[1]:
        return f"{OUT_OF_RANGE}: {declaration}"
    return declaration


def _resolve_port(pin: str, ports: Mapping[str, HdlPortV1]) -> HdlPortV1 | None:
    """The port a pin target names, resolving a bit-select to its bus.

    The row stays keyed on the raw target (D11: normalization is display-only);
    only this lookup falls back to the base name. Without the fallback a
    bit-select of a real bus rendered ``absent``: measured on ``addr[0]`` ..
    ``addr[3]`` against ``addr [3:0]`` in ``t6_intent_full``
    (``cfg/symbols.tcl:36-39``), ``WDATA[7]`` against ``WDATA [7:0]`` in
    ``t2_sram32x8_revB`` and ``DIN[7]`` against ``DIN [7:0]`` in
    ``t2_sram32x8_hand`` -- six fabricated off-boundary rows, and for the two
    ``t2`` decks the only off-boundary row each reported.
    """
    port = ports.get(pin)
    if port is not None:
        return port
    base = _base_name(pin)
    return ports.get(base) if base != pin else None


def _base_name(pin: str) -> str:
    """``addr[0]`` -> ``addr``. A name with no trailing select is unchanged."""
    if not pin.endswith("]"):
        return pin
    opening = pin.rfind("[")
    return pin[:opening] if opening > 0 else pin


def _bit_index(pin: str) -> int | None:
    """The literal index of a single-bit select, or ``None`` if not literal.

    ``ADDR[$addr_msb]`` (``t3_flowgen/input/cfg/pins.tcl:18``) and a part-select
    ``addr[3:0]`` both return ``None``: an index we cannot read is not an index
    we may call out of range.
    """
    if not pin.endswith("]"):
        return None
    opening = pin.rfind("[")
    if opening <= 0:
        return None
    return _decimal(pin[opening + 1 : -1])


def _declared_range(width_text: str | None) -> tuple[int, int] | None:
    """``[7:0]`` -> ``(0, 7)``; a scalar -> ``(0, 0)``. ``None`` when unreadable.

    A missing ``width_text`` is not an unreadable width, it is unambiguously a
    one-bit port -- ``_boundary_text`` reads it exactly that way two lines away
    when it renders ``port.width_text or "1"``. Returning ``None`` here instead
    would decline to say what the module already knows, and ``clk[5]`` on a
    scalar ``clk`` would render as a clean row.
    """
    if width_text is None or not width_text.strip():
        return (0, 0)
    text = width_text.strip()
    if not (text.startswith("[") and text.endswith("]")):
        return None
    left, separator, right = text[1:-1].partition(":")
    if not separator:
        return None
    low, high = _decimal(left), _decimal(right)
    if low is None or high is None:
        return None
    return (min(low, high), max(low, high))


def _decimal(text: str) -> int | None:
    """Parse a bounded decimal literal, or ``None``.

    ``str.isdecimal`` rather than ``str.isdigit``: both accept non-ASCII digits
    but only ``isdecimal`` agrees with what ``int`` accepts, and ``int("\u00b2")``
    raises. Nine digits is the same bound the evidence verifier uses, and it
    keeps ``int`` clear of CPython's digit-conversion limit. Both callers read
    untrusted bytes -- a deck target and a scanned HDL width -- and decision D8
    forbids raising on either.
    """
    stripped = text.strip()
    if not stripped.isdecimal() or len(stripped) > 9:
        return None
    return int(stripped)


def _where(command: NormalizedCommandV1) -> str:
    span = command.command.span
    return f"{span.relative_path}:{span.start_line}"


__all__ = [
    "ABSENT",
    "OUT_OF_RANGE",
    "PinRow",
    "SupplyRow",
    "boundary_pins",
    "configured_pins",
    "off_boundary_pins",
    "out_of_range_pins",
    "pin_inventory",
    "supply_inventory",
]
