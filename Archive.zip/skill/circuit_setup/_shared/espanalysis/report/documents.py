"""Deterministic Markdown documents for one setup-deck build outcome.

An agent reads these with an ordinary confined `read` tool, so `model.md` is an
overview whose size does not grow with the deck and the two detail documents
carry what does. Every section of the overview is always present: an empty one
says so rather than disappearing, because a missing heading and an empty one are
indistinguishable to a reader who only sees the rendered page.

These functions are pure -- a `BuildOutcome` in, document text out. Nothing here
imports orchestration or touches the filesystem; the toolbox writes what they
return. They state what the deterministic build observed and never whether the
deck is acceptable.
"""

from __future__ import annotations

from collections import Counter
from collections.abc import Iterable, Sequence
from typing import get_args

from ..builder import BuildOutcome
from ..catalog import CommandCatalog, load_command_catalog
from ..models import (
    BoundReachedV1,
    CoverageCategory,
    CoverageRecord,
    CyclePlanFactV1,
    DeckDiagnostic,
    HdlStructureV1,
    NormalizedCommandV1,
    SetupDeckModelV1,
    SourceRecordV1,
    SourceSpan,
    VerificationSetupFactV1,
)
from .inventories import ABSENT, OUT_OF_RANGE, pin_inventory, supply_inventory
from .option_view import option_view

OVERVIEW_DOCUMENT_NAME = "model.md"
DIAGNOSTICS_DOCUMENT_NAME = "diagnostics.md"
SOURCES_DOCUMENT_NAME = "model-sources.md"
COMMANDS_DOCUMENT_NAME = "model-commands.md"
BOUNDARY_DOCUMENT_NAME = "model-boundary.md"

_NONE_CAPTURED = "none captured"
_NO_BOUND_REACHED = "no bound reached"
_NO_VALUES = "(none)"
_NO_WIDTH = "(no declared width)"
_ENTRY_PARENT = "(entry)"
_SEVERITIES = ("error", "warning", "info")
# Every coverage class the deterministic analyzer can report. Printing all of
# them, zeros included, distinguishes "checked and found none" from "not
# checked", and makes the overview's coverage section constant-size -- one
# fewer term driving overview growth. The count is deliberately not written
# here: it is whatever `CoverageCategory` declares, and a number in a comment
# is a number that goes stale.
_COVERAGE_CATEGORIES: tuple[str, ...] = tuple(sorted(get_args(CoverageCategory)))
# Each detail document names the bound on *its own* rows. Reporting the whole
# bounds set in both would tell a reader of model-sources.md that a reached
# `command_count` truncated the source list, which it did not. The overview's
# `## Bounds` remains the complete record.
_SOURCES_ROW_BOUND = "file_count"
_COMMANDS_ROW_BOUND = "command_count"
# Deck text is untrusted and lands verbatim in this Markdown, so it is
# neutralized -- but only for what it can actually forge. These documents are
# read as raw bytes by a `read` call and never rendered as HTML, so an HTML
# entity defends nothing and hides exactly the syntax a deck analysis turns on:
# `[5:0]`, `WDATA[7]`, `%s<%d>`.
#
# Escaping was never the injection defence either. A deck comment telling the
# analyst to ignore its instructions carries no special character and always
# passed through untouched; untrusted framing is what answers that. What
# escaping owns is document-structure integrity -- a forged row, column or
# heading, which a reader parsing these documents takes for observed fact.
#
# `_inline` neutralizes the one threat common to every site: ending a line. Every
# rendered value sits mid-line, behind a `- ` bullet, a `## n. ` heading prefix
# or a `| ` cell delimiter, and column 0 is where `#`, `---`, a fence and a
# table's delimiter row acquire their meaning. A value that cannot end its line
# cannot reach column 0, which leaves `#`, backticks, brackets, parentheses and
# angle brackets inert where they stand -- and legible.
#
# What ends a line is decided by the reader, not by CommonMark. These documents
# reach the analyst through `workspace_read`, which splits them with
# `str.splitlines()`, and `map_read_result` then wraps each resulting line in its
# own untrusted delimiters -- so a line only `splitlines()` sees is framed
# exactly like a real one. `str.splitlines()` ends a line on ten characters, not
# two: `\n`, `\v`, `\f`, `\r`, the three C0 separators, NEL, and U+2028/U+2029.
# Neutralizing only `\n` and `\r` left a deck free to write `\v## 9. CODE (error)`
# and forge a diagnostic heading in exactly the shape `_diagnostic_block` writes.
# The set below is the measured one; `_splitlines_terminators` in
# tests/orchestration/test_deck_analysis_documents.py sweeps the whole codepoint
# space and fails if this table ever goes short of it again.
#
# Each takes a stand-in rather than an escape because no escape stops a byte from
# ending a line, and a table row is one line. The seven C0 terminators take the
# Unicode control picture that names them, `chr(0x2400 + codepoint)`; the three
# with no control picture take the closest glyph that names what they replace.
# None can be misread as an escape sequence: writing `\n` instead would be
# indistinguishable from a deck that wrote a backslash and an `n`, and the corpus
# does put a Tcl line continuation -- a backslash, then a newline -- inside a
# command word.
_INLINE_ESCAPES = str.maketrans(
    {
        "\n": "\u240a",  # SYMBOL FOR LINE FEED
        "\v": "\u240b",  # SYMBOL FOR VERTICAL TABULATION
        "\f": "\u240c",  # SYMBOL FOR FORM FEED
        "\r": "\u240d",  # SYMBOL FOR CARRIAGE RETURN
        "\x1c": "\u241c",  # SYMBOL FOR FILE SEPARATOR
        "\x1d": "\u241d",  # SYMBOL FOR GROUP SEPARATOR
        "\x1e": "\u241e",  # SYMBOL FOR RECORD SEPARATOR
        "\x85": "\u2424",  # SYMBOL FOR NEWLINE, for NEXT LINE
        "\u2028": "\u23ce",  # RETURN SYMBOL, for LINE SEPARATOR
        "\u2029": "\u00b6",  # PILCROW SIGN, for PARAGRAPH SEPARATOR
    }
)

# A table cell carries the one threat a list item does not: an unescaped `|`
# opens a column, and a code span does not protect it, because GFM splits cells
# before it parses inline spans. Markdown's own `\|` is the escape, and the
# backslash is escaped with it -- deck text `\|` encoded as `\\|` leaves a pipe
# whose only protection is a parser's backslash lookbehind, and drops the deck's
# backslash on the floor when rendered.
#
# `_table` applies this to every cell it assembles, so no row builder can forget
# it, and applying it after `_inline` cannot double-encode: `_inline` emits only
# the ten stand-ins above, none of which this table reads.
_CELL_ESCAPES = str.maketrans({"\\": "\\\\", "|": "\\|"})


def render_overview_document(outcome: BuildOutcome) -> str:
    """Render the deck overview whose length does not grow with the deck."""
    model = outcome.model
    integrity = outcome.integrity
    header = "\n".join(
        (
            "# Setup deck model",
            "",
            f"- Entry deck: {_entry_deck(model)}",
            f"- Builder: {_inline(integrity.builder_identity)} "
            f"{_inline(integrity.builder_version)}",
            f"- Parser: {_inline(integrity.parser_identity)} {_inline(integrity.parser_version)}",
            f"- Model digest: {outcome.model_digest}",
        )
    )
    sections = (
        header,
        _section("## Inventory", _inventory_lines(outcome)),
        _section("## Verification setup", _fact_lines(model.verification_setup, model.commands)),
        _section("## Cycle plan facts", _fact_lines(model.cycle_plan, model.commands)),
        _section("## HDL structure", _hdl_structure_lines(model.hdl_structure)),
        _section("## Coverage and unresolved", _coverage_lines(model.coverage)),
        _section("## Bounds", _bounds_lines(integrity.bounds_reached)),
        _section("## Detail documents", _detail_document_lines(outcome)),
    )
    return "\n\n".join(sections) + "\n"


def render_boundary_document(outcome: BuildOutcome) -> str:
    """Render the two deck inventories: pins against the boundary, and supplies.

    A detail document rather than an overview section, for the reason the
    overview's own docstring gives: its length must not grow with the deck, and
    a pin table does (``t6_intent_full`` carries 29 rows). The analyst reads this
    the way it reads ``model-commands.md``.

    Both tables describe **the deck**. They replaced the coverage sections
    revision 0019 removed, which described this scanner instead.
    """
    model = outcome.model
    pins = pin_inventory(model)
    supplies = supply_inventory(model)
    off_boundary = sum(1 for row in pins if row.boundary == ABSENT)
    out_of_range = sum(1 for row in pins if row.boundary.startswith(OUT_OF_RANGE))
    header = "\n".join(
        (
            "# Deck boundary",
            "",
            f"- Model digest: {outcome.model_digest}",
            f"- Pins: {_rows(len(pins))}, {off_boundary} off boundary, {out_of_range} out of range",
            f"- Supplies: {_rows(len(supplies))}",
        )
    )
    return (
        "\n\n".join(
            (
                header,
                _section("## Pins", (_pin_inventory_lines(model),)),
                _section("## Supplies", (_supply_inventory_lines(model),)),
            )
        )
        + "\n"
    )


def render_diagnostics_document(outcome: BuildOutcome) -> str:
    """Render every deterministic diagnostic in the deterministic sort order."""
    diagnostics = tuple(sorted(outcome.diagnostics.diagnostics, key=_diagnostic_sort_key))
    header = "\n".join(
        (
            "# Deck diagnostics",
            "",
            f"- Model digest: {outcome.diagnostics.model_digest}",
            f"- {_diagnostic_count_line(diagnostics)}",
        )
    )
    if not diagnostics:
        return f"{header}\n\nResult: no deterministic diagnostic was raised.\n"
    blocks = tuple(
        _diagnostic_block(ordinal, diagnostic)
        for ordinal, diagnostic in enumerate(diagnostics, start=1)
    )
    return "\n\n".join((header, *blocks)) + "\n"


def render_sources_document(outcome: BuildOutcome) -> str:
    """Render one row per reachable source, bounded by the builder's file bound."""
    sources = outcome.model.sources
    header = "\n".join(
        (
            "# Deck sources",
            "",
            f"- Model digest: {outcome.model_digest}",
            f"- Rows: {len(sources)} (one per reachable source)",
            f"- {_row_bound_line(outcome.integrity.bounds_reached, _SOURCES_ROW_BOUND)}",
        )
    )
    table = _table(
        ("Relative path", "Digest", "Role", "Parse status", "Reached from"),
        (_source_row(record) for record in sources),
    )
    return f"{header}\n\n{table}\n"


def render_commands_document(outcome: BuildOutcome) -> str:
    """Render one row per normalized command occurrence, in builder flow order."""
    commands = outcome.model.commands
    header = "\n".join(
        (
            "# Deck commands",
            "",
            f"- Model digest: {outcome.model_digest}",
            f"- Rows: {len(commands)} (one per normalized command occurrence)",
            f"- {_row_bound_line(outcome.integrity.bounds_reached, _COMMANDS_ROW_BOUND)}",
        )
    )
    table = _table(
        ("Flow order", "Command", "Arguments", "Resolution", "Source span"),
        (_command_row(command) for command in commands),
    )
    return f"{header}\n\n{table}\n"


def _section(heading: str, lines: Sequence[str]) -> str:
    """Render one overview section, stating emptiness rather than vanishing."""
    body = "\n".join(lines) if lines else _NONE_CAPTURED
    return f"{heading}\n\n{body}"


def _entry_deck(model: SetupDeckModelV1) -> str:
    """Return the one source no other source reaches: the deck the build entered."""
    for record in model.sources:
        if record.reachability_parent is None:
            return _inline(record.source_ref.relative_path)
    return _NONE_CAPTURED


def _inventory_lines(outcome: BuildOutcome) -> list[str]:
    return [
        f"- Sources: {len(outcome.model.sources)}",
        f"- Commands: {len(outcome.model.commands)}",
        f"- {_diagnostic_count_line(outcome.diagnostics.diagnostics)}",
    ]


def _diagnostic_count_line(diagnostics: Sequence[DeckDiagnostic]) -> str:
    counts = Counter(diagnostic.severity for diagnostic in diagnostics)
    breakdown = ", ".join(f"{severity} {counts[severity]}" for severity in _SEVERITIES)
    return f"Diagnostics: {len(diagnostics)} ({breakdown})"


def _fact_lines(
    facts: Sequence[VerificationSetupFactV1 | CyclePlanFactV1],
    commands: Sequence[NormalizedCommandV1] = (),
) -> list[str]:
    """Render one line per fact, structured by the reviewed option spec.

    A flat comma-join discards the option/value relationship a reader needs:
    ``supply: -i, -design, PRECHARGE_XTOR, -type, virtual`` reads as five peers
    when it is one target and two settings. Values with no reviewed spec stay a
    flat list, which is 114 of the catalog's 205 commands and is the documented
    fallback rather than an error (§3 property 2).
    """
    by_occurrence = {command.command.occurrence_id: command for command in commands}
    catalog = load_command_catalog()
    lines: list[str] = []
    for fact in facts:
        command = by_occurrence.get(fact.command_occurrence_id)
        rendered = (
            _structured_values(command.command.name, fact.values, catalog)
            if command is not None
            else _values(fact.values)
        )
        lines.append(f"- {_inline(fact.kind)}: {rendered} ({_span(fact.span)})")
    return lines


def _structured_values(command: str, values: Sequence[str], catalog: CommandCatalog) -> str:
    view = option_view(command, values, catalog)
    if not view.has_spec:
        return _values(values)
    parts: list[str] = []
    if view.targets:
        parts.append(" ".join(_inline(target) for target in view.targets))
    parts.extend(f"{_inline(option)}={_inline(value)}" for option, value in view.options)
    parts.extend(_inline(flag) for flag in view.flags)
    return " ".join(parts) if parts else _NO_VALUES


def _values(values: Sequence[str]) -> str:
    return ", ".join(_inline(value) for value in values) if values else _NO_VALUES


def _pin_inventory_lines(model: SetupDeckModelV1) -> str:
    """The pin table: every pin the deck names or the boundary exports.

    ``absent`` in the Boundary column is the point of the table. A configured
    pin with no HDL port is the highest-value defect class in a setup deck, and
    this column is the only thing that surfaces it.
    """
    rows = pin_inventory(model)
    if not rows:
        return _NONE_CAPTURED
    return _table(
        ("Pin", "Boundary", "Function", "Group", "Constraint", "Timing"),
        (
            (
                _inline(row.name),
                _inline(row.boundary),
                _join_cell(row.function),
                _join_cell(row.group),
                _join_cell(row.constraint),
                _join_cell(row.timing),
            )
            for row in rows
        ),
    )


def _supply_inventory_lines(model: SetupDeckModelV1) -> str:
    """The supply table: one row per declared rail, removals marked not deleted."""
    rows = supply_inventory(model)
    if not rows:
        return _NONE_CAPTURED
    return _table(
        ("Rail", "Type", "Logic", "Subcircuit", "Status"),
        (
            (
                _inline(row.rail),
                _inline(row.supply_type),
                _inline(row.logic),
                _inline(row.subcircuit) if row.subcircuit else _NO_VALUES,
                _inline(row.status),
            )
            for row in rows
        ),
    )


def _join_cell(values: Sequence[str]) -> str:
    return "; ".join(_inline(value) for value in values) if values else _NO_VALUES


def _hdl_structure_lines(structure: HdlStructureV1 | None) -> list[str]:
    if structure is None:
        return []
    lines = [f"- Selected top: {_selected_top(structure)}"]
    lines.append(f"- Ports: {len(structure.ports) if structure.ports else _NONE_CAPTURED}")
    lines.extend(
        f"  - {_inline(port.name)} {port.direction} {_width(port.width_text)} ({_span(port.span)})"
        for port in structure.ports
    )
    findings = structure.scanner_findings
    lines.append(f"- Scanner findings: {len(findings) if findings else _NONE_CAPTURED}")
    lines.extend(
        f"  - {_inline(finding.code)}: {_inline(finding.detail)} ({_optional_span(finding.span)})"
        for finding in findings
    )
    return lines


def _selected_top(structure: HdlStructureV1) -> str:
    """Name the top, adding its declaration span only when the scanner found one."""
    if structure.selected_top is None:
        return _NONE_CAPTURED
    top = _inline(structure.selected_top)
    if structure.selected_top_span is None:
        return top
    return f"{top} ({_span(structure.selected_top_span)})"


def _width(width_text: str | None) -> str:
    return _inline(width_text) if width_text else _NO_WIDTH


def _coverage_lines(coverage: Sequence[CoverageRecord]) -> list[str]:
    """Report every coverage class with its count, so the section is constant-size."""
    counts = Counter(record.category for record in coverage)
    return [f"- {category}: {counts[category]}" for category in _COVERAGE_CATEGORIES]


def _bounds_lines(bounds: Sequence[BoundReachedV1]) -> list[str]:
    if not bounds:
        return [_NO_BOUND_REACHED]
    return [
        f"- {_inline(bound.name)}: limit {bound.limit}, observed {bound.observed}"
        for bound in bounds
    ]


def _row_bound_line(bounds: Sequence[BoundReachedV1], row_bound: str) -> str:
    """State this document's own row ceiling; it invents no second one."""
    for bound in bounds:
        if bound.name == row_bound:
            return (
                f"Bounds reached: {_inline(bound.name)} "
                f"(limit {bound.limit}, observed {bound.observed})"
            )
    return f"Bounds: {row_bound} not reached"


def _detail_document_lines(outcome: BuildOutcome) -> list[str]:
    model = outcome.model
    return [
        f"- {DIAGNOSTICS_DOCUMENT_NAME}: {_rows(len(outcome.diagnostics.diagnostics))} "
        "(one per deterministic diagnostic)",
        f"- {SOURCES_DOCUMENT_NAME}: {_rows(len(model.sources))} (one per reachable source)",
        f"- {COMMANDS_DOCUMENT_NAME}: {_rows(len(model.commands))} "
        "(one per normalized command occurrence)",
        f"- {BOUNDARY_DOCUMENT_NAME}: {_rows(len(pin_inventory(model)))} "
        "(one per pin the deck names or the boundary exports)",
    ]


def _rows(count: int) -> str:
    return f"{count} row" if count == 1 else f"{count} rows"


def _diagnostic_block(ordinal: int, diagnostic: DeckDiagnostic) -> str:
    lines = [
        f"## {ordinal}. {_inline(diagnostic.code)} ({diagnostic.severity})",
        "",
        f"- Diagnostic ID: {_inline(diagnostic.diagnostic_id)}",
        f"- Message: {_inline(diagnostic.message)}",
        f"- Source span: {_optional_span(diagnostic.span)}",
    ]
    # A diagnostic may carry a source without a span. Naming it then is what
    # keeps a span-less diagnostic locatable; naming it otherwise is noise.
    if diagnostic.source_ref is not None:
        lines.append(f"- Source: {_inline(diagnostic.source_ref.relative_path)}")
    return "\n".join(lines)


def _diagnostic_sort_key(diagnostic: DeckDiagnostic) -> tuple[str, int, str, str]:
    if diagnostic.span is not None:
        return (
            diagnostic.span.relative_path,
            diagnostic.span.start_byte,
            diagnostic.code,
            diagnostic.diagnostic_id,
        )
    if diagnostic.source_ref is not None:
        return (
            diagnostic.source_ref.relative_path,
            -1,
            diagnostic.code,
            diagnostic.diagnostic_id,
        )
    return ("", -1, diagnostic.code, diagnostic.diagnostic_id)


def _source_row(record: SourceRecordV1) -> tuple[str, ...]:
    parent = record.reachability_parent
    return (
        _inline(record.source_ref.relative_path),
        record.source_ref.content_digest,
        _inline(record.role),
        _inline(record.parse_status),
        _inline(parent.relative_path) if parent is not None else _ENTRY_PARENT,
    )


def _command_row(command: NormalizedCommandV1) -> tuple[str, ...]:
    arguments = command.command.words[1:]
    return (
        str(command.flow_order),
        _inline(command.command.name),
        " ".join(_inline(word.text) for word in arguments) if arguments else _NO_VALUES,
        command.resolution_state,
        _span(command.command.span),
    )


def _table(headers: Sequence[str], rows: Iterable[Sequence[str]]) -> str:
    """Assemble the table, escaping in every cell what would open a column."""
    lines = [
        "| " + " | ".join(_cell(header) for header in headers) + " |",
        "|" + "|".join("---" for _ in headers) + "|",
    ]
    lines.extend("| " + " | ".join(_cell(value) for value in row) + " |" for row in rows)
    return "\n".join(lines)


def _span(span: SourceSpan) -> str:
    return f"{_inline(span.relative_path)}:{span.start_line}-{span.end_line}"


def _optional_span(span: SourceSpan | None) -> str:
    return _span(span) if span is not None else _NONE_CAPTURED


def _inline(value: str) -> str:
    """Neutralize the line breaks that would let deck text forge structure."""
    return value.translate(_INLINE_ESCAPES)


def _cell(value: str) -> str:
    """Escape what would open a new column in an already-inlined cell value."""
    return value.translate(_CELL_ESCAPES)


__all__ = [
    "COMMANDS_DOCUMENT_NAME",
    "DIAGNOSTICS_DOCUMENT_NAME",
    "OVERVIEW_DOCUMENT_NAME",
    "SOURCES_DOCUMENT_NAME",
    "render_commands_document",
    "render_diagnostics_document",
    "render_overview_document",
    "render_sources_document",
]
