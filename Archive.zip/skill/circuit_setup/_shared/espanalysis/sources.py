"""Literal, bounded source discovery for static setup-deck analysis.

This module deliberately owns no filesystem capability. Callers provide a
confined reader port; the locator validates literal paths before requesting a
read and verifies every consumed content identity returned by that port.
"""

from __future__ import annotations

from collections.abc import Awaitable
from dataclasses import dataclass
from hashlib import sha256
from posixpath import dirname, normpath
from typing import Literal, Protocol, final

from .models import (
    CoverageRecord,
    DeckDiagnostic,
    ScannedCommand,
    SourceRef,
    SourceSpan,
)
from .tcl import TclScanResult, scan_tcl


@dataclass(frozen=True, slots=True)
class SourceLocatorBounds:
    """Finite Descriptor-owned source-discovery limits."""

    max_file_bytes: int = 128 * 1024
    max_total_bytes: int = 1 * 1024 * 1024
    max_files: int = 128
    max_source_depth: int = 16
    max_commands: int = 1_024
    max_filelist_nesting: int = 8


@dataclass(frozen=True, slots=True)
class SourceRead:
    """Reader-port result. Production ports may return a structural equivalent."""

    relative_path: str
    data: bytes
    digest: str


class SourceReadPayload(Protocol):
    """Structural source-reader result accepted by the pure domain locator."""

    relative_path: str
    data: bytes
    digest: str


class SourceReader(Protocol):
    """The only capability needed by the source locator."""

    def read(
        self,
        relative_path: str,
        /,
    ) -> SourceReadPayload | Awaitable[SourceReadPayload]:
        """Return or await a read with a path, bytes, and SHA-256 identity."""
        ...


@dataclass(frozen=True, slots=True)
class SourceRecord:
    """One content-identified source consumed during literal discovery."""

    source_ref: SourceRef
    role: Literal["deck", "source-deck", "filelist", "rtl"]
    reachability_parent: SourceRef | None
    parse_status: Literal["scanned", "opaque"]


@dataclass(frozen=True, slots=True)
class SourceEdge:
    """A literal edge admitted after lexical canonicalization."""

    parent: SourceRef
    child_path: str
    role: Literal["source", "filelist", "rtl"]
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ReadVerilogOption:
    """A raw option fact; it carries no include, macro, or compiler semantics."""

    token: str
    argument: str | None
    span: SourceSpan


@dataclass(frozen=True, slots=True)
class ReadVerilogInvocation:
    """A VCS-style vector plus facts discovered from that literal invocation."""

    arguments: tuple[str, ...]
    span: SourceSpan
    source_ref: SourceRef
    base_directory: str
    sources: tuple[SourceRef, ...]
    options: tuple[ReadVerilogOption, ...]


@dataclass(frozen=True, slots=True)
class SourceGraphResult:
    """Source-locator output; ``complete`` is false only for internal failures."""

    sources: tuple[SourceRecord, ...]
    edges: tuple[SourceEdge, ...]
    read_verilog: tuple[ReadVerilogInvocation, ...]
    option_facts: tuple[ReadVerilogOption, ...]
    coverage: tuple[CoverageRecord, ...]
    diagnostics: tuple[DeckDiagnostic, ...]
    complete: bool
    bounds_reached: tuple[str, ...]


_OPTIONS_WITH_ARGUMENT = frozenset(
    {"-f", "-I", "-D", "-vcs", "-work", "-top", "-v", "-y", "-libext", "-timescale"}
)


DEFAULT_SOURCE_LOCATOR_BOUNDS = SourceLocatorBounds()


async def locate_sources(
    entry_path: str,
    reader: SourceReader,
    /,
    *,
    bounds: SourceLocatorBounds | None = None,
) -> SourceGraphResult:
    """Build the static source graph rooted at one literal entry deck."""
    state = _LocatorState(
        reader,
        DEFAULT_SOURCE_LOCATOR_BOUNDS if bounds is None else bounds,
    )
    try:
        entry = _canonical_relative("", entry_path)
        if entry is None:
            state.record_root_escape(None, None)
        else:
            _ = await state.consume_tcl(entry, None, "deck", 0, None)
    except Exception as error:  # An implementation failure is never partial success.
        state.complete = False
        state.diagnostics.append(
            state.make_diagnostic(
                "ESP-F3-SOURCE-LOCATOR-FAILURE",
                "error",
                f"Source locator failed: {type(error).__name__}",
                None,
                None,
                coverage_impact=False,
            )
        )
    return state.result()


build_source_graph = locate_sources


@final
class _LocatorState:
    def __init__(self, reader: SourceReader, bounds: SourceLocatorBounds) -> None:
        self.reader = reader
        self.bounds = bounds
        self.sources: list[SourceRecord] = []
        self.edges: list[SourceEdge] = []
        self.invocations: list[ReadVerilogInvocation] = []
        self.option_facts: list[ReadVerilogOption] = []
        self.coverage: list[CoverageRecord] = []
        self.diagnostics: list[DeckDiagnostic] = []
        self.cache: dict[str, SourceRead] = {}
        self.tcl_stack: list[str] = []
        self.processed_tcl_paths: set[str] = set()
        self.filelist_stack: list[str] = []
        self.total_bytes = 0
        self.complete = True
        self.bounds_reached: list[str] = []
        self.entry_base = ""

    async def consume_tcl(
        self,
        path: str,
        parent: SourceRef | None,
        role: Literal["deck", "source-deck"],
        depth: int,
        edge_span: SourceSpan | None,
    ) -> SourceRef | None:
        if self._source_depth_exceeded(depth, edge_span, parent):
            return None
        if path in self.tcl_stack:
            self._cycle("Tcl source cycle", edge_span, parent)
            return None
        read = await self._read(path, edge_span, parent)
        if read is None:
            return None
        source_ref = SourceRef(relative_path=read.relative_path, content_digest=read.digest)
        if depth == 0:
            self.entry_base = dirname(path)
        self._record_source(source_ref, role, parent, "scanned")
        if path in self.processed_tcl_paths:
            return source_ref
        self.processed_tcl_paths.add(path)
        self.tcl_stack.append(path)
        try:
            scanned = scan_tcl(source_ref, read.data, max_commands=self.bounds.max_commands)
            self._merge_scan(scanned)
            if scanned.command_limit_reached:
                self._bound("command_count", edge_span, parent)
                return source_ref
            for command in scanned.commands:
                if command.name == "source":
                    await self._follow_source(command, source_ref, depth)
                elif command.name == "read_verilog":
                    await self._read_verilog(command, source_ref, depth)
        finally:
            _ = self.tcl_stack.pop()
        return source_ref

    async def _follow_source(self, command: ScannedCommand, parent: SourceRef, depth: int) -> None:
        if len(command.words) != 2:
            return
        word = command.words[1]
        if word.dynamic:
            self._dynamic(word.span, parent, "Dynamic Tcl source path")
            return
        child = self._resolve(parent.relative_path, word.text, word.span, parent)
        if child is None:
            return
        self.edges.append(SourceEdge(parent, child, "source", word.span))
        _ = await self.consume_tcl(child, parent, "source-deck", depth + 1, word.span)

    async def _read_verilog(self, command: ScannedCommand, parent: SourceRef, depth: int) -> None:
        words = command.words[1:]
        options: list[ReadVerilogOption] = []
        sources: list[SourceRef] = []
        index = 0
        while index < len(words):
            word = words[index]
            token = word.text
            if word.dynamic:
                self._dynamic(word.span, parent, "Dynamic read_verilog argument", rv=True)
                index += 1
            elif token in _OPTIONS_WITH_ARGUMENT:
                argument = words[index + 1] if index + 1 < len(words) else None
                if argument is None:
                    option = ReadVerilogOption(token, None, word.span)
                    options.append(option)
                    self.option_facts.append(option)
                    self._invalid_option(word.span, parent, token)
                    index += 1
                else:
                    option = ReadVerilogOption(token, argument.text, word.span)
                    options.append(option)
                    self.option_facts.append(option)
                    if argument.dynamic:
                        self._dynamic(argument.span, parent, "Dynamic read_verilog option", rv=True)
                    elif token == "-f":
                        child = self._resolve(
                            parent.relative_path,
                            argument.text,
                            argument.span,
                            parent,
                        )
                        if child is not None:
                            self.edges.append(SourceEdge(parent, child, "filelist", argument.span))
                            sources.extend(
                                await self.consume_filelist(
                                    child,
                                    parent,
                                    depth + 1,
                                    1,
                                    argument.span,
                                )
                            )
                    elif _contains_ascii_whitespace(argument.text):
                        sources.extend(
                            await self._embedded_option_vector(
                                token,
                                argument.text,
                                argument.span,
                                parent,
                                depth,
                            )
                        )
                    index += 2
            elif token.startswith("+incdir+") or token.startswith("+define+"):
                option = ReadVerilogOption(token, None, word.span)
                options.append(option)
                self.option_facts.append(option)
                index += 1
            elif token.startswith("-"):
                option = ReadVerilogOption(token, None, word.span)
                options.append(option)
                self.option_facts.append(option)
                index += 1
            else:
                child = self._resolve(parent.relative_path, token, word.span, parent)
                if child is not None:
                    self.edges.append(SourceEdge(parent, child, "rtl", word.span))
                    discovered = await self.consume_rtl(child, parent, depth + 1, word.span)
                    if discovered is not None:
                        sources.append(discovered)
                index += 1
        self.invocations.append(
            ReadVerilogInvocation(
                arguments=tuple(word.text for word in words),
                span=command.span,
                source_ref=parent,
                base_directory=dirname(parent.relative_path),
                sources=tuple(sources),
                options=tuple(options),
            )
        )

    async def _embedded_option_vector(
        self,
        option: str,
        value: str,
        span: SourceSpan,
        parent: SourceRef,
        depth: int,
    ) -> tuple[SourceRef, ...]:
        if '"' in value or "'" in value or "\\" in value:
            self.coverage.append(
                CoverageRecord(
                    category="FILELIST-UNSUPPORTED-FORM",
                    span=span,
                    source_ref=parent,
                    detail="Embedded option vector has unsupported quote or escape",
                )
            )
            return ()
        tokens = _ascii_whitespace_tokens(value)
        first_token = tokens[0] if tokens else ""
        if not tokens or (
            first_token not in {"-f", "-I", "-D"}
            and not first_token.startswith(("+incdir+", "+define+"))
        ):
            return ()
        self.coverage.append(
            CoverageRecord(
                category="RV-EMBEDDED-OPTION-VECTOR",
                span=span,
                source_ref=parent,
                detail=f"Embedded option vector from {option}",
            )
        )
        sources: list[SourceRef] = []
        index = 0
        while index < len(tokens):
            token = tokens[index]
            if token == "-f" and index + 1 < len(tokens):
                child = _canonical_relative(dirname(parent.relative_path), tokens[index + 1])
                if child is None:
                    self.record_root_escape(span, parent)
                else:
                    self.edges.append(SourceEdge(parent, child, "filelist", span))
                    sources.extend(await self.consume_filelist(child, parent, depth + 1, 1, span))
                index += 2
            elif token in {"-I", "-D"} and index + 1 < len(tokens):
                self.option_facts.append(ReadVerilogOption(token, tokens[index + 1], span))
                index += 2
            elif token.startswith(("+incdir+", "+define+")):
                self.option_facts.append(ReadVerilogOption(token, None, span))
                index += 1
            else:
                index += 1
        return tuple(sources)

    async def consume_filelist(
        self, path: str, parent: SourceRef, depth: int, nesting: int, edge_span: SourceSpan
    ) -> tuple[SourceRef, ...]:
        if nesting > self.bounds.max_filelist_nesting:
            self._filelist_depth(edge_span, parent)
            return ()
        if self._source_depth_exceeded(depth, edge_span, parent):
            return ()
        if path in self.filelist_stack:
            self._filelist_cycle(edge_span, parent)
            return ()
        read = await self._read(path, edge_span, parent)
        if read is None:
            return ()
        source_ref = SourceRef(relative_path=read.relative_path, content_digest=read.digest)
        self._record_source(source_ref, "filelist", parent, "opaque")
        self.filelist_stack.append(path)
        sources: list[SourceRef] = []
        try:
            for start, raw_line in _lines(read.data):
                line = raw_line.strip(b" \t\r\n")
                if not line or line.startswith(b"#") or line.startswith(b"//"):
                    continue
                span = _span(path, start, start + len(raw_line), read.data)
                text = line.decode("utf-8", errors="replace")
                if text.startswith("-f ") and _simple_two_token(text):
                    child = self._resolve(path, text.split()[1], span, source_ref)
                    if child is not None:
                        self.edges.append(SourceEdge(source_ref, child, "filelist", span))
                        sources.extend(
                            await self.consume_filelist(
                                child,
                                source_ref,
                                depth + 1,
                                nesting + 1,
                                span,
                            )
                        )
                elif text.startswith("+incdir+") or text.startswith("+define+"):
                    self.option_facts.append(ReadVerilogOption(text, None, span))
                elif (text.startswith("-I ") or text.startswith("-D ")) and _simple_two_token(text):
                    token, argument = text.split()
                    self.option_facts.append(ReadVerilogOption(token, argument, span))
                elif _simple_filelist_source(text):
                    child = self._resolve(path, text, span, source_ref)
                    if child is not None:
                        self.edges.append(SourceEdge(source_ref, child, "rtl", span))
                        discovered = await self.consume_rtl(child, source_ref, depth + 1, span)
                        if discovered is not None:
                            sources.append(discovered)
                else:
                    self.coverage.append(
                        CoverageRecord(
                            category="FILELIST-UNSUPPORTED-FORM",
                            span=span,
                            source_ref=source_ref,
                            detail="Unsupported filelist line form",
                        )
                    )
        finally:
            _ = self.filelist_stack.pop()
        return tuple(sources)

    async def consume_rtl(
        self, path: str, parent: SourceRef, depth: int, edge_span: SourceSpan
    ) -> SourceRef | None:
        if self._source_depth_exceeded(depth, edge_span, parent):
            return None
        read = await self._read(path, edge_span, parent)
        if read is None:
            return None
        source_ref = SourceRef(relative_path=read.relative_path, content_digest=read.digest)
        self._record_source(source_ref, "rtl", parent, "opaque")
        return source_ref

    async def _read(
        self, path: str, span: SourceSpan | None, parent: SourceRef | None
    ) -> SourceRead | None:
        cached = self.cache.get(path)
        if cached is not None:
            return cached
        if len(self.cache) >= self.bounds.max_files:
            self._bound("file_count", span, parent)
            return None
        try:
            raw = self.reader.read(path)
            result: SourceReadPayload
            if isinstance(raw, Awaitable):
                result = await raw
            else:
                result = raw
            read = SourceRead(
                result.relative_path,
                result.data,
                result.digest,
            )
        except Exception as error:
            self._reader_error(error, span, parent)
            return None
        if read.relative_path != path or sha256(read.data).hexdigest() != read.digest:
            self.complete = False
            self.diagnostics.append(
                self.make_diagnostic(
                    "ESP-F3-SOURCE-IDENTITY-MISMATCH",
                    "error",
                    "Reader content identity does not match consumed bytes",
                    span,
                    parent,
                    coverage_impact=False,
                )
            )
            return None
        if len(read.data) > self.bounds.max_file_bytes:
            self._bound("file_bytes", span, parent)
            return None
        if self.total_bytes + len(read.data) > self.bounds.max_total_bytes:
            self._bound("aggregate_bytes", span, parent)
            return None
        self.total_bytes += len(read.data)
        self.cache[path] = read
        return read

    def _record_source(
        self,
        source_ref: SourceRef,
        role: Literal["deck", "source-deck", "filelist", "rtl"],
        parent: SourceRef | None,
        status: Literal["scanned", "opaque"],
    ) -> None:
        if not any(
            record.source_ref.relative_path == source_ref.relative_path for record in self.sources
        ):
            self.sources.append(SourceRecord(source_ref, role, parent, status))

    def _merge_scan(self, scanned: TclScanResult) -> None:
        self.coverage.extend(scanned.coverage)
        self.diagnostics.extend(scanned.diagnostics)

    def _resolve(
        self, parent_path: str, token: str, span: SourceSpan, parent: SourceRef
    ) -> str | None:
        if "$" in token or "[" in token or "]" in token:
            self._dynamic(span, parent, "Dynamic source path")
            return None
        result = _canonical_relative(dirname(parent_path), token)
        if result is None:
            self.record_root_escape(span, parent)
        return result

    def _reader_error(
        self, error: Exception, span: SourceSpan | None, parent: SourceRef | None
    ) -> None:
        code = str(getattr(error, "code", ""))
        if code == "not_found" or isinstance(error, FileNotFoundError):
            self.coverage.append(
                CoverageRecord(
                    category="SOURCE-MISSING",
                    span=span,
                    source_ref=parent,
                    detail="Declared source does not exist",
                )
            )
            diagnostic_code, message = "AA-SRC-MISSING", "Declared source does not exist"
        elif code == "outside_root":
            self.record_root_escape(span, parent)
            return
        elif code == "symlink_denied":
            self.coverage.append(
                CoverageRecord(
                    category="SOURCE-SYMLINK",
                    span=span,
                    source_ref=parent,
                    detail="Declared source is a symlink",
                )
            )
            diagnostic_code = "ESP-F3-SOURCE-SYMLINK"
            message = "Declared source is a symlink"
        elif code == "budget_exhausted":
            self._bound("reader_budget", span, parent)
            return
        else:
            self.complete = False
            diagnostic_code = "ESP-F3-SOURCE-READ-FAILED"
            message = f"Source reader failed: {type(error).__name__}"
        self.diagnostics.append(
            self.make_diagnostic(
                diagnostic_code,
                "warning" if diagnostic_code.startswith("AA-") else "error",
                message,
                span,
                parent,
                coverage_impact=diagnostic_code.startswith("AA-"),
            )
        )

    def record_root_escape(
        self,
        span: SourceSpan | None,
        parent: SourceRef | None,
    ) -> None:
        self.coverage.append(
            CoverageRecord(
                category="SOURCE-ROOT-ESCAPE",
                span=span,
                source_ref=parent,
                detail="Declared source escapes the registered root",
            )
        )
        self.diagnostics.append(
            self.make_diagnostic(
                "AA-SRC-OUTSIDE-ROOT",
                "warning",
                "Declared source escapes the registered root",
                span,
                parent,
                coverage_impact=True,
            )
        )

    def _dynamic(
        self,
        span: SourceSpan,
        parent: SourceRef,
        detail: str,
        *,
        rv: bool = False,
    ) -> None:
        self.coverage.append(
            CoverageRecord(
                category="RV-DYNAMIC-ARGUMENT" if rv else "TCL-DYNAMIC",
                span=span,
                source_ref=parent,
                detail=detail,
            )
        )
        self.diagnostics.append(
            self.make_diagnostic(
                "AA-SRC-DYNAMIC",
                "warning",
                detail,
                span,
                parent,
                coverage_impact=True,
            )
        )

    def _cycle(self, message: str, span: SourceSpan | None, parent: SourceRef | None) -> None:
        self.diagnostics.append(
            self.make_diagnostic(
                "AA-SRC-CYCLE",
                "warning",
                message,
                span,
                parent,
                coverage_impact=True,
            )
        )

    def _filelist_cycle(self, span: SourceSpan, parent: SourceRef) -> None:
        self.coverage.append(
            CoverageRecord(
                category="FILELIST-CYCLE",
                span=span,
                source_ref=parent,
                detail="Filelist inclusion cycle",
            )
        )
        self._cycle("Filelist inclusion cycle", span, parent)

    def _source_depth_exceeded(
        self, depth: int, span: SourceSpan | None, parent: SourceRef | None
    ) -> bool:
        if depth <= self.bounds.max_source_depth:
            return False
        self.diagnostics.append(
            self.make_diagnostic(
                "AA-SRC-DEPTH-EXCEEDED",
                "warning",
                "Source depth limit reached",
                span,
                parent,
                coverage_impact=True,
            )
        )
        self._bound("source_depth", span, parent, emit_diagnostic=False)
        return True

    def _filelist_depth(self, span: SourceSpan, parent: SourceRef) -> None:
        self.coverage.append(
            CoverageRecord(
                category="FILELIST-DEPTH",
                span=span,
                source_ref=parent,
                detail="Filelist nesting limit reached",
            )
        )
        self._bound("filelist_nesting", span, parent)

    def _invalid_option(self, span: SourceSpan, parent: SourceRef, token: str) -> None:
        self.diagnostics.append(
            self.make_diagnostic(
                "ESP-F3-READ-VERILOG-OPTION",
                "warning",
                f"Missing argument for {token}",
                span,
                parent,
                coverage_impact=True,
            )
        )

    def _bound(
        self,
        name: str,
        span: SourceSpan | None,
        parent: SourceRef | None,
        *,
        emit_diagnostic: bool = True,
    ) -> None:
        if name in self.bounds_reached:
            return
        self.bounds_reached.append(name)
        value = {
            "aggregate_bytes": self.bounds.max_total_bytes,
            "command_count": self.bounds.max_commands,
            "file_bytes": self.bounds.max_file_bytes,
            "file_count": self.bounds.max_files,
            "filelist_nesting": self.bounds.max_filelist_nesting,
            "source_depth": self.bounds.max_source_depth,
        }.get(name, "reader")
        detail = f"Descriptor bound reached: {name}={value}"
        self.coverage.append(
            CoverageRecord(
                category="BOUNDS-LIMIT-REACHED",
                span=span,
                source_ref=parent,
                detail=detail,
            )
        )
        if emit_diagnostic:
            self.diagnostics.append(
                self.make_diagnostic(
                    "ESP-F3-SOURCE-BOUND",
                    "warning",
                    detail,
                    span,
                    parent,
                    coverage_impact=True,
                )
            )

    def make_diagnostic(
        self,
        code: str,
        severity: Literal["error", "warning", "info"],
        message: str,
        span: SourceSpan | None,
        source_ref: SourceRef | None,
        *,
        coverage_impact: bool,
    ) -> DeckDiagnostic:
        location = (
            "none" if span is None else f"{span.relative_path}:{span.start_byte}:{span.end_byte}"
        )
        diagnostic_id = sha256(f"{code}:{location}".encode()).hexdigest()[:16]
        return DeckDiagnostic(
            diagnostic_id=f"diag-{diagnostic_id}",
            code=code,
            severity=severity,
            message=message,
            span=span,
            source_ref=source_ref,
            remediation_class=None,
            coverage_impact=coverage_impact,
        )

    def result(self) -> SourceGraphResult:
        return SourceGraphResult(
            sources=tuple(self.sources),
            edges=tuple(self.edges),
            read_verilog=tuple(self.invocations),
            option_facts=tuple(self.option_facts),
            coverage=tuple(self.coverage),
            diagnostics=tuple(self.diagnostics),
            complete=self.complete,
            bounds_reached=tuple(self.bounds_reached),
        )


def _canonical_relative(base: str, token: str) -> str | None:
    if not token or token.startswith(("/", "~", "\\")) or (len(token) > 1 and token[1] == ":"):
        return None
    candidate = normpath(f"{base}/{token}" if base else token)
    if candidate in {".", ".."} or candidate.startswith("../") or candidate.startswith("/"):
        return None
    return candidate


def _contains_ascii_whitespace(value: str) -> bool:
    return any(character in " \t\n\r\f\v" for character in value)


def _ascii_whitespace_tokens(value: str) -> tuple[str, ...]:
    tokens: list[str] = []
    current: list[str] = []
    for character in value:
        if character in " \t\n\r\f\v":
            if current:
                tokens.append("".join(current))
                current.clear()
        else:
            current.append(character)
    if current:
        tokens.append("".join(current))
    return tuple(tokens)


def _simple_two_token(text: str) -> bool:
    markers = ('"', "'", "*", "[", "]", "$")
    return len(text.split()) == 2 and not any(marker in text for marker in markers)


def _simple_filelist_source(text: str) -> bool:
    return (
        len(text.split()) == 1
        and not text.startswith("-")
        and not any(marker in text for marker in ('"', "'", "*", "[", "]", "$"))
    )


def _lines(data: bytes) -> tuple[tuple[int, bytes], ...]:
    lines: list[tuple[int, bytes]] = []
    offset = 0
    for raw in data.splitlines(keepends=True):
        lines.append((offset, raw))
        offset += len(raw)
    if offset < len(data):
        lines.append((offset, data[offset:]))
    return tuple(lines)


def _span(path: str, start: int, end: int, data: bytes) -> SourceSpan:
    return SourceSpan(
        relative_path=path,
        start_byte=start,
        end_byte=end,
        start_line=data.count(b"\n", 0, start) + 1,
        end_line=data.count(b"\n", 0, max(start, end - 1)) + 1,
    )


__all__ = [
    "ReadVerilogInvocation",
    "ReadVerilogOption",
    "SourceEdge",
    "SourceGraphResult",
    "SourceLocatorBounds",
    "SourceRead",
    "SourceReader",
    "SourceRecord",
    "build_source_graph",
    "locate_sources",
]
