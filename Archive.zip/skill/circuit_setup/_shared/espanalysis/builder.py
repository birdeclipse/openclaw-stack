"""Deterministic public facade for static setup-deck model construction."""

from __future__ import annotations

from collections.abc import Sequence
from dataclasses import dataclass
from hashlib import sha256
from inspect import isawaitable
from typing import Protocol, cast

from .canonical import content_digest
from .catalog import CommandCatalog, load_command_catalog
from .diagnostics import analyze_diagnostics
from .hdl import HdlScanBounds, HdlScanResult, scan_top_ports
from .lifters import LiftResult, lift_commands
from .models import (
    BUILDER_IDENTITY,
    PARSER_IDENTITY,
    BoundReachedV1,
    CoverageRecord,
    DeckDiagnostic,
    DeckDiagnosticsV1,
    HdlPortV1,
    HdlScannerFindingV1,
    HdlStructureV1,
    ScannedCommand,
    SetupDeckModelV1,
    SetupModelIntegrityV1,
    SourceRecordV1,
    SourceRef,
)
from .sources import SourceGraphResult, SourceLocatorBounds, SourceReader, build_source_graph
from .tcl import scan_tcl

BUILDER_VERSION = "1"
PARSER_VERSION = "1"


class BuildFailure(RuntimeError):
    """Raised when a builder/scanner failure prevents a complete model."""


@dataclass(frozen=True, slots=True)
class BuildBounds:
    """Finite limits for all parser surfaces in one model build."""

    max_file_bytes: int = 128 * 1024
    max_total_bytes: int = 1 * 1024 * 1024
    max_files: int = 128
    max_source_depth: int = 16
    max_commands: int = 1_024
    max_filelist_nesting: int = 8
    max_hdl_files: int = 64
    max_hdl_total_bytes: int = 512 * 1024
    max_hdl_file_bytes: int = 128 * 1024

    def __post_init__(self) -> None:
        if (
            min(
                self.max_file_bytes,
                self.max_total_bytes,
                self.max_files,
                self.max_source_depth,
                self.max_commands,
                self.max_filelist_nesting,
                self.max_hdl_files,
                self.max_hdl_total_bytes,
                self.max_hdl_file_bytes,
            )
            < 1
        ):
            raise ValueError("setup model build bounds must be positive")

    def source_locator_bounds(self) -> SourceLocatorBounds:
        """Return the source-graph bounds corresponding to this build."""
        return SourceLocatorBounds(
            max_file_bytes=self.max_file_bytes,
            max_total_bytes=self.max_total_bytes,
            max_files=self.max_files,
            max_source_depth=self.max_source_depth,
            max_commands=self.max_commands,
            max_filelist_nesting=self.max_filelist_nesting,
        )

    def hdl_scan_bounds(self) -> HdlScanBounds:
        """Return the HDL scanner bounds corresponding to this build."""
        return HdlScanBounds(
            max_files=self.max_hdl_files,
            max_total_bytes=self.max_hdl_total_bytes,
            max_file_bytes=self.max_hdl_file_bytes,
        )


@dataclass(frozen=True, slots=True)
class BuildOutcome:
    """All digest-bound F3 documents and their canonical encodings."""

    model: SetupDeckModelV1
    diagnostics: DeckDiagnosticsV1
    integrity: SetupModelIntegrityV1
    model_bytes: bytes
    diagnostics_bytes: bytes
    integrity_bytes: bytes
    model_digest: str
    diagnostics_digest: str
    integrity_digest: str


@dataclass(slots=True)
class _RecordingReader:
    """Reader adapter retaining the first port failure after scanners recover it."""

    delegate: SourceReader
    error: Exception | None = None

    async def read(self, relative_path: str, /) -> _ReaderPayload:
        try:
            raw = self.delegate.read(relative_path)
            result = await raw if isawaitable(raw) else raw
        except Exception as error:
            if self.error is None:
                self.error = error
            raise
        return cast(_ReaderPayload, result)


class _ReaderPayload(Protocol):
    relative_path: str
    data: bytes
    digest: str


async def build_setup_deck_model(
    *,
    entry_deck: str,
    reader: SourceReader,
    bounds: BuildBounds | None = None,
    catalog: CommandCatalog | None = None,
) -> BuildOutcome:
    """Build all F3 documents from confined source-reader bytes only.

    A scanner or builder exception is deliberately terminal: the facade never
    converts an internal failure into a partial successful document.
    """
    recording_reader = _RecordingReader(reader)
    selected_bounds = BuildBounds() if bounds is None else bounds
    selected_catalog = load_command_catalog() if catalog is None else catalog
    try:
        entry_ref, entry_bytes = await _read_entry(entry_deck, recording_reader)
        # This explicit entry scan is the facade's first fail-closed parser
        # boundary. The source graph performs the authoritative traversal.
        _ = scan_tcl(entry_ref, entry_bytes, max_commands=selected_bounds.max_commands)
        graph = await build_source_graph(
            entry_deck,
            recording_reader,
            bounds=selected_bounds.source_locator_bounds(),
        )
        if not graph.complete:
            raise BuildFailure("source graph did not complete")

        commands = await _commands_from_graph(
            graph, recording_reader, selected_bounds, entry_ref, entry_bytes
        )
        lifted = _lift(commands, selected_catalog)
        selected_top = _literal_selected_top(commands)
        hdl_result = await _scan_hdl(graph, recording_reader, selected_top, selected_bounds)
        model = _assemble_model(graph, lifted, hdl_result)
        model_bytes = model.to_canonical_bytes()
        model_digest = content_digest(model_bytes)
        diagnostics = DeckDiagnosticsV1(
            model_digest=model_digest,
            diagnostics=_diagnose(graph, model.coverage, lifted, selected_catalog),
        )
        integrity = SetupModelIntegrityV1(
            model_digest=model_digest,
            captured_sources=tuple(
                sorted(
                    (record.source_ref for record in graph.sources),
                    key=lambda source: source.relative_path,
                )
            ),
            builder_identity=BUILDER_IDENTITY,
            builder_version=BUILDER_VERSION,
            parser_identity=PARSER_IDENTITY,
            parser_version=PARSER_VERSION,
            bounds_reached=_bounds_reached(graph, hdl_result, selected_bounds),
            validation_results=(
                "canonical-model-digest",
                "complete-source-graph",
                "schema-valid",
            ),
        )
    except BuildFailure as error:
        if recording_reader.error is not None and error.__cause__ is None:
            raise BuildFailure(str(error)) from recording_reader.error
        raise
    except Exception as error:
        raise BuildFailure(f"setup model build failed: {type(error).__name__}: {error}") from error

    diagnostics_bytes = diagnostics.to_canonical_bytes()
    integrity_bytes = integrity.to_canonical_bytes()
    return BuildOutcome(
        model=model,
        diagnostics=diagnostics,
        integrity=integrity,
        model_bytes=model_bytes,
        diagnostics_bytes=diagnostics_bytes,
        integrity_bytes=integrity_bytes,
        model_digest=model_digest,
        diagnostics_digest=content_digest(diagnostics_bytes),
        integrity_digest=content_digest(integrity_bytes),
    )


async def _read_entry(entry_deck: str, reader: SourceReader) -> tuple[SourceRef, bytes]:
    raw = reader.read(entry_deck)
    result = await raw if isawaitable(raw) else raw
    payload = cast(_ReaderPayload, result)
    if payload.relative_path != entry_deck or sha256(payload.data).hexdigest() != payload.digest:
        raise BuildFailure("entry deck reader identity does not match consumed bytes")
    return (
        SourceRef(relative_path=payload.relative_path, content_digest=payload.digest),
        payload.data,
    )


async def _commands_from_graph(
    graph: SourceGraphResult,
    reader: SourceReader,
    bounds: BuildBounds,
    entry_ref: SourceRef,
    entry_bytes: bytes,
) -> tuple[ScannedCommand, ...]:
    commands: list[ScannedCommand] = []
    for record in graph.sources:
        if record.parse_status != "scanned":
            continue
        if record.source_ref == entry_ref:
            scanned = scan_tcl(entry_ref, entry_bytes, max_commands=bounds.max_commands)
        else:
            raw = reader.read(record.source_ref.relative_path)
            payload = await raw if isawaitable(raw) else raw
            source = cast(_ReaderPayload, payload)
            if (
                source.relative_path != record.source_ref.relative_path
                or source.digest != record.source_ref.content_digest
                or sha256(source.data).hexdigest() != source.digest
            ):
                raise BuildFailure("captured source changed during model build")
            scanned = scan_tcl(record.source_ref, source.data, max_commands=bounds.max_commands)
        commands.extend(scanned.commands)
    return tuple(commands)


def _lift(commands: tuple[ScannedCommand, ...], catalog: CommandCatalog) -> LiftResult:
    """Lift only catalog-specified literal facts from normalized occurrences."""
    return lift_commands(commands, catalog=catalog)


def _literal_selected_top(commands: Sequence[ScannedCommand]) -> str | None:
    """Return the literal reference top, otherwise the last unqualified top."""
    reference_top: str | None = None
    unqualified_top: str | None = None
    for command in commands:
        if command.name != "set_top_design" or not command.anchor_safe:
            continue
        arguments = command.words[1:]
        if not arguments or any(word.dynamic for word in arguments):
            continue
        positional = tuple(word.text for word in arguments if not word.text.startswith("-"))
        if len(positional) != 1:
            continue
        if any(word.text == "-r" for word in arguments):
            reference_top = positional[0]
        elif not any(word.text == "-i" for word in arguments):
            unqualified_top = positional[0]
    return reference_top or unqualified_top


async def _scan_hdl(
    graph: SourceGraphResult,
    reader: SourceReader,
    selected_top: str | None,
    bounds: BuildBounds,
) -> HdlScanResult:
    return await scan_top_ports(
        sources=tuple(record.source_ref for record in graph.sources if record.role == "rtl"),
        selected_top=selected_top,
        reader=reader,
        bounds=bounds.hdl_scan_bounds(),
    )


def _assemble_model(
    graph: SourceGraphResult,
    lifted: LiftResult,
    hdl: HdlScanResult,
) -> SetupDeckModelV1:
    lifted_result = lifted
    coverage = tuple((*graph.coverage, *lifted_result.coverage, *hdl.coverage))
    return SetupDeckModelV1(
        sources=tuple(
            SourceRecordV1(
                source_ref=record.source_ref,
                role=record.role,
                parse_status=record.parse_status,
                reachability_parent=record.reachability_parent,
            )
            for record in graph.sources
        ),
        commands=lifted_result.normalized_commands,
        verification_setup=lifted_result.verification_setup,
        cycle_plan=lifted_result.cycle_plan,
        hdl_structure=_hdl_structure(hdl),
        coverage=coverage,
    )


def _hdl_structure(result: HdlScanResult) -> HdlStructureV1 | None:
    if result.selected_module is None and not result.coverage:
        return None
    return HdlStructureV1(
        selected_top=result.selected_module,
        ports=tuple(
            HdlPortV1(
                name=port.name,
                direction=port.direction,
                width_text=port.declared_width_text,
                span=port.span,
            )
            for port in result.ports
        ),
        scanner_findings=tuple(
            HdlScannerFindingV1(
                code=coverage.category,
                detail=coverage.detail,
                span=coverage.span,
                source_ref=coverage.source_ref,
            )
            for coverage in result.coverage
        ),
    )


def _diagnose(
    graph: SourceGraphResult,
    coverage: tuple[CoverageRecord, ...],
    lifted: LiftResult,
    catalog: CommandCatalog,
) -> tuple[DeckDiagnostic, ...]:
    return analyze_diagnostics(
        commands=lifted.normalized_commands,
        coverage=coverage,
        verification_setup=lifted.verification_setup,
        cycle_plan=lifted.cycle_plan,
        prior_diagnostics=graph.diagnostics,
        catalog=catalog,
    )


def _bounds_reached(
    graph: SourceGraphResult,
    hdl: HdlScanResult,
    bounds: BuildBounds,
) -> tuple[BoundReachedV1, ...]:
    values = {
        "aggregate_bytes": bounds.max_total_bytes,
        "command_count": bounds.max_commands,
        "file_bytes": bounds.max_file_bytes,
        "file_count": bounds.max_files,
        "filelist_nesting": bounds.max_filelist_nesting,
        "reader_budget": 0,
        "source_depth": bounds.max_source_depth,
    }
    source_bounds = tuple(
        BoundReachedV1(name=name, limit=values.get(name, 0), observed=values.get(name, 0))
        for name in sorted(graph.bounds_reached)
    )
    hdl_bounds = tuple(
        BoundReachedV1(name=f"hdl:{index}", limit=0, observed=0)
        for index, coverage in enumerate(hdl.coverage)
        if coverage.category == "BOUNDS-LIMIT-REACHED"
    )
    return (*source_bounds, *hdl_bounds)


__all__ = [
    "BUILDER_VERSION",
    "PARSER_VERSION",
    "BuildBounds",
    "BuildFailure",
    "BuildOutcome",
    "build_setup_deck_model",
]
