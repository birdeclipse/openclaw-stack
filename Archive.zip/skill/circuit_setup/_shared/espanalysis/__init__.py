"""Deterministic core of the ``circuit-deck-analysis`` skill.

A 1:1 port of the legacy ESP deck-analysis deterministic modules --
``setup_analysis/{models,catalog,lifters,tcl,hdl,sources,builder,
diagnostics}.py`` and ``setup_analysis/report/*.py`` in the legacy checkout --
with three seams replaced:

* ``canonical_json_bytes`` is vendored into :mod:`espanalysis.canonical`
  (legacy ``_canonical.py``, renamed only) instead of being reachable as a
  private module name;
* the reviewed command catalog is loaded from ``_shared/data/`` -- one copy
  shared with :mod:`espdeck.emit` -- instead of a package-local ``data/``;
* the kernel's claim-bound ``ModuleSourcePort`` is replaced by
  :mod:`espanalysis.reader`, which is that port with the claim/projection seam
  removed and the same confinement, bounds, symlink denial, and mutation
  checks kept.

Nothing here imports the legacy package. :mod:`espanalysis.cli` is the single
entry point the opencode tool wrappers spawn; every other module keeps its
legacy shape so oracle review stays a file-by-file diff.

:mod:`espanalysis.models` is also the home of the §10.3 shared records --
``SetupDeckModelV1``, ``HdlPortV1``, ``SourceRef``, ``SourceSpan``,
``CyclePlanFactV1`` -- which ``espcycle`` consumes as
``from espanalysis.models import ...``; ``_shared`` is one ``sys.path`` root, so
that import works from the sibling package without a records package.

pydantic v2 is the one third-party dependency (MIGRATION.md section 10.2); the
CLI carries a PEP 723 header so ``uv run`` provisions it, and a system install
satisfies it too.

Submodules are imported explicitly (``from espanalysis.builder import ...``);
this file deliberately imports none of them, so spawning the CLI costs one
module rather than the whole package. The legacy ``__init__`` re-exported the
public facade eagerly; that shape existed for in-process importers, and this
package has none.
"""
