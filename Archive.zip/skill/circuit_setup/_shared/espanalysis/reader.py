"""The filesystem seam: work-root-confined, bounded, identity-checked reads.

This is the one module of :mod:`espanalysis` that is *not* a 1:1 file port,
because the thing it replaces was not one legacy file. The legacy runtime handed
the pure locator a ``ClaimBoundModuleSourcePort``
(``orchestration/runtime/module_source.py``) layered over
``workspace_tools.confine.confine_relative`` and
``workspace_tools.safe_fs.read_confined_bytes``. Three layers, one capability:
"read this work-root-relative path, bounded, and tell me if it moved".

Everything those three layers did that is a property of the *deck* is kept:

* a path must be relative, must not contain ``..``, and must resolve inside the
  work root (``outside_root``);
* no component of the declared path may be a symlink, checked lexically before
  any open (``symlink_denied``), and the resolved components are opened with
  ``O_NOFOLLOW`` so a component swapped mid-walk cannot redirect the read;
* the opened parent directory is revalidated by ``(dev, ino)`` against the
  lexical parent, and the file handle is revalidated by ``(dev, ino, size,
  mtime_ns)`` across the read (``mutated``);
* per-file, aggregate-byte, file-count and wall-clock budgets, all finite, all
  refusing with ``budget_exhausted``;
* a path read once and gone, or read twice with two digests, is ``mutated`` --
  the property the source graph's captured digests hang off;
* the run's own fact ledger is protected: its bytes are never deck evidence
  (``protected_path``).

Everything those layers did that is a property of the *kernel* is dropped: the
claim token, the execution projection, and therefore the ``stale_claim`` code.
There is no Attempt to be stale relative to -- one CLI invocation is the whole
lifetime -- and a claim seam with no claim would be a shim.

``read`` is synchronous. The pure locator's ``SourceReader`` protocol accepts a
payload or an awaitable one (``sources.SourceReader``) and the builder resolves
either with ``inspect.isawaitable``, so a synchronous port is the honest shape
for a synchronous filesystem: the legacy port was ``async`` because it awaited
the execution projection, which is exactly the seam that is gone.
"""

from __future__ import annotations

import errno
import os
import stat
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from time import monotonic
from typing import Final, Literal, NoReturn, final

#: Closed failure taxonomy, the legacy ``ModuleSourceErrorCode`` minus
#: ``stale_claim``. ``cli.py`` maps these onto its refusal vocabulary, so adding
#: one is a wire-contract change.
SourceErrorCode = Literal[
    "not_found",
    "outside_root",
    "symlink_denied",
    "protected_path",
    "budget_exhausted",
    "mutated",
    "unreadable",
]

#: The deck-analysis Module's own budget, ported verbatim from
#: ``setup_analysis/runtime/catalog.py:_SETUP_ANALYZE_SOURCE_BUDGET``. The four
#: numbers deliberately agree with ``builder.BuildBounds``: the reader is the
#: outer bound and the scanners are the inner one, and a reader looser than the
#: scanners would let a build fail on a bound the reader had already granted.
MAX_FILE_BYTES: Final[int] = 128 * 1024
MAX_TOTAL_BYTES: Final[int] = 1024 * 1024
MAX_FILES: Final[int] = 128
MAX_DURATION_SECONDS: Final[float] = 30.0

_READ_CHUNK_BYTES: Final[int] = 64 * 1024
_DIRECTORY_FLAGS: Final[int] = (
    os.O_RDONLY | getattr(os, "O_DIRECTORY", 0) | getattr(os, "O_CLOEXEC", 0)
)
_FILE_FLAGS: Final[int] = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0)
_NOFOLLOW: Final[int] = getattr(os, "O_NOFOLLOW", 0)


@dataclass(frozen=True, slots=True)
class SourceError(Exception):
    """One coded refusal from the source seam."""

    code: SourceErrorCode
    message: str


@dataclass(frozen=True, slots=True)
class SourceRead:
    """One content-identified byte sequence. Structurally a ``SourceReadPayload``."""

    relative_path: str
    data: bytes
    digest: str
    bytes_read: int


@dataclass(frozen=True, slots=True)
class SourceBudget:
    """Finite limits for one whole CLI invocation's reads."""

    max_file_bytes: int = MAX_FILE_BYTES
    max_total_bytes: int = MAX_TOTAL_BYTES
    max_files: int = MAX_FILES
    max_duration_seconds: float = MAX_DURATION_SECONDS

    def __post_init__(self) -> None:
        if min(self.max_file_bytes, self.max_total_bytes, self.max_files) < 1:
            raise ValueError("source budget limits must be positive")
        if self.max_duration_seconds <= 0:
            raise ValueError("source budget duration must be positive")


@final
class WorkRootSourceReader:
    """The concrete ``SourceReader`` the deck analyzer runs on.

    One instance serves one CLI invocation: the budget, the digest map, and the
    duration clock are all per-instance, which is what makes ``mutated`` and
    ``budget_exhausted`` mean what they say.
    """

    __slots__ = (
        "_budget",
        "_digests",
        "_files_read",
        "_protected",
        "_started_at",
        "_total_bytes",
        "_work_root",
    )

    def __init__(
        self,
        work_root: Path,
        *,
        budget: SourceBudget | None = None,
        protected: frozenset[Path] | None = None,
    ) -> None:
        self._work_root = Path(work_root).resolve()
        self._budget = SourceBudget() if budget is None else budget
        self._protected = frozenset(
            path.resolve() for path in (protected if protected is not None else ())
        )
        self._started_at = monotonic()
        self._total_bytes = 0
        self._files_read: set[str] = set()
        self._digests: dict[str, str] = {}

    @property
    def work_root(self) -> Path:
        return self._work_root

    def read(self, relative_path: str, /) -> SourceRead:
        """Return one bounded, confined, identity-checked read, or raise."""

        self._ensure_within_duration()
        relative = self._confined_relative(relative_path)
        is_new_file = relative not in self._files_read
        if is_new_file and len(self._files_read) >= self._budget.max_files:
            self._raise("budget_exhausted", "the source file-count budget is exhausted")
        remaining = self._budget.max_total_bytes - self._total_bytes
        if remaining <= 0:
            self._raise("budget_exhausted", "the aggregate source byte budget is exhausted")
        raw = self._read_bytes(relative, max_bytes=min(self._budget.max_file_bytes, remaining))
        self._ensure_within_duration()
        digest = sha256(raw).hexdigest()
        prior_digest = self._digests.get(relative)
        if prior_digest is not None and prior_digest != digest:
            self._raise("mutated", "a source changed while the deck was being read")
        bytes_read = len(raw)
        if bytes_read > self._budget.max_file_bytes or bytes_read > remaining:
            self._raise("budget_exhausted", "the source byte budget is exhausted")
        self._files_read.add(relative)
        self._digests[relative] = digest
        self._total_bytes += bytes_read
        return SourceRead(
            relative_path=relative,
            data=raw,
            digest=digest,
            bytes_read=bytes_read,
        )

    def line_count(self, relative_path: str, /) -> int:
        """Total lines in one confined file, for the citation gate.

        Counted over the whole file rather than a delivered page, which is the
        number the gate needs: a citation into line 900 of a 1000-line file
        resolves even though no reader ever paged that far. This deliberately
        does not spend the read budget -- a citation probe is not deck evidence,
        and letting a model's prose exhaust the analyzer's byte budget would
        make the two share a resource they do not share.
        """

        relative = self._confined_relative(relative_path)
        raw = self._read_bytes(relative, max_bytes=self._budget.max_file_bytes)
        if not raw:
            return 0
        count = raw.count(b"\n")
        return count if raw.endswith(b"\n") else count + 1

    # ---- confinement -------------------------------------------------

    def _confined_relative(self, relative_path: str) -> str:
        """Resolve one declared path to its canonical work-root-relative form."""

        if not relative_path or relative_path.startswith(("/", "~")):
            self._raise("outside_root", "a source path must be relative to the work root")
        parts = Path(relative_path).parts
        if ".." in parts:
            self._raise("outside_root", "a source path escapes the work root")
        self._deny_lexical_symlinks(parts)
        candidate = (self._work_root / relative_path).resolve()
        try:
            relative = candidate.relative_to(self._work_root).as_posix()
        except ValueError:
            self._raise("outside_root", "a source path escapes the work root")
        if candidate in self._protected:
            self._raise("protected_path", "that path is protected")
        return relative

    def _deny_lexical_symlinks(self, parts: tuple[str, ...]) -> None:
        """Refuse a symlink in any declared component, before any open.

        Lexical and eager on purpose: ``resolve`` below would happily follow a
        link that lands back inside the root, and a deck whose source resolves
        through a link is a source-integrity fact the analyst must see rather
        than a path to normalize away.
        """

        candidate = self._work_root
        for part in parts:
            candidate = candidate / part
            try:
                if stat.S_ISLNK(candidate.lstat().st_mode):
                    self._raise("symlink_denied", "a source path contains a symlink")
            except FileNotFoundError:
                return

    # ---- bounded read ------------------------------------------------

    def _read_bytes(self, relative: str, *, max_bytes: int) -> bytes:
        """Open the resolved components with ``O_NOFOLLOW`` and read them once.

        The property worth having is that the path did not change between
        resolution and open, and that is what ``O_NOFOLLOW`` on resolved
        components plus the identity revalidation below deliver.
        """

        target = self._work_root / relative
        parts = target.parts
        if len(parts) < 2:
            self._raise("unreadable", "a source path must name a file")
        if not _NOFOLLOW:
            self._raise("unreadable", "safe source reads require O_NOFOLLOW")

        descriptors: list[int] = []
        try:
            descriptors.append(self._opened(parts[0], _DIRECTORY_FLAGS, dir_fd=None))
            for component in parts[1:-1]:
                descriptors.append(
                    self._opened(component, _DIRECTORY_FLAGS, dir_fd=descriptors[-1])
                )
            parent_fd = descriptors[-1]
            # The TOCTOU half of the guarantee: the directory this walk arrived
            # at is still the one resolution named. A component swapped for a
            # symlink is caught by O_NOFOLLOW above; one swapped for a different
            # real directory is caught here.
            try:
                opened_parent = os.fstat(parent_fd)
                lexical_parent = target.parent.lstat()
            except OSError as error:
                raise self._os_error(error) from error
            if not stat.S_ISDIR(opened_parent.st_mode) or not _same_identity(
                opened_parent, lexical_parent
            ):
                self._raise("mutated", "a source path changed while it was being opened")
            file_fd = self._opened(parts[-1], _FILE_FLAGS, dir_fd=parent_fd)
            try:
                # Kind and size are checked on the raw descriptor, before
                # ``fdopen``: a directory descriptor makes ``fdopen`` raise
                # ``IsADirectoryError``, which would escape this method as an
                # uncoded OSError instead of the "not a regular file" fact.
                before = os.fstat(file_fd)
                if not stat.S_ISREG(before.st_mode):
                    # A FIFO, socket, device, or directory is a fact about the
                    # named path, not a confinement boundary.
                    self._raise("unreadable", "a source path is not a regular file")
                if before.st_size > max_bytes:
                    self._raise("budget_exhausted", "a source exceeds the per-file read budget")
                handle = os.fdopen(file_fd, "rb", closefd=True)
            except BaseException:
                os.close(file_fd)
                raise
            with handle:
                chunks: list[bytes] = []
                byte_count = 0
                while True:
                    chunk = handle.read(_READ_CHUNK_BYTES)
                    if not chunk:
                        break
                    byte_count += len(chunk)
                    if byte_count > max_bytes:
                        self._raise("budget_exhausted", "a source exceeds the per-file read budget")
                    chunks.append(chunk)
                after = os.fstat(handle.fileno())
                if (
                    not _same_identity(before, after)
                    or before.st_size != after.st_size
                    or before.st_mtime_ns != after.st_mtime_ns
                ):
                    self._raise("mutated", "a source changed while it was being read")
            return b"".join(chunks)
        finally:
            for descriptor in reversed(descriptors):
                os.close(descriptor)

    def _opened(self, component: str, flags: int, *, dir_fd: int | None) -> int:
        try:
            if dir_fd is None:
                return os.open(component, flags | _NOFOLLOW)
            return os.open(component, flags | _NOFOLLOW, dir_fd=dir_fd)
        except OSError as error:
            raise self._os_error(error) from error

    # ---- refusal -----------------------------------------------------

    def _ensure_within_duration(self) -> None:
        if monotonic() - self._started_at > self._budget.max_duration_seconds:
            self._raise("budget_exhausted", "the source read duration budget is exhausted")

    @staticmethod
    def _os_error(error: OSError) -> SourceError:
        """Classify one ``OSError`` from the confined walk.

        ``ELOOP``/``ENOTDIR`` is what ``O_NOFOLLOW`` reports for a component
        that became a symlink between resolution and open, which is a link, not
        an unreadable file.
        """

        if isinstance(error, FileNotFoundError):
            return SourceError("not_found", "the named path does not exist under the work root")
        if isinstance(error, NotADirectoryError) or error.errno in _LINK_ERRNOS:
            return SourceError("symlink_denied", "a source path changed into a link while opening")
        return SourceError("unreadable", "a source could not be opened safely")

    @staticmethod
    def _raise(code: SourceErrorCode, message: str) -> NoReturn:
        raise SourceError(code, message)


def _same_identity(left: os.stat_result, right: os.stat_result) -> bool:
    return (left.st_dev, left.st_ino) == (right.st_dev, right.st_ino)


#: What ``O_NOFOLLOW`` reports for a component that became a symlink between
#: resolution and open. ``ENOTDIR`` arrives as ``NotADirectoryError`` and is
#: matched by class above.
_LINK_ERRNOS: Final[frozenset[int]] = frozenset({errno.ELOOP})


__all__ = [
    "MAX_DURATION_SECONDS",
    "MAX_FILES",
    "MAX_FILE_BYTES",
    "MAX_TOTAL_BYTES",
    "SourceBudget",
    "SourceError",
    "SourceErrorCode",
    "SourceRead",
    "WorkRootSourceReader",
]
