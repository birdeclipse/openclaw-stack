"""The evidence catalog: the CITATION MENU a survey serves to the planner.

One namespace, allocated in one place, so a ref a reader resolves is the ref
the survey minted. Nothing here enforces anything: the catalog is a menu of
citations the planner may quote in the ``plan.md`` prose it writes itself, and
resolving one is what a READER does when checking a claim -- the interrogator's
adversarial review, or a human reading the document. There is no gate on the
other end of a ref any more (MIGRATION.md section 13.11), which is why the
allocator no longer takes carried context or a finding set: those existed to
number refs for a review round that a hard-failing checker then scored.

Ref formats are frozen -- ``survey.md`` prints them verbatim and a published
``plan.md`` quotes them, so a renumbering would silently invalidate documents
already written:

```
pin:<PIN_NAME>    one per inventory pin; the constraint target AND citable evidence
cycle_fact:<n>    n = 0-based index into PreparedCorpusV3.cycle_facts
fact:<fact_id>    DeclaredDesignFactV1.fact_id
directive:<n>     n = 0-based index into PreparedCorpusV3.directives
```

Deterministic ordering: the allocator walks its inputs in their own stable
tuple order, so an identical corpus always produces a byte-identical catalog --
which is what makes the catalog printable into a published survey report.
"""

from __future__ import annotations

from typing import Literal

from pydantic import Field

from espanalysis.models import SourceSpan

from .corpus import PreparedCorpusV3
from .models import _CycleModel

_EvidenceKind = Literal["cycle_fact", "fact", "directive", "pin"]


def pin_ref(name: str) -> str:
    """Return the canonical ``pin:<PIN_NAME>`` ref for one pin name."""
    return f"pin:{name}"


def _indexed_ref(kind: str, index: int) -> str:
    """Mint ``kind:index`` while guarding the frozen 0-based convention."""
    if index < 0:
        raise ValueError(f"{kind} ref is 0-based, got {index}")
    return f"{kind}:{index}"


def cycle_fact_ref(index: int) -> str:
    """Return the canonical 0-based ``cycle_fact:<n>`` evidence ref."""
    return _indexed_ref("cycle_fact", index)


def directive_ref(index: int) -> str:
    """Return the canonical 0-based ``directive:<n>`` evidence ref."""
    return _indexed_ref("directive", index)


def fact_ref(fact_id: str) -> str:
    """Return the canonical ``fact:<fact_id>`` evidence ref."""
    return f"fact:{fact_id}"


class EvidenceEntryV2(_CycleModel):
    """One allocated, resolvable evidence reference and the text/span it names."""

    ref: str = Field(min_length=1, max_length=280)
    kind: _EvidenceKind
    text: str = Field(min_length=1, max_length=4096)
    span: SourceSpan | None = None


class EvidenceCatalogV2(_CycleModel):
    """The complete, deterministically ordered evidence catalog for one corpus."""

    entries: tuple[EvidenceEntryV2, ...] = ()


def allocate_evidence_catalog(corpus: PreparedCorpusV3) -> EvidenceCatalogV2:
    """Allocate the complete evidence catalog for one prepared corpus."""
    entries: list[EvidenceEntryV2] = []
    for index, fact in enumerate(corpus.cycle_facts):
        entries.append(
            EvidenceEntryV2(
                ref=cycle_fact_ref(index),
                kind="cycle_fact",
                text=f"{fact.table_identity}: {fact.kind}({', '.join(fact.values)})",
                span=fact.span,
            )
        )
    seen_fact_ids: set[str] = set()
    for fact in corpus.declared_facts:
        if fact.fact_id in seen_fact_ids:
            continue
        seen_fact_ids.add(fact.fact_id)
        entries.append(
            EvidenceEntryV2(
                ref=fact_ref(fact.fact_id),
                kind="fact",
                text=fact.statement,
                span=fact.excerpt,
            )
        )
    for index, directive in enumerate(corpus.directives):
        entries.append(
            EvidenceEntryV2(ref=directive_ref(index), kind="directive", text=directive, span=None)
        )
    # Pins are evidence, not just constraint targets: every inventory entry came
    # from an evidence-carrying ledger fact, and both the planner docs and the
    # survey report teach ``pin:<NAME>`` as citable. Trial-2 live testing caught
    # the gap where the docs taught it and this allocator did not honor it.
    for pin in corpus.pin_inventory:
        entries.append(
            EvidenceEntryV2(
                ref=pin_ref(pin.name),
                kind="pin",
                text=f"{pin.name} ({pin.direction})",
                span=None,
            )
        )
    return EvidenceCatalogV2(entries=tuple(entries))


def resolve_evidence_ref(catalog: EvidenceCatalogV2, ref: str) -> EvidenceEntryV2 | None:
    """Resolve one evidence ref string against an allocated catalog, or ``None``.

    The reader's half of the contract. A ``None`` means "this citation names
    nothing in the served corpus", which is a finding for whoever is reviewing
    the document -- not a refusal any tool raises.
    """
    for entry in catalog.entries:
        if entry.ref == ref:
            return entry
    return None


__all__ = [
    "EvidenceCatalogV2",
    "EvidenceEntryV2",
    "allocate_evidence_catalog",
    "cycle_fact_ref",
    "directive_ref",
    "fact_ref",
    "pin_ref",
    "resolve_evidence_ref",
]
