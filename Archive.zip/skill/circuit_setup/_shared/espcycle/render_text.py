"""Markdown-safe text neutralization for the one trusted document left.

``survey.md`` is the only Markdown ``espcycle`` still writes: ``plan.md``,
``review.md`` and the cross-corner reports are prose the planner and the
interrogator author themselves (MIGRATION.md section 13.11), so the deterministic
renderers that used to own this helper are gone. It lands in a module of its own
rather than in ``cli.py`` because it is pure and has no business importing the
ledger: anything that wants to put an evidence sentence, a pin name or a corner
slug into a table cell can reach it without pulling in ``espdeck``, pydantic
adapters and the whole wire seam.

The concern is real and not cosmetic: a roster ``reason`` quotes a Verification
Directive verbatim, and a directive is user text. A backtick or a bracket in it
would otherwise close a code span or open a link in a document a human reads as
trusted output.
"""

from __future__ import annotations

from html import escape
from typing import Final

_MARKDOWN_CONTROL_ESCAPES: Final[dict[int, str]] = str.maketrans(
    {
        "#": "&#35;",
        "`": "&#96;",
        "[": "&#91;",
        "]": "&#93;",
        "(": "&#40;",
        ")": "&#41;",
    }
)


def neutralize_inline(value: str) -> str:
    """Encode Markdown controls and HTML delimiters without introducing markup."""
    single_line = value.replace("\r", "&#13;").replace("\n", "&#10;")
    return escape(single_line, quote=False).translate(_MARKDOWN_CONTROL_ESCAPES)


__all__ = ["neutralize_inline"]
