"""Canonical serialization owned by the cycle-planning domain package."""

from __future__ import annotations

import json
from hashlib import sha256
from typing import Any


def canonical_json_bytes(value: Any) -> bytes:
    """Return deterministic UTF-8 JSON bytes for a JSON-compatible value."""
    return json.dumps(
        value,
        allow_nan=False,
        ensure_ascii=False,
        separators=(",", ":"),
        sort_keys=True,
    ).encode("utf-8")


def content_digest(data: bytes) -> str:
    """Return the SHA-256 hexadecimal digest for exact content bytes."""
    return sha256(data).hexdigest()
