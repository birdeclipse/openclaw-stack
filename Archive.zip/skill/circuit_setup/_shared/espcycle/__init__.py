"""Public cycle-plan schema and deterministic-layer facade.

Trimmed to the surviving layers (MIGRATION.md section 13.11). Twelve modules
left this package with the deterministic gate layer -- ``gates``, ``checkers``,
``archetypes``, ``applicability``, ``prediction``, ``reconcile``, ``render``,
``outcomes``, ``review``, ``unresolved``, ``context``, ``provenance`` -- and
every name they exported went with them: the V2 proposal/review schema graph,
the A/A/A archetype tables, the finding codes, the coverage prediction, the
markdown renderers, the cross-corner reconciliation types.

What is left is the EVIDENCE half of the skill, which is the half that was
never a gate:

* ``canonical`` / ``models`` / ``corpus`` -- the fact schemas and the prepared
  evidence corpus assembled from the shared Design Fact Ledger.
* ``survey`` -- the deterministic Corner Roster rules over that corpus.
* ``corner_roster`` -- the ``function_corner`` fact seam: the open corner
  vocabulary, its slug rule, and the live-roster lookup.
* ``refs`` -- the Evidence catalog: the citation menu a survey serves and a
  reader resolves against.
* ``render_text`` -- Markdown neutralization for ``survey.md``, the one trusted
  document this package still writes.

``plan.md``, ``review.md`` and the cross-corner reporting are now prose the
planner and interrogator agents author, governed by the skill's ``guide.md``
rather than by a schema a checker scores. Legacy ADR 0037 reached that
conclusion once already ("document loops over schema gates"); trial-2 live
testing re-proved it when a buggy gate spun the planner for 27 turns.

Port note (MIGRATION.md section 10), retained because it explains two names:

* ``._canonical`` is ``.canonical`` -- the leading underscore said "private to
  this package", which was already false and is doubly false now that
  ``espdeck`` and ``espanalysis`` each carry a sibling ``canonical`` under the
  same ``_shared`` root.
* ``corner_roster`` joins the facade. It was ``runtime/corner_roster.py``,
  outside the package, because the kernel's toolbox shell reached it from
  ``runtime/``; that shell is gone (replaced by ``tool/corner.ts`` +
  ``espcycle.cli``) and the module is now an ordinary package member.
* ``spec_extract`` left it, with the markdown intake it served (ADR 0043
  amendment). ``survey`` assembles the corpus from the shared ledger's ``pin``
  / ``operation`` / ``plan_scalar`` rows, so the module that guessed a pin
  table out of prose has no producer left. ``PreparedCorpusV2`` became
  ``PreparedCorpusV3``.
"""

from .canonical import canonical_json_bytes, content_digest
from .corner_roster import (
    CORNER_FACT_KIND,
    CORNER_ORIGIN,
    Corner,
    CornerRetractAction,
    LogFunctionCornerFactAction,
    corner_names,
    is_safe_slug,
    roster,
)
from .corpus import (
    CycleFactRecordV2,
    PinRecordV1,
    PreparedCorpusV3,
    corpus_digest,
    mint_declared_fact,
    prepare_corpus,
)
from .models import (
    BUILTIN_CORNERS,
    CORNER_ROSTER_CAP,
    CORNER_SLUG_MAX_CHARS,
    CORNER_SLUG_PATTERN,
    CUSTOM_CORNER_CAP,
    BoundedText,
    CornerKind,
    CornerRosterEntryV1,
    CornerRosterV1,
    CornerSlug,
    DeclaredDesignFactV1,
    DesignSpecExcerptV1,
    declared_design_fact_id,
)
from .refs import (
    EvidenceCatalogV2,
    EvidenceEntryV2,
    allocate_evidence_catalog,
    cycle_fact_ref,
    directive_ref,
    fact_ref,
    pin_ref,
    resolve_evidence_ref,
)
from .render_text import neutralize_inline
from .survey import (
    CORNER_DIRECTIVE_KEYWORDS,
    CORNER_RECOMMENDATION_PRIORITY,
    FACT_CORNER_IMPLICATIONS,
    PIN_CANDIDATE_TOKENS,
    CustomCorner,
    derive_corner_roster,
    recommend_corners,
)

__all__ = [
    "BUILTIN_CORNERS",
    "CORNER_DIRECTIVE_KEYWORDS",
    "CORNER_FACT_KIND",
    "CORNER_ORIGIN",
    "CORNER_RECOMMENDATION_PRIORITY",
    "CORNER_ROSTER_CAP",
    "CORNER_SLUG_MAX_CHARS",
    "CORNER_SLUG_PATTERN",
    "CUSTOM_CORNER_CAP",
    "FACT_CORNER_IMPLICATIONS",
    "PIN_CANDIDATE_TOKENS",
    "BoundedText",
    "Corner",
    "CornerKind",
    "CornerRetractAction",
    "CornerRosterEntryV1",
    "CornerRosterV1",
    "CornerSlug",
    "CustomCorner",
    "CycleFactRecordV2",
    "DeclaredDesignFactV1",
    "DesignSpecExcerptV1",
    "EvidenceCatalogV2",
    "EvidenceEntryV2",
    "LogFunctionCornerFactAction",
    "PinRecordV1",
    "PreparedCorpusV3",
    "allocate_evidence_catalog",
    "canonical_json_bytes",
    "content_digest",
    "corner_names",
    "corpus_digest",
    "cycle_fact_ref",
    "declared_design_fact_id",
    "derive_corner_roster",
    "directive_ref",
    "fact_ref",
    "is_safe_slug",
    "mint_declared_fact",
    "neutralize_inline",
    "pin_ref",
    "prepare_corpus",
    "recommend_corners",
    "resolve_evidence_ref",
    "roster",
]
