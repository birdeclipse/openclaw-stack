#!/usr/bin/env python3
# /// script
# requires-python = ">=3.12"
# dependencies = ["pydantic>=2,<3"]
# ///
"""JSON-on-stdin entry point for the ``espcycle`` deterministic core.

    echo '{"workdir": "...", "run": "r1", "directives": ["verify the read"]}' \\
        | python3 cli.py survey

Five verbs, one wire contract with ``espdeck``/``espanalysis`` (MIGRATION.md
section 9.4): a JSON object on stdin, a single ``{ok, message, data, refusal}``
object on stdout, **exit 0 for every domain refusal**, non-zero only for a
harness defect (an unknown verb, unparseable stdin, a non-object payload).

    operation_log   append a BATCH of ``operation`` facts -- truth-table rows
    scalar_log      append a BATCH of ``plan_scalar`` facts -- cycle-arithmetic
                    numbers, always ``declared``
    survey          shared ledger -> corpus -> the deterministic Corner Roster
                    report, published with the corpus that produced it
    corner_log      append a BATCH of ``function_corner`` facts to the ledger
    corner_retract  retract one, keeping the row and the reason

**Provision, not gating** (MIGRATION.md section 13.11). There used to be three
more verbs -- ``check``, ``render``, ``reconcile`` -- and a JSON proposal
contract behind them: the planner submitted a machine-readable plan, a gate
layer scored it against schema rules, and only a clean score published a
``plan.md`` this module rendered. That is gone, and the reversal is deliberate.
Legacy ADR 0037 already concluded that a document loop beats a schema gate, and
trial-2 live testing re-proved it the expensive way: one buggy gate spun the
planner for 27 turns arguing with a checker instead of reading the design.

So the tool surface is now EVIDENCE plus CORNER LOGGING AND LOOKUP, and nothing
else. ``survey`` provisions: it turns the shared ledger into a corpus, a corner
roster, a pin inventory and an Evidence catalog -- the citation menu ``plan.md``
prose quotes. The design knowledge that used to be encoded as gate rules lives
in the skill's ``guide.md``, where the planner can read it. ``plan.md`` itself is
written by the planner agent, in prose, and the quality check is the
interrogator's adversarial review of that document. This module refuses bad
ARGUMENTS and bad LEDGER DATA; it never refuses a plan.

**The three logging verbs take a ``rows`` array** and are all-or-nothing: every
row is validated before any row is stored, so a batch with one bad row stores
nothing and the refusal names the offending index. Each row is still its own
ledger fact with its own id and its own evidence -- a truth table logged in one
call and the same table logged row by row produce the identical ledger, because
batching saves tool calls and never merges facts.

There is no ``operation_retract``/``scalar_retract``: ``espdeck``'s
``fact_retract`` is ledger-generic and already retracts any row by id.

**The corpus comes from the ledger** (ADR 0043 amendment). ``survey`` used to
take spec paths and inline spec text, scrape a pin table and a truth table out
of the markdown, and hope the scrape was right. It now reads the live ``pin``,
``operation`` and ``plan_scalar`` facts: the model states each one explicitly,
with the evidence sentence the ledger requires, and the deterministic layer
serves them back as a citable Evidence catalog in ``survey.md``. A scrape that
missed a row produced a plan that silently ignored an operation; a missing fact
is now a fact the planner never logged, which the receipt counts out loud.

**Run state.** Everything hangs off ``<workdir>/work/<run>/``, the root
``espdeck.ledger`` already owns, so one session's cycle-plan run shares the
Design Fact Ledger with ``setup.deck`` and ``deck-analysis`` instead of
standing up a second store (ADR 0043). Every verb takes an optional ``dir``
naming that root relative to the workdir instead -- ``<workdir>/<dir>/``, with
the run id NOT appended -- resolved by the same ``espdeck.ledger.run_dir`` the
other two CLIs use, because three CLIs writing one ledger must never disagree
about where it is. Under the root:

    facts.sqlite3                        the shared ledger: pin, operation,
                                         plan_scalar, function_corner
    cycle-plans/corpus.json              the prepared corpus survey assembled
    cycle-plans/survey.md                the deterministic roster report

Those two files are everything this module writes. ``cycle-plans/<corner>/`` and
the ``plan.md`` inside it are the planner's to author, and the constraint
lowering the authoring skill does next writes ``constraints.tcl`` and
``testbench_declarations.sv`` as siblings, which is why the plan is a directory
rather than a flat file. ``cycle-plans/`` is the legacy ``cycle_plan_loop``
``_PUBLISH_DIRNAME`` verbatim.

**Why ``survey`` persists the corpus.** ``corpus.json`` plus the corpus digest
in ``survey.md`` are PROVENANCE: the digest names the exact evidence the plan
was written against, the planner cites it in ``plan.md``, and a reviewer who
re-runs ``survey`` and gets a different digest knows the ledger moved under the
document. Re-reading the ledger instead would lose that -- a fact logged after
the survey would silently change what the plan appears to have been written
against. Storing the canonical bytes makes staleness observable rather than
invisible; nothing enforces freshness, because a stale digest is a finding for
the interrogator, not a refusal for a tool.
"""

from __future__ import annotations

import json
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Final

_PACKAGE_PARENT: Final[str] = str(Path(__file__).resolve().parent.parent)
if _PACKAGE_PARENT not in sys.path:
    # This module is spawned by path (`python3 .../espcycle/cli.py`), so it has
    # no package context of its own; absolute imports of its own package are the
    # one form that works both as a script and under `python3 -m espcycle.cli`.
    # The same insert is what makes the sibling `espdeck` (the shared ledger)
    # and `espanalysis.models` (the shared record types) importable: all three
    # packages sit under this one `_shared` root.
    sys.path.insert(0, _PACKAGE_PARENT)

from pydantic import ValidationError  # noqa: E402

from espdeck.facts import (  # noqa: E402
    VALID_ORIGINS,
    FactRecord,
    facts_of_kind,
)
from espdeck.ledger import (  # noqa: E402
    FactDraft,
    FactLedger,
    FactLedgerSchemaError,
    FactLogResult,
    fact_ledger_path,
    run_dir,
)

from espcycle.corner_roster import (  # noqa: E402
    CORNER_FACT_KIND,
    CORNER_ORIGIN,
    CornerRetractAction,
    LogFunctionCornerFactAction,
    is_safe_slug,
    roster,
)
from espcycle.corpus import (  # noqa: E402
    CycleFactRecordV2,
    PinRecordV1,
    PreparedCorpusV3,
    corpus_digest,
    mint_declared_fact,
    prepare_corpus,
)
from espcycle.models import (  # noqa: E402
    BUILTIN_CORNERS,
    CUSTOM_CORNER_CAP,
    CornerKind,
    CornerRosterV1,
)
from espcycle.refs import allocate_evidence_catalog  # noqa: E402
from espcycle.render_text import neutralize_inline  # noqa: E402
from espcycle.survey import CustomCorner, derive_corner_roster  # noqa: E402

VERBS: Final[tuple[str, ...]] = (
    "operation_log",
    "scalar_log",
    "survey",
    "corner_log",
    "corner_retract",
)

#: Domain refusal codes. Closed set: ``tool/corner.ts``, ``tool/plan.ts``, and
#: the SKILL.md workflow read these, so a new one is a contract change rather
#: than a message tweak. Every one of them is an ARGUMENT or LEDGER-DATA
#: refusal: ``invalid_proposal`` / ``plan_rejected`` / ``no_corpus`` /
#: ``no_plans`` went with the gate layer, because there is no longer a plan for
#: this module to have an opinion about (MIGRATION.md section 13.11).
REFUSALS: Final[tuple[str, ...]] = (
    "invalid_args",
    "no_facts",
    "corpus_rejected",
    "no_ledger",
    "unknown_corner",
    "publish_failed",
)

#: Legacy ``cycle_plan_loop._PUBLISH_DIRNAME``, verbatim. The planner authors
#: ``<corner>/plan.md`` underneath it; the two names below are what this module
#: itself writes.
PUBLISH_DIRECTORY: Final[str] = "cycle-plans"
CORPUS_ARTEFACT_NAME: Final[str] = "corpus.json"
SURVEY_DOCUMENT_NAME: Final[str] = "survey.md"

_MESSAGE_MAX_CHARS: Final[int] = 8192

_MAX_DIRECTIVES: Final[int] = 32
_MAX_DIRECTIVE_CHARS: Final[int] = 2048
_MAX_PROMPT_CHARS: Final[int] = 8192

#: Rows one batched intake call carries. The ledger itself is unbounded (see
#: ``espdeck.ledger``); these are the *transport's* bounds. A truth table is
#: long, the scalar vocabulary is three names, and a corner roster is a handful,
#: which is why only the operation bound is a loose one.
_MAX_OPERATION_ROWS: Final[int] = 64
_MAX_SCALAR_ROWS: Final[int] = 16
_MAX_CORNER_ROWS: Final[int] = 16

#: ``PreparedCorpusV3.declared_facts``'s own tuple cap, restated at the read
#: seam so an over-full ledger reads as a named refusal rather than a pydantic
#: traceback. The ledger itself is unbounded on purpose (``espdeck.ledger``);
#: this is the corpus renderer's bound, which is where a row-count cap belongs.
_MAX_DECLARED_FACTS: Final[int] = 16


@dataclass(frozen=True, slots=True)
class Result:
    """The wire result. ``refusal`` is the authoritative classification."""

    ok: bool
    message: str
    data: dict[str, Any] = field(default_factory=dict)
    refusal: str | None = None

    def to_json(self) -> str:
        payload = {
            "ok": self.ok,
            "message": self.message[:_MESSAGE_MAX_CHARS],
            "data": self.data or None,
            "refusal": self.refusal,
        }
        return json.dumps(payload, ensure_ascii=False)


def _refuse(code: str, message: str) -> Result:
    return Result(ok=False, message=message, refusal=code)


def _first_validation_error(error: ValidationError, *, limit: int = 3) -> str:
    """Name the first few failures by location. A refusal is an instruction."""

    parts = []
    for entry in error.errors()[:limit]:
        location = ".".join(str(item) for item in entry.get("loc", ())) or "(root)"
        parts.append(f"{location}: {entry.get('msg', 'invalid')}")
    remaining = len(error.errors()) - len(parts)
    if remaining > 0:
        parts.append(f"(+{remaining} more)")
    return "; ".join(parts)


class HarnessDefect(Exception):
    """Malformed invocation. Exits non-zero; never a domain observation."""


# ---- argument seam ----------------------------------------------------


@dataclass(frozen=True, slots=True)
class RunContext:
    """The workdir and run root every verb resolves before doing anything."""

    workdir: Path
    run: str
    root: Path

    @property
    def publish_root(self) -> Path:
        return self.root / PUBLISH_DIRECTORY

    @property
    def corpus_path(self) -> Path:
        return self.publish_root / CORPUS_ARTEFACT_NAME

    @property
    def ledger_path(self) -> Path:
        return fact_ledger_path(self.root)


def _context(arguments: dict[str, Any]) -> RunContext | Result:
    """Resolve the run, or return the refusal that explains why not."""

    raw = str(arguments.get("workdir", "") or "").strip()
    workdir = Path(raw).expanduser() if raw else Path.cwd()
    run = str(arguments.get("run", "") or "").strip()
    try:
        # ``run_dir`` owns run-id AND ``dir`` segment validation, including the
        # confinement check: one implementation, shared with the other two CLIs.
        root = run_dir(workdir, run, str(arguments.get("dir", "") or ""))
    except ValueError as error:
        return _refuse("invalid_args", str(error))
    return RunContext(workdir=workdir, run=run, root=root)


def _relative(path: Path, base: Path) -> str:
    """Name ``path`` relative to the run's workdir when it sits inside it."""

    try:
        return str(path.resolve().relative_to(Path(base).resolve()))
    except (OSError, ValueError):
        return str(path)


def _open_ledger(context: RunContext, *, create: bool) -> FactLedger | Result:
    """Open the run's ledger, or return the refusal that explains why not."""

    path = context.ledger_path
    if not create and not path.is_file():
        return _refuse("no_ledger", "this run has no fact ledger yet")
    try:
        return FactLedger(context.workdir, context.run, root=context.root)
    except FactLedgerSchemaError as error:
        return _refuse("invalid_args", str(error))
    except OSError as error:
        return _refuse("invalid_args", f"could not open the ledger: {type(error).__name__}")


def _write(path: Path, payload: bytes) -> str | None:
    """Write one published file, or return the sentence that says why not."""

    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(payload)
    except OSError as error:
        return f"could not write {path.name}: {type(error).__name__}"
    return None


# ---- survey -----------------------------------------------------------
#
# The four ledger kinds ``survey`` reads. ``pin`` is ``setup.deck``'s own kind,
# shared rather than duplicated: a run that already logged its pins for a deck
# does not log them again for a cycle plan, and one pin inventory is what makes
# the two skills agree about the design. ``operation`` and ``plan_scalar`` are
# cycle.plan's, added to ``espdeck.facts`` because the ledger is the shared
# authority for what a fact IS -- a second vocabulary in this file would be a
# second ledger. ``function_corner`` (``corner_roster.CORNER_FACT_KIND``) is the
# fourth: it opens the corner vocabulary, so it is a roster INPUT and not merely
# the walk's worklist. It is deliberately NOT a corpus input -- a declared
# corner says what to verify, not what the design is -- so logging one leaves
# ``corpus.json`` and the corpus digest untouched while changing the certified
# selection the next ``survey`` reports.
PIN_FACT_KIND: Final[str] = "pin"
OPERATION_FACT_KIND: Final[str] = "operation"
SCALAR_FACT_KIND: Final[str] = "plan_scalar"

#: Which ``function_corner`` names are already built-in corners. A fact naming
#: one of these upgrades that roster entry rather than adding a new one, so it
#: does not spend a custom slot.
_BUILTIN_CORNER_NAMES: Final[frozenset[str]] = frozenset(BUILTIN_CORNERS)

#: ``plan_scalar`` is a Declared Design Fact: its whole point is a number only
#: the user can state, which is exactly what ``declared`` means. It is pinned
#: rather than argued so a model cannot dress a guess as ``parsed``.
SCALAR_ORIGIN: Final[str] = "declared"

#: What the operation row's three values are called in the corpus. Frozen here
#: because ``cycle_fact:<n>`` entries render as ``kind(values)`` and a reviewer
#: reads the headers to know which value is which.
_OPERATION_COLUMN_HEADERS: Final[tuple[str, str, str]] = (
    "operation",
    "pin_conditions",
    "output_effect",
)
#: The corpus kind a logged operation lifts to. ``truth_table_row`` is the
#: legacy ``spec_extract`` kind, kept verbatim: it is the string a reader of
#: ``corpus.json`` and of the survey's Evidence catalog sees, and the skill's
#: ``guide.md`` teaches truth-table rows under that name.
_OPERATION_CORPUS_KIND: Final[str] = "truth_table_row"

_NO_FACTS_MESSAGE: Final[str] = (
    "this run has no live pin facts, so there is nothing to survey. Log the "
    "design first: fact_log_pin for every top-level pin, plan_log_operation "
    "for every truth-table row, plan_log_scalar for pipeline_depth / "
    "scan_chain_length / reset_latency_cycles."
)


def _directives(arguments: dict[str, Any]) -> tuple[str, ...] | Result:
    raw = arguments.get("directives") or []
    if not isinstance(raw, list):
        return _refuse("invalid_args", "directives must be a list")
    if len(raw) > _MAX_DIRECTIVES:
        return _refuse("invalid_args", f"at most {_MAX_DIRECTIVES} directives")
    cleaned = []
    for item in raw:
        text = str(item or "").strip()
        if not text:
            continue
        cleaned.append(text[:_MAX_DIRECTIVE_CHARS])
    return tuple(cleaned)


def _duplicate_refusal(
    *,
    label: str,
    key: str,
    fact_ids: tuple[int, ...],
) -> Result:
    """Refuse a corpus two live facts disagree about, naming the rows to fix.

    Two live ``pin`` facts for ``CLK``, or two ``scan_chain_length`` scalars,
    is a question the deterministic layer must not answer by picking one:
    "last wins" would make the corpus depend on log order, and the roster and
    every A/A/A arithmetic downstream would follow the coin flip. The caller
    knows which row is right, so the refusal names both ids and the verb.
    """

    ids = ", ".join(str(item) for item in fact_ids)
    return _refuse(
        "corpus_rejected",
        f"two or more live {label} facts name {key!r} (fact ids {ids}); "
        "retract the wrong one with fact_retract and survey again",
    )


def _pin_inventory(facts: tuple[FactRecord, ...]) -> tuple[PinRecordV1, ...] | Result:
    """Project live ``pin`` facts onto the corpus pin inventory.

    ``width_text`` is ``None``: a ledger pin fact carries a name, a direction, a
    function type and an allowed-value set, and no width. Deriving one from a
    name that happens to end in ``[31:0]`` would invent evidence, and nothing
    downstream reads the width except the survey's own display column.
    """

    by_name: dict[str, int] = {}
    records: list[PinRecordV1] = []
    for fact in facts:
        name = fact.fields.get("pin_name", "")
        first = by_name.get(name)
        if first is not None:
            return _duplicate_refusal(label="pin", key=name, fact_ids=(first, fact.fact_id))
        by_name[name] = fact.fact_id
        records.append(
            PinRecordV1(
                name=name,
                direction=fact.fields.get("direction", "unknown"),
                width_text=None,
            )
        )
    return tuple(records)


def _operation_records(facts: tuple[FactRecord, ...]) -> tuple[CycleFactRecordV2, ...]:
    """Project live ``operation`` facts onto corpus cycle facts.

    ``table_identity`` is ``ledger:<fact_id>`` -- the analogue of the deck
    path's ``deck:<occurrence_id>``. It has to be an identity a reader can
    follow back, and the ledger row id is the only one a logged fact has.
    Duplicates are legal here and deliberately so: two operations may share an
    ``operation_name`` under different conditions ("READ, CEN=L" and "READ,
    CEN=H"), and each row is cited by its own ``cycle_fact:<n>``.
    """

    return tuple(
        CycleFactRecordV2(
            kind=_OPERATION_CORPUS_KIND,
            values=(
                fact.fields.get("operation_name", ""),
                fact.fields.get("pin_conditions", ""),
                fact.fields.get("output_effect", ""),
            ),
            column_headers=_OPERATION_COLUMN_HEADERS,
            table_identity=f"ledger:{fact.fact_id}",
            span=None,
        )
        for fact in facts
    )


def _declared_facts(facts: tuple[FactRecord, ...]) -> tuple[Any, ...] | Result:
    """Mint one Declared Design Fact per live ``plan_scalar`` fact.

    ``fact_id`` is content-derived by ``mint_declared_fact`` and never stored on
    the ledger row: a stored id could not survive ``DeclaredDesignFactV1``'s own
    validator, which recomputes it from kind, value and statement digest.
    """

    if len(facts) > _MAX_DECLARED_FACTS:
        return _refuse(
            "corpus_rejected",
            f"at most {_MAX_DECLARED_FACTS} plan_scalar facts fit one corpus, "
            f"and this run has {len(facts)} live; retract the stale ones with fact_retract",
        )
    by_name: dict[str, int] = {}
    minted = []
    for fact in facts:
        name = fact.fields.get("name", "")
        first = by_name.get(name)
        if first is not None:
            return _duplicate_refusal(
                label="plan_scalar", key=name, fact_ids=(first, fact.fact_id)
            )
        by_name[name] = fact.fact_id
        try:
            minted.append(
                mint_declared_fact(
                    name,  # type: ignore[arg-type]
                    int(fact.fields.get("value", "0")),
                    # No slice: ``MAX_FIELD_CHARS`` already bounded the stored
                    # statement at 1024, half of what ``DeclaredDesignFactV1``
                    # admits, so a truncation here could never fire.
                    fact.fields.get("statement", ""),
                )
            )
        except ValidationError as error:
            return _refuse(
                "corpus_rejected",
                f"plan_scalar fact {fact.fact_id} does not make a declared design fact: "
                f"{_first_validation_error(error)}",
            )
    return tuple(minted)


def _custom_corners(ledger: FactLedger) -> tuple[CustomCorner, ...] | Result:
    """Project the run's live ``function_corner`` facts onto roster inputs.

    Deduplicated BY NAME, later fact id winning the cited statement: two live
    rows naming one corner is one corner on the roster, and the newer row is the
    planner's current reading of the spec. Nothing reports the duplication as a
    defect any more -- the admissibility rule that did went with the gate layer
    (MIGRATION.md section 13.11) -- and the projection is the right place to
    absorb it: the roster answers "which corners does this run intend to
    verify", and asking that twice about one name has one answer. ``survey.md``
    cites the winning fact id, so a reader who cares can see which row it read.

    The cap is the roster's, restated here so an over-full ledger reads as a
    named refusal rather than a pydantic traceback from ``entries``. Recording
    corners is unbounded by design (``corner_roster.roster``); the SURVEY is
    what has a document-sized bound.
    """

    live = roster(ledger)
    by_name: dict[str, CustomCorner] = {}
    for corner in live:
        by_name[corner.name] = CustomCorner(
            name=corner.name, statement=corner.statement, fact_id=corner.fact_id
        )
    custom = tuple(name for name in by_name if name not in _BUILTIN_CORNER_NAMES)
    if len(custom) > CUSTOM_CORNER_CAP:
        return _refuse(
            "corpus_rejected",
            f"at most {CUSTOM_CORNER_CAP} custom function_corner names fit one roster "
            f"(the roster carries {len(_BUILTIN_CORNER_NAMES)} built-in corners and holds "
            f"{CUSTOM_CORNER_CAP + len(_BUILTIN_CORNER_NAMES)} entries in all), and this run "
            f"has {len(custom)} live; retract the ones you are not planning with "
            "corner_retract.",
        )
    # ``dict`` keeps first-appearance order under re-assignment, so this is
    # ledger order with each name's newest statement.
    return tuple(by_name.values())


def _verb_survey(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Assemble the corpus from the shared ledger, derive the roster, publish both.

    ``create=False``: a survey publishes a reading of what is already recorded,
    so a run with no ledger has nothing to read and leaving an empty store
    behind would misreport that as "surveyed, found nothing".
    """

    directives = _directives(arguments)
    if isinstance(directives, Result):
        return directives

    opened = _open_ledger(context, create=False)
    if isinstance(opened, Result):
        # An absent ledger and an empty one are the same shortfall to the
        # caller -- no facts to survey -- so they answer with one code and one
        # instruction rather than making the model tell `no_ledger` from
        # `no_facts`.
        if opened.refusal == "no_ledger":
            return _refuse("no_facts", _NO_FACTS_MESSAGE)
        return opened
    try:
        snapshot = opened.snapshot()
        custom_corners = _custom_corners(opened)
    finally:
        opened.close()
    if isinstance(custom_corners, Result):
        return custom_corners

    pin_facts = facts_of_kind(snapshot, PIN_FACT_KIND)
    if not pin_facts:
        return _refuse("no_facts", _NO_FACTS_MESSAGE)
    pins = _pin_inventory(pin_facts)
    if isinstance(pins, Result):
        return pins
    scalar_facts = facts_of_kind(snapshot, SCALAR_FACT_KIND)
    facts = _declared_facts(scalar_facts)
    if isinstance(facts, Result):
        return facts
    operation_facts = facts_of_kind(snapshot, OPERATION_FACT_KIND)

    try:
        corpus = prepare_corpus(
            user_prompt=str(arguments.get("user_prompt", "") or "")[:_MAX_PROMPT_CHARS],
            directives=directives,
            declared_facts=facts,
            pins=pins,
            cycle_facts=_operation_records(operation_facts),
        )
    except ValidationError as error:
        return _refuse("corpus_rejected", _first_validation_error(error))

    roster_record = derive_corner_roster(corpus, custom_corners)
    digest = corpus_digest(corpus)
    report = _render_survey_report(corpus=corpus, roster=roster_record, digest=digest)
    survey_path = context.publish_root / SURVEY_DOCUMENT_NAME
    for path, payload in (
        (context.corpus_path, corpus.to_canonical_bytes()),
        (survey_path, report),
    ):
        failure = _write(path, payload)
        if failure is not None:
            return _refuse("publish_failed", failure)
    return Result(
        ok=True,
        message=report.decode("utf-8"),
        data={
            "corpus_digest": digest,
            "corpus_path": _relative(context.corpus_path, context.workdir),
            "survey_path": _relative(survey_path, context.workdir),
            "recommended": list(roster_record.recommended),
            "custom_corner_count": len(custom_corners),
            "pin_count": len(corpus.pin_inventory),
            "operation_count": len(operation_facts),
            "scalar_count": len(corpus.declared_facts),
            "directive_count": len(corpus.directives),
        },
    )


def _render_survey_report(
    *,
    corpus: PreparedCorpusV3,
    roster: CornerRosterV1,
    digest: str,
) -> bytes:
    """Render the deterministic roster report. Trusted output, not prose.

    Trusted in the sense that every line is derived from the ledger by code:
    the roster classifications, the pin inventory, the ref strings. It is the
    planner's INPUT -- the evidence and the citation menu ``plan.md`` is written
    from -- and it makes no claim about any plan, because no plan exists yet.
    """

    lines = [
        "# Corner Survey",
        "",
        f"Schema: {neutralize_inline(roster.schema_identity)}",
        f"Corpus digest: {digest}",
        f"Ledger facts: {len(corpus.pin_inventory)} pin(s), "
        f"{len(corpus.cycle_facts)} operation(s), {len(corpus.declared_facts)} scalar(s)",
        "",
        "## Roster",
        "",
        "| Corner | Classification | Reason |",
        "| --- | --- | --- |",
    ]
    for entry in roster.entries:
        lines.append(
            "| "
            + " | ".join(
                (
                    neutralize_inline(entry.corner),
                    neutralize_inline(entry.classification),
                    neutralize_inline(entry.reason),
                )
            )
            + " |"
        )
    lines.extend(("", "## Certified selection", ""))
    if roster.recommended:
        lines.extend(f"- {neutralize_inline(corner)}" for corner in roster.recommended)
    else:
        lines.append(
            "No corner is recommendable from this evidence: every entry above is "
            "`unresolved`, `absent` or `conflicting`. Add a Verification "
            "Directive, log the operation that names the behaviour, or declare "
            "the corner with `corner_log` before planning one."
        )
    lines.extend(("", "## Pin inventory", ""))
    if corpus.pin_inventory:
        lines.append("| Pin | Direction |")
        lines.append("| --- | --- |")
        for pin in corpus.pin_inventory:
            lines.append(
                "| "
                + " | ".join((neutralize_inline(pin.name), neutralize_inline(pin.direction)))
                + " |"
            )
    else:
        lines.append("No pin fact is live in this run's ledger.")
    # The catalog is the whole point of the fact-ledger intake: it is the
    # CITATION MENU. Nothing forces a citation, and nothing resolves one on the
    # planner's behalf -- ``plan.md`` is prose -- but a ref the planner quotes
    # from this table is a ref the interrogator (or a human) can resolve back
    # through ``refs.resolve_evidence_ref`` against this same corpus. Serving
    # the exact strings is what keeps the model from inventing the numbering.
    lines.extend(("", "## Evidence catalog", ""))
    catalog = allocate_evidence_catalog(corpus)
    # Pin entries are real catalog rows (`pin:<NAME>` is citable evidence), but
    # re-listing every pin here would duplicate the inventory table above; the
    # footer states the rule instead.
    listed = tuple(entry for entry in catalog.entries if entry.kind != "pin")
    if listed:
        lines.append("| Ref | Evidence |")
        lines.append("| --- | --- |")
        for entry in listed:
            lines.append(
                "| "
                + " | ".join((neutralize_inline(entry.ref), neutralize_inline(entry.text)))
                + " |"
            )
    else:
        lines.append("No citable evidence: log an operation, a scalar or a directive.")
    lines.append("")
    lines.append(
        "Every pin in the inventory above is also citable evidence as "
        "`pin:<NAME>`."
    )
    lines.extend(("", "## Evidence gaps", ""))
    gaps = []
    if corpus.deck_model_digest is None:
        # Named, not silently absent. ``prepare_corpus`` takes an optional
        # ``deck_model``, and a SetupDeckModelV1 is what would type every pin
        # from HDL rather than from an assertion; ``deck-analysis`` publishes
        # five markdown DOCUMENTS and a digest receipt, not a canonical model
        # artefact, so there is nothing on disk to load. Consequence, stated
        # once here rather than inferred from a silence: pin directions rest on
        # the ledger fact the planner logged. ``_proved_single_port`` still
        # succeeds over a fully typed inventory, so the contention clause defers
        # to what the roster actually concluded instead of asserting the proof
        # failed.
        contention_proved_absent = any(
            entry.corner == CornerKind.MULTI_PORT_CONTENTION
            and entry.classification == "absent"
            for entry in roster.entries
        )
        contention_clause = (
            "The corner rules read those same logged directions."
            if contention_proved_absent
            else "`multi-port-contention` cannot be proved structurally absent "
            "from them, so the roster leaves it open."
        )
        gaps.append(
            "- No deck model: pin directions come from the logged pin facts "
            f"only. {contention_clause}"
        )
    if not corpus.cycle_facts:
        gaps.append(
            "- No operation facts: nothing states what the design does, so "
            "every corner rests on pin names and directives alone. Log the "
            "truth table with `plan_log_operation`."
        )
    if not corpus.declared_facts:
        gaps.append(
            "- No declared design facts: `pipeline_depth`, `scan_chain_length` "
            "and `reset_latency_cycles` are unbound, so any cycle count that "
            "depends on one is a number nobody has stated. Declare it with "
            "`plan_log_scalar` or say in the plan that it is unknown."
        )
    lines.extend(gaps or ("None.",))
    return ("\n".join(lines) + "\n").encode("utf-8")


# ---- fact intake ------------------------------------------------------


def _rows(
    arguments: dict[str, Any], *, required: tuple[str, ...], limit: int
) -> tuple[dict[str, Any], ...] | Result:
    """Read the ``rows`` array and check every row, before the ledger is touched.

    ``normalize_fact`` checks the same fields, and this is not redundant with
    it: ``_open_ledger(create=True)`` CREATES the store, so a malformed call
    that reached the ledger would leave an empty ``facts.sqlite3`` behind for
    facts it then refused. Checking EVERY row here rather than the first is what
    keeps that property for a batch, and the refusal names the row by index so a
    sixteen-row call with one bad row is one fix away rather than a bisect.
    ``corner_log`` holds the same ordering for the same reason -- validate every
    row, then open.
    """

    expected = ", ".join(required)
    raw = arguments.get("rows")
    if not isinstance(raw, list) or not raw:
        return _refuse("invalid_args", f"rows must be a non-empty array of objects; {expected}")
    if len(raw) > limit:
        return _refuse(
            "invalid_args", f"rows carries {len(raw)} rows; one call takes at most {limit}"
        )
    rows: list[dict[str, Any]] = []
    for index, entry in enumerate(raw):
        if not isinstance(entry, dict):
            return _refuse(
                "invalid_args", f"rows[{index}]: each row must be an object; {expected}"
            )
        for name in required:
            if not _text(entry, name).strip():
                return _refuse("invalid_args", f"rows[{index}]: {name} is required")
        rows.append(entry)
    return tuple(rows)


def _text(row: dict[str, Any], name: str) -> str:
    """One row field as the ledger sees it: ``str(...)``, never a falsy coercion.

    ``row.get(name) or ""`` would turn a legitimate ``0`` into an empty field,
    and a zero ``pipeline_depth`` or ``reset_latency_cycles`` is a real
    assertion. The wrapper sends every value as a string, but a CLI is callable
    without its wrapper, so the ``None`` case is spelled out instead of leaning
    on truthiness.
    """

    value = row.get(name)
    return "" if value is None else str(value)


def _indexed(outcome: FactLogResult) -> str:
    """Name the refused row by its argument path, so the model fixes that row."""

    if outcome.rejected_index is None:
        return outcome.message
    return f"rows[{outcome.rejected_index}]: {outcome.message}"


def _verb_operation_log(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Append a batch of ``operation`` facts -- rows of the design's truth table.

    Shape and receipt style follow ``corner_log``. ``origin`` is a per-row
    argument here and pinned on ``scalar_log`` because an operation genuinely
    has more than one provenance: a datasheet row is ``parsed``, a behaviour the
    user asserted in the session is ``declared``, and a reader's conclusion
    about a deck is ``inferred`` -- and one batch may carry a mix.
    """

    rows = _rows(
        arguments,
        required=("operation_name", "pin_conditions", "evidence"),
        limit=_MAX_OPERATION_ROWS,
    )
    if isinstance(rows, Result):
        return rows
    drafts: list[FactDraft] = []
    for index, row in enumerate(rows):
        origin = (_text(row, "origin").strip() or "parsed").lower()
        if origin not in VALID_ORIGINS:
            valid = ", ".join(sorted(VALID_ORIGINS))
            return _refuse(
                "invalid_args",
                f"rows[{index}]: unknown origin {origin!r}; valid origins are {valid}",
            )
        drafts.append(
            FactDraft(
                fields={
                    "operation_name": _text(row, "operation_name"),
                    "pin_conditions": _text(row, "pin_conditions"),
                    "output_effect": _text(row, "output_effect"),
                },
                evidence=_text(row, "evidence"),
                origin=origin,
            )
        )
    opened = _open_ledger(context, create=True)
    if isinstance(opened, Result):
        return opened
    try:
        outcome = opened.log_many(OPERATION_FACT_KIND, drafts)
        if outcome.is_error:
            return _refuse("invalid_args", _indexed(outcome))
        live = facts_of_kind(opened.snapshot(), OPERATION_FACT_KIND)
        named = ", ".join(
            repr(record.fields["operation_name"]) for record in outcome.records
        )
        return Result(
            ok=True,
            message=(
                f"recorded {len(outcome.records)} operation(s) {named} "
                f"({len(live)} on the truth table)"
            ),
            data={
                "fact_ids": [record.fact_id for record in outcome.records],
                "operation_count": len(live),
            },
        )
    finally:
        opened.close()


def _verb_scalar_log(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Append a batch of ``plan_scalar`` facts -- the cycle-arithmetic numbers.

    ``origin`` is pinned to ``declared`` and is not an argument: these three
    numbers are the legacy Declared Design Facts, whose defining property is
    that no spec table states them and only the user can. A ``parsed``
    pipeline depth would be a claim the ledger cannot support.
    """

    rows = _rows(
        arguments,
        required=("name", "value", "statement", "evidence"),
        limit=_MAX_SCALAR_ROWS,
    )
    if isinstance(rows, Result):
        return rows
    drafts = [
        FactDraft(
            fields={
                "name": _text(row, "name"),
                "value": _text(row, "value"),
                "statement": _text(row, "statement"),
            },
            evidence=_text(row, "evidence"),
            origin=SCALAR_ORIGIN,
        )
        for row in rows
    ]
    opened = _open_ledger(context, create=True)
    if isinstance(opened, Result):
        return opened
    try:
        outcome = opened.log_many(SCALAR_FACT_KIND, drafts)
        if outcome.is_error:
            return _refuse("invalid_args", _indexed(outcome))
        live = facts_of_kind(opened.snapshot(), SCALAR_FACT_KIND)
        # The stored value, not the argument: the ledger canonicalizes "02" to
        # "2", and the receipt has to show what was actually recorded.
        stated = ", ".join(
            f"{record.fields['name']} = {record.fields['value']}"
            for record in outcome.records
        )
        return Result(
            ok=True,
            message=(
                f"recorded {len(outcome.records)} scalar(s) {stated} "
                f"({len(live)} scalar(s) declared)"
            ),
            data={
                "fact_ids": [record.fact_id for record in outcome.records],
                "scalar_count": len(live),
            },
        )
    finally:
        opened.close()


# ---- corner roster ----------------------------------------------------


def _verb_corner_log(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Append a batch of ``function_corner`` facts. Ported from ``LOG_CORNER_TOOL``."""

    rows = _rows(
        arguments,
        required=("corner_name", "statement", "evidence"),
        limit=_MAX_CORNER_ROWS,
    )
    if isinstance(rows, Result):
        return rows
    actions: list[LogFunctionCornerFactAction] = []
    for index, row in enumerate(rows):
        try:
            action = LogFunctionCornerFactAction.model_validate(
                {
                    "corner_name": _text(row, "corner_name"),
                    "statement": _text(row, "statement"),
                    "evidence": _text(row, "evidence"),
                }
            )
        except ValidationError as error:
            return _refuse("invalid_args", f"rows[{index}]: {_first_validation_error(error)}")
        # Path safety is this seam's job: ``normalize_fact`` validates fact shape
        # and knows nothing about directories, but ``corner_name`` becomes one.
        # EVERY row is slug-checked before the ledger is opened, so an unsafe
        # name in the last row of a batch never reaches the ledger and never
        # leaves a store behind for the corners the call then refused.
        if not is_safe_slug(action.corner_name):
            return _refuse(
                "invalid_args",
                f"rows[{index}]: corner_name {action.corner_name!r} is not one safe path "
                "segment: letters, digits, dot, dash and underscore, starting with a letter "
                "or digit. It becomes a directory under cycle-plans/.",
            )
        actions.append(action)
    opened = _open_ledger(context, create=True)
    if isinstance(opened, Result):
        return opened
    try:
        outcome = opened.log_many(
            CORNER_FACT_KIND,
            [
                FactDraft(
                    fields={
                        "corner_name": action.corner_name,
                        "statement": action.statement,
                    },
                    evidence=action.evidence,
                    origin=CORNER_ORIGIN,
                )
                for action in actions
            ],
        )
        if outcome.is_error:
            return _refuse("invalid_args", _indexed(outcome))
        live = roster(opened)
        named = ", ".join(repr(action.corner_name) for action in actions)
        return Result(
            ok=True,
            message=(
                f"recorded {len(actions)} functional corner(s) {named} "
                f"({len(live)} on the roster)"
            ),
            data={
                "fact_ids": [record.fact_id for record in outcome.records],
                "corner_names": [action.corner_name for action in actions],
                "roster": [corner.name for corner in live],
            },
        )
    finally:
        opened.close()


def _verb_corner_retract(context: RunContext, arguments: dict[str, Any]) -> Result:
    """Retract one corner, keeping the row and the reason. Ported from
    ``RETRACT_CORNER_TOOL``."""

    try:
        action = CornerRetractAction.model_validate(
            {
                "corner_name": str(arguments.get("corner_name", "") or ""),
                "reason": str(arguments.get("reason", "") or ""),
            }
        )
    except ValidationError as error:
        return _refuse("invalid_args", _first_validation_error(error))
    opened = _open_ledger(context, create=False)
    if isinstance(opened, Result):
        return opened
    try:
        match = next(
            (corner for corner in roster(opened) if corner.name == action.corner_name),
            None,
        )
        if match is None:
            live = ", ".join(corner.name for corner in roster(opened)) or "(empty)"
            return _refuse(
                "unknown_corner",
                f"no live corner named {action.corner_name!r}; the roster holds: {live}",
            )
        outcome = opened.retract(match.fact_id, action.reason)
        if outcome.is_error:
            return _refuse("invalid_args", outcome.message)
        remaining = roster(opened)
        return Result(
            ok=True,
            message=(
                f"retracted functional corner {action.corner_name!r} "
                f"({len(remaining)} on the roster)"
            ),
            data={"roster": [corner.name for corner in remaining]},
        )
    finally:
        opened.close()


_HANDLERS: Final[dict[str, Any]] = {
    "operation_log": _verb_operation_log,
    "scalar_log": _verb_scalar_log,
    "survey": _verb_survey,
    "corner_log": _verb_corner_log,
    "corner_retract": _verb_corner_retract,
}


def run(verb: str, arguments: dict[str, Any]) -> Result:
    """Dispatch one verb. Raises :class:`HarnessDefect` for a bad invocation."""

    handler = _HANDLERS.get(verb)
    if handler is None:
        raise HarnessDefect(f"unknown verb {verb!r}; expected one of {', '.join(VERBS)}")
    context = _context(arguments)
    if isinstance(context, Result):
        return context
    return handler(context, arguments)


def main(argv: list[str]) -> int:
    if len(argv) != 1:
        print(f"usage: cli.py <{'|'.join(VERBS)}>  (JSON arguments on stdin)", file=sys.stderr)
        return 2
    raw = sys.stdin.read()
    try:
        arguments = json.loads(raw or "{}")
    except json.JSONDecodeError as error:
        print(f"stdin is not JSON: {error}", file=sys.stderr)
        return 2
    if not isinstance(arguments, dict):
        print("stdin must be a JSON object", file=sys.stderr)
        return 2
    try:
        result = run(argv[0], arguments)
    except HarnessDefect as error:
        print(str(error), file=sys.stderr)
        return 2
    print(result.to_json())
    return 0


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
