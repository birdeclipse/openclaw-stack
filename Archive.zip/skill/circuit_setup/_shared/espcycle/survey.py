"""Deterministic Corner Roster rules over a prepared evidence corpus.

Rules emit ``candidate``, never a claim of presence. ``absent`` is reserved for
structural impossibility from typed evidence. ``conflicting`` is a weak
pin-name proposal contradicted by an authoritative directive.

Two kinds of corner reach the roster. The eight :class:`CornerKind` BUILT-INS
are classified by the keyword/pin/fact tables below and appear on every roster.
The CUSTOM corners are the distinct live ``function_corner`` facts a run
declared: nothing structural is known about a name nobody wrote a rule for, so
the fact itself is the support and the classification is ``fact_supported`` --
or ``directive_named`` when a Verification Directive quotes the slug, which is
the same "an authoritative directive outranks everything" precedence the
built-ins use.
"""

from __future__ import annotations

import re
from collections.abc import Sequence
from typing import NamedTuple

from .corpus import PinRecordV1, PreparedCorpusV3
from .models import (
    BUILTIN_CORNERS,
    CornerKind,
    CornerRosterEntryV1,
    CornerRosterV1,
    DeclaredDesignFactV1,
)

# Case-insensitive keyword table: a Verification Directive names a corner when
# any listed token occurs as a substring of the directive text.
CORNER_DIRECTIVE_KEYWORDS: dict[CornerKind, frozenset[str]] = {
    CornerKind.MISSION_MODE_READ_WRITE: frozenset(
        {"mission", "mission-mode", "read/write", "read-write", "functional"}
    ),
    CornerKind.LOW_POWER_SEQUENCE: frozenset(
        {"sleep", "retention", "power", "shutdown", "low-power", "lowpower", "dslp", "wakeup"}
    ),
    CornerKind.SCAN_DFT: frozenset({"scan", "dft", "atpg", "bist", "scan-dft"}),
    CornerKind.CALIBRATION: frozenset({"calibration", "calibrate", "trim"}),
    CornerKind.MULTI_PORT_CONTENTION: frozenset(
        {"multi-port", "multiport", "dual-port", "dualport", "contention", "two-port"}
    ),
    CornerKind.CLOCK_GATING: frozenset({"clock-gating", "clock gating", "gating"}),
    CornerKind.IDLE: frozenset({"idle", "standby"}),
    CornerKind.REDUNDANCY: frozenset({"redundancy", "repair"}),
}

# Case-insensitive keyword table: a directive contradicts pin-name candidacy
# for a corner when any listed token occurs as a substring of the directive.
CORNER_CONTRADICTION_KEYWORDS: dict[CornerKind, frozenset[str]] = {
    CornerKind.MULTI_PORT_CONTENTION: frozenset(
        {"single-port", "singleport", "one-port", "single port"}
    ),
}

# Case-insensitive pin-name identifiers that propose a corner as a candidate.
PIN_CANDIDATE_TOKENS: dict[CornerKind, frozenset[str]] = {
    CornerKind.LOW_POWER_SEQUENCE: frozenset({"SD", "DSLP", "DS", "POFF", "RET"}),
    CornerKind.SCAN_DFT: frozenset({"SE", "SI", "SO", "scan"}),
    CornerKind.REDUNDANCY: frozenset({"CRE", "FCA", "RRE", "FRA"}),
    CornerKind.CLOCK_GATING: frozenset({"CG", "CKE"}),
    CornerKind.MULTI_PORT_CONTENTION: frozenset(
        {"CLKA", "CLKB", "CLK1", "CLK2", "CENA", "CENB", "A1", "A2"}
    ),
}

# Narrow dual-port structural pairs for ``_proved_single_port``. A single
# unpaired match is not dual-port evidence. Tokens are matched with the same
# identifier rule as pin-name candidacy, so ``A1`` does not pair via ``FCA1``.
_DUAL_PORT_PAIRS: tuple[tuple[str, str], ...] = (
    ("CLKA", "CLKB"),
    ("CENA", "CENB"),
    ("CLK1", "CLK2"),
    ("A1", "A2"),
)

# Declared Design Fact kinds that directly imply a corner.
FACT_CORNER_IMPLICATIONS: dict[str, CornerKind] = {
    "scan_chain_length": CornerKind.SCAN_DFT,
}

_LETTER_OR_DIGIT = re.compile(r"[a-z]+|\d+")

# a2a severity-derived recommendation order (mission first, multi-port last).
CORNER_RECOMMENDATION_PRIORITY: tuple[CornerKind, ...] = (
    CornerKind.MISSION_MODE_READ_WRITE,
    CornerKind.LOW_POWER_SEQUENCE,
    CornerKind.SCAN_DFT,
    CornerKind.REDUNDANCY,
    CornerKind.CLOCK_GATING,
    CornerKind.CALIBRATION,
    CornerKind.IDLE,
    CornerKind.MULTI_PORT_CONTENTION,
)

#: Membership test for "is this name a built-in?", built once.
_BUILTIN_CORNER_SET: frozenset[str] = frozenset(BUILTIN_CORNERS)

_UNRESOLVED_REASON = "no supporting fact"
_REASON_MAX = 1024


class CustomCorner(NamedTuple):
    """One distinct live ``function_corner`` fact, as the roster reads it.

    ``fact_id`` and ``statement`` are cited verbatim in the classification
    reason, so a reader of the roster can find the row that put the corner
    there. The name may be a built-in value -- a planner is allowed to declare
    the corner it read in the spec even when a rule table already knows the
    name -- in which case it upgrades that built-in rather than adding an entry.
    """

    name: str
    statement: str
    fact_id: int


def derive_corner_roster(
    corpus: PreparedCorpusV3,
    custom_corners: Sequence[CustomCorner] = (),
) -> CornerRosterV1:
    """Classify every corner from corpus evidence and attach a recommendation.

    ``custom_corners`` are the run's distinct live ``function_corner`` facts,
    already deduplicated by name by the caller. A fact whose name is a built-in
    value supports that built-in; every other name appends one entry of its own.
    """

    by_name = {corner.name: corner for corner in custom_corners}
    builtin_entries = tuple(
        _classify_corner(kind, corpus, by_name.get(kind.value))
        for kind in sorted(CornerKind, key=lambda kind: kind.value)
    )
    custom_entries = tuple(
        _classify_custom_corner(by_name[name], corpus)
        for name in sorted(name for name in by_name if name not in _BUILTIN_CORNER_SET)
    )
    entries = (*builtin_entries, *custom_entries)
    draft = CornerRosterV1(entries=entries, recommended=())
    return CornerRosterV1(entries=entries, recommended=recommend_corners(draft))


def recommend_corners(roster: CornerRosterV1) -> tuple[str, ...]:
    """Return recommended corners: named, then fact-supported, then candidates.

    Built-ins come first within each group, in
    ``CORNER_RECOMMENDATION_PRIORITY`` (a2a severity) order; custom corners
    follow in name order, because severity is a property of the a2a corner set
    and a run's own corner has no place in it. Absent, unresolved, and
    conflicting corners are never included. Uncapped: the roster's own
    ``max_length`` is the bound, and truncating here would drop a corner from
    the certified selection ``survey.md`` prints, which is the whole answer the
    planner reads before choosing what to plan.
    """
    by_corner = {entry.corner: entry.classification for entry in roster.entries}
    ordered = (
        *CORNER_RECOMMENDATION_PRIORITY,
        *sorted(name for name in by_corner if name not in _BUILTIN_CORNER_SET),
    )
    return tuple(
        corner
        for classification in ("directive_named", "fact_supported", "candidate")
        for corner in ordered
        if by_corner.get(corner) == classification
    )


def _classify_corner(
    kind: CornerKind,
    corpus: PreparedCorpusV3,
    corner_fact: CustomCorner | None = None,
) -> CornerRosterEntryV1:
    """Classify one built-in corner. ``corner_fact`` is a live ``function_corner``
    fact whose ``corner_name`` equals this built-in's value, if the run logged one."""

    keywords = CORNER_DIRECTIVE_KEYWORDS.get(kind, frozenset())
    directives = _matching_directives(corpus.directives, keywords)
    if directives:
        cited = "; ".join(directives)
        return CornerRosterEntryV1(
            corner=kind,
            classification="directive_named",
            reason=_bounded_reason(f"directive named the corner: {cited}"),
        )

    facts = _matching_facts(corpus.declared_facts, kind)
    if facts:
        cited = ", ".join(f"{fact.kind} ({fact.fact_id})" for fact in facts)
        return CornerRosterEntryV1(
            corner=kind,
            classification="fact_supported",
            reason=_bounded_reason(f"declared fact {cited}"),
        )

    if corner_fact is not None:
        # Above the structural-absence proof on purpose: a ``function_corner``
        # fact is a planner's DECLARED verification intent, cited to a spec line,
        # and declared intent outranks an inference drawn from what the pin
        # inventory does not contain. Below the declared-fact implication, which
        # is the stronger claim about the same corner (a scan_chain_length fact
        # says the chain EXISTS, not merely that someone intends to verify it),
        # so a run that logs both keeps the implication's reason.
        return CornerRosterEntryV1(
            corner=kind,
            classification="fact_supported",
            reason=_corner_fact_reason(corner_fact),
        )

    if kind is CornerKind.MULTI_PORT_CONTENTION and _proved_single_port(corpus):
        typed = tuple(pin.name for pin in corpus.pin_inventory if pin.direction != "unknown")
        cited = ", ".join(typed) if typed else "HDL port inventory"
        return CornerRosterEntryV1(
            corner=kind,
            classification="absent",
            reason=_bounded_reason(f"structurally impossible: single-port from typed pins {cited}"),
        )

    pin_names = _matching_pin_names(
        corpus.pin_inventory,
        PIN_CANDIDATE_TOKENS.get(kind, frozenset()),
    )
    contradictions = _matching_directives(
        corpus.directives,
        CORNER_CONTRADICTION_KEYWORDS.get(kind, frozenset()),
    )
    if pin_names and contradictions:
        return CornerRosterEntryV1(
            corner=kind,
            classification="conflicting",
            reason=_conflict_reason(pin_names, contradictions),
        )
    if pin_names:
        cited = ", ".join(pin_names)
        return CornerRosterEntryV1(
            corner=kind,
            classification="candidate",
            reason=_bounded_reason(f"pin-name rule matched {cited}"),
        )

    if kind is CornerKind.MISSION_MODE_READ_WRITE:
        inputs = tuple(pin.name for pin in corpus.pin_inventory if pin.direction == "input")
        if inputs:
            cited = ", ".join(inputs)
            return CornerRosterEntryV1(
                corner=kind,
                classification="candidate",
                reason=_bounded_reason(f"input pin present: {cited}"),
            )

    if contradictions:
        # A contradiction with nothing on the other side is not a conflict: no rule
        # proposed this corner, and an authoritative directive excludes it. Calling
        # that `conflicting` would ask the user to adjudicate a question the
        # evidence already answers.
        cited = "; ".join(contradictions)
        return CornerRosterEntryV1(
            corner=kind,
            classification="absent",
            reason=_bounded_reason(f"no supporting evidence; directive excludes it: {cited}"),
        )

    return CornerRosterEntryV1(
        corner=kind,
        classification="unresolved",
        reason=_UNRESOLVED_REASON,
    )


def _classify_custom_corner(
    corner: CustomCorner,
    corpus: PreparedCorpusV3,
) -> CornerRosterEntryV1:
    """Classify one corner no rule table knows about.

    There is nothing structural to read: no keyword set, no candidate pin token,
    no fact kind implies this name. The fact IS the support, so the answer is
    ``fact_supported`` -- and ``directive_named`` when a Verification Directive
    quotes the slug, matching the built-in precedence where an authoritative
    directive outranks everything else. Never ``absent``, ``conflicting`` or
    ``unresolved``: each of those is a claim some rule made about this corner,
    and no rule speaks to it.
    """

    directives = _matching_directives(corpus.directives, frozenset({corner.name}))
    if directives:
        cited = "; ".join(directives)
        return CornerRosterEntryV1(
            corner=corner.name,
            classification="directive_named",
            reason=_bounded_reason(f"directive named the corner: {cited}"),
        )
    return CornerRosterEntryV1(
        corner=corner.name,
        classification="fact_supported",
        reason=_corner_fact_reason(corner),
    )


def _corner_fact_reason(corner: CustomCorner) -> str:
    """Cite the ledger row that put this corner on the roster."""

    return _bounded_reason(f"function_corner fact {corner.fact_id}: {corner.statement}")


def _matching_directives(
    directives: tuple[str, ...],
    keywords: frozenset[str],
) -> tuple[str, ...]:
    if not keywords:
        return ()
    folded_keywords = tuple(keyword.casefold() for keyword in keywords)
    matched: list[str] = []
    for directive in directives:
        folded = directive.casefold()
        if any(keyword in folded for keyword in folded_keywords):
            matched.append(directive)
    return tuple(matched)


def _matching_facts(
    facts: tuple[DeclaredDesignFactV1, ...],
    kind: CornerKind,
) -> tuple[DeclaredDesignFactV1, ...]:
    return tuple(fact for fact in facts if FACT_CORNER_IMPLICATIONS.get(fact.kind) is kind)


def _pin_name_components(name: str) -> frozenset[str]:
    """Return identifier components of a pin name.

    A token matches the full name, any underscore-delimited segment, or any
    letter/digit run inside a segment. ``A1`` is not a component of ``FCA1``;
    ``FCA`` is, and ``SE`` is a component of ``SE_IN``.
    """
    folded = name.casefold()
    components = {folded}
    for segment in folded.split("_"):
        if not segment:
            continue
        components.add(segment)
        components.update(_LETTER_OR_DIGIT.findall(segment))
    return frozenset(components)


def _matching_pin_names(
    pins: tuple[PinRecordV1, ...],
    tokens: frozenset[str],
) -> tuple[str, ...]:
    if not tokens:
        return ()
    folded_tokens = tuple(token.casefold() for token in tokens)
    matched: list[str] = []
    for pin in pins:
        components = _pin_name_components(pin.name)
        if any(token in components for token in folded_tokens):
            matched.append(pin.name)
    return tuple(matched)


def _has_paired_dual_port_pins(pins: tuple[PinRecordV1, ...]) -> bool:
    """True when both members of an explicit dual-port pair are present."""
    return any(
        _matching_pin_names(pins, frozenset({left}))
        and _matching_pin_names(pins, frozenset({right}))
        for left, right in _DUAL_PORT_PAIRS
    )


def _proved_single_port(corpus: PreparedCorpusV3) -> bool:
    """True only with an authoritative direction source and no dual-port pair.

    ``absent`` claims structural impossibility, so it may rest only on pins
    whose direction someone actually asserted: a deck model, or ledger ``pin``
    facts, each of which carries a required ``direction``. An ``unknown``
    direction means the pin reached the inventory as a bare name (deck-lifted
    cycle facts do that), and an inventory of bare names could hide the second
    port. Dual-port evidence is a paired match (``CLKA``/``CLKB``,
    ``CENA``/``CENB``, ``CLK1``/``CLK2``, ``A1``/``A2``); an unpaired name is
    not enough.
    """
    if not _has_authoritative_direction_source(corpus):
        return False
    typed = tuple(pin for pin in corpus.pin_inventory if pin.direction != "unknown")
    if not typed:
        return False
    return not _has_paired_dual_port_pins(corpus.pin_inventory)


def _has_authoritative_direction_source(corpus: PreparedCorpusV3) -> bool:
    if corpus.deck_model_digest is not None:
        return True
    return any(pin.direction != "unknown" for pin in corpus.pin_inventory)


def _conflict_reason(pin_names: tuple[str, ...], directives: tuple[str, ...]) -> str:
    quote = "; ".join(directives)
    if pin_names:
        cited = ", ".join(pin_names)
        return _bounded_reason(
            f"pin-name rule matched {cited} but directive states single-port: {quote}"
        )
    return _bounded_reason(
        f"pin-name rule matched no dual-port identifier but directive states single-port: {quote}"
    )


def _bounded_reason(text: str) -> str:
    if len(text) <= _REASON_MAX:
        return text
    return text[: _REASON_MAX - 3] + "..."


__all__ = [
    "CORNER_CONTRADICTION_KEYWORDS",
    "CORNER_DIRECTIVE_KEYWORDS",
    "CORNER_RECOMMENDATION_PRIORITY",
    "FACT_CORNER_IMPLICATIONS",
    "PIN_CANDIDATE_TOKENS",
    "CustomCorner",
    "derive_corner_roster",
    "recommend_corners",
]
