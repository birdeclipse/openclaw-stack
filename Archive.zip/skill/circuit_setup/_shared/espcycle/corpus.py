"""Pure evidence-corpus assembly for cycle planning.

V3 intake (ADR 0043 amendment): the corpus is assembled from the shared Design
Fact Ledger, never from markdown. ``espcycle.cli``'s ``survey`` verb reads the
live ``pin`` / ``operation`` / ``plan_scalar`` facts and hands the already-typed
records below straight to :func:`prepare_corpus`; the ``deck_model`` merge path
is unchanged and still lifts an ``espanalysis`` deck model's own cycle facts.

What V2 carried and V3 does not: ``spec_sources``, ``spec_documents``,
``excerpts``, and ``aggregate_source_bytes``. All four existed only for the
markdown-scrape intake, whose whole job was to guess a pin table and a truth
table out of prose. The ledger states both, so the guess -- and the byte budget
that bounded it -- has no producer left. A V2 ``corpus.json`` therefore fails to
parse here, which is the intended answer: a corpus captured under the old
intake is stale and the caller must re-run ``survey``.
"""

from __future__ import annotations

from typing import Annotated, Literal, Self

from pydantic import Field, model_validator

from espanalysis.models import (
    CyclePlanFactV1,
    HdlPortV1,
    SetupDeckModelV1,
    SourceSpan,
)

from .canonical import content_digest
from .models import (
    DeclaredDesignFactV1,
    _CycleModel,
    declared_design_fact_id,
)

_SHA256_HEX_PATTERN = r"^[0-9a-f]{64}$"
_DECK_PIN_FACT_KINDS = frozenset({"cycle_assignment", "cycle_check", "cycle_style", "check_event"})
DeclaredFactKind = Literal["pipeline_depth", "scan_chain_length", "reset_latency_cycles"]
PinDirection = Literal["input", "output", "inout", "unknown"]


class PinRecordV1(_CycleModel):
    """One pin in the prepared corpus, from HDL ports and/or deck pin names."""

    name: str = Field(min_length=1, max_length=256)
    direction: PinDirection
    width_text: str | None = Field(default=None, max_length=256)


class CycleFactRecordV2(_CycleModel):
    """A lifted cycle-plan fact with its table identity, headers, and source span.

    Contract §4.1 / §11.2: an unlabeled value tuple is insufficient for
    reliable citation. ``table_identity`` names where the values came from --
    ``ledger:<fact_id>`` for a fact the planner logged, ``deck:<occurrence_id>``
    for a deck-lifted one; ``column_headers`` is empty for deck-lifted facts,
    which have no header row of their own.

    ``span`` is optional because a ledger fact has no byte span: nobody read it
    out of a file at an offset. Synthesizing one would be fabricated evidence,
    and the ``fact.evidence`` sentence the planner had to write is the citation
    that replaces it.
    """

    kind: str = Field(min_length=1, max_length=128)
    values: tuple[str, ...]
    table_identity: str = Field(min_length=1, max_length=256)
    column_headers: tuple[str, ...] = Field(default=(), max_length=32)
    span: SourceSpan | None = None


class PreparedCorpusV3(_CycleModel):
    """Bounded, content-identified evidence corpus for cycle-plan planning and review."""

    schema_identity: Literal["esp.cycle-plan-corpus.v3"] = Field(
        default="esp.cycle-plan-corpus.v3",
        serialization_alias="schema",
        validation_alias="schema",
    )
    deck_model_digest: str | None = Field(default=None, pattern=_SHA256_HEX_PATTERN)
    declared_facts: tuple[DeclaredDesignFactV1, ...] = Field(default=(), max_length=16)
    directives: tuple[Annotated[str, Field(min_length=1, max_length=2048)], ...] = Field(
        default=(),
        max_length=32,
    )
    user_prompt: str = Field(default="", max_length=8192)
    pin_inventory: tuple[PinRecordV1, ...] = Field(default=(), max_length=1024)
    cycle_facts: tuple[CycleFactRecordV2, ...] = Field(default=(), max_length=256)

    @model_validator(mode="after")
    def _validate_unique_ids(self) -> Self:
        fact_ids = tuple(fact.fact_id for fact in self.declared_facts)
        if len(fact_ids) != len(frozenset(fact_ids)):
            msg = "declared_facts must have unique fact_id values"
            raise ValueError(msg)
        names = tuple(pin.name for pin in self.pin_inventory)
        if len(names) != len(frozenset(names)):
            msg = "pin_inventory must have unique pin names"
            raise ValueError(msg)
        return self


def mint_declared_fact(
    kind: DeclaredFactKind,
    value: int,
    statement: str,
    *,
    message_id: str | None = None,
    excerpt: SourceSpan | None = None,
) -> DeclaredDesignFactV1:
    """Return a Declared Design Fact with a content-derived ``fact_id``."""
    return DeclaredDesignFactV1(
        fact_id=declared_design_fact_id(
            kind,
            value,
            content_digest(statement.encode("utf-8")),
        ),
        kind=kind,
        value=value,
        statement=statement,
        message_id=message_id,
        excerpt=excerpt,
    )


def prepare_corpus(
    *,
    user_prompt: str = "",
    directives: tuple[str, ...] = (),
    declared_facts: tuple[DeclaredDesignFactV1, ...] = (),
    deck_model: SetupDeckModelV1 | None = None,
    pins: tuple[PinRecordV1, ...] = (),
    cycle_facts: tuple[CycleFactRecordV2, ...] = (),
) -> PreparedCorpusV3:
    """Assemble a prepared corpus from ledger records and an optional deck model.

    ``pins`` / ``cycle_facts`` / ``declared_facts`` are the already-typed
    projection of the live ``pin`` / ``operation`` / ``plan_scalar`` facts;
    deck-lifted facts on ``deck_model.cycle_plan`` are converted internally and
    merged AHEAD of them, so a ``cycle_fact:<n>`` ref keeps its meaning as long
    as the deck model does.
    """
    deck_ports: tuple[HdlPortV1, ...] = ()
    deck_cycle_facts: tuple[CyclePlanFactV1, ...] = ()
    deck_model_digest: str | None = None
    if deck_model is not None:
        deck_model_digest = content_digest(deck_model.to_canonical_bytes())
        if deck_model.hdl_structure is not None:
            deck_ports = deck_model.hdl_structure.ports
        deck_cycle_facts = deck_model.cycle_plan

    merged_cycle_facts = (*(_cycle_fact_from_deck(fact) for fact in deck_cycle_facts), *cycle_facts)
    pin_inventory = _merge_pins(
        hdl_ports=deck_ports,
        pins=pins,
        deck_pins=_pins_from_cycle_facts(merged_cycle_facts),
    )
    return PreparedCorpusV3(
        deck_model_digest=deck_model_digest,
        declared_facts=declared_facts,
        directives=directives,
        user_prompt=user_prompt,
        pin_inventory=pin_inventory,
        cycle_facts=merged_cycle_facts,
    )


def corpus_digest(corpus: PreparedCorpusV3) -> str:
    """Return the SHA-256 hex digest of a prepared corpus's canonical bytes."""
    return content_digest(corpus.to_canonical_bytes())


def _cycle_fact_from_deck(fact: CyclePlanFactV1) -> CycleFactRecordV2:
    return CycleFactRecordV2(
        kind=fact.kind,
        values=fact.values,
        table_identity=f"deck:{fact.command_occurrence_id}",
        column_headers=(),
        span=fact.span,
    )


def _pin_from_hdl(port: HdlPortV1) -> PinRecordV1:
    return PinRecordV1(name=port.name, direction=port.direction, width_text=port.width_text)


def _pins_from_cycle_facts(facts: tuple[CycleFactRecordV2, ...]) -> tuple[PinRecordV1, ...]:
    names: list[str] = []
    seen: set[str] = set()
    for fact in facts:
        if fact.kind not in _DECK_PIN_FACT_KINDS or len(fact.values) < 2:
            continue
        for name in fact.values[:-1]:
            if not name or name.startswith("-") or name in seen:
                continue
            seen.add(name)
            names.append(name)
    return tuple(PinRecordV1(name=name, direction="unknown", width_text=None) for name in names)


def _merge_pins(
    *,
    hdl_ports: tuple[HdlPortV1, ...],
    pins: tuple[PinRecordV1, ...],
    deck_pins: tuple[PinRecordV1, ...],
) -> tuple[PinRecordV1, ...]:
    by_name: dict[str, PinRecordV1] = {}
    for record in (*(_pin_from_hdl(port) for port in hdl_ports), *pins, *deck_pins):
        existing = by_name.get(record.name)
        if existing is None or (existing.direction == "unknown" and record.direction != "unknown"):
            by_name[record.name] = record
    return tuple(by_name[name] for name in sorted(by_name))
