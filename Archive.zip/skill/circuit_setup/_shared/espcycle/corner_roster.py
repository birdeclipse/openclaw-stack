"""``cycle.plan``'s functional-corner roster, held as ``function_corner`` facts
in the shared Design Fact Ledger (ADR 0043).

Replaces the bespoke ``TodoStore`` this module used to carry: a checkbox-markdown
file, reached through a tool named ``todo``, with its own 8-row cap and its own
markdown parser. Three defects came with that shape and all three are gone here.

* **The name.** ``todo`` collided with the host agent's own session task list
  while carrying an incompatible schema, and it invited every model's generic
  task-list prior. ``corner_log`` matches the sibling ledger tools and has no
  prior to fight.
* **The second store.** Every other skill records domain state as facts in this
  same per-run ledger. ``cycle.plan`` read that ledger for pin facts but could
  not write to it, so its own primary entity had nowhere to go.
* **The cap.** An 8-row ceiling enforced at the write seam produced a refusal a
  different argument could not undo. Recording is now unbounded and the *walk*
  takes a resumable prefix instead.

``skip`` is ``FactLedger.retract`` -- the reason is kept on the row, which is a
better audit trail than the old hand-rolled field. ``done`` is not stored at all:
a corner is complete when its documents exist on disk, which survives the
session boundary a continuation crosses.

Port note (MIGRATION.md section 10): the legacy module returned the kernel's
``ConfinedToolResult``; the two callers now live in ``espcycle.cli`` and return
its ``Result`` wire shape instead. The validation rules below -- the safe
``corner_name`` path segment and the ``espdeck.facts`` evidence/field caps --
are carried over verbatim.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Final

from pydantic import BaseModel, ConfigDict, Field

from espdeck.facts import MAX_EVIDENCE_CHARS, MAX_FIELD_CHARS, facts_of_kind
from espdeck.ledger import FactLedger

from .models import CORNER_SLUG_MAX_CHARS, CORNER_SLUG_PATTERN

#: One safe path segment. A ``corner_name`` becomes a directory under
#: ``cycle-plans/`` AND a ``CornerRosterEntryV1.corner`` value, so the rule is
#: ``models.CORNER_SLUG_PATTERN`` compiled -- not a second copy. A name this
#: check admits is therefore always representable as a roster entry.
_SLUG_PATTERN: Final[re.Pattern[str]] = re.compile(CORNER_SLUG_PATTERN)

CORNER_FACT_KIND: Final[str] = "function_corner"

#: The corner roster's own fact origin. A functional corner is something the
#: planner *declares* from the spec, not something parsed out of a netlist.
CORNER_ORIGIN: Final[str] = "declared"


class LogFunctionCornerFactAction(BaseModel):
    """Trusted arguments for the ``corner_log`` tool. Schemas stay static.

    ``tool/corner.ts`` mirrors these bounds BY VALUE in its provider-visible Zod
    schema rather than importing this class -- it is TypeScript and this is
    Python. The mirror is asserted by the golden test rather than enforced by
    the type system.

    ``evidence`` is required, and deliberately so. A functional corner is a
    claim about what the spec demands, so the planner names the line it read.
    The interrogator's review pass can then check the claim instead of taking it
    on trust.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    corner_name: str = Field(min_length=1, max_length=MAX_FIELD_CHARS)
    statement: str = Field(min_length=1, max_length=MAX_FIELD_CHARS)
    evidence: str = Field(min_length=1, max_length=MAX_EVIDENCE_CHARS)


class CornerRetractAction(BaseModel):
    """Trusted arguments for the ``corner_retract`` tool.

    Mirrored BY VALUE in ``tool/corner.ts`` for the same reason as above.
    """

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True)

    corner_name: str = Field(min_length=1, max_length=MAX_FIELD_CHARS)
    reason: str = Field(min_length=1, max_length=MAX_FIELD_CHARS)


def is_safe_slug(slug: str) -> bool:
    """Whether ``slug`` is one safe path segment for a corner directory.

    Also the roster-entry admission test. ``espdeck.facts`` bounds every field
    at ``MAX_FIELD_CHARS`` (1024), which is a transport bound; a corner name is
    additionally a directory and a ``CornerRosterEntryV1.corner`` value, so it
    is narrowed to ``CORNER_SLUG_MAX_CHARS`` here -- at the write seam, before
    the ledger -- rather than failing later as an unrepresentable roster.
    """

    if not slug or len(slug) > CORNER_SLUG_MAX_CHARS or "/" in slug or ".." in slug:
        return False
    return _SLUG_PATTERN.fullmatch(slug) is not None


@dataclass(frozen=True, slots=True)
class Corner:
    """One live ``function_corner`` fact, projected to what the walk needs."""

    fact_id: int
    name: str
    statement: str


def roster(ledger: FactLedger) -> tuple[Corner, ...]:
    """Live corners in ledger order.

    Unbounded on purpose: what a design has is what it has. The SKILL.md
    workflow plans one corner at a time, so a large roster is walked as a
    resumable prefix rather than met with a refusal.
    """

    return tuple(
        Corner(
            fact_id=record.fact_id,
            name=record.fields.get("corner_name", ""),
            statement=record.fields.get("statement", ""),
        )
        for record in facts_of_kind(ledger.snapshot(), CORNER_FACT_KIND)
    )


def corner_names(ledger: FactLedger) -> tuple[str, ...]:
    return tuple(corner.name for corner in roster(ledger))


__all__ = [
    "CORNER_FACT_KIND",
    "CORNER_ORIGIN",
    "Corner",
    "CornerRetractAction",
    "LogFunctionCornerFactAction",
    "corner_names",
    "is_safe_slug",
    "roster",
]
