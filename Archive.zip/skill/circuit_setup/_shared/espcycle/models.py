"""Fact-only schemas for the corner roster, the pin inventory, and declared facts.

What is left after the gate removal (MIGRATION.md section 13.11). The
proposal/review/context/provenance schema graph that hung off this module is
deleted with the layers that read it: ``plan.md`` is prose the planner writes,
so there is no submission for a checker to parse and no carried-context
document for a finalize step to mint. The survivors are the schemas the
SURVEY still needs -- ``CornerKind`` and the roster, the declared design fact,
the corner-slug rule -- plus the strict base and the bounded text alias they
are built from.

``CORNER_SLUG_PATTERN`` in particular stays exactly as it was: the corner
vocabulary is OPEN (every distinct live ``function_corner`` fact adds a
corner), and this is the one rule that says what such a name may be spelled
with. ``corner_roster.is_safe_slug`` compiles this pattern rather than
carrying a second copy.
"""

from __future__ import annotations

from enum import StrEnum
from typing import Annotated, Literal, Self

from pydantic import BaseModel, ConfigDict, Field, model_validator

from espanalysis.models import SourceRef, SourceSpan

from .canonical import canonical_json_bytes, content_digest

_FACT_ID_PATTERN = r"^ddf-[0-9a-f]{8}$"
_FACT_VALUE_MAX = {
    "pipeline_depth": 64,
    "scan_chain_length": 1_000_000,
    "reset_latency_cycles": 4096,
}

#: One Verification Corner's identity outside the built-in rule tables. The
#: eight :class:`CornerKind` values are BUILT-INS; every distinct live
#: ``function_corner`` ledger fact contributes one more, so corner identity in
#: the roster -- and in the ``plan.md`` prose that cites it -- is a validated
#: slug string rather than a closed enum member.
#:
#: This is the ONE corner-slug rule. It lives here, in the schema layer every
#: other module already imports, and ``corner_roster.is_safe_slug`` -- the check
#: the ``corner_log`` write seam applies before a name reaches the ledger --
#: compiles this same pattern rather than carrying a second copy. The charset is
#: what a directory under ``cycle-plans/`` may be spelled with: letters, digits,
#: dot, dash and underscore, starting with a letter or digit, which also makes a
#: separator and a ``..`` traversal unspellable.
CORNER_SLUG_PATTERN = r"^[A-Za-z0-9][A-Za-z0-9._-]*$"
#: Longest corner slug. ``espdeck.facts`` bounds every fact field at 1024, which
#: is a transport bound and not a sane directory name; the write seam narrows to
#: this so a name that reached the ledger is always representable as a roster
#: entry.
CORNER_SLUG_MAX_CHARS = 128

#: Corners one roster may carry: the eight built-ins plus the custom corners a
#: run declared. ``CUSTOM_CORNER_CAP`` is what is left for ``function_corner``
#: facts once the built-ins have their places.
CORNER_ROSTER_CAP = 32
CUSTOM_CORNER_CAP = CORNER_ROSTER_CAP - 8

#: The one surviving bounded-text alias: a roster entry's ``reason``. The
#: ``BoundedPin`` / ``BoundedRef`` / ``BoundedEscalation`` siblings went with
#: the proposal and review schemas that were their only fields.
BoundedText = Annotated[str, Field(min_length=1, max_length=1024)]
#: The corner-identity field type: one built-in ``CornerKind`` value or one
#: custom ``function_corner`` slug. ``CornerKind`` is a ``StrEnum``, so its
#: members satisfy this alias and the rule tables keyed on them keep working.
CornerSlug = Annotated[
    str, Field(min_length=1, max_length=CORNER_SLUG_MAX_CHARS, pattern=CORNER_SLUG_PATTERN)
]


class _CycleModel(BaseModel):
    """Strict immutable base for every public cycle-planning schema."""

    model_config = ConfigDict(extra="forbid", frozen=True, strict=True, populate_by_name=True)

    def to_canonical_bytes(self) -> bytes:
        """Return this document's stable canonical JSON representation."""
        return canonical_json_bytes(self.model_dump(mode="json", by_alias=True))


class CornerKind(StrEnum):
    """The BUILT-IN Verification Corner vocabulary from the a2a corner set.

    Not the whole vocabulary any more: these eight are the corners the
    deterministic rule tables in ``survey.py`` know how to classify from pin
    names, directives and declared facts, and they appear on every roster. A run
    adds its own corners by logging ``function_corner`` facts, which classify
    from the fact itself. Corner identity outside those rule tables is
    :data:`CornerSlug`; because this is a ``StrEnum``, a membership test against
    a table keyed on these members still answers correctly for a plain ``str``.
    """

    MISSION_MODE_READ_WRITE = "mission-mode-read-write"
    LOW_POWER_SEQUENCE = "low-power-sequence"
    SCAN_DFT = "scan-dft"
    CALIBRATION = "calibration"
    MULTI_PORT_CONTENTION = "multi-port-contention"
    CLOCK_GATING = "clock-gating"
    IDLE = "idle"
    REDUNDANCY = "redundancy"


#: The built-in corner slugs in roster order: value-sorted, and the prefix every
#: roster's ``entries`` starts with. Built once because the roster validator, the
#: D1 checker and the survey all need exactly this tuple.
BUILTIN_CORNERS: tuple[str, ...] = tuple(
    kind.value for kind in sorted(CornerKind, key=lambda kind: kind.value)
)


def declared_design_fact_id(kind: str, value: int, statement_digest: str) -> str:
    """Return the content-derived identifier for one declared design fact."""
    digest = content_digest(
        canonical_json_bytes(
            {
                "kind": kind,
                "statement_digest": statement_digest,
                "value": value,
            }
        )
    )
    return f"ddf-{digest[:8]}"


class DeclaredDesignFactV1(_CycleModel):
    """A Design Fact whose only support is an explicit user assertion."""

    fact_id: str = Field(pattern=_FACT_ID_PATTERN)
    kind: Literal["pipeline_depth", "scan_chain_length", "reset_latency_cycles"]
    value: int = Field(ge=0, le=1_000_000)
    statement: str = Field(min_length=1, max_length=2048)
    provenance: Literal["user_statement"] = "user_statement"
    excerpt: SourceSpan | None = None
    message_id: str | None = Field(default=None, min_length=1, max_length=128)

    @model_validator(mode="after")
    def _validate_fact(self) -> Self:
        cap = _FACT_VALUE_MAX[self.kind]
        if self.value > cap:
            msg = f"{self.kind} value must be <= {cap}"
            raise ValueError(msg)
        expected = declared_design_fact_id(
            self.kind,
            self.value,
            content_digest(self.statement.encode("utf-8")),
        )
        if self.fact_id != expected:
            msg = "fact_id must match declared_design_fact_id"
            raise ValueError(msg)
        return self


class DesignSpecExcerptV1(_CycleModel):
    """A content-identified Markdown or plain-text span under the work root."""

    source: SourceRef
    span: SourceSpan
    text: str = Field(min_length=1, max_length=4096)


class CornerRosterEntryV1(_CycleModel):
    """One Verification Corner's classification on a design's evidence.

    C2's survey emits `unresolved` for want of facts; `unknown` in older plan text is this value.
    """

    corner: CornerSlug
    classification: Literal[
        "directive_named",
        "fact_supported",
        "candidate",
        "conflicting",
        "absent",
        "unresolved",
    ]
    reason: BoundedText


class CornerRosterV1(_CycleModel):
    """Complete corner roster: the eight built-ins, then this run's own corners.

    ``entries`` is the built-in prefix -- every :class:`CornerKind` value exactly
    once, sorted by value -- followed by zero or more custom slugs, sorted and
    unique and disjoint from the built-ins. The prefix is fixed so a reader can
    always find a built-in corner at the same place and a roster from a run with
    no ``function_corner`` facts is byte-identical to the closed-vocabulary one.
    """

    schema_identity: Literal["esp.corner-roster.v1"] = Field(
        default="esp.corner-roster.v1",
        serialization_alias="schema",
        validation_alias="schema",
    )
    entries: tuple[CornerRosterEntryV1, ...] = Field(min_length=1, max_length=CORNER_ROSTER_CAP)
    recommended: tuple[CornerSlug, ...] = Field(max_length=CORNER_ROSTER_CAP)

    @model_validator(mode="after")
    def _validate_complete_roster(self) -> Self:
        observed = tuple(entry.corner for entry in self.entries)
        builtins = observed[: len(BUILTIN_CORNERS)]
        if builtins != BUILTIN_CORNERS:
            msg = "entries must begin with every CornerKind exactly once, ordered by value"
            raise ValueError(msg)
        custom = observed[len(BUILTIN_CORNERS) :]
        if custom != tuple(sorted(custom)):
            msg = "custom corner entries must follow the built-ins, sorted by name"
            raise ValueError(msg)
        if len(frozenset(custom)) != len(custom):
            msg = "custom corner entries must be unique"
            raise ValueError(msg)
        if frozenset(custom) & frozenset(BUILTIN_CORNERS):
            msg = "a custom corner entry must not repeat a CornerKind value"
            raise ValueError(msg)
        if len(self.recommended) != len(frozenset(self.recommended)):
            msg = "recommended must be unique"
            raise ValueError(msg)
        present = frozenset(observed)
        if any(corner not in present for corner in self.recommended):
            msg = "recommended must name corners the roster classifies"
            raise ValueError(msg)
        non_absent = frozenset(
            entry.corner for entry in self.entries if entry.classification != "absent"
        )
        if any(corner not in non_absent for corner in self.recommended):
            msg = "recommended must be a subset of non-absent corners"
            raise ValueError(msg)
        return self
