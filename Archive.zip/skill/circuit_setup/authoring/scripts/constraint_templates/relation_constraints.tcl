# ---------------------------------------------------------------------------
# Reference template: set_constraint RELATION form
#
# REFERENCE ONLY. Copy the pattern, never the pin names.
#
# A RELATION is a pattern over a LIST of pins (or over a bus's bits) with no
# single value:
#
#     set_constraint {<pin_a> <pin_b> ...} -<intent> [-cycle {...}] [-if {...}]
#
# The seven intents. "hot" counts the 1s and "cold" counts the 0s; a leading
# "0" means the all-none case is allowed as well:
#
#     -1hot             exactly one bit (or one listed pin) is 1
#     -1cold            exactly one is 0
#     -01hot            at most one is 1   (all-zero also allowed)
#     -01cold           at most one is 0   (all-ones also allowed)
#     -equal            every listed pin takes the value of the first
#     -opposite         exactly two pins; the second inverts the first
#     -symbolic_static  the pins hold the same symbolic value for the entire
#                       simulation
# ---------------------------------------------------------------------------

# "make wmask one-hot"
#   reason: a pattern over wmask's bits, no single value: one-hot bus.
set_constraint wmask -1hot

# "exactly one of the four bank selects must be deasserted"
#   reason: counts the 0s: 1cold over the listed pins.
set_constraint {bank0_n bank1_n bank2_n bank3_n} -1cold

# "at most one of we or re may be high"
#   reason: counts the 1s, none allowed: 01hot.
set_constraint {we re} -01hot

# "at most one of the enables may be low"
#   reason: counts the 0s, all-ones allowed: 01cold.
set_constraint {en_a en_b en_c} -01cold

# "keep the two trim inputs at the same value"
#   reason: the pair is driven together: equality over the list.
set_constraint {trim0 trim1} -equal

# "an is the inverse of a"
#   reason: pair relation, second inverts first. Exactly two pins.
set_constraint {a an} -opposite

# "the trim bits are config straps — one value for the whole run"
#   reason: same symbolic value for the entire simulation.
#   NOTE: -symbolic_static takes NO -if and NO -cycle. A value that never
#         changes contradicts both. A request that asks for one anyway is a
#         gap in the report, never a silent drop of the option.
set_constraint {trim0 trim1 trim2} -symbolic_static

# A relation may be scoped and conditioned like an EDIT (except
# -symbolic_static).
#   "in symcycle 2 only, at most one of we or re may be high"
set_constraint {we re} -01hot -cycle {SYMCYCLE2}
#   "while the part is enabled, sel must be one-hot"
set_constraint sel -1hot -if {ce}

# A relation is genuinely plural only when the wish is: one edit plus one
# relation stays two commands.
#   "tie ce high and make wmask one-hot"
set_constraint {ce} -set {1'b1}
set_constraint wmask -1hot
