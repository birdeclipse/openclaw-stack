# ---------------------------------------------------------------------------
# Reference template: set_constraint EDIT form
#
# REFERENCE ONLY. Copy the pattern, never the pin names — every name below is
# a placeholder from a worked example, not a pin in your design.
#
# An EDIT is one pin driven to one value, optionally under a condition:
#
#     set_constraint {<pin>} [-cycle {<CYCLENAME>}] -set {<value>} [-if {<cond>}]
#
# Values and conditions are VERILOG expressions, never Tcl. A `$name`
# substitution or a `[command]` bracket inside {} is always a mistake.
# Widths are exact: prefer sized literals over bare integers.
# `-cycle` precedes `-set` and appears only when the request names a cycle.
# ---------------------------------------------------------------------------

# "tie ce high"
#   reason: ce = 1'b1;
set_constraint {ce} -set {1'b1}

# "when we is high, force din to zero"
#   reason: if (we) din = 32'h00000000;
set_constraint {din} -set {32'h00000000} -if {we}

# "while the part is in reset, force ce low"          (rstb is active-low)
#   reason: if (!rstb) ce = 1'b0;
set_constraint {ce} -set {1'b0} -if {!rstb}

# "during an active write — chip enabled, not in reset, we asserted — drive
#  wmask to all ones"
#   reason: if (ce && rstb && we) wmask = 4'hF;
set_constraint {wmask} -set {4'hF} -if {ce && rstb && we}

# "hold din at zero except during enabled writes"
#   reason: if (!(ce && we)) din = 32'h00000000;
set_constraint {din} -set {32'h00000000} -if {!(ce && we)}

# "when ce is high and either we or reset is low, hold addr at zero"
#   reason: if (ce && (!we || !rstb)) addr = 6'h00;
set_constraint {addr} -set {6'h00} -if {ce && (!we || !rstb)}

# "when the low three address bits are all set, drive the mask to all ones"
#   reason: if (addr[2:0] == 3'b111) wmask = 4'hF;
#   note:   a slice in a CONDITION is just an expression; no -cycle needed.
set_constraint {wmask} -set {4'hF} -if {addr[2:0] == 3'b111}

# "for each mask bit, zero the matching byte of din when that bit is low"
#   reason: four lane edits, one per mask bit.
#   note:   each command constrains EXACTLY the bits the wish names.
#           Constraining all of din here would be over-constraint by accident.
set_constraint {din[7:0]}   -set {8'h00} -if {!wmask[0]}
set_constraint {din[15:8]}  -set {8'h00} -if {!wmask[1]}
set_constraint {din[23:16]} -set {8'h00} -if {!wmask[2]}
set_constraint {din[31:24]} -set {8'h00} -if {!wmask[3]}

# "drive din to zero on writes and all ones otherwise"
#   reason: din = we ? 32'h00000000 : 32'hFFFFFFFF;
#   note:   one expression covers both modes — no -if, and no second command.
set_constraint {din} -set {we ? 32'h00000000 : 32'hFFFFFFFF}

# "in symcycle 1 only, hold addr at the top of the array"
#   reason: addr = 6'h3F, scoped to SYMCYCLE1 because the REQUEST names it.
set_constraint {addr} -cycle {SYMCYCLE1} -set {6'h3F}

# Lookback and symbolic references are legal in -if ONLY. They are never the
# constrained target and never driven by -set.
#   "hold ce low whenever it was high last cycle"
set_constraint {ce} -set {1'b0} -if {innopv_ce}
#   "in flush cycles, hold we low"
set_constraint {we} -set {1'b0} -if {inno_cycle_mode == "FLUSHCYCLE"}

# Do NOT emit a trivially-true condition; omit -if instead.
#   WRONG: set_constraint {ce} -set {1'b1} -if {1'b1}
