# ---------------------------------------------------------------------------
# Reference template: wiring a declaration file from the constraints Tcl
#
# REFERENCE ONLY.
#
# Reach for a declaration file only when the wish cannot be expressed as
# set_constraint: it relates cycles to each other, needs helper state or
# custom stimulus, is a decode table / priority chain, or the request
# explicitly asked for a declaration file. Read documents/guide.md (Part 2)
# before writing one.
# ---------------------------------------------------------------------------

# The value is a UNIX filename. House convention: ./testbench_declarations.sv
# in the deck directory. Emit this line ONCE; if the deck already wires a
# declaration file, append your rule to that file instead and leave this line
# alone.
set_app_var testbench_declaration_file ./testbench_declarations.sv

# The .sv file is Verilog at module scope — new reg/wire, always blocks, tasks
# and functions, and SVA `assume property`. Sketch of the two shapes (the full
# rules and worked examples live in documents/guide.md):
#
#   // RULE: no-write-write-contention
#   no_write_write_contention: assume property (@(posedge CLK)
#     !(innont_we_a && innont_we_b && (innont_wa_a == innont_wa_b)));
#
#   // RULE: mode-decode
#   `define REMOVE_DEFAULT_apply_global_constraints
#   task apply_global_constraints;
#     begin
#       case (mode)
#         2'b00: WE == 1'b0;
#         default: begin WE == 1'b0; RE == 1'b0; end
#       endcase
#     end
#   endtask
#
# Reminders that bite:
#   - always LABEL an assume (snake_case) — an unnamed assume is untraceable;
#   - |-> is the only supported operator: no $past, $stable, |=>, ##N;
#   - write SVA over the innont_<pin> drive buffers, and on INPUTS only;
#   - inside apply_global_constraints a bare comparison IS the constraint
#     (`WE == 1'b0;`) — do not "fix" it into an assignment;
#   - the task replacement is TOTAL: copy the generated content first.
