# ---------------------------------------------------------------------------
# Reference template: testbench cycle counts
#
# REFERENCE ONLY. The numbers below are placeholders.
#
# Cycle counts are APP VARS, not constraints. Emit one only when the request
# or the design sources justify the number. Never copy a count from another
# design — a borrowed cycle count silently changes what the run explores.
# ---------------------------------------------------------------------------

# "give the run three symbolic cycles"
set_app_var testbench_symbolic_cycles 3

# Flush cycles run before the checked window; binary cycles drive concrete
# stimulus. Emit each only when a number was actually asked for or derived.
set_app_var testbench_flush_cycles  1
set_app_var testbench_binary_cycles 2

# The cycle names that constraints may reference follow from these counts:
#   FLUSHCYCLE<N>, BINCYCLE<N>, SYMCYCLE<N>   (N is 1-based)
# They appear only in -cycle options and in inno_cycle comparisons — never as
# a constrained target.
#
#   set_constraint {addr} -cycle {SYMCYCLE1} -set {6'h3F}
#   set_constraint {we}   -set {1'b0} -if {inno_cycle_mode == "FLUSHCYCLE"}
#
# If the request is about masking an OUTPUT check during flush cycles, that is
# not an input constraint and not a cycle count: record it as a gap
# ("output-check masking is not a constraint-authoring target") plus the open
# question of where it should be routed.
